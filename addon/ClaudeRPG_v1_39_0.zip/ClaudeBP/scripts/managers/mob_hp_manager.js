// mob_hp_manager.js -- virtual HP pool for Ascension-scaled mobs.
//
// Vanilla mobs cannot be given more max HP by script, so each scaled mob keeps a
// pool on itself (entity dynamic properties, cleaned up automatically when it dies):
//   crpg:vmax  virtual max HP  (vanilla max HP x multiplier at first hit)
//   crpg:vhp   virtual current HP
// The pool decides when the mob dies; the real health bar is kept in proportion.
// Pure state helpers -- the damage commands live in damage_manager.js.

import { system } from "@minecraft/server";
import { MOB_SCALING } from "../config/progression_config.js";
import { XP_CONFIG } from "../config/xp_config.js";
import { isBoss } from "../config/mob_config.js";
import { ProgressionManager } from "./progression_manager.js";
import { EvolutionManager } from "./evolution_manager.js";

const VMAX = "crpg:vmax";
const VHP  = "crpg:vhp";
const _burst = new Map();   // Core entity id -> { tick, used } (runtime only)

export class MobHpManager {

    static isScalable(entity) {
        const id = entity?.typeId;
        if (!id || id === "minecraft:player") return false;
        if (MOB_SCALING.EXCLUDE.includes(id)) return false;
        return isBoss(id) || XP_CONFIG[id]?.type === "mob";
    }

    // Combined damage multiplier of a hostile attacker: Ascension x Evolution (x Boss), capped.
    static getAttackMult(entity) {
        let m = ProgressionManager.getMobDamageMult() * EvolutionManager.getDamageMult(entity);
        if (isBoss(entity?.typeId)) m *= ProgressionManager.getBossDamageMult();
        return Math.min(MOB_SCALING.TOTAL_DAMAGE_CAP, m);
    }

    // Player -> hostile mob damage multiplier (Ascension offset). 1 at Ascension 0.
    static getPlayerAttackMult(victim) {
        return this.isScalable(victim) ? ProgressionManager.getPlayerDamageMult() : 1;
    }

    static getMultiplier(entity) {
        if (isBoss(entity.typeId)) return ProgressionManager.getBossHpMult();
        return ProgressionManager.getMobHpMult() * EvolutionManager.getHpMult(entity);
    }

    // Returns { vhp, vmax, realMax, real } or null when this mob is not scaled right now.
    static readPool(entity) {
        try {
            if (!entity?.isValid || !this.isScalable(entity)) return null;
            const health = entity.getComponent("minecraft:health");
            if (!health) return null;
            const realMax = health.effectiveMax;
            const real = health.currentValue;

            let vmax = entity.getDynamicProperty(VMAX);
            let vhp  = entity.getDynamicProperty(VHP);
            if (typeof vmax !== "number" || typeof vhp !== "number") {
                const mult = this.getMultiplier(entity);
                if (mult <= 1) return null;                 // Ascension 0: vanilla behaviour
                vmax = Math.max(1, Math.round(realMax * mult));
                vhp  = Math.max(1, Math.round(vmax * (real / realMax)));
                entity.setDynamicProperty(VMAX, vmax);
                entity.setDynamicProperty(VHP, vhp);
            }
            return { vhp, vmax, realMax, real };
        } catch (_) { return null; }
    }

    // Read-only twin of readPool(): same numbers, but never creates or changes the stored pool.
    // Used by the HP name tag so just looking at a mob does not freeze its Ascension multiplier.
    static peekPool(entity) {
        try {
            if (!entity?.isValid || !this.isScalable(entity)) return null;
            const health = entity.getComponent("minecraft:health");
            if (!health) return null;
            const vmax = entity.getDynamicProperty(VMAX);
            const vhp  = entity.getDynamicProperty(VHP);
            if (typeof vmax === "number" && typeof vhp === "number") return { vhp, vmax };
            const mult = this.getMultiplier(entity);
            if (mult <= 1) return null;
            const realMax = health.effectiveMax;
            const predictedMax = Math.max(1, Math.round(realMax * mult));
            return { vhp: Math.max(1, Math.round(predictedMax * (health.currentValue / realMax))), vmax: predictedMax };
        } catch (_) { return null; }
    }

    // Core evolution: one hit may never remove more than a fraction of the max pool, and every
    // source of damage landing inside the same short burst window (default 5 ticks) shares that
    // one allowance. Without the shared window, a main hit + chain + rune bonus + Chorus blast in
    // the same tick each took their own 10% and together killed the Core "in one hit".
    static capHit(entity, amount, vmax) {
        try {
            const t = EvolutionManager.getTier(entity);
            if (t?.id === "core" && vmax > 0) return this._burstCap(entity, amount, Math.max(1, Math.floor(vmax * t.hitCapFraction)), t.burstTicks ?? 5);
        } catch (_) {}
        return amount;
    }

    // Same rule for a Core that has no virtual pool (real health only).
    static capHitReal(entity, amount) {
        try {
            const t = EvolutionManager.getTier(entity);
            if (t?.id !== "core") return amount;
            const health = entity.getComponent("minecraft:health");
            if (!health) return amount;
            return this._burstCap(entity, amount, Math.max(1, Math.floor(health.effectiveMax * t.hitCapFraction)), t.burstTicks ?? 5);
        } catch (_) { return amount; }
    }

    static _burstCap(entity, amount, cap, windowTicks) {
        const now = system.currentTick;
        let rec = _burst.get(entity.id);
        if (!rec || now - rec.tick >= windowTicks) {
            if (_burst.size > 256) for (const [k, v] of _burst) if (now - v.tick >= windowTicks) _burst.delete(k);
            rec = { tick: now, used: 0 };
            _burst.set(entity.id, rec);
        }
        const allowed = Math.max(0, Math.min(amount, cap - rec.used));
        rec.used += allowed;
        return allowed;
    }

    static setVhp(entity, value) {
        try { entity.setDynamicProperty(VHP, Math.max(0, value)); } catch (_) {}
    }
}
