// progression_manager.js -- owner of Prestige / Ascension state, Max Level and feature gates.
// Phase 1: Max Level + feature gates. Prestige (Phase 2) and Ascension (Phase 3) will
// write the values this file already reads.
//
// Kept dependency-light (config + world only) so any system can import it safely.

import { world, system } from "@minecraft/server";
import { PROGRESSION, PROG_KEYS, PRESTIGE, PRESTIGE_KEYS, ASCENSION } from "../config/progression_config.js";
import { isBoss } from "../config/mob_config.js";
import { AchievementManager } from "../systems/achievement_manager.js";

function num(v, fallback = 0) {
    return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

const ascCache = { tick: -1, value: 0 };

export class ProgressionManager {

    // ─── State ───────────────────────────────────────────────────────────────

    static getPrestige(player) {
        return Math.max(0, Math.floor(num(player?.getDynamicProperty(PROG_KEYS.PRESTIGE))));
    }

    // Read on every hit and mob scan, so it is cached for the current tick (set by Ascension / Admin).
    static getAscension() {
        const tick = system.currentTick;
        if (ascCache.tick !== tick) {
            ascCache.tick = tick;
            ascCache.value = Math.max(0, Math.floor(num(world.getDynamicProperty(PROG_KEYS.ASCENSION))));
        }
        return ascCache.value;
    }
    static invalidateAscension() { ascCache.tick = -1; }

    static getMaxLevel(player) {
        return PROGRESSION.BASE_MAX_LEVEL + PROGRESSION.MAX_LEVEL_PER_PRESTIGE * this.getPrestige(player);
    }

    static getLevel(player) {
        return Math.max(0, Math.floor(num(player?.getDynamicProperty("stat_level"))));
    }

    static isMaxLevel(player) {
        return this.getLevel(player) >= this.getMaxLevel(player);
    }

    // ─── Permanent level unlocks ─────────────────────────────────────────────

    static _readUnlocks(player) {
        const raw = player?.getDynamicProperty(PROG_KEYS.UNLOCKS);
        return typeof raw === "string" && raw.length ? new Set(raw.split(",")) : new Set();
    }

    static hasLevelUnlock(player, feature) {
        return this._readUnlocks(player).has(feature);
    }

    // Records every level gate the player has reached. Call after any level change and
    // BEFORE anything that resets Level (Prestige), so unlocks stay permanent.
    static syncUnlocks(player) {
        if (!player) return;
        const level = this.getLevel(player);
        const unlocks = this._readUnlocks(player);
        let changed = false;
        for (const [id, def] of Object.entries(PROGRESSION.FEATURES)) {
            if ((def.level ?? 0) > 0 && level >= def.level && !unlocks.has(id)) {
                unlocks.add(id);
                changed = true;
            }
        }
        if (changed) player.setDynamicProperty(PROG_KEYS.UNLOCKS, [...unlocks].join(","));
    }

    static setLevelUnlock(player, feature, on) {
        const unlocks = this._readUnlocks(player);
        if (on) unlocks.add(feature); else unlocks.delete(feature);
        player.setDynamicProperty(PROG_KEYS.UNLOCKS, [...unlocks].join(","));
    }

    // ─── Gates ───────────────────────────────────────────────────────────────

    // Returns { ok, missing: string[] } for a feature id.
    static check(player, feature) {
        const def = PROGRESSION.FEATURES[feature];
        if (!def) return { ok: true, missing: [] };
        this.syncUnlocks(player);

        const missing = [];
        if ((def.level ?? 0) > 0 && !this.hasLevelUnlock(player, feature)) missing.push(`Lv.${def.level}`);
        if ((def.prestige ?? 0) > this.getPrestige(player)) missing.push(`Prestige ${def.prestige}`);
        if ((def.ascension ?? 0) > this.getAscension()) missing.push(`Ascension ${def.ascension}`);
        return { ok: missing.length === 0, missing };
    }

    static canUse(player, feature) {
        return this.check(player, feature).ok;
    }

    // Short label for menus, e.g. "Lv.80 · Prestige 2 · Ascension 2"
    static requirementText(feature) {
        const def = PROGRESSION.FEATURES[feature];
        if (!def) return "";
        const parts = [];
        if ((def.level ?? 0) > 0) parts.push(`Lv.${def.level}`);
        if ((def.prestige ?? 0) > 0) parts.push(`Prestige ${def.prestige}`);
        if ((def.ascension ?? 0) > 0) parts.push(`Ascension ${def.ascension}`);
        return parts.join(" · ");
    }

    // Level part of a gate only (permanent once reached). Used for lore / menu wording.
    static levelReached(player, feature) {
        const def = PROGRESSION.FEATURES[feature];
        if (!def || (def.level ?? 0) <= 0) return true;
        this.syncUnlocks(player);
        return this.hasLevelUnlock(player, feature);
    }

    // Returns true if allowed; otherwise tells the player what is missing and returns false.
    static guard(player, feature) {
        const { ok, missing } = this.check(player, feature);
        if (ok) return true;
        const name = PROGRESSION.FEATURES[feature]?.name ?? feature;
        player.sendMessage(`§c[${name}] Locked. Still needed: §f${missing.join(" · ")}`);
        return false;
    }

    // ─── Diminishing returns / Limit Break (Prestige) ───────────────────────

    // Strength (0..1) of the Nth Prestige.
    static prestigeFactor(n) {
        if (n <= PRESTIGE.FULL_UNTIL) return 1;
        return Math.max(PRESTIGE.MIN_FACTOR, Math.pow(PRESTIGE.DECAY, n - PRESTIGE.FULL_UNTIL));
    }

    static limitBreakUnits(prestige) {
        let units = 0;
        for (let i = 1; i <= prestige; i++) units += this.prestigeFactor(i);
        return units;
    }

    // Multiplier applied to every stat cap.
    static getStatCapMultiplier(player) {
        return 1 + PRESTIGE.LIMIT_BREAK_STEP * this.limitBreakUnits(this.getPrestige(player));
    }

    // ─── Perks ──────────────────────────────────────────────────────────────

    static getPendingPerks(player) {
        return Math.max(0, Math.floor(num(player?.getDynamicProperty(PRESTIGE_KEYS.PENDING))));
    }

    static _readPerkPicks(player) {
        const raw = player?.getDynamicProperty(PRESTIGE_KEYS.PERKS);
        if (typeof raw !== "string" || !raw.length) return [];
        return raw.split(",").map((t) => {
            const [id, p] = t.split("@");
            return { id, prestige: Math.max(1, Math.floor(Number(p) || 1)) };
        }).filter((t) => PRESTIGE.PERKS[t.id]);
    }

    static _roundPerk(v) { return Math.round(v * 100) / 100; }

    // Total power of one perk (sum over every pick, each fixed at its pick-time strength).
    static getPerkValue(player, perkId) {
        const def = PRESTIGE.PERKS[perkId];
        if (!def) return 0;
        let total = 0;
        for (const pick of this._readPerkPicks(player)) {
            if (pick.id === perkId) total += def.base * this.prestigeFactor(pick.prestige);
        }
        return this._roundPerk(total);
    }

    static getPerkCount(player, perkId) {
        return this._readPerkPicks(player).filter((p) => p.id === perkId).length;
    }

    // Power the NEXT pick of a perk would give at the player's current Prestige.
    static getNextPerkValue(player, perkId) {
        const def = PRESTIGE.PERKS[perkId];
        return def ? this._roundPerk(def.base * this.prestigeFactor(this.getPrestige(player))) : 0;
    }

    static getAvailablePerks(player) {
        const p = this.getPrestige(player);
        return Object.entries(PRESTIGE.PERKS).filter(([, d]) => d.minPrestige <= p).map(([id]) => id);
    }

    static addPerkPick(player, perkId) {
        if (!PRESTIGE.PERKS[perkId] || this.getPendingPerks(player) <= 0) return false;
        if (!this.getAvailablePerks(player).includes(perkId)) return false;
        const raw = player.getDynamicProperty(PRESTIGE_KEYS.PERKS);
        const entry = `${perkId}@${this.getPrestige(player)}`;
        player.setDynamicProperty(PRESTIGE_KEYS.PERKS, typeof raw === "string" && raw.length ? `${raw},${entry}` : entry);
        player.setDynamicProperty(PRESTIGE_KEYS.PENDING, this.getPendingPerks(player) - 1);
        AchievementManager.event(player, "perks_picked");
        return true;
    }

    static describePerk(perkId, value) {
        const def = PRESTIGE.PERKS[perkId];
        return def ? def.desc.replace("{v}", String(value)) : "";
    }

    // Extra loot roll (Plunderer). Called for player kills.
    static rollBonusDrop(killer, victim) {
        try {
            const chance = this.getPerkValue(killer, "drop_rate");
            if (chance <= 0 || Math.random() * 100 >= chance) return false;
            const id = victim?.typeId;
            if (!id || !id.startsWith("minecraft:") || id === "minecraft:player" || isBoss(id)) return false;
            const { x, y, z } = victim.location;
            victim.dimension.runCommand(`loot spawn ${x.toFixed(2)} ${y.toFixed(2)} ${z.toFixed(2)} loot "entities/${id.slice(10)}"`);
            return true;
        } catch (_) { return false; }
    }

    // ─── Ascension scaling (values used by Phase 5 mob systems) ─────────────

    static _asc(def, asc) { return Math.min(def.CAP, 1 + asc * def.PER_ASC); }
    static getMobHpMult(asc = this.getAscension())     { return this._asc(ASCENSION.MOB_HP, asc); }
    static getMobDamageMult(asc = this.getAscension()) {
        const d = ASCENSION.MOB_DAMAGE;
        const soft = d.SOFT_AFTER ?? Infinity;
        const steps = Math.min(asc, soft) + Math.max(0, asc - soft) * (d.SOFT_FACTOR ?? 1);
        return Math.min(d.CAP, 1 + steps * d.PER_ASC);
    }
    // Percent XP bonuses from the world state (added to the other XP % bonuses).
    static getPrestigeXpBonus(player) {
        return Math.min(PRESTIGE.XP_BONUS_CAP, PRESTIGE.XP_BONUS_PER * this.getPrestige(player));
    }
    static getAscensionXpBonus(asc = this.getAscension()) {
        return Math.min(ASCENSION.XP_BONUS.CAP, ASCENSION.XP_BONUS.PER_ASC * asc);
    }
    static getBossDamageMult(asc = this.getAscension())   { return this._asc(ASCENSION.BOSS_DAMAGE, asc); }
    static getPlayerDamageMult(asc = this.getAscension()) { return this._asc(ASCENSION.PLAYER_DAMAGE, asc); }
    static getBossHpMult(asc = this.getAscension())    { return this._asc(ASCENSION.BOSS_HP, asc); }

    // Prestige needed to press the Ascension that follows `currentAsc`.
    static getRequiredPrestigeForNext(currentAsc = this.getAscension()) {
        const next = currentAsc + 1;
        return ASCENSION.REQUIRED_PRESTIGE[next] ?? ASCENSION.REQUIRED_PRESTIGE.DEFAULT;
    }
}
