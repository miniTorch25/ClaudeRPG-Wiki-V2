// DamageManager — central damage pipeline.
//
// Pipeline (in order):
//   1. Base damage          — vanilla hit value
//   2. Flat bonus           — Augment attackDamage + Rune permanent bonuses (Bloodshed, Overcharge)
//   3. % Multiplier         — Rune triggers (Opening Strike, Ruination, Deadeye…)
//                             All multipliers are ADDITIVE: +50% + +60% = ×1.10, NOT ×1.5×1.6
//   4. applyFinalDamage()   — issues the /damage command (bypasses invulnerability window)
//
// Calling applyFinalDamage() also prevents the Augment suppressRedirect re-entry guard
// from firing again on the damage command we just issued.

import { system } from "@minecraft/server";
import { HPManager } from "./hp_manager.js";
import { DamageContext } from "../core/damage_context.js";
import { CONFIG } from "../config/config.js";
import * as RuneCN from "../rune/rune_curseneutral.js";
import { MobHpManager } from "./mob_hp_manager.js";
import { MOB_SCALING } from "../config/progression_config.js";

// Re-use the same suppress set that augment.js uses so both systems share one guard.
// Imported lazily to avoid circular dependency at module load time.
let _getSuppressSet = null;
export function registerSuppressGetter(fn) { _getSuppressSet = fn; }

// Convert @minecraft/server EntityDamageCause names (camelCase) to the
// snake_case identifiers accepted by Bedrock's /damage command.
// The Script API can report values such as "entityAttack" / "fireTick",
// while /damage expects "entity_attack" / "fire_tick".
const DAMAGE_CAUSE_ALIASES = Object.freeze({
    entityAttack: "entity_attack",
    entityExplosion: "entity_explosion",
    blockExplosion: "block_explosion",
    fireTick: "fire_tick",
    inFire: "in_fire",
    flyIntoWall: "fly_into_wall",
    ramAttack: "ram_attack",
    sonicBoom: "sonic_boom",
    soulCampfire: "soul_campfire",
    fallingBlock: "falling_block",
    magic: "magic",
    // Bug fix: Mace's fall-smash attack reports cause "maceSmash", which was
    // passed straight through unconverted into the /damage command and caused
    // a syntax error there (see DamageManager.applyFinalDamage) — meaning the
    // whole hit silently failed and Mace fall-smash damage was effectively 0.
    maceSmash: "mace_smash",
});

export function normalizeDamageCause(cause) {
    if (!cause) return "entity_attack";
    const raw = String(cause);
    return DAMAGE_CAUSE_ALIASES[raw] ?? raw;
}

// True if this entity's current hit is a reissued /damage command (from Augment's
// on-hit redirect OR from fireSuppressedDamage below) that should NOT be treated
// as a brand-new attack by any other system (Runes included).
export function isSuppressed(id) {
    return _getSuppressSet?.()?.has(id) ?? false;
}

// Generic guard for any script-issued command that will itself trigger a new
// entityHurt event on `id` (e.g. DeathManager's "kill @s"). Runs `fn` with `id`
// marked suppressed for its duration so CombatPipeline treats that resulting
// event as already-handled instead of reprocessing it as a fresh attack.
export function withSuppressed(id, fn) {
    const suppressSet = _getSuppressSet?.();
    suppressSet?.add(id);
    try {
        return fn();
    } finally {
        suppressSet?.delete(id);
    }
}

// Shared helper for any rune bonus-damage "reissue": adds the victim to the shared
// suppress set for the duration of the reissued /damage command, so:
//   - RuneManager's entityHurt.before/.after subscribers skip this synthetic hit
//     (see the isSuppressed() guard added there), preventing the same rune (or any
//     other on-hit rune/augment effect) from re-triggering off its own bonus damage.
// Use this instead of calling victim.runCommand("damage ...") directly.
//
// Ascension mob HP: damage to a scaled mob goes to its virtual pool instead.
// Returns true when the pool handled the hit (caller must not issue its own /damage).
function applyToMobPool(victim, attackerName, amount, cause, out = null) {
    if (MOB_SCALING.HP_MODE !== "pool") return false;
    const pool = MobHpManager.readPool(victim);
    if (!pool) return false;

    amount = MobHpManager.capHit(victim, amount, pool.vmax);   // Core: no one-shots
    if (out) out.applied = amount;                              // what was really taken off the pool
    const vhp = pool.vhp - amount;
    const lethal = vhp <= 0;
    MobHpManager.setVhp(victim, vhp);

    const target = Math.max(1, Math.round((Math.max(vhp, 0) / pool.vmax) * pool.realMax));
    const suppressSet = _getSuppressSet?.();
    suppressSet?.add(victim.id);
    system.run(() => {
        try {
            if (!victim.isValid) return;
            const attackerPart = attackerName ? ` entity @a[name="${attackerName}"]` : "";
            const health = victim.getComponent("minecraft:health");
            if (lethal) {
                victim.runCommand(`damage @s ${Math.max(1000, Math.ceil(pool.realMax * 10))} ${cause}${attackerPart}`);
            } else if (health) {
                // Hurt flash + knockback via a 1-point hit, health steered to the pool's share.
                const start = Math.min(pool.realMax, target + 1);
                if (start > target) {
                    health.setCurrentValue(start);
                    victim.runCommand(`damage @s 1 ${cause}${attackerPart}`);
                } else {
                    health.setCurrentValue(target);
                }
            }
        } catch (err) {
            console.warn(`[DamageManager] mob pool damage failed: ${err}`);
        } finally {
            suppressSet?.delete(victim.id);
        }
    });
    return true;
}

// `out` (optional) receives { applied } = damage that really landed (after the Core hit cap).
export function fireSuppressedDamage(victim, attacker, amount, cause = "entity_attack", out = null) {
    if (!victim || !attacker || amount <= 0) return;
    let safeAmount   = Math.min(Math.max(1, Math.round(amount)), CONFIG.MAX_SINGLE_HIT_DAMAGE);
    const attackerName = attacker.name.replace(/"/g, "");
    if (applyToMobPool(victim, attackerName, safeAmount, cause, out)) return;
    safeAmount = MobHpManager.capHitReal(victim, safeAmount);   // Core without a pool: still no one-shot
    if (out) out.applied = safeAmount;
    if (safeAmount <= 0) return;
    const suppressSet  = _getSuppressSet?.();
    suppressSet?.add(victim.id);
    system.run(() => {
        try {
            if (victim.isValid) {
                victim.runCommand(`damage @s ${safeAmount} ${cause} entity @a[name="${attackerName}"]`);
            }
        } catch (err) {
            console.warn(`[DamageManager] fireSuppressedDamage failed: ${err}`);
        } finally {
            suppressSet?.delete(victim.id);
        }
    });
}

export class DamageManager {
    // Build a damage context object. Callers accumulate modifiers then call applyFinalDamage.
    //
    // ctx = {
    //   attacker:    Player,
    //   victim:      Entity,
    //   baseDamage:  number,   // original vanilla damage value
    //   flatBonus:   number,   // sum of all flat additions
    //   multipliers: number[], // list of \uE21F additions, e.g. [50, 20] means ×1.70 total
    // }
    static createContext(attacker, victim, baseDamage) {
        return new DamageContext(attacker, victim, baseDamage);
    }

    // Add a flat damage bonus (e.g. Augment attackDamage, Bloodshed stack)
    static addFlat(ctx, amount) {
        return ctx?.addFlat(amount) ?? ctx;
    }

    // Add a \uE21F multiplier (e.g. Opening Strike +50 → pass 50, Ruination +60 → pass 60)
    // All are summed: addMultiplier(50) + addMultiplier(60) → ×1.10 total, not ×1.5×1.6
    static addMultiplier(ctx, percent) {
        return ctx?.addMultiplier(percent) ?? ctx;
    }

    // Compute and return the final integer damage value (minimum 1).
    static computeFinal(ctx) {
        if (!ctx || ctx.cancelled) return 0;
        const afterFlat = Math.max(0, ctx.baseDamage + ctx.flatBonus);
        const runeDealtPct = ctx.attacker?.typeId === "minecraft:player"
            ? RuneCN.getDamageDealtPercent(ctx.attacker) : 0;
        const totalPct = ctx.multipliers.reduce((sum, m) => sum + m, 0) + runeDealtPct;
        const final = afterFlat * (1 + totalPct / 100);
        // Safety net — see CONFIG.MAX_SINGLE_HIT_DAMAGE. Also guards against a
        // non-finite result (NaN/Infinity) from any of the above ever reaching
        // the /damage command, which would otherwise render as an invalid token.
        const safeFinal = Number.isFinite(final) ? final : CONFIG.MAX_SINGLE_HIT_DAMAGE;
        ctx.finalDamage = Math.min(Math.max(1, Math.round(safeFinal)), CONFIG.MAX_SINGLE_HIT_DAMAGE);
        return ctx.finalDamage;
    }

    // Issue the final /damage command. Uses victim.runCommand so attacker attribution
    // is preserved. The suppress set prevents the augment on-hit handler re-firing.
    //
    // Returns the computed final damage value for callers that need it.
    static applyFinalDamage(ctx) {
        if (!ctx || ctx.cancelled || !ctx.victim?.isValid) return 0;
        let finalDamage  = this.computeFinal(ctx);
        ctx.phase = "dispatching";
        const attackerName = ctx.attacker?.name?.replace(/"/g, "") ?? null;
        const suppressSet  = _getSuppressSet?.();
        const cause = normalizeDamageCause(ctx.cause);

        // Ascension mob HP scaling
        if (ctx.victim.typeId !== "minecraft:player") {
            const poolOut = {};
            if (applyToMobPool(ctx.victim, attackerName, finalDamage, cause, poolOut)) {
                if (typeof poolOut.applied === "number") ctx.meta.appliedDamage = poolOut.applied;
                ctx.resolved = true;
                ctx.phase = "resolved";
                return finalDamage;
            }
            if (MOB_SCALING.HP_MODE === "reduce" && MobHpManager.isScalable(ctx.victim)) {
                const mult = MobHpManager.getMultiplier(ctx.victim);
                if (mult > 1) finalDamage = Math.max(1, Math.round(finalDamage / mult));
            }
        }

        if (ctx.victim.typeId !== "minecraft:player") {
            finalDamage = MobHpManager.capHitReal(ctx.victim, finalDamage);   // Core without a pool
            if (finalDamage <= 0) { ctx.resolved = true; ctx.phase = "resolved"; return 0; }
        }
        suppressSet?.add(ctx.victim.id);
        system.run(() => {
            try {
                if (ctx.victim.isValid) {
                    const command = attackerName
                        ? `damage @s ${finalDamage} ${cause} entity @a[name="${attackerName}"]`
                        : `damage @s ${finalDamage} ${cause}`;
                    ctx.victim.runCommand(command);
                }
                ctx.resolved = true;
                ctx.phase = "resolved";
            } catch (err) {
                console.warn(`[DamageManager] applyFinalDamage failed: ${err}`);
            } finally {
                suppressSet?.delete(ctx.victim.id);
            }
        });

        return finalDamage;
    }

    // Convenience: build context, add flat & multipliers, and fire — all in one call.
    // flatBonus and multiplierPercents are optional.
    static dealDamage(attacker, victim, baseDamage, { flatBonus = 0, multiplierPercents = [] } = {}) {
        const ctx = this.createContext(attacker, victim, baseDamage);
        if (flatBonus)             this.addFlat(ctx, flatBonus);
        for (const m of multiplierPercents) this.addMultiplier(ctx, m);
        return this.applyFinalDamage(ctx);
    }
    // ─── RPG HP integration ───────────────────────────────────────────────────

    // Route a computed context's final damage into HPManager instead of /damage.
    // Use this when the victim IS a player so RPG HP is the authoritative pool.
    static applyToRpgHP(ctx) {
        if (ctx.victim?.typeId !== "minecraft:player") return this.applyFinalDamage(ctx);
        if (!ctx || ctx.cancelled || !ctx.victim?.isValid) return 0;
        let finalDamage = this.computeFinal(ctx);
        if (ctx.meta.ascensionMobHit) {
            // Ascension anti one-shot: one hit never takes more than a fraction of Max HP.
            const cap = Math.max(1, Math.floor(HPManager.getMaxHP(ctx.victim) * MOB_SCALING.MAX_HIT_FRACTION));
            if (finalDamage > cap) finalDamage = cap;
            ctx.finalDamage = finalDamage;
        }
        // Gem hooks set by the pipeline: Unyielding caps one hit at a share of Max HP,
        // Mind Over Matter lets Mana pay part of what is left.
        const hitFrac = ctx.meta.maxHitFraction;
        if (hitFrac) {
            const cap = Math.max(1, Math.floor(HPManager.getMaxHP(ctx.victim) * hitFrac));
            if (finalDamage > cap) { finalDamage = cap; ctx.finalDamage = finalDamage; }
        }
        if (typeof ctx.meta.manaAbsorb === "function" && finalDamage > 0) {
            finalDamage = Math.max(0, finalDamage - ctx.meta.manaAbsorb(finalDamage));
            ctx.finalDamage = finalDamage;
        }
        ctx.phase = "applying_hp";
        const result = HPManager.damage(ctx.victim, finalDamage, ctx);
        ctx.resolved = true;
        ctx.phase = "resolved";
        ctx.meta.hpResult = result;
        return finalDamage;
    }

    // ─── Environmental damage translation ────────────────────────────────────
    // Called from main.js entityHurt handler for non-combat damage causes,
    // and — bug fix — also for mob melee/ranged attacks on a player (see below).
    // Translates vanilla damage × scale factor into RPG HP damage so players
    // don't die in 1 hit from fall / fire / lava but are still meaningfully hurt.

    static getEnvironmentalScale(cause) {
        const scales = { entityAttack: CONFIG.ENV_DAMAGE_MOB_MELEE, fall: CONFIG.ENV_DAMAGE_FALL, fire: CONFIG.ENV_DAMAGE_FIRE, fire_tick: CONFIG.ENV_DAMAGE_FIRE, in_fire: CONFIG.ENV_DAMAGE_FIRE, entity_attack: CONFIG.ENV_DAMAGE_MOB_MELEE, void: CONFIG.ENV_DAMAGE_VOID, out_of_world: CONFIG.ENV_DAMAGE_VOID };
        return scales[normalizeDamageCause(cause)] ?? scales[cause] ?? 0.4;
    }
}


// Secondary / area damage (Chain Attack, AoE runes) may only hit real mobs: never players, pets,
// villagers, golems, summoned allies, damage numbers, armor stands or anything without a health bar.
const SPLASH_DENY = new Set([
    "minecraft:player", "minecraft:armor_stand", "minecraft:npc", "minecraft:villager", "minecraft:villager_v2",
    "minecraft:wandering_trader", "minecraft:iron_golem", "minecraft:snow_golem", "minecraft:copper_golem",
    "minecraft:xp_orb", "minecraft:item", "minecraft:arrow", "minecraft:agent", "crpg:damage_indicator",
]);
export function isSplashTarget(e) {
    try {
        if (!e?.isValid || SPLASH_DENY.has(e.typeId)) return false;
        if (e.hasTag("crpg_summoned")) return false;
        if (e.getComponent("minecraft:tameable")?.isTamed) return false;
        const hp = e.getComponent("minecraft:health");
        return !!hp && hp.currentValue > 0;
    } catch (_) { return false; }
}
