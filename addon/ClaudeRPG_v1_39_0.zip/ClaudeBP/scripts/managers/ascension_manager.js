// ascension_manager.js -- performs an Ascension (world-wide difficulty step).
// State lives in a world dynamic property; ProgressionManager reads it.

import { world } from "@minecraft/server";
import { ProgressionManager } from "./progression_manager.js";
import { EventBus } from "../core/event_bus.js";
import { PROG_KEYS, ASCENSION } from "../config/progression_config.js";
import { CostManager } from "./cost_manager.js";
import { ToastManager } from "../systems/toast_manager.js";

export class AscensionManager {

    // { ok, reason, current, next, requiredPrestige }
    static check(player) {
        const current = ProgressionManager.getAscension();
        const next = current + 1;
        const requiredPrestige = ProgressionManager.getRequiredPrestigeForNext(current);
        if (ASCENSION.MAX != null && current >= ASCENSION.MAX) {
            return { ok: false, reason: "max", current, next, requiredPrestige };
        }
        if (ProgressionManager.getPrestige(player) < requiredPrestige) {
            return { ok: false, reason: "prestige", current, next, requiredPrestige };
        }
        return { ok: true, reason: null, current, next, requiredPrestige };
    }

    static perform(player) {
        const c = this.check(player);
        if (!c.ok) return { success: false, reason: c.reason };

        const cost = CostManager.ascensionStatus(player, c.current);
        if (!cost.ok || !CostManager.consume(player, cost.item, cost.need)) {
            return { success: false, reason: "cost", need: cost.need, have: cost.have, name: cost.name };
        }

        world.setDynamicProperty(PROG_KEYS.ASCENSION, c.next);
        ProgressionManager.invalidateAscension();
        world.setDynamicProperty("prog_ascension_by", player.name);

        world.sendMessage(
            `§4§l[Ascension] §r§c${player.name} §7has raised the world to §c§lAscension ${c.next}§r§7. ` +
            `Every player now faces the consequences.`
        );
        try {   // toast for everyone with Toast on (the chat line above stays: it explains the consequences)
            ToastManager.broadcast({ frame: "ascension", icon: "TASC", header: "Ascension Raised", body: `§c§lAscension ${c.next}`, sound: null });
        } catch (_) {}
        for (const p of world.getAllPlayers()) {
            try { p.playSound("mob.wither.spawn", { volume: 0.6 }); } catch (_) {}
        }
        EventBus.emit("progression:ascension", { player, ascension: c.next });
        return { success: true, ascension: c.next };
    }
}
