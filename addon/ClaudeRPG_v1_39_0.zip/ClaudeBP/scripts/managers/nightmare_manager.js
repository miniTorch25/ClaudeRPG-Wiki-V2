// nightmare_manager.js -- the Nightmare event (Ascension 6+).
// Every player is tracked for "days without sleeping" (world days). From 3 days the night
// starts spawning Nightmare mobs around them; the longer, the likelier and the closer.
// At 5+ days they appear right next to the player, even inside a house.
// Sleeping in a bed resets everything.

import { world } from "@minecraft/server";
import { NIGHTMARE } from "../config/evolution_config.js";
import { ProgressionManager } from "./progression_manager.js";
import { EvolutionManager } from "./evolution_manager.js";

const LAST_SLEEP = "prog_last_sleep_day";
const NOTIFIED = "prog_insomnia_level";
const TAG_NM = "crpg_nightmare";

let counter = 0;

export class NightmareManager {

    // Whole in-game days since the player last slept.
    static getInsomniaDays(player) {
        const last = player.getDynamicProperty(LAST_SLEEP);
        if (typeof last !== "number") {
            player.setDynamicProperty(LAST_SLEEP, world.getDay());
            return 0;
        }
        return Math.max(0, world.getDay() - last);
    }

    static _level(days) {
        return NIGHTMARE.LEVELS.find((l) => days >= l.days) ?? null;
    }

    // Called every 20 ticks. Sleep detection every call, spawn checks every CHECK_EVERY_TICKS.
    static tick(players) {
        counter += 20;
        const doCheck = counter >= NIGHTMARE.CHECK_EVERY_TICKS;
        if (doCheck) counter = 0;

        for (const p of players) {
            try {
                if (!p.isValid) continue;
                if (p.isSleeping) {
                    p.setDynamicProperty(LAST_SLEEP, world.getDay());
                    if ((p.getDynamicProperty(NOTIFIED) ?? 0) > 0) {
                        p.setDynamicProperty(NOTIFIED, 0);
                        p.sendMessage("§7[Nightmare] Rest at last. The dark recedes.");
                    }
                    continue;
                }
                if (ProgressionManager.getAscension() < NIGHTMARE.MIN_ASCENSION) continue;

                const days = this.getInsomniaDays(p);
                const level = this._level(days);
                if (!level) continue;

                // Warn once when a stage is reached
                if ((p.getDynamicProperty(NOTIFIED) ?? 0) < level.days) {
                    p.setDynamicProperty(NOTIFIED, level.days);
                    p.sendMessage(`${level.message} §8(${days} days without sleep)`);
                }
                if (doCheck) this._maybeSpawn(p, level);
            } catch (_) {}
        }
    }

    static _isNight() {
        const t = world.getTimeOfDay();
        return t >= NIGHTMARE.NIGHT_FROM && t <= NIGHTMARE.NIGHT_TO;
    }

    static _maybeSpawn(player, level) {
        if (player.dimension.id !== "minecraft:overworld" || !this._isNight()) return;
        if (Math.random() >= level.chance) return;

        const alive = player.dimension.getEntities({ tags: [TAG_NM], location: player.location, maxDistance: 64 }).length;
        if (alive >= NIGHTMARE.MAX_ALIVE_NEAR) return;

        const [min, max] = level.wave;
        const want = Math.min(NIGHTMARE.MAX_ALIVE_NEAR - alive, min + Math.floor(Math.random() * (max - min + 1)));
        let spawned = 0;
        for (let i = 0; i < want; i++) if (this._spawnOne(player, level.close)) spawned++;
        if (spawned > 0) player.sendMessage(level.message);
    }

    static _spawnOne(player, close) {
        const dim = player.dimension;
        const [dMin, dMax] = close ? [NIGHTMARE.CLOSE_MIN, NIGHTMARE.CLOSE_MAX] : [NIGHTMARE.FAR_MIN, NIGHTMARE.FAR_MAX];
        for (let attempt = 0; attempt < 10; attempt++) {
            const ang = Math.random() * Math.PI * 2;
            const dist = dMin + Math.random() * (dMax - dMin);
            const x = Math.floor(player.location.x + Math.cos(ang) * dist);
            const z = Math.floor(player.location.z + Math.sin(ang) * dist);
            let y;
            if (close) {
                y = Math.floor(player.location.y);                    // same level: inside the house too
            } else {
                const top = dim.getTopmostBlock({ x, z });
                if (!top) continue;
                y = top.location.y + 1;
            }
            const feet = dim.getBlock({ x, y, z });
            const head = dim.getBlock({ x, y: y + 1, z });
            const floor = dim.getBlock({ x, y: y - 1, z });
            if (!feet || !head || !floor) continue;
            if (feet.typeId !== "minecraft:air" || head.typeId !== "minecraft:air") continue;
            if (floor.isAir || floor.isLiquid) continue;

            const type = NIGHTMARE.TYPES[Math.floor(Math.random() * NIGHTMARE.TYPES.length)];
            try {
                const mob = dim.spawnEntity(type, { x: x + 0.5, y, z: z + 0.5 });
                EvolutionManager.makeEvolved(mob, "nightmare");
                mob.addTag(TAG_NM);
                mob.addEffect("speed", 200, { amplifier: 0, showParticles: false });   // close the gap quickly
                return true;
            } catch (_) { /* try another spot */ }
        }
        return false;
    }
}
