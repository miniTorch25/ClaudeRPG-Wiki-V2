import { world } from "@minecraft/server";
import { StatsManager } from "./stats_manager.js";
import { ManaManager } from "./mana_manager.js";
import { HPManager } from "./hp_manager.js";

// fadeIn/fadeOut are 0 so re-setting every tick causes no visible flicker
const TITLE_OPTIONS = { fadeInDuration: 0, stayDuration: 30, fadeOutDuration: 0 };

// Per-player dirty flag: HUD only re-renders when something actually changed.
// Call HudManager.markDirty(player) whenever mana, XP, or level changes.
const dirtyPlayers = new Set();

export class HudManager {
    static markDirty(player) {
        dirtyPlayers.add(player.id);
    }

    static updatePersistentBar(player) {
        const data   = StatsManager.getPlayerData(player);
        const maxXp  = StatsManager.getMaxXp(data.level);
        const { mana, maxMana } = ManaManager.getMana(player);

        const hp    = HPManager.getHP(player);
        const maxHp = HPManager.getMaxHP(player);

        player.onScreenDisplay.setTitle(
            `§9\uE20F Name: §f${player.name}\n` +
            `§c\uE20D HP: §f${hp} / ${maxHp}\n` +
            `§a\uE207 Level: §f${data.level}\n` +
            `§3\uE208 Xp: §f${data.xp} / ${maxXp}\n` +
            `§w\uE205 Mana: §f${mana} / ${maxMana}`,
            TITLE_OPTIONS
        );
    }

    // Called every 5 ticks; only refreshes players whose state changed
    static tick() {
        for (const player of world.getAllPlayers()) {
            if (!dirtyPlayers.has(player.id)) continue;
            dirtyPlayers.delete(player.id);
            this.updatePersistentBar(player);
        }
    }
}
