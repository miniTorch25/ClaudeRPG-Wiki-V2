// special_mob_manager.js -- Special monsters of the Ascension system.
//   * Awakened special mobs (Creeper, Enderman, Witch, Blaze, Pillager, Vindicator, Piglin
//     Brute, Evoker, Guardian, Breeze): unique abilities run from the Mob Evolution scan
//     through EvolutionManager.addTickHook.
//   * Bosses (Wither, Warden, Ender Dragon, Elder Guardian): HP phases unlocked by Ascension.
//   * Cleanup sweep: evolved mobs / boss minions far from every player are removed, because a
//     named mob never despawns on its own.
// All numbers come from config/special_config.js.
//
// Markers:  tag "crpg_minion" = summoned by a boss (also tagged "crpg_summoned": never evolves)
//           tag "crpg_boss_enrage" = boss currently in an Enrage phase (damage bonus)
//           tags "crpg_bm_<phase>" / "crpg_bs_<phase>" = phase message / summon already done

import { world, system } from "@minecraft/server";
import { SPECIAL, SPECIAL_ABILITIES, SPECIAL_BOSSES } from "../config/special_config.js";
import { EvolutionManager } from "./evolution_manager.js";
import { ProgressionManager } from "./progression_manager.js";
import { MobHpManager } from "./mob_hp_manager.js";
import { DamageManager } from "./damage_manager.js";
import { AugmentManager } from "../systems/augment.js";
import { GemAbility } from "../systems/gem_ability.js";

const TAG_MINION = "crpg_minion";
const TAG_SUMMONED = "crpg_summoned";
const TAG_BERSERK = "crpg_berserk";
const TAG_BOSS_ENRAGE = "crpg_boss_enrage";
const TAG_HEALED = "crpg_sp_healed";
const DIMENSIONS = ["overworld", "nether", "the_end"];

// ─── Small helpers ───────────────────────────────────────────────────────────

function validTarget(p) {
    try {
        if (!p?.isValid) return false;
        const gm = String(p.getGameMode?.() ?? "").toLowerCase();
        return gm !== "creative" && gm !== "spectator";
    } catch (_) { return true; }
}

function dist3(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function dirXZ(from, to) {
    const dx = to.x - from.x, dz = to.z - from.z;
    const len = Math.sqrt(dx * dx + dz * dz) || 1;
    return { x: dx / len, z: dz / len };
}

function groupOf(typeId) {
    for (const [key, g] of Object.entries(SPECIAL_ABILITIES)) if (g.types.includes(typeId)) return key;
    return null;
}

// Push a player along a horizontal direction. Tries the current API shape, then the older one.
function knock(player, dir, strength, lift) {
    try { player.applyKnockback({ x: dir.x * strength, z: dir.z * strength }, lift); return; } catch (_) {}
    try { player.applyKnockback(dir.x, dir.z, strength, lift); } catch (_) {}
}

// Ability damage goes through the same rules as a normal mob hit: Ascension / tier damage
// multipliers, Augment + Gem reduction, and the "one hit <= 50% Max HP" cap.
function hurt(mob, player, base, cause = "entity_attack") {
    try {
        if (!mob?.isValid || !player?.isValid || !(base > 0)) return;
        const ctx = DamageManager.createContext(mob, player, base);
        ctx.cause = cause;
        ctx.phase = "before";
        const mult = MobHpManager.getAttackMult(mob);
        if (mult > 1) ctx.addMultiplier((mult - 1) * 100);
        const red = AugmentManager.getDamageReductionPercent(player, mob) + GemAbility.getGemDamageReductionPercent(player, cause);
        if (red > 0) ctx.addMultiplier(-red);
        ctx.meta.ascensionMobHit = true;   // enables the max-hit cap
        DamageManager.applyToRpgHP(ctx);
    } catch (_) {}
}

function heal(mob, fraction) {
    try {
        const health = mob.getComponent("minecraft:health");
        if (!health) return;
        const pool = MobHpManager.readPool(mob);
        if (pool) {
            const nv = Math.min(pool.vmax, pool.vhp + pool.vmax * fraction);
            MobHpManager.setVhp(mob, nv);
            health.setCurrentValue(Math.max(1, Math.round((nv / pool.vmax) * pool.realMax)));
        } else {
            health.setCurrentValue(Math.min(health.effectiveMax, health.currentValue + health.effectiveMax * fraction));
        }
    } catch (_) {}
}

function minionsNear(boss) {
    try {
        return boss.dimension.getEntities({ tags: [TAG_MINION], location: boss.location, maxDistance: SPECIAL.MINION_RADIUS }).length;
    } catch (_) { return 0; }
}

// ─── Manager ─────────────────────────────────────────────────────────────────

export class SpecialMobManager {

    static register() {
        EvolutionManager.addTickHook((mob, tier, players) => this._onMobTick(mob, tier, players));
    }

    // ─── Awakened special mobs ───────────────────────────────────────────────

    static _onMobTick(mob, tier, players) {
        if (tier.id !== "awaken" || !mob?.isValid) return;
        const group = groupOf(mob.typeId);
        if (!group) return;
        const cfg = SPECIAL_ABILITIES[group];
        const targets = players.filter(validTarget);
        const { player, dist } = EvolutionManager._nearest(mob, targets);

        switch (group) {
            case "creeper": return this._creeper(mob, cfg, player, dist);
            case "enderman": return this._enderman(mob, cfg, player, dist);
            case "witch": return this._witch(mob, cfg, player, dist);
            case "blaze": return this._blaze(mob, cfg, player, dist);
            case "pillager": return this._pillager(mob, cfg, player, dist);
            case "rage": return this._rage(mob);
            case "evoker": return this._evoker(mob, cfg, player, dist);
            case "guardian": return this._guardian(mob, cfg, player, dist);
            case "breeze": return this._breeze(mob, cfg, player, dist);
        }
    }

    static _creeper(mob, cfg, player, dist) {
        const p = cfg.pounce;
        if (!player || dist < p.minDist || dist > p.maxDist || !mob.isOnGround) return;
        if (!EvolutionManager._ready(mob, "pounce", p.cooldownMs)) return;
        const d = dirXZ(mob.location, player.location);
        mob.applyImpulse({ x: d.x * p.push, y: p.lift, z: d.z * p.push });
    }

    static _enderman(mob, cfg, player, dist) {
        const b = cfg.blink;
        if (!player || dist < b.minDist || dist > b.maxDist) return;
        try {
            // Only when the player looks at it (the same trigger as vanilla anger).
            const view = player.getViewDirection();
            const dx = mob.location.x - player.location.x;
            const dy = (mob.location.y + 1.5) - (player.location.y + 1.6);
            const dz = mob.location.z - player.location.z;
            const len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            if ((view.x * dx + view.y * dy + view.z * dz) / len < b.lookDot) return;

            const hl = Math.sqrt(view.x * view.x + view.z * view.z) || 1;
            const dest = {
                x: player.location.x - (view.x / hl) * b.behind,
                y: player.location.y,
                z: player.location.z - (view.z / hl) * b.behind,
            };
            const dim = mob.dimension;
            const feet = dim.getBlock({ x: Math.floor(dest.x), y: Math.floor(dest.y), z: Math.floor(dest.z) });
            const head = dim.getBlock({ x: Math.floor(dest.x), y: Math.floor(dest.y) + 1, z: Math.floor(dest.z) });
            if (!feet?.isAir || !head?.isAir) return;      // only a safe spot
            if (!EvolutionManager._ready(mob, "blink", b.cooldownMs)) return;
            mob.teleport(dest, { dimension: dim, facingLocation: player.location });
        } catch (_) {}
    }

    static _witch(mob, cfg, player, dist) {
        const h = cfg.heal;
        if (!mob.hasTag(TAG_HEALED) && EvolutionManager._hpFraction(mob) < h.below) {
            mob.addTag(TAG_HEALED);
            heal(mob, h.fraction);
        }
        const x = cfg.hex;
        if (!player || dist > x.maxDist || !EvolutionManager._ready(mob, "hex", x.cooldownMs)) return;
        try {
            player.addEffect("slowness", x.slowTicks, { amplifier: x.slowAmp, showParticles: true });
            player.addEffect("weakness", x.weakTicks, { amplifier: x.weakAmp, showParticles: true });
        } catch (_) {}
    }

    static _blaze(mob, cfg, player, dist) {
        const v = cfg.volley;
        if (!player || dist < v.minDist || dist > v.maxDist || !EvolutionManager._ready(mob, "firevolley", v.cooldownMs)) return;
        let launched = 0;
        try {
            const from = { x: mob.location.x, y: mob.location.y + 1.0, z: mob.location.z };
            const to = { x: player.location.x, y: player.location.y + 1.0, z: player.location.z };
            const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
            const len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            for (let i = 0; i < v.count; i++) {
                const ang = (i - (v.count - 1) / 2) * v.spread;
                const c = Math.cos(ang), s = Math.sin(ang);
                const ux = (dx * c - dz * s) / len, uz = (dx * s + dz * c) / len, uy = dy / len;
                let ball = null;
                try {
                    ball = mob.dimension.spawnEntity("minecraft:small_fireball", { x: from.x + ux * 1.3, y: from.y + uy * 1.3, z: from.z + uz * 1.3 });
                    const proj = ball.getComponent("minecraft:projectile");
                    if (!proj) { ball.remove(); continue; }
                    try { proj.owner = mob; } catch (_) {}
                    proj.shoot({ x: ux * v.speed, y: uy * v.speed, z: uz * v.speed });
                    launched++;
                } catch (_) { try { ball?.remove(); } catch (_) {} }
            }
        } catch (_) {}
        if (launched === 0) {
            // Fallback when fireballs cannot be launched by script: a direct flame lash.
            hurt(mob, player, v.fallbackDamage);
            try { player.setOnFire(v.fallbackBurnSeconds, true); } catch (_) {}
        }
    }

    static _pillager(mob, cfg, player, dist) {
        const v = cfg.volley;
        if (!player || dist < v.minDist || dist > v.maxDist || !EvolutionManager._ready(mob, "pvolley", v.cooldownMs)) return;
        EvolutionManager._volley(mob, player, v);
    }

    static _rage(mob) {
        const r = SPECIAL.RAGE;
        if (EvolutionManager._hpFraction(mob) >= r.below) return;
        if (!mob.hasTag(TAG_BERSERK)) mob.addTag(TAG_BERSERK);
        try { mob.addEffect("speed", 40, { amplifier: r.speedAmp, showParticles: false }); } catch (_) {}
    }

    static _evoker(mob, cfg, player, dist) {
        const f = cfg.fangs;
        if (!player || dist < f.minDist || dist > f.maxDist || !EvolutionManager._ready(mob, "fangs", f.cooldownMs)) return;
        try {
            const dim = mob.dimension;
            const d = dirXZ(mob.location, player.location);
            const base = { x: mob.location.x, y: mob.location.y, z: mob.location.z };
            for (let i = 1; i <= f.count; i++) {
                const px = base.x + d.x * f.spacing * i, pz = base.z + d.z * f.spacing * i;
                system.runTimeout(() => {
                    try {
                        let y = base.y;
                        const b = dim.getBlock({ x: Math.floor(px), y: Math.floor(y), z: Math.floor(pz) });
                        if (b && !b.isAir) y += 1;        // step over a one-block rise
                        dim.spawnEntity("minecraft:evocation_fang", { x: px, y, z: pz });
                    } catch (_) {}
                }, i * f.stepTicks);
            }
        } catch (_) {}
    }

    static _guardian(mob, cfg, player, dist) {
        const p = cfg.pull;
        if (!player || dist < p.minDist || dist > p.maxDist || !EvolutionManager._ready(mob, "pull", p.cooldownMs)) return;
        knock(player, dirXZ(player.location, mob.location), p.push, p.lift);
        hurt(mob, player, p.damage, "magic");
    }

    static _breeze(mob, cfg, player, dist) {
        const g = cfg.gust;
        if (!player || dist > g.maxDist || !EvolutionManager._ready(mob, "gust", g.cooldownMs)) return;
        knock(player, dirXZ(mob.location, player.location), g.push, g.lift);
        hurt(mob, player, g.damage, "entity_attack");
    }

    // ─── Creeper death blast (kill listener; register BEFORE EvolutionManager.onKill) ──

    static onKill(killEvent) {
        try {
            const victim = killEvent?.victim;
            if (victim?.typeId !== "minecraft:creeper" || !killEvent.isPlayerKill) return;
            if (EvolutionManager.getTierId(victim) !== "awaken") return;
            const cfg = SPECIAL_ABILITIES.creeper.deathBlast;
            let dim, loc;
            try { dim = victim.dimension; loc = { x: victim.location.x, y: victim.location.y, z: victim.location.z }; }
            catch (_) { return; }
            try { dim.spawnParticle("minecraft:basic_smoke_particle", { x: loc.x, y: loc.y + 1, z: loc.z }); } catch (_) {}
            system.runTimeout(() => {
                try { dim.createExplosion(loc, cfg.radius, { breaksBlocks: false, causesFire: false }); } catch (_) {}
            }, cfg.delayTicks);
        } catch (_) {}
    }

    // ─── Bosses ──────────────────────────────────────────────────────────────

    static tickBosses() {
        const asc = ProgressionManager.getAscension();
        let minUnlock = Infinity;
        for (const b of Object.values(SPECIAL_BOSSES)) for (const ph of b.phases) minUnlock = Math.min(minUnlock, ph.unlockAsc);
        if (asc < minUnlock) return;

        const all = world.getAllPlayers();
        for (const dimId of DIMENSIONS) {
            const players = all.filter((p) => { try { return p.isValid && p.dimension.id === `minecraft:${dimId}`; } catch (_) { return false; } });
            if (!players.length) continue;
            let dim;
            try { dim = world.getDimension(dimId); } catch (_) { continue; }
            for (const [typeId, cfg] of Object.entries(SPECIAL_BOSSES)) {
                let bosses;
                try { bosses = dim.getEntities({ type: typeId }); } catch (_) { continue; }
                for (const boss of bosses) {
                    try { this._tickBoss(boss, cfg, players, asc); } catch (_) {}
                }
            }
        }
    }

    static _tickBoss(boss, cfg, players, asc) {
        if (!boss?.isValid) return;
        const near = players.filter((p) => p.isValid && dist3(p.location, boss.location) <= SPECIAL.BOSS_SCAN_RADIUS);
        if (!near.length) return;
        const targets = near.filter(validTarget);
        const frac = EvolutionManager._hpFraction(boss);
        let enraged = false;

        for (const ph of cfg.phases) {
            if (asc < ph.unlockAsc || frac > ph.below) continue;

            const msgTag = `crpg_bm_${ph.id}`;
            if (ph.message && !boss.hasTag(msgTag)) {
                boss.addTag(msgTag);
                for (const p of near) { try { p.sendMessage(ph.message); } catch (_) {} }
            }
            if (ph.aura) this._aura(boss, ph, targets);
            if (ph.tremor) this._tremor(boss, ph, targets);
            if (ph.summon && !boss.hasTag(`crpg_bs_${ph.id}`)) this._summon(boss, ph, near);
            if (ph.enrage) {
                enraged = true;
                try { boss.addEffect("speed", 60, { amplifier: ph.enrage.speedAmp, showParticles: false }); } catch (_) {}
            }
        }
        if (enraged) { if (!boss.hasTag(TAG_BOSS_ENRAGE)) boss.addTag(TAG_BOSS_ENRAGE); }
        else if (boss.hasTag(TAG_BOSS_ENRAGE)) boss.removeTag(TAG_BOSS_ENRAGE);
    }

    static _aura(boss, ph, targets) {
        const a = ph.aura;
        if (!EvolutionManager._ready(boss, `aura_${ph.id}`, a.intervalMs)) return;
        for (const p of targets) {
            if (dist3(p.location, boss.location) > a.radius) continue;
            for (const e of a.effects) {
                try { p.addEffect(e.id, e.ticks, { amplifier: e.amp, showParticles: true }); } catch (_) {}
            }
        }
    }

    static _tremor(boss, ph, targets) {
        const t = ph.tremor;
        if (!EvolutionManager._ready(boss, `tremor_${ph.id}`, t.intervalMs)) return;
        for (const p of targets) {
            if (dist3(p.location, boss.location) > t.radius) continue;
            knock(p, dirXZ(boss.location, p.location), t.push, t.lift);
            hurt(boss, p, t.damage, "entity_attack");
            try { p.addEffect("darkness", t.darknessTicks, { amplifier: 0, showParticles: false }); } catch (_) {}
        }
    }

    static _summon(boss, ph, near) {
        const s = ph.summon;
        const room = SPECIAL.MINION_CAP - minionsNear(boss);
        if (room <= 0) return;                       // try again on a later scan
        const n = Math.min(s.count, room);
        const dim = boss.dimension;
        let spawned = 0;
        for (let i = 0; i < n; i++) {
            const centre = s.mode === "players" ? near[Math.floor(Math.random() * near.length)].location : boss.location;
            const ang = Math.random() * Math.PI * 2;
            const r = s.radius * (0.5 + Math.random() * 0.5);
            const pos = { x: centre.x + Math.cos(ang) * r, y: centre.y, z: centre.z + Math.sin(ang) * r };
            try {
                if (s.water) {
                    const b = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) });
                    if (b?.typeId !== "minecraft:water") continue;
                }
                const m = dim.spawnEntity(s.type, pos);
                m.addTag(TAG_SUMMONED);              // never evolves
                m.addTag(TAG_MINION);                // cleaned up when far from players
                spawned++;
            } catch (_) {}
        }
        if (spawned > 0) boss.addTag(`crpg_bs_${ph.id}`);
    }

    // ─── Cleanup sweep ───────────────────────────────────────────────────────

    // Removes evolved mobs and boss minions that are farther than CLEANUP.DISTANCE from every player.
    static cleanup() {
        if (!SPECIAL.CLEANUP.ENABLED) return 0;
        const all = world.getAllPlayers();
        let removed = 0;
        for (const dimId of DIMENSIONS) {
            let dim;
            try { dim = world.getDimension(dimId); } catch (_) { continue; }
            const players = all.filter((p) => { try { return p.isValid && p.dimension.id === `minecraft:${dimId}`; } catch (_) { return false; } });
            for (const tag of ["crpg_evo", TAG_MINION]) {
                let ents;
                try { ents = dim.getEntities({ tags: [tag] }); } catch (_) { continue; }
                for (const e of ents) {
                    try {
                        if (!e.isValid) continue;
                        let nearest = Infinity;
                        for (const p of players) nearest = Math.min(nearest, dist3(p.location, e.location));
                        if (nearest > SPECIAL.CLEANUP.DISTANCE) { e.remove(); removed++; }
                    } catch (_) {}
                }
            }
        }
        return removed;
    }
}
