// admin_manager.js -- permission check, in-game Config Editor registry and Audit Log.
//
// Only players with the tag "Admin" may use the admin tools:  /tag <name> add Admin
//
// Config Editor: a whitelist of numeric / enum values from the config files. Edits are applied
// to the live config objects at once and stored as overrides in a world dynamic property, so
// they survive restarts (applied again on worldLoad). Only values that the game reads live are
// listed, so every edit takes effect immediately.

import { world } from "@minecraft/server";
import { CONFIG } from "../config/config.js";
import { PROGRESSION, PRESTIGE, ASCENSION, MOB_SCALING, ACTION_COSTS } from "../config/progression_config.js";
import { MASTERY } from "../config/mastery_config.js";
import { EVOLUTION, NIGHTMARE, ENCHANTED } from "../config/evolution_config.js";
import { SPECIAL, SPECIAL_ABILITIES, SPECIAL_BOSSES } from "../config/special_config.js";
import { CHORUS_ROLL_COST, CHORUS_LOCK_COST, CHORUS_ROLL_SETTINGS, CHORUS_FUSION_COST, CHORUS_FUSION_UNLOCK } from "../config/chorus_config.js";
import { GEM_CAPS } from "../config/gem_ability_config.js";
import { RUNE_LEVEL_MULT } from "../config/level_config.js";
import { SYNERGY } from "../config/synergy_config.js";
import { LOOT_BONUS } from "../config/loot_bonus_config.js";
import { ACHIEVEMENT } from "../config/achievement_config.js";
import { TOAST } from "../config/toast_config.js";
import { GUIDE } from "../config/guide_quest_config.js";
import { WAYPOINT, DISCOVERY } from "../config/exploration_config.js";
import { STASH, REPLANT, CHORUS_AURA } from "../config/qol_config.js";
import { HEALTH_DISPLAY } from "../config/health_display_config.js";
import { DAMAGE_INDICATOR } from "../config/damage_indicator_config.js";

export const ADMIN_TAG = "Admin";
const OVERRIDE_KEY = "admin_config_overrides";
const AUDIT_KEY = "admin_audit_log";
const AUDIT_MAX = 20;

export const GROUPS = [
    { id: "level",     label: "Levels, XP & Gates" },
    { id: "prestige",  label: "Prestige & Perks" },
    { id: "ascension", label: "Ascension & Mob Scaling" },
    { id: "mastery",   label: "Mastery" },
    { id: "evolution", label: "Mob Evolution" },
    { id: "nightmare", label: "Nightmare Event" },
    { id: "special",   label: "Special Mobs & Bosses" },
    { id: "chorus",    label: "Chorus Costs" },
    { id: "fusion",    label: "Chorus Fusion (Awaken / Melodious / Genesis)" },
    { id: "synergy",   label: "Chorus Synergy (Gem / Rune)" },
    { id: "gemrune",   label: "Gem Caps & Rune Levels" },
    { id: "loot",      label: "Looting / Fortune Drops" },
    { id: "achievement", label: "Achievements" },
    { id: "toast",      label: "Toast Notifications" },
    { id: "guide",      label: "Guide Quest" },
    { id: "explore",   label: "Exploration (Waypoint / Discovery)" },
    { id: "qol",       label: "Quality of Life (Quick Stash)" },
    { id: "health",    label: "Health Display (HP numbers)" },
    { id: "dmgnum",    label: "Damage Indicator (damage numbers)" },
];

// ─── Registry ────────────────────────────────────────────────────────────────

const registry = new Map();   // id -> { id, group, label, obj, key, kind, min, max, options, def }

function add(group, id, label, obj, key, kind, min, max, options) {
    if (!obj || !(key in obj)) return;
    registry.set(id, { id, group, label, obj, key, kind, min, max, options, def: obj[key] });
}
const int = (g, id, label, obj, key, min, max) => add(g, id, label, obj, key, "int", min, max);
const flt = (g, id, label, obj, key, min, max) => add(g, id, label, obj, key, "float", min, max);

// Levels, XP & Gates
int("level", "level.base_max", "Base Max Level", PROGRESSION, "BASE_MAX_LEVEL", 1, 1000);
int("level", "level.per_prestige", "Max Level per Prestige", PROGRESSION, "MAX_LEVEL_PER_PRESTIGE", 0, 100);
int("level", "level.soft_level", "XP curve: soft after Level", CONFIG, "XP_SOFT_LEVEL", 1, 10000);
flt("level", "level.soft_factor", "XP curve: growth factor after soft Level", CONFIG, "XP_SOFT_FACTOR", 0, 1);
int("level", "level.points_per_level", "Points per Level", CONFIG, "POINTS_PER_LEVEL", 0, 50);
int("level", "level.base_xp", "XP for Level 0 -> 1", CONFIG, "BASE_MAX_XP", 1, 1000000);
int("level", "level.xp_per_level", "XP increase per Level", CONFIG, "XP_PER_LEVEL_INCREASE", 0, 100000);
for (const [fid, f] of Object.entries(PROGRESSION.FEATURES)) {
    const nm = f.name ?? fid;
    int("level", `gate.${fid}.level`, `${nm} gate: Level`, f, "level", 0, 1000);
    if ("prestige" in f) int("level", `gate.${fid}.prestige`, `${nm} gate: Prestige`, f, "prestige", 0, 1000);
    if ("ascension" in f) int("level", `gate.${fid}.ascension`, `${nm} gate: Ascension`, f, "ascension", 0, 1000);
}

// Chorus Synergy
for (const need of Object.keys(SYNERGY.LEVEL_BONUS)) {
    int("synergy", `syn.level.${need}`, `Level bonus at ${need}+ matching sockets`, SYNERGY.LEVEL_BONUS, need, 0, 4);
}
int("synergy", "syn.transcend", "Extra Level for Transcend match (4+ sockets)", SYNERGY, "TRANSCEND_EXTRA_LEVEL", 0, 4);
int("synergy", "syn.genesis", "Extra Level for Genesis armor (needs 4+ Genesis sockets)", SYNERGY, "GENESIS_EXTRA_LEVEL", 0, 4);
int("synergy", "syn.genesis_min", "Genesis sockets needed for that bonus", SYNERGY, "GENESIS_MIN_SOCKETS", 1, 8);
int("synergy", "syn.rider_min", "Sockets needed for the bonus effect", SYNERGY, "RIDER_MIN_SLOTS", 1, 8);
int("synergy", "syn.rider_cd", "Bonus effect cooldown (ticks)", SYNERGY, "RIDER_COOLDOWN_TICKS", 0, 1200);
flt("synergy", "syn.max_dmg", "Max Synergy damage bonus (%)", SYNERGY, "MAX_BONUS_DAMAGE_PCT", 0, 500);

// Looting / Fortune drops
flt("loot", "loot.chance_per_level", "Looting: chance bonus per level (x)", LOOT_BONUS, "LOOTING_CHANCE_PER_LEVEL", 0, 5);
flt("loot", "loot.max_chance", "Looting: max chance (0-1)", LOOT_BONUS, "LOOTING_MAX_CHANCE", 0, 1);
int("loot", "loot.count_per_level", "Looting: extra count per level", LOOT_BONUS, "LOOTING_COUNT_PER_LEVEL", 0, 10);
int("loot", "loot.apply_favor", "Looting affects Fortune's Favor (1/0)", LOOT_BONUS, "APPLY_FORTUNES_FAVOR", 0, 1);
int("loot", "loot.apply_gem", "Looting affects evolved-mob Gem drops (1/0)", LOOT_BONUS, "APPLY_EVO_GEM", 0, 1);
int("loot", "loot.apply_rare", "Looting affects Awaken rare drops (1/0)", LOOT_BONUS, "APPLY_EVO_RARE", 0, 1);
int("loot", "loot.apply_core", "Looting affects Core drop chance (1/0)", LOOT_BONUS, "APPLY_EVO_CORE", 0, 1);
int("loot", "loot.apply_shard", "Looting affects Echo Shard amount (1/0)", LOOT_BONUS, "APPLY_EVO_SHARD", 0, 1);
int("loot", "loot.apply_essence", "Looting affects Enchant Essence amount (1/0)", LOOT_BONUS, "APPLY_EVO_ESSENCE", 0, 1);

// Prestige & Ascension cost items
int("prestige", "cost.prestige.base", "Prestige cost: base Sigils", ACTION_COSTS.PRESTIGE, "BASE", 0, 1000);
flt("prestige", "cost.prestige.per", "Prestige cost: extra per Prestige", ACTION_COSTS.PRESTIGE, "PER", 0, 20);
int("prestige", "cost.prestige.cap", "Prestige cost: cap", ACTION_COSTS.PRESTIGE, "CAP", 0, 10000);
int("ascension", "cost.ascension.base", "Ascension cost: base Relics", ACTION_COSTS.ASCENSION, "BASE", 0, 1000);
flt("ascension", "cost.ascension.per", "Ascension cost: extra per Ascension", ACTION_COSTS.ASCENSION, "PER", 0, 20);
int("ascension", "cost.ascension.cap", "Ascension cost: cap", ACTION_COSTS.ASCENSION, "CAP", 0, 10000);

// Prestige & Perks
flt("prestige", "prestige.xp_bonus_per", "Veteran XP bonus per Prestige (%)", PRESTIGE, "XP_BONUS_PER", 0, 100);
flt("prestige", "prestige.xp_bonus_cap", "Veteran XP bonus cap (%)", PRESTIGE, "XP_BONUS_CAP", 0, 1000);
flt("prestige", "prestige.limit_step", "Stat Limit Break step (x base cap)", PRESTIGE, "LIMIT_BREAK_STEP", 0, 5);
int("prestige", "prestige.full_until", "Full-strength until Prestige", PRESTIGE, "FULL_UNTIL", 0, 100);
flt("prestige", "prestige.decay", "Decay per Prestige after that", PRESTIGE, "DECAY", 0, 1);
flt("prestige", "prestige.min_factor", "Minimum strength factor", PRESTIGE, "MIN_FACTOR", 0, 1);
for (const [pid, p] of Object.entries(PRESTIGE.PERKS)) {
    flt("prestige", `perk.${pid}.base`, `Perk ${p.name}: base power`, p, "base", 0, 1000);
    int("prestige", `perk.${pid}.min`, `Perk ${p.name}: first Prestige`, p, "minPrestige", 0, 1000);
}

// Ascension & Mob Scaling
flt("ascension", "asc.mob_hp_per", "Mob HP per Ascension", ASCENSION.MOB_HP, "PER_ASC", 0, 100);
flt("ascension", "asc.mob_hp_cap", "Mob HP cap (x)", ASCENSION.MOB_HP, "CAP", 1, 1000);
flt("ascension", "asc.mob_dmg_per", "Mob damage per Ascension", ASCENSION.MOB_DAMAGE, "PER_ASC", 0, 100);
flt("ascension", "asc.mob_dmg_cap", "Mob damage cap (x)", ASCENSION.MOB_DAMAGE, "CAP", 1, 1000);
flt("ascension", "asc.mob_dmg_soft_after", "Mob damage: soft curve after Ascension", ASCENSION.MOB_DAMAGE, "SOFT_AFTER", 0, 1000);
flt("ascension", "asc.mob_dmg_soft_factor", "Mob damage: growth factor after soft point", ASCENSION.MOB_DAMAGE, "SOFT_FACTOR", 0, 1);
flt("ascension", "asc.boss_dmg_per", "Boss damage per Ascension", ASCENSION.BOSS_DAMAGE, "PER_ASC", 0, 100);
flt("ascension", "asc.boss_dmg_cap", "Boss damage cap (x)", ASCENSION.BOSS_DAMAGE, "CAP", 1, 1000);
flt("ascension", "asc.player_dmg_per", "Player damage per Ascension", ASCENSION.PLAYER_DAMAGE, "PER_ASC", 0, 100);
flt("ascension", "asc.player_dmg_cap", "Player damage cap (x)", ASCENSION.PLAYER_DAMAGE, "CAP", 1, 1000);
flt("ascension", "mob.total_dmg_cap", "Combined hostile damage cap (x)", MOB_SCALING, "TOTAL_DAMAGE_CAP", 1, 1000);
flt("ascension", "asc.xp_bonus_per", "XP bonus per Ascension (%)", ASCENSION.XP_BONUS, "PER_ASC", 0, 100);
flt("ascension", "asc.xp_bonus_cap", "Ascension XP bonus cap (%)", ASCENSION.XP_BONUS, "CAP", 0, 1000);
flt("ascension", "asc.boss_hp_per", "Boss HP per Ascension", ASCENSION.BOSS_HP, "PER_ASC", 0, 100);
flt("ascension", "asc.boss_hp_cap", "Boss HP cap (x)", ASCENSION.BOSS_HP, "CAP", 1, 1000);
int("ascension", "asc.req_1", "Prestige needed for Ascension 1", ASCENSION.REQUIRED_PRESTIGE, 1, 0, 1000);
int("ascension", "asc.req_2", "Prestige needed for Ascension 2", ASCENSION.REQUIRED_PRESTIGE, 2, 0, 1000);
int("ascension", "asc.req_3", "Prestige needed for Ascension 3+", ASCENSION.REQUIRED_PRESTIGE, "DEFAULT", 0, 1000);
flt("ascension", "mob.max_hit", "Max hit (fraction of player Max HP)", MOB_SCALING, "MAX_HIT_FRACTION", 0.05, 1);
int("ascension", "mob.boss_gem_asc", "Boss Uncarved Gem: from Ascension", MOB_SCALING, "BOSS_GEM_MIN_ASCENSION", 0, 1000);
add("ascension", "mob.hp_mode", "Mob HP mode (pool / reduce)", MOB_SCALING, "HP_MODE", "enum", 0, 0, ["pool", "reduce"]);

// Mastery
int("mastery", "mastery.unlock_prestige", "Prestige needed (all lines)", MASTERY, "UNLOCK_PRESTIGE", 0, 1000);
int("mastery", "mastery.path_cd", "Path change cooldown (seconds)", MASTERY, "PATH_SWITCH_COOLDOWN_SEC", 0, 86400);
int("mastery", "mastery.speed_floor", "Movement Speed floor (%)", MASTERY, "MOVE_SPEED_FLOOR_PCT", -100, 0);
flt("mastery", "mastery.variance", "Random spread per level (0 = even)", MASTERY.RANDOM, "VARIANCE", 0, 0.95);
flt("mastery", "mastery.crit_base", "Chance-crit base bonus (%)", MASTERY, "CRIT_BASE_BONUS", 0, 1000);
flt("mastery", "mastery.travel_xp", "Travel XP per block", MASTERY, "TRAVEL_XP_PER_BLOCK", 0, 100);
flt("mastery", "mastery.travel_nether", "Travel Nether multiplier", MASTERY, "TRAVEL_NETHER_MULT", 0, 100);
flt("mastery", "mastery.travel_glide", "Travel Elytra multiplier", MASTERY, "TRAVEL_GLIDE_MULT", 0, 100);
flt("mastery", "mastery.crit_xp", "XP per critical hit (Melee/Ranged)", MASTERY, "CRIT_XP", 0, 10000);
flt("mastery", "mastery.fishing_mult", "Fishing XP multiplier", MASTERY, "FISHING_XP_MULT", 0, 1000);
flt("mastery", "mastery.gem_engrave", "Gem XP per Engrave attempt", MASTERY, "GEM_XP_ENGRAVE", 0, 100000);
flt("mastery", "mastery.gem_salvage", "Gem XP per salvaged Gem", MASTERY, "GEM_XP_SALVAGE_PER_GEM", 0, 100000);
flt("mastery", "mastery.gem_carve_common", "Gem XP per carved Common Gem", MASTERY.GEM_XP_CARVE, "common", 0, 100000);
flt("mastery", "mastery.gem_carve_uncommon", "Gem XP per carved Uncommon Gem", MASTERY.GEM_XP_CARVE, "uncommon", 0, 100000);
flt("mastery", "mastery.gem_carve_rare", "Gem XP per carved Rare Gem", MASTERY.GEM_XP_CARVE, "rare", 0, 100000);
flt("mastery", "mastery.gem_carve_unique", "Gem XP per carved Unique Gem", MASTERY.GEM_XP_CARVE, "unique", 0, 100000);
flt("mastery", "mastery.gem_carve_legend", "Gem XP per carved Legend Gem", MASTERY.GEM_XP_CARVE, "legend", 0, 100000);
flt("mastery", "mastery.gem_carve_epic", "Gem XP per carved Epic Gem", MASTERY.GEM_XP_CARVE, "epic", 0, 100000);
flt("mastery", "mastery.gem_carve_mythical", "Gem XP per carved Mythical Gem", MASTERY.GEM_XP_CARVE, "mythical", 0, 100000);
flt("mastery", "mastery.leveling_ratio", "Leveling XP per RPG XP", MASTERY, "LEVELING_XP_RATIO", 0, 1000);
flt("mastery", "mastery.defense_xp", "Defense XP per damage taken", MASTERY, "DEFENSE_XP_PER_DAMAGE", 0, 1000);
flt("mastery", "mastery.magic_xp", "Magic XP per mana spent", MASTERY, "MAGIC_XP_PER_MANA", 0, 1000);
flt("mastery", "mastery.gather_xp", "Gathering XP per block", MASTERY, "GATHER_XP_PER_BLOCK", 0, 1000);
for (const [tid, v] of Object.entries(MASTERY.CHORUS_XP)) flt("mastery", `mastery.chorus_xp.${tid}`, `Chorus XP per roll: ${tid}`, MASTERY.CHORUS_XP, tid, 0, 1000000);
for (const [lid, line] of Object.entries(MASTERY.LINES)) {
    int("mastery", `mastery.line.${lid}.max`, `${line.name}: max Level`, line, "maxLevel", 1, 1000);
    int("mastery", `mastery.line.${lid}.xp_base`, `${line.name}: XP base per Level`, line.xp, "base", 1, 100000000);
    int("mastery", `mastery.line.${lid}.xp_per`, `${line.name}: XP increase per Level`, line.xp, "per", 0, 100000000);
    for (const [eid, e] of Object.entries(line.effects ?? {})) {
        flt("mastery", `mastery.fx.${lid}.${eid}`, `${line.name}: ${e.name} (${e.kind === "fixed" ? "per Level" : "at max"})`, e, e.kind === "fixed" ? "per" : "max", -10000, 10000);
    }
    for (const [pid, p] of Object.entries(line.paths ?? {})) {
        for (const [eid, e] of Object.entries(p.effects)) {
            flt("mastery", `mastery.fx.${lid}.${pid}.${eid}`, `${line.name}/${p.name}: ${e.name} (at max)`, e, "max", -10000, 10000);
        }
    }
    for (const u of line.unlocks ?? []) int("mastery", `mastery.unlock.${lid}.${u.id}`, `${line.name}: ${u.name} at Level`, u, "level", 1, 1000);
}

// Mob Evolution
flt("evolution", "evo.asc_dmg_per", "Evolved damage per Ascension", EVOLUTION.ASC_DAMAGE, "PER_ASC", 0, 10);
flt("evolution", "evo.asc_dmg_cap", "Evolved damage Ascension cap (x)", EVOLUTION.ASC_DAMAGE, "CAP", 1, 100);
flt("evolution", "evo.ench_dmg", "Enchanted mob damage (x)", ENCHANTED, "damage", 0.1, 100);
flt("evolution", "evo.chance_base", "Evolve chance: base", EVOLUTION, "CHANCE_BASE", 0, 1);
flt("evolution", "evo.chance_per_asc", "Evolve chance: per Ascension", EVOLUTION, "CHANCE_PER_ASC", 0, 1);
flt("evolution", "evo.chance_max", "Evolve chance: maximum", EVOLUTION, "CHANCE_MAX", 0, 1);
int("evolution", "evo.area_cap", "Evolved mobs per area", EVOLUTION, "AREA_CAP", 0, 1000);
int("evolution", "evo.area_radius", "Area radius (blocks)", EVOLUTION, "AREA_RADIUS", 8, 256);
const TIER_EXTRA = {
    elite:  [["enrageBelow", 0, 1, "f"], ["callBelow", 0, 1, "f"], ["callCount", 0, 10, "i"]],
    sculk:  [["shardMin", 0, 16, "i"], ["shardMax", 0, 16, "i"], ["senseRange", 0, 128, "f"], ["senseRangeNoisy", 0, 128, "f"], ["hotDamageBonus", 0, 10, "f"]],
    geode:  [["gemChance", 0, 1, "f"]],
    inferno:[["burnChance", 0, 1, "f"], ["burnSeconds", 0, 60, "i"], ["netherPower", 0, 20, "f"], ["otherPower", 0, 20, "f"]],
    nightmare: [["blindChance", 0, 1, "f"]],
    core:   [["hitCapFraction", 0.01, 1, "f"], ["dropChance", 0, 1, "f"]],
};
for (const [tid, t] of Object.entries(EVOLUTION.TIERS)) {
    const nm = t.name;
    flt("evolution", `evo.${tid}.hp`, `${nm}: HP multiplier`, t, "hp", 0, 100);
    flt("evolution", `evo.${tid}.damage`, `${nm}: damage multiplier`, t, "damage", 0, 100);
    flt("evolution", `evo.${tid}.xp`, `${nm}: EXP multiplier`, t, "xp", 0, 100);
    int("evolution", `evo.${tid}.unlock`, `${nm}: unlock Ascension`, t, "unlockAsc", 0, 1000);
    if (!t.event) flt("evolution", `evo.${tid}.weight`, `${nm}: spawn weight`, t, "weight", 0, 100);
    for (const [key, min, max, k] of TIER_EXTRA[tid] ?? []) {
        add("evolution", `evo.${tid}.${key}`, `${nm}: ${key}`, t, key, k === "i" ? "int" : "float", min, max);
    }
}

// Enchanted modifier
flt("evolution", "ench.chance_base", "Enchanted: base chance", ENCHANTED, "CHANCE_BASE", 0, 1);
flt("evolution", "ench.chance_asc", "Enchanted: chance per Ascension", ENCHANTED, "CHANCE_PER_ASC", 0, 1);
flt("evolution", "ench.chance_max", "Enchanted: max chance", ENCHANTED, "CHANCE_MAX", 0, 1);
flt("evolution", "ench.xp", "Enchanted: EXP multiplier", ENCHANTED, "xp", 0, 100);
int("evolution", "ench.shield_ms", "Enchanted: shield return (ms)", ENCHANTED, "shieldIntervalMs", 1000, 600000);
int("evolution", "ench.ess_min", "Enchanted: Essence min", ENCHANTED, "essenceMin", 0, 64);
int("evolution", "ench.ess_max", "Enchanted: Essence max", ENCHANTED, "essenceMax", 0, 64);
int("evolution", "ench.cry_min", "Enchanted: Augment Crystal min", ENCHANTED, "crystalMin", 0, 64);
int("evolution", "ench.cry_max", "Enchanted: Augment Crystal max", ENCHANTED, "crystalMax", 0, 64);

// Nightmare
int("nightmare", "nm.min_asc", "Starts at Ascension", NIGHTMARE, "MIN_ASCENSION", 0, 1000);
int("nightmare", "nm.max_alive", "Max alive near a player", NIGHTMARE, "MAX_ALIVE_NEAR", 0, 100);
int("nightmare", "nm.check_ticks", "Check interval (ticks)", NIGHTMARE, "CHECK_EVERY_TICKS", 20, 24000);
NIGHTMARE.LEVELS.forEach((lv, i) => {
    int("nightmare", `nm.l${i}.days`, `Stage ${NIGHTMARE.LEVELS.length - i}: days without sleep`, lv, "days", 0, 100);
    flt("nightmare", `nm.l${i}.chance`, `Stage ${NIGHTMARE.LEVELS.length - i}: chance per check`, lv, "chance", 0, 1);
});

// Special Mobs & Bosses
int("special", "sp.boss_radius", "Boss ability radius (players in range)", SPECIAL, "BOSS_SCAN_RADIUS", 8, 256);
int("special", "sp.minion_cap", "Boss minions alive near a boss (max)", SPECIAL, "MINION_CAP", 0, 100);
int("special", "sp.minion_radius", "Minion count radius", SPECIAL, "MINION_RADIUS", 8, 256);
int("special", "sp.cleanup_dist", "Remove evolved mobs farther than (blocks)", SPECIAL.CLEANUP, "DISTANCE", 16, 512);
flt("special", "sp.rage_below", "Rage (Vindicator / Brute): below HP fraction", SPECIAL.RAGE, "below", 0, 1);
int("special", "sp.rage_speed", "Rage: Speed level", SPECIAL.RAGE, "speedAmp", 0, 10);
flt("special", "sp.rage_damage", "Rage: extra damage (fraction)", SPECIAL.RAGE, "damageBonus", 0, 10);
function addNumbers(group, idPrefix, labelPrefix, obj) {
    for (const [k, v] of Object.entries(obj)) {
        if (typeof v !== "number") continue;
        const id = `${idPrefix}.${k}`, label = `${labelPrefix}: ${k}`;
        if (k.endsWith("Ms")) int(group, id, label, obj, k, 0, 3600000);
        else if (Number.isInteger(v)) int(group, id, label, obj, k, 0, 1000);
        else flt(group, id, label, obj, k, 0, 100);
    }
}
for (const [gid, g] of Object.entries(SPECIAL_ABILITIES)) {
    for (const [aid, a] of Object.entries(g)) {
        if (a && typeof a === "object" && !Array.isArray(a)) addNumbers("special", `sp.${gid}.${aid}`, `${gid} ${aid}`, a);
    }
}
for (const [typeId, boss] of Object.entries(SPECIAL_BOSSES)) {
    const bid = typeId.replace("minecraft:", "");
    for (const ph of boss.phases) {
        const pid = `sp.boss.${bid}.${ph.id}`, lbl = `${boss.name} ${ph.id}`;
        int("special", `${pid}.unlock`, `${lbl}: unlock Ascension`, ph, "unlockAsc", 0, 1000);
        flt("special", `${pid}.below`, `${lbl}: starts below HP fraction`, ph, "below", 0, 1);
        for (const part of ["aura", "tremor", "summon", "enrage"]) {
            if (ph[part]) addNumbers("special", `${pid}.${part}`, `${lbl} ${part}`, ph[part]);
        }
    }
}

// Chorus costs (roll = both sockets; lock = per socket)
const MATS = [["resonant", "Resonant Ink"], ["stellar", "Stellar Core"]];
for (const tier of Object.keys(CHORUS_ROLL_COST)) {
    for (const [key, name] of MATS) {
        int("chorus", `chorus.roll.${tier}.${key}`, `Roll ${tier}: ${name}`, CHORUS_ROLL_COST[tier], key, 0, 100000);
        int("chorus", `chorus.lock.${tier}.${key}`, `Lock ${tier}: ${name}`, CHORUS_LOCK_COST[tier], key, 0, 100000);
    }
}
flt("chorus", "chorus.single_factor", "Roll one socket: cost fraction", CHORUS_ROLL_SETTINGS, "SINGLE_FACTOR", 0, 1);

// Chorus Fusion: one payment per Fusion (even when it fuses two pieces). Chorus Mastery level gates and Chorus XP per
// Fusion are in the Mastery group (mastery.chorus_xp.awaken / melodious / genesis).
for (const tier of Object.keys(CHORUS_FUSION_COST)) {
    for (const [key, name] of MATS) int("fusion", `fusion.${tier}.${key}`, `Fusion ${tier}: ${name}`, CHORUS_FUSION_COST[tier], key, 0, 100000);
    int("fusion", `fusion.${tier}.prestige`, `Fusion ${tier}: minimum Prestige`, CHORUS_FUSION_UNLOCK[tier], "prestige", 0, 1000);
}

// Gem caps (all Gem sources together) and Rune level multipliers
int("gemrune", "gem.cap.reduction", "Gem cap: damage taken reduction (%)", GEM_CAPS, "dmgReduction", 0, 100);
int("gemrune", "gem.cap.dodge", "Gem cap: Dodge (%)", GEM_CAPS, "dodge", 0, 100);
int("gemrune", "gem.cap.melee", "Gem cap: melee damage bonus (%)", GEM_CAPS, "meleeBonus", 0, 500);
int("gemrune", "gem.cap.speed", "Gem cap: movement speed (%)", GEM_CAPS, "speed", 0, 300);
for (const lv of Object.keys(RUNE_LEVEL_MULT)) flt("gemrune", `rune.level_mult.${lv}`, `Rune Level ${lv}: strength multiplier`, RUNE_LEVEL_MULT, lv, 0, 20);

// Achievements (on/off switches: 1 = on, 0 = off)
int("achievement", "ach.enabled", "Achievement system (1 = on, 0 = off)", ACHIEVEMENT, "ENABLED", 0, 1);
int("achievement", "ach.notify_chat", "Unlock message in chat (1 = on)", ACHIEVEMENT.NOTIFY, "CHAT", 0, 1);
// Toast notifications
int("guide", "guide.enabled", "Guide Quest (1 = on, 0 = off for everyone)", GUIDE, "ENABLED", 0, 1);
int("guide", "guide.interval", "Guide Quest: check interval (ticks)", GUIDE, "CHECK_INTERVAL_TICKS", 5, 400);
int("guide", "guide.next", "Guide Quest: announce the next step (1 = yes)", GUIDE, "NOTIFY_NEXT", 0, 1);
int("guide", "guide.welcome", "Guide Quest: welcome pop-up for new players (1 = yes)", GUIDE, "WELCOME", 0, 1);
int("toast", "toast.enabled", "Toast pop-ups (1 = on, 0 = classic chat / action bar)", TOAST, "ENABLED", 0, 1);
int("toast", "toast.spacing", "Toast: gap between cards (ticks)", TOAST, "SPACING_TICKS", 0, 100);
int("toast", "toast.queue", "Toast: max queued per player", TOAST, "MAX_QUEUE", 1, 100);
int("toast", "toast.send_enabled", "Custom toasts for players (1 = on, 0 = Admin only)", TOAST, "SEND_ENABLED", 0, 1);
int("toast", "toast.send_cost", "Custom toast to another player: Common Gem cost", TOAST, "SEND_COST", 0, 640);
int("toast", "toast.send_cooldown", "Custom toast: cooldown between paid sends (seconds)", TOAST, "SEND_COOLDOWN_SEC", 0, 600);
// Exploration: Waypoint Stone + Discovery Log
int("explore", "wp.enabled", "Waypoint travel (1 = on, 0 = off)", WAYPOINT, "ENABLED", 0, 1);
int("explore", "wp.blocks_per_pearl", "Waypoint: blocks per Ender Pearl", WAYPOINT, "BLOCKS_PER_PEARL", 10, 100000);
int("explore", "wp.min_cost", "Waypoint: minimum cost (pearls)", WAYPOINT, "MIN_COST", 0, 64);
int("explore", "wp.max_cost", "Waypoint: maximum cost / cross-dimension (pearls)", WAYPOINT, "MAX_COST", 1, 64);
int("explore", "wp.cooldown", "Waypoint: stone teleport cooldown (seconds)", WAYPOINT, "COOLDOWN_SEC", 0, 600);
int("explore", "wp.per_player", "Waypoint: named stones owned per player", WAYPOINT, "PER_PLAYER_MAX", 1, 100);
int("explore", "wp.saved_max", "Waypoint: saved stones per player", WAYPOINT, "SAVED_MAX", 1, 150);
int("explore", "wp.special_max", "Waypoint Orb: special points per player", WAYPOINT, "SPECIAL_MAX", 1, 20);
int("explore", "wp.special_cooldown", "Waypoint Orb: special point cooldown (seconds)", WAYPOINT, "SPECIAL_COOLDOWN_SEC", 0, 600);
int("explore", "wp.spacing", "Waypoint: minimum spacing (blocks)", WAYPOINT, "MIN_SPACING", 0, 100);
int("explore", "disc.enabled", "Discovery Log (1 = on, 0 = off)", DISCOVERY, "ENABLED", 0, 1);
int("explore", "disc.show_names", "Show undiscovered names (1 = yes)", DISCOVERY, "SHOW_UNDISCOVERED_NAMES", 0, 1);
int("explore", "disc.xp_biome", "Travel XP: new biome", DISCOVERY, "XP_BIOME", 0, 100000);
int("explore", "disc.xp_other", "Travel XP: biome not in catalog", DISCOVERY, "XP_OTHER_BIOME", 0, 100000);
int("explore", "disc.xp_structure", "Travel XP: new structure", DISCOVERY, "XP_STRUCTURE", 0, 100000);
int("explore", "disc.xp_dimension", "Travel XP: new dimension", DISCOVERY, "XP_DIMENSION", 0, 100000);
int("explore", "disc.scan_radius", "Structure scan radius (blocks)", DISCOVERY, "SCAN_RADIUS", 4, 24);
// Quality of Life
int("qol", "stash.enabled", "Quick Stash (1 = on, 0 = off)", STASH, "ENABLED", 0, 1);
int("qol", "stash.radius", "Quick Stash: search radius (blocks)", STASH, "RADIUS", 1, 12);
int("qol", "stash.cooldown", "Quick Stash: cooldown (seconds)", STASH, "COOLDOWN_SEC", 0, 60);
int("qol", "stash.max_containers", "Quick Stash: max containers used", STASH, "MAX_CONTAINERS", 1, 30);
int("qol", "stash.skip_lore", "Quick Stash: skip items with lore (1 = skip)", STASH, "SKIP_LORE", 0, 1);
int("qol", "replant.enabled", "Re-Crops Rune replanting (1 = on, 0 = off)", REPLANT, "ENABLED", 0, 1);
int("qol", "replant.require_hoe", "Auto-Replant: Hoe required (1 = yes)", REPLANT, "REQUIRE_HOE", 0, 1);
int("qol", "replant.use_inventory", "Auto-Replant: may use a seed from the inventory", REPLANT, "USE_INVENTORY", 0, 1);
int("qol", "aura.enabled", "Chorus Aura (1 = on, 0 = off)", CHORUS_AURA, "ENABLED", 0, 1);
int("qol", "aura.min_slots", "Chorus Aura: element slots needed", CHORUS_AURA, "MIN_SLOTS", 1, 8);
int("qol", "aura.per_tick", "Chorus Aura: base particles per pulse", CHORUS_AURA, "PER_TICK", 1, 8);
// Health Display (HP numbers above mobs and bosses)
int("health", "hd.enabled", "Health Display (1 = on, 0 = off)", HEALTH_DISPLAY, "ENABLED", 0, 1);
int("health", "hd.mobs", "Show on regular mobs (1 = on)", HEALTH_DISPLAY, "SHOW_MOBS", 0, 1);
int("health", "hd.bosses", "Show on bosses (1 = on)", HEALTH_DISPLAY, "SHOW_BOSSES", 0, 1);
int("health", "hd.radius", "Mob range around a player (blocks)", HEALTH_DISPLAY, "SCAN_RADIUS", 8, 64);
int("health", "hd.boss_radius", "Boss range around a player (blocks)", HEALTH_DISPLAY, "BOSS_RADIUS", 16, 128);
int("health", "hd.max_per_scan", "Max mobs shown per scan", HEALTH_DISPLAY, "MAX_PER_SCAN", 10, 300);
int("health", "hd.compact_from", "Shorten numbers (K/M) from this HP", HEALTH_DISPLAY, "COMPACT_FROM", 1000, 1000000);
int("health", "hd.flash_ticks", "Red/green flash time (ticks)", HEALTH_DISPLAY, "FLASH_TICKS", 0, 100);
// Damage Indicator (floating damage numbers; the 2 s lifetime is fixed in the entity file)
int("dmgnum", "di.enabled", "Damage Indicator (1 = on, 0 = off)", DAMAGE_INDICATOR, "ENABLED", 0, 1);
int("dmgnum", "di.max_per_player", "Max numbers alive per player", DAMAGE_INDICATOR, "MAX_PER_PLAYER", 1, 30);
int("dmgnum", "di.merge_ticks", "Merge hits on the same mob within (ticks, 20 = 1 s, 0 = off)", DAMAGE_INDICATOR, "MERGE_TICKS", 0, 40);
int("dmgnum", "di.view_radius", "Show only if the mob is within (blocks)", DAMAGE_INDICATOR, "VIEW_RADIUS", 4, 64);
flt("dmgnum", "di.radius_min", "Spawn distance from the mob: min (blocks)", DAMAGE_INDICATOR, "RADIUS_MIN", 0, 4);
flt("dmgnum", "di.radius_max", "Spawn distance from the mob: max (blocks)", DAMAGE_INDICATOR, "RADIUS_MAX", 0, 4);
flt("dmgnum", "di.height_min", "Spawn height vs. the mob's head: min (blocks)", DAMAGE_INDICATOR, "HEIGHT_MIN", -3, 3);
flt("dmgnum", "di.height_max", "Spawn height vs. the mob's head: max (blocks)", DAMAGE_INDICATOR, "HEIGHT_MAX", -3, 3);
int("achievement", "ach.notify_actionbar", "Unlock text on action bar (1 = on)", ACHIEVEMENT.NOTIFY, "ACTIONBAR", 0, 1);

// ─── State ───────────────────────────────────────────────────────────────────

let overrides = {};   // id -> value

function readJson(key, fallback) {
    try {
        const raw = world.getDynamicProperty(key);
        return typeof raw === "string" && raw.length ? JSON.parse(raw) : fallback;
    } catch (_) { return fallback; }
}

export class AdminManager {

    static isAdmin(player) {
        try { return !!player?.isValid && player.hasTag(ADMIN_TAG); } catch (_) { return false; }
    }

    // ── Config Editor ──

    static entry(id) { return registry.get(id) ?? null; }
    static entriesOf(groupId) { return [...registry.values()].filter((e) => e.group === groupId); }
    static current(id) { const e = registry.get(id); return e ? e.obj[e.key] : undefined; }
    static isOverridden(id) { return Object.prototype.hasOwnProperty.call(overrides, id); }
    static overrideCount() { return Object.keys(overrides).length; }

    static format(entry, value = entry.obj[entry.key]) {
        return typeof value === "number" ? String(Math.round(value * 10000) / 10000) : String(value);
    }

    static describeRange(entry) {
        if (entry.kind === "enum") return entry.options.join(" / ");
        return `${entry.kind === "int" ? "whole number" : "number"} ${entry.min} to ${entry.max}`;
    }

    // Validates raw text -> { ok, value | error }
    static parse(entry, raw) {
        const text = String(raw ?? "").trim();
        if (entry.kind === "enum") {
            const v = text.toLowerCase();
            return entry.options.includes(v) ? { ok: true, value: v } : { ok: false, error: `Use one of: ${entry.options.join(", ")}` };
        }
        const n = Number(text);
        if (text === "" || !Number.isFinite(n)) return { ok: false, error: "Not a number." };
        const v = entry.kind === "int" ? Math.round(n) : n;
        if (v < entry.min || v > entry.max) return { ok: false, error: `Out of range (${this.describeRange(entry)}).` };
        return { ok: true, value: v };
    }

    static _save() {
        try { world.setDynamicProperty(OVERRIDE_KEY, JSON.stringify(overrides)); } catch (_) {}
    }

    static setValue(id, value) {
        const e = registry.get(id);
        if (!e) return false;
        e.obj[e.key] = value;
        if (value === e.def) delete overrides[id]; else overrides[id] = value;
        this._save();
        return true;
    }

    static resetValue(id) {
        const e = registry.get(id);
        if (!e) return false;
        e.obj[e.key] = e.def;
        delete overrides[id];
        this._save();
        return true;
    }

    static resetAll() {
        for (const id of Object.keys(overrides)) { const e = registry.get(id); if (e) e.obj[e.key] = e.def; }
        const n = Object.keys(overrides).length;
        overrides = {};
        this._save();
        return n;
    }

    // Called on worldLoad: re-applies the stored overrides to the live config.
    static applyStored() {
        const stored = readJson(OVERRIDE_KEY, {});
        overrides = {};
        let applied = 0;
        for (const [id, value] of Object.entries(stored)) {
            const e = registry.get(id);
            if (!e) continue;
            const ok = e.kind === "enum" ? e.options.includes(value) : (typeof value === "number" && Number.isFinite(value));
            if (!ok) continue;
            e.obj[e.key] = value;
            overrides[id] = value;
            applied++;
        }
        return applied;
    }

    // ── Audit Log ──

    static log(adminName, text) {
        try {
            const list = readJson(AUDIT_KEY, []);
            list.push({ t: Date.now(), who: adminName, text });
            while (list.length > AUDIT_MAX) list.shift();
            world.setDynamicProperty(AUDIT_KEY, JSON.stringify(list));
        } catch (_) {}
    }

    static getLog() { return readJson(AUDIT_KEY, []); }
}
