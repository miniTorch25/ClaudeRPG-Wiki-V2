// ClaudeRPG PlayerManager — lifecycle and persistent player-data ownership.
// Phase 2: Player & Data Core.
//
// This manager owns initialization/normalization of persistent RPG player data.
// Feature systems should not invent their own player-data initialization.

import { system } from "@minecraft/server";
import { CONFIG } from "../config/config.js";
import { PROG_KEYS } from "../config/progression_config.js";
import { StatsManager } from "./stats_manager.js";
import { HPManager } from "./hp_manager.js";
import { ManaManager } from "./mana_manager.js";
import { HudManager } from "./hud_manager.js";
import { RuntimeState } from "../core/runtime_state.js";
import { ProgressionManager } from "./progression_manager.js";

const STAT_DEFAULTS = {
    stat_level: 0,
    stat_xp: 0,
    stat_points: 0,
    stat_str: 0,
    stat_def: 0,
    stat_agi: 0,
    stat_psi: 0,
    stat_exc: 0,
    stat_mag: 0,
    stat_wis: 0,
    stat_con: 0,
    stat_vit: 0,
    stat_mana: 50,
};

const PLAYER_SCHEMA_VERSION = 2;
const SCHEMA_PROP = "crpg:data_schema";

export class PlayerManager {
    static initialize(player, { resetHp = false } = {}) {
        if (!player) return false;

        this.ensurePersistentData(player);
        this.migrateLevelCap(player);
        ProgressionManager.syncUnlocks(player); // backfill permanent level unlocks for existing saves
        HPManager.recalcMaxHP(player);

        const maxMana = ManaManager.getMaxMana(player);
        const currentMana = StatsManager.getStat(player, "stat_mana", maxMana);
        if (resetHp) {
            HPManager.setHP(player, HPManager.getMaxHP(player));
            ManaManager.setMana(player, maxMana);
        } else {
            ManaManager.setMana(player, Math.min(currentMana, maxMana));
            const hp = HPManager.getHP(player);
            if (hp <= 0) HPManager.setHP(player, HPManager.getMaxHP(player));
            else HPManager.setHP(player, hp);
        }

        RuntimeState.player(player.id).lifecycle.initialized = true;
        RuntimeState.player(player.id).lifecycle.schemaVersion = PLAYER_SCHEMA_VERSION;
        HudManager.markDirty(player);
        return true;
    }

    // One-time migration for the lower Level cap (40 + 20/Prestige) and the higher Points per Level (4).
    // Players above the new cap drop to it (extra XP is discarded). Every allocated stat point goes back
    // to the pool (free respec) and the pool is recomputed: -OLD rate for removed levels, +delta for kept ones.
    static migrateLevelCap(player) {
        if (player.getDynamicProperty(PROG_KEYS.MIGRATION) === 1) return false;
        const OLD_POINTS = 2;
        const oldLevel = Math.max(0, Math.floor(StatsManager.getStat(player, "stat_level", 0)));
        let notice = null;
        if (oldLevel > 0) {
            const newLevel = Math.min(oldLevel, ProgressionManager.getMaxLevel(player));
            StatsManager.refundAllStats(player);
            let points = StatsManager.getStat(player, "stat_points", 0);
            points = Math.max(0, points - OLD_POINTS * (oldLevel - newLevel) + (CONFIG.POINTS_PER_LEVEL - OLD_POINTS) * newLevel);
            StatsManager.setStat(player, "stat_points", points);
            if (newLevel < oldLevel) {
                StatsManager.setStat(player, "stat_level", newLevel);
                StatsManager.setStat(player, "stat_xp", 0);
            }
            notice = `\u00a76[Update] Max Level is now \u00a7f${ProgressionManager.getMaxLevel(player)}\u00a76 and each Level gives \u00a7f${CONFIG.POINTS_PER_LEVEL}\u00a76 Points. ` +
                     (newLevel < oldLevel ? `Your Level was set to \u00a7f${newLevel}\u00a76. ` : "") +
                     `All stat points were refunded (${points} Points) so you can respec for free.`;
        }
        player.setDynamicProperty(PROG_KEYS.MIGRATION, 1);
        if (notice) system.runTimeout(() => { try { if (player.isValid) player.sendMessage(notice); } catch (_) {} }, 100);
        return true;
    }

    static ensurePersistentData(player) {
        let changed = false;
        for (const [key, defaultValue] of Object.entries(STAT_DEFAULTS)) {
            const current = player.getDynamicProperty(key);
            if (typeof current !== "number" || !Number.isFinite(current)) {
                player.setDynamicProperty(key, defaultValue);
                changed = true;
            }
        }

        const schema = player.getDynamicProperty(SCHEMA_PROP);
        if (schema !== PLAYER_SCHEMA_VERSION) {
            player.setDynamicProperty(SCHEMA_PROP, PLAYER_SCHEMA_VERSION);
            changed = true;
        }
        return changed;
    }

    static onInitialSpawn(player) {
        this.initialize(player, { resetHp: true });
        if (CONFIG.WELCOME_MESSAGE) player.sendMessage(CONFIG.WELCOME_MESSAGE);
    }

    static onRespawn(player) {
        // Persistent stats survive; combat resources return to their normal spawn state.
        this.initialize(player, { resetHp: true });
    }

    static onLeave(playerId) {
        RuntimeState.deletePlayer(playerId);
    }

    static getSchemaVersion(player) {
        const value = player.getDynamicProperty(SCHEMA_PROP);
        return typeof value === "number" ? value : 0;
    }
}
