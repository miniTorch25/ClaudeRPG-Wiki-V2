// cost_manager.js -- item costs for Prestige and Ascension (single-material, paid in bulk).
// Pure inventory helpers; no imports from GUI/system files so managers can use it safely.

import { EntityComponentTypes } from "@minecraft/server";
import { ACTION_COSTS } from "../config/progression_config.js";

function inv(player) {
    return player.getComponent(EntityComponentTypes.Inventory)?.container ?? null;
}

export class CostManager {

    static prestigeCost(currentPrestige) {
        const c = ACTION_COSTS.PRESTIGE;
        return Math.max(0, Math.min(c.CAP, c.BASE + Math.floor(c.PER * Math.max(0, currentPrestige))));
    }

    static ascensionCost(currentAscension) {
        const c = ACTION_COSTS.ASCENSION;
        return Math.max(0, Math.min(c.CAP, c.BASE + Math.floor(c.PER * Math.max(0, currentAscension))));
    }

    static count(player, typeId) {
        const container = inv(player);
        if (!container) return 0;
        let n = 0;
        for (let i = 0; i < container.size; i++) {
            const it = container.getItem(i);
            if (it && it.typeId === typeId) n += it.amount;
        }
        return n;
    }

    // All-or-nothing: returns false (and removes nothing) if the player cannot pay.
    static consume(player, typeId, amount) {
        if (amount <= 0) return true;
        if (this.count(player, typeId) < amount) return false;
        const container = inv(player);
        let left = amount;
        for (let i = 0; i < container.size && left > 0; i++) {
            const it = container.getItem(i);
            if (!it || it.typeId !== typeId) continue;
            if (it.amount <= left) { left -= it.amount; container.setItem(i, undefined); }
            else { it.amount -= left; container.setItem(i, it); left = 0; }
        }
        return left === 0;
    }

    // { item, name, need, have, ok } for the Prestige the player is about to do.
    static prestigeStatus(player, currentPrestige) {
        const c = ACTION_COSTS.PRESTIGE, need = this.prestigeCost(currentPrestige), have = this.count(player, c.ITEM);
        return { item: c.ITEM, name: c.NAME, need, have, ok: have >= need };
    }

    static ascensionStatus(player, currentAscension) {
        const c = ACTION_COSTS.ASCENSION, need = this.ascensionCost(currentAscension), have = this.count(player, c.ITEM);
        return { item: c.ITEM, name: c.NAME, need, have, ok: have >= need };
    }
}
