import { XPManager } from "./xp_manager.js";
import { XpNotifier } from "./xp_notifier.js";
import { KillManager } from "./kill_manager.js";

export class MobXpManager {
    // Registers as a KillManager listener instead of subscribing to entityDie directly.
    // KillManager.register() must be called before MobXpManager.register().
    static register() {
        KillManager.addListener((killEvent) => {
            // Only count player kills on non-player entities
            if (!killEvent.isPlayerKill || killEvent.isPlayerVictim) return;
            // mobXp is pre-resolved by KillManager from XP_CONFIG
            if (killEvent.mobXp <= 0) return;

            XPManager.addXp(killEvent.killer, killEvent.mobXp, "Combat", { notify: false });
            XpNotifier.notify(killEvent.killer, killEvent.mobXp, "Combat");
        });
    }
}
