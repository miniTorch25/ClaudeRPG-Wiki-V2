// MovementManager — scripted movement-speed bonus that keeps vanilla Sprint working.
//
// Old behaviour: AugmentManager wrote `movement.setCurrentValue(base * (1 + pct/100))`
// every 10 ticks. That REPLACES the whole attribute value, wiping the engine's
// sprint boost (+30%) and Speed/Slowness effect modifiers -> walking == running.
//
// New behaviour: the % bonus (Augment/Gem/Rune/Perk/Mastery) is cached by
// applyPassiveStats; this tick rebuilds the value INCLUDING vanilla modifiers:
//   value = default * (1 + pct/100) * (1 + 0.2*SpeedLv - 0.15*SlownessLv) * (sprinting ? 1.3 : 1)
// When pct == 0 the attribute is left to the engine (fully vanilla).
import { EntityComponentTypes, system } from "@minecraft/server";

const SPRINT_MULT = 1.3;
const SPEED_PER_LEVEL = 0.2;
const SLOW_PER_LEVEL = 0.15;

const bonusPct = new Map();   // playerId -> % bonus (cached by applyPassiveStats)
const modded = new Set();     // playerIds whose attribute we have overridden
// Scripted "Speed" buffs (replace vanilla Speed potion effect): playerId -> Map(key -> { level, until })
// Same strength as vanilla (+20% per level, highest level wins, no stacking).
const speedBuffs = new Map();

function scriptedSpeedLevel(playerId) {
    const m = speedBuffs.get(playerId);
    if (!m) return 0;
    const now = system.currentTick;
    let best = 0;
    for (const [k, b] of m) {
        if (b.until <= now) { m.delete(k); continue; }
        if (b.level > best) best = b.level;
    }
    if (m.size === 0) speedBuffs.delete(playerId);
    return best;
}

function effectLevel(player, id) {
    try {
        const e = player.getEffect(id);
        return e ? (e.amplifier ?? 0) + 1 : 0;
    } catch { return 0; }
}

function vanillaFactor(player, scriptedLevel = 0) {
    const speedLv = Math.max(effectLevel(player, "speed"), scriptedLevel);
    const f = 1 + SPEED_PER_LEVEL * speedLv - SLOW_PER_LEVEL * effectLevel(player, "slowness");
    return Math.max(0, f) * (player.isSprinting ? SPRINT_MULT : 1);
}

export const MovementManager = {
    setBonus(player, pct) { bonusPct.set(player.id, pct); },

    // Scripted Speed buff. `level` = vanilla amplifier + 1 (Speed I = 1). Re-calling with the
    // same key refreshes it. Different keys / levels coexist; the highest level wins.
    addSpeed(player, key, level, seconds) {
        if (!(level > 0) || !(seconds > 0)) return;
        let m = speedBuffs.get(player.id);
        if (!m) { m = new Map(); speedBuffs.set(player.id, m); }
        m.set(`${key}:${level}`, { level, until: system.currentTick + Math.round(seconds * 20) });
    },
    removeSpeed(player, key) {
        const m = speedBuffs.get(player.id);
        if (!m) return;
        for (const k of [...m.keys()]) if (k.startsWith(`${key}:`)) m.delete(k);
        if (m.size === 0) speedBuffs.delete(player.id);
    },
    // Death clears buffs, like vanilla effects do.
    clear(playerId) { speedBuffs.delete(playerId); },

    // Run every 2 ticks (event_router). Cheap: one component read per player.
    tick(player) {
        const pct = bonusPct.get(player.id) ?? 0;
        const scripted = scriptedSpeedLevel(player.id);
        const isModded = modded.has(player.id);
        if (pct === 0 && scripted === 0 && !isModded) return;   // vanilla untouched
        const movement = player.getComponent(EntityComponentTypes.Movement);
        if (!movement) return;
        try {
            const base = movement.defaultValue ?? 0.1;
            const target = base * (1 + pct / 100) * vanillaFactor(player, scripted);
            if (Math.abs((movement.currentValue ?? 0) - target) > 0.0001) movement.setCurrentValue(Math.max(0, target));
            if (pct === 0 && scripted === 0) modded.delete(player.id);   // final vanilla-equivalent write, then hands off
            else modded.add(player.id);
        } catch { /* component unavailable this tick */ }
    },

    onLeave(playerId) { bonusPct.delete(playerId); modded.delete(playerId); speedBuffs.delete(playerId); }
};
