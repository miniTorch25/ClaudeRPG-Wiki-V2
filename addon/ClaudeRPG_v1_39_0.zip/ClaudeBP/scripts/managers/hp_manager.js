// hp_manager.js — RPG Health Engine
//
// All RPG HP values are stored as dynamic properties on the player so they
// survive across ticks without requiring scoreboard reads on every call.
// Scoreboards (rpg_hp / rpg_max_hp) are synced once per interval for HUD
// and external display; they are never the authoritative source.
//
// API (all static):
//   HPManager.getHP(player)          → number (current RPG HP)
//   HPManager.getMaxHP(player)       → number (max RPG HP)
//   HPManager.setHP(player, value)   — clamp + persist + sync HUD
//   HPManager.setMaxHP(player, val)  — persist + clamp current HP
//   HPManager.addHP(player, amount)  — heal (positive) or damage (negative)
//   HPManager.damage(player, amount) — apply damage (positive = take damage)
//   HPManager.heal(player, amount)   — restore HP (positive)
//   HPManager.isDead(player)         → bool
//   HPManager.kill(player)           — set HP to 0 and trigger DeathManager
//   HPManager.recalcMaxHP(player)    — recompute maxHP from stats + augments
//   HPManager.syncScoreboards(player)— push current values to rpg_hp / rpg_max_hp

import { world } from "@minecraft/server";
import { CONFIG } from "../config/config.js";
import { StatsManager } from "./stats_manager.js";
import { HudManager } from "./hud_manager.js";
import { EventBus } from "../core/event_bus.js";
import { ProgressionManager } from "./progression_manager.js";
import { MasteryManager } from "./mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";

// RuneCN (Curse/Neutral rune modifiers) lazy loader — rune_curseneutral.js
// pulls in rune_manager.js → rune_combat.js → mana_manager.js → augment.js,
// which imports HPManager, so a static import here would be circular.
let _RuneCN = null;
function getRuneCN() {
    if (!_RuneCN) {
        import("../rune/rune_curseneutral.js").then((m) => { _RuneCN = m; }).catch(() => {});
    }
    return _RuneCN;
}

// GemAbility lazy loader — gem_ability.js imports HPManager (for Fortress heal,
// Undying, etc.), so a static import here would be circular.
let _GemAbility = null;
function getGemAbility() {
    if (!_GemAbility) {
        import("../systems/gem_ability.js").then((m) => { _GemAbility = m.GemAbility; }).catch(() => {});
    }
    return _GemAbility;
}

const PROP_HP     = "rpg_hp";
const PROP_MAX_HP = "rpg_max_hp";
const PROP_DEATH_LOCK = "rpg_death_lock";

export class HPManager {

    // ─── Getters ──────────────────────────────────────────────────────────────

    static getHP(player) {
        const v = player.getDynamicProperty(PROP_HP);
        return typeof v === "number" ? v : this.getMaxHP(player);
    }

    static getMaxHP(player) {
        const v = player.getDynamicProperty(PROP_MAX_HP);
        return typeof v === "number" ? v : CONFIG.HP_BASE;
    }

    // ─── Setters ──────────────────────────────────────────────────────────────

    static setHP(player, value) {
        const maxHp   = this.getMaxHP(player);
        const clamped = Math.max(0, Math.min(maxHp, Math.round(value)));
        player.setDynamicProperty(PROP_HP, clamped);
        HudManager.markDirty(player);
        this._mirrorToVanilla(player, clamped, maxHp);
        return clamped;
    }

    static setMaxHP(player, value) {
        const maxHp = Math.max(1, Math.round(value));
        player.setDynamicProperty(PROP_MAX_HP, maxHp);
        // Clamp current HP to new max
        const current = this.getHP(player);
        if (current > maxHp) this.setHP(player, maxHp);
        HudManager.markDirty(player);
    }

    // ─── Damage / Heal ────────────────────────────────────────────────────────

    static damage(player, amount, context = null) {
        if (!player?.isValid || !Number.isFinite(amount) || amount <= 0) return { applied: 0, hp: this.getHP(player), killed: false };
        if (this.isDead(player) || player.getDynamicProperty(PROP_DEATH_LOCK) === true) {
            return { applied: 0, hp: 0, killed: true, ignored: true };
        }

        const takenPct = getRuneCN()?.getDamageTakenPercent(player) ?? 0;
        const scaled = amount * (1 + takenPct / 100);
        const applied = Math.max(0, Math.round(scaled * CONFIG.HP_DAMAGE_SCALE));
        if (applied <= 0) return { applied: 0, hp: this.getHP(player), killed: false };

        MasteryManager.addXp(player, "defense", applied * MASTERY.DEFENSE_XP_PER_DAMAGE);
        const current = this.getHP(player);
        const newHp = current - applied;
        const clamped = this.setHP(player, newHp);
        const killed = clamped <= 0;

        try { getRuneCN()?.onPlayerHurt(player); } catch (_) { /* rune hooks must never break damage */ }   // Hollow Vessel / Mounting Dread
        const result = { applied, hp: clamped, killed, previousHp: current, contextId: context?.id ?? null };
        EventBus.emit("damage:resolved", { context, target: player, result });
        if (killed) this._triggerDeath(player, context);
        return result;
    }

    static heal(player, amount) {
        if (amount <= 0) return;
        const healed = amount * (getRuneCN()?.getHealReceivedMultiplier(player) ?? 1);
        this.setHP(player, this.getHP(player) + healed);
    }

    static addHP(player, amount) {
        if (amount >= 0) this.heal(player, amount);
        else             this.damage(player, -amount);
    }

    // ─── Status ───────────────────────────────────────────────────────────────

    static isDead(player) {
        return this.getHP(player) <= 0;
    }

    static kill(player) {
        if (!player?.isValid || this.isDead(player)) return false;
        this.setHP(player, 0);
        this._triggerDeath(player);
        return true;
    }

    // ─── MaxHP recalculation ──────────────────────────────────────────────────
    // Called after stat allocation, augment changes, and on player spawn.
    // Formula: HP_BASE + (con × HP_PER_CON) + (augmentHealth × HP_AUGMENT_MULT) + gemHpBonus
    // (Def used to contribute flat HP too, but Con already covers that role — removed.)

    static recalcMaxHP(player) {
        const con    = StatsManager.getStat(player, "stat_con", 0);
        const augHp  = player.getDynamicProperty("augment_health") ?? 0;
        const gemHp  = getGemAbility()?.getGemHpBonus(player) ?? 0;

        const base  = CONFIG.HP_BASE
            + (con   * CONFIG.HP_PER_CON)
            + (augHp * CONFIG.HP_AUGMENT_MULT)
            + gemHp
            + ProgressionManager.getPerkValue(player, "max_hp")
            + Math.round(MasteryManager.getBonus(player, "max_health"));

        const hpPct = getRuneCN()?.getHpModPercent(player) ?? 0;
        const maxHp = base * (1 + hpPct / 100);

        this.setMaxHP(player, maxHp);
        return maxHp;
    }

    // ─── Regen (Vit stat) ─────────────────────────────────────────────────────
    // Called once per second from main.js alongside Mana regen.
    // Formula: HP_REGEN_PER_SEC + (vit × HP_REGEN_PER_VIT) + gemRegenBonus (Vigor)

    static getRegenPerSecond(player) {
        const vit      = StatsManager.getStat(player, "stat_vit", 0);
        const gemRegen = getGemAbility()?.getGemRegenBonus(player) ?? 0;
        return CONFIG.HP_REGEN_PER_SEC + (vit * CONFIG.HP_REGEN_PER_VIT) + gemRegen + ProgressionManager.getPerkValue(player, "hp_regen");
    }

    static regenTick(player) {
        if (getRuneCN()?.shouldDisableRegen(player)) return; // Numbness
        const hp    = this.getHP(player);
        const maxHp = this.getMaxHP(player);
        if (hp >= maxHp) return; // nothing to regen
        const regen = this.getRegenPerSecond(player);
        if (regen <= 0) return;
        this.heal(player, regen);
    }

    // ─── Scoreboard sync ─────────────────────────────────────────────────────
    // Called from ScoreboardManager.syncPlayer() once per interval.

    static syncScoreboards(player) {
        const hpObj    = world.scoreboard.getObjective(CONFIG.SCOREBOARDS.hp);
        const maxHpObj = world.scoreboard.getObjective(CONFIG.SCOREBOARDS.maxHp);
        if (!hpObj || !maxHpObj) return;

        try { hpObj.setScore(player,    this.getHP(player));    } catch (_) {}
        try { maxHpObj.setScore(player, this.getMaxHP(player)); } catch (_) {}
    }

    // ─── Internal ─────────────────────────────────────────────────────────────

    // Mirror RPG HP to vanilla HP bar as a fraction so the vanilla bar
    // acts as a visual proxy (vanilla max = 20 hearts = 20 HP units).
    static _mirrorToVanilla(player, currentRpg, maxRpg) {
        try {
            const health    = player.getComponent("minecraft:health");
            if (!health) return;
            const fraction  = maxRpg > 0 ? currentRpg / maxRpg : 0;
            const vanillaHp = Math.max(0.5, fraction * health.effectiveMax);
            health.setCurrentValue(vanillaHp);
        } catch (_) {}
    }

    // Deferred so that death cleanup (respawn, DeathManager) can run after
    // the current event completes.
    static _triggerDeath(player, context = null) {
        if (!player?.isValid) return false;
        if (player.getDynamicProperty(PROP_DEATH_LOCK) === true) return false;
        player.setDynamicProperty(PROP_DEATH_LOCK, true);
        EventBus.emit("player:rpgDeath", { player, context });
        // Import DeathManager lazily to avoid circular dependency.
        import("./death_manager.js").then(({ DeathManager }) => {
            DeathManager.onRpgDeath(player, context);
        }).catch((e) => {
            player.setDynamicProperty(PROP_DEATH_LOCK, false);
            console.warn(`[HPManager] DeathManager import failed: ${e}`);
        });
        return true;
    }

    static clearDeathLock(player) {
        if (!player?.isValid) return;
        player.setDynamicProperty(PROP_DEATH_LOCK, false);
    }
}
