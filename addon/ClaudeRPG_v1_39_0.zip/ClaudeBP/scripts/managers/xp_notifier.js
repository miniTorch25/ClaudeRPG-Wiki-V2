import { StatsManager } from "./stats_manager.js";

export class XpNotifier {
    static notify(player, amount, source) {
        const data  = StatsManager.getPlayerData(player);
        const maxXp = StatsManager.getMaxXp(data.level);
        player.onScreenDisplay.setActionBar(`§a+${amount} Xp §ffrom ${source} §8( §e${data.xp} §8/ §e${maxXp} §8)`);
        player.playSound("random.orb");
    }
}
