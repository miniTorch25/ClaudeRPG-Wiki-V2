// ClaudeRPG FishingXpManager — grants RPG Xp for items caught while fishing.
//
// Bedrock's script API has no "fish caught" event, so a catch is detected by
// correlating the bobber (minecraft:fishing_hook) with the item entity that
// spawns at the bobber when the line is reeled in:
//   1. Every hook is tracked (owner, last position, last tick it was in water).
//   2. An item entity spawning within CATCH_RADIUS of a tracked hook is a catch candidate.
//   3. When the hook is removed (reeled in) the candidate is paid out, once per hook.
// Reeling in a mob, or an empty bobber, spawns no item → no Xp.
//
// Event ownership stays in core/event_router.js, which forwards the entitySpawn /
// entityRemove events to handleEntitySpawn / handleEntityRemove below.

import { system, world } from "@minecraft/server";
import { XPManager } from "./xp_manager.js";
import { XpNotifier } from "./xp_notifier.js";
import { MasteryManager } from "./mastery_manager.js";
import { FISHING_XP_CONFIG } from "../config/xp_config.js";
import { onFishCaught } from "../systems/achievement_hooks.js";

const HOOK_TYPE_ID = "minecraft:fishing_hook";
const ITEM_TYPE_ID = "minecraft:item";
const CATCH_RADIUS = 2.5;      // max distance between the hook and the caught item's spawn point
const GRACE_TICKS = 4;         // how long a removed hook can still claim a spawning item
const WATER_TICKS = 10;        // hook must have been in water within this many ticks
const CATEGORY_COLOR = { fish: "§b", junk: "§7", treasure: "§6" };

// hookId -> { hookId, ownerId, dimension, loc, lastWaterTick, removedTick, candidate, paid }
const hooks = new Map();

function distSq(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return dx * dx + dy * dy + dz * dz;
}

function resolveOwnerId(hook) {
    try {
        const owner = hook.getComponent("minecraft:projectile")?.owner;
        if (owner?.typeId === "minecraft:player") return owner.id;
    } catch (_) { /* owner not available yet */ }
    return null;
}

function isInWater(hook) {
    try {
        const block = hook.dimension.getBlock(hook.location);
        return !!block && (block.isLiquid || block.typeId === "minecraft:water" || block.typeId === "minecraft:flowing_water");
    } catch (_) { return false; }
}

function readItem(itemEntity) {
    try {
        const stack = itemEntity.getComponent("minecraft:item")?.itemStack;
        if (!stack) return null;
        const enchants = stack.getComponent("minecraft:enchantable")?.getEnchantments?.() ?? [];
        return { typeId: stack.typeId, enchanted: enchants.length > 0 };
    } catch (_) { return null; }
}

function resolveXp(item) {
    const cfg = FISHING_XP_CONFIG[item.typeId];
    if (!cfg) return null;
    if (item.enchanted && cfg.enchantedXp) return { xp: cfg.enchantedXp, category: "treasure" };
    return { xp: cfg.xp, category: cfg.category };
}

function pay(entry, item) {
    if (entry.paid) return;
    const result = resolveXp(item);
    if (!result || result.xp <= 0) return;
    const player = world.getAllPlayers().find((p) => p.id === entry.ownerId);
    if (!player?.isValid) return;
    entry.paid = true;
    const xp = Math.round(result.xp * (1 + MasteryManager.getBonus(player, "fishing_xp") / 100));
    XPManager.addXp(player, xp, "Fishing", { notify: false });
    XpNotifier.notify(player, xp, `${CATEGORY_COLOR[result.category] ?? "§f"}Fishing`);
    MasteryManager.onFish(player, result.xp, result.category);
    onFishCaught(player, item.typeId, result.category);
}

export class FishingXpManager {
    static handleEntitySpawn(event) {
        const entity = event.entity;
        if (!entity?.isValid) return;

        if (entity.typeId === HOOK_TYPE_ID) {
            hooks.set(entity.id, {
                hookId: entity.id, ownerId: resolveOwnerId(entity), dimension: entity.dimension,
                loc: { ...entity.location }, lastWaterTick: -999, removedTick: null, candidate: null, paid: false,
            });
            return;
        }

        if (entity.typeId !== ITEM_TYPE_ID || hooks.size === 0) return;
        const now = system.currentTick;
        const loc = entity.location;
        const item = readItem(entity);
        if (!item || !FISHING_XP_CONFIG[item.typeId]) return;

        for (const entry of hooks.values()) {
            if (entry.paid || entry.dimension.id !== entity.dimension.id) continue;
            if (now - entry.lastWaterTick > WATER_TICKS) continue;
            if (distSq(entry.loc, loc) > CATCH_RADIUS * CATCH_RADIUS) continue;
            if (entry.removedTick !== null) {
                // Hook already reeled in this tick → the spawning item is the catch.
                if (now - entry.removedTick <= GRACE_TICKS) pay(entry, item);
            } else if (!entry.candidate) {
                // Item appeared before the hook removal event → wait for the reel-in.
                entry.candidate = item;
            }
            break;
        }
    }

    static handleEntityRemove(event) {
        const entry = hooks.get(event.removedEntityId);
        if (!entry) return;
        entry.removedTick = system.currentTick;
        if (entry.candidate) pay(entry, entry.candidate);
    }

    // Runs every tick (cheap: the map is empty unless someone is fishing).
    static tick() {
        if (hooks.size === 0) return;
        const now = system.currentTick;
        for (const [id, entry] of hooks) {
            if (entry.removedTick !== null) {
                if (now - entry.removedTick > GRACE_TICKS) hooks.delete(id);
                continue;
            }
            let hook;
            try { hook = world.getEntity(id); } catch (_) { hook = null; }
            if (!hook?.isValid) {
                // Removed without an event we saw (unload, death, etc.) → treat as reeled in.
                entry.removedTick = now;
                if (entry.candidate) pay(entry, entry.candidate);
                continue;
            }
            entry.loc = { ...hook.location };
            if (!entry.ownerId) entry.ownerId = resolveOwnerId(hook);
            if (isInWater(hook)) entry.lastWaterTick = now;
        }
    }
}
