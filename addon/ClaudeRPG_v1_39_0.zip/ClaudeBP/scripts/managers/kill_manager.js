// KillManager — single subscriber for entityDie that builds a KillEvent
// and dispatches it to all registered listeners in a defined order.
//
// KillEvent shape:
// {
//   killer:        Player | null,       // the player who dealt the kill (null if not player)
//   victim:        Entity,              // the entity that died
//   damageSource:  EntityDamageSource,  // raw Bedrock damage source
//   weapon:        ItemStack | null,    // mainhand item of killer at kill time
//   weaponTypeId:  string | null,       // typeId of weapon (from projectile tag or mainhand)
//   isPlayerKill:  bool,                // killer is a player
//   isPlayerVictim:bool,                // victim is a player
//   isBoss:        bool,                // via mob_config
//   isGiant:       bool,                // via mob_config
//   isUndead:      bool,                // via mob_config
//   soulValue:     number,              // soul count for Soul Reaper rune
//   mobXp:         number,              // ClaudeRPG XP value from mob_config
// }

import { world, EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { MOB_CONFIG, getMobMeta } from "../config/mob_config.js";
import { XP_CONFIG } from "../config/xp_config.js";
import { EvolutionManager } from "./evolution_manager.js";

// Listeners registered via KillManager.addListener(fn)
// Each fn receives a KillEvent and is called in registration order.
const listeners = new Set();
let registered = false;

function buildKillEvent(event) {
    const { deadEntity, damageSource } = event;

    const rawKiller   = damageSource?.damagingEntity ?? null;
    const isPlayer    = rawKiller?.typeId === "minecraft:player";
    const killer      = isPlayer ? rawKiller : null;

    // Resolve weapon: prefer projectile tag (set at fire time), fall back to current mainhand
    let weapon       = null;
    let weaponTypeId = null;
    if (killer) {
        const projectile = damageSource?.damagingProjectile;
        weaponTypeId     = projectile?.getDynamicProperty("crpg:weapon_typeid") ?? null;

        const equipment    = killer.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (mainhandSlot?.hasItem()) {
            weapon       = mainhandSlot.getItem();
            weaponTypeId = weaponTypeId ?? weapon.typeId;
        }
    }

    const meta = getMobMeta(deadEntity.typeId);
    const xpEntry = XP_CONFIG[deadEntity.typeId];

    return {
        killer,
        victim:         deadEntity,
        damageSource,
        weapon,
        weaponTypeId,
        isPlayerKill:   !!killer,
        isPlayerVictim: deadEntity.typeId === "minecraft:player",
        isBoss:         meta?.tags?.includes("boss")  ?? false,
        isGiant:        meta?.tags?.includes("giant") ?? false,
        isUndead:       meta?.tags?.includes("undead") ?? false,
        soulValue:      meta?.soulValue ?? 0,
        mobXp:          (xpEntry?.type === "mob" ? Math.round(xpEntry.xp * EvolutionManager.getXpMult(deadEntity)) : 0),
    };
}

export class KillManager {
    // Register a listener function — called in order on every entity death.
    // fn(killEvent: KillEvent) — return value is ignored.
    static addListener(fn) {
        if (typeof fn !== "function") throw new TypeError("KillManager listener must be a function");
    listeners.add(fn);
    }

    static register() {
        if (registered) return false;
        registered = true;
        world.afterEvents.entityDie.subscribe((event) => {
            try {
                const killEvent = buildKillEvent(event);
                for (const fn of [...listeners]) {
                    try { fn(killEvent); } catch (err) {
                        console.warn(`[KillManager] Listener error: ${err}`);
                    }
                }
            } catch (err) {
                console.warn(`[KillManager] Failed to build KillEvent: ${err}`);
            }
        });
    }
}
