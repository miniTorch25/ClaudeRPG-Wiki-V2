// ClaudeRPG XPManager — single owner of the main RPG XP / Level progression.
// Phase 8: XP & Progression Core.
//
// Persistent XP/level/points remain player dynamic properties, while this
// manager owns mutation, level-up calculation, source metadata and progression
// events. Feature systems should call XPManager.addXp() rather than modifying
// stat_xp/stat_level/stat_points directly.

import { CONFIG } from "../config/config.js";
import { EventBus } from "../core/event_bus.js";
import { HudManager } from "./hud_manager.js";
import { ProgressionManager } from "./progression_manager.js";
import { MasteryManager } from "./mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";

let _RuneCN = null;
function getRuneCN() {
    if (!_RuneCN) {
        import("../rune/rune_curseneutral.js").then((m) => { _RuneCN = m; }).catch(() => {});
    }
    return _RuneCN;
}

const SOURCE_NAMES = new Set(["Combat", "Mining", "Eating", "Fishing", "Vein", "Scholar's Mark", "System"]);

export class XPManager {
    static get(player, key, fallback = 0) {
        const value = player?.getDynamicProperty(key);
        return typeof value === "number" && Number.isFinite(value) ? value : fallback;
    }

    static getLevel(player) { return Math.max(0, Math.floor(this.get(player, "stat_level", 0))); }
    // XP is a whole number everywhere. Older saves may hold a fractional value:
    // it is read rounded down and rewritten as an integer by normalizeXp / the next gain.
    static getXp(player) { return Math.max(0, Math.floor(this.get(player, "stat_xp", 0))); }

    static normalizeXp(player) {
        const raw = player?.getDynamicProperty("stat_xp");
        if (typeof raw === "number" && Number.isFinite(raw) && raw !== Math.floor(raw)) {
            player.setDynamicProperty("stat_xp", Math.max(0, Math.floor(raw)));
        }
    }
    static getPoints(player) { return Math.max(0, this.get(player, "stat_points", 0)); }

    static getMaxXp(level) {
        const L = Math.max(0, level);
        const soft = CONFIG.XP_SOFT_LEVEL ?? Infinity;
        const steps = Math.min(L, soft) + Math.max(0, L - soft) * (CONFIG.XP_SOFT_FACTOR ?? 1);
        return Math.max(1, Math.round(CONFIG.BASE_MAX_XP + steps * CONFIG.XP_PER_LEVEL_INCREASE));
    }

    static getProgress(player) {
        const level = this.getLevel(player);
        const xp = this.getXp(player);
        const maxXp = this.getMaxXp(level);
        return { level, xp, maxXp, points: this.getPoints(player), percent: Math.min(100, (xp / maxXp) * 100) };
    }

    static addXp(player, amount, source = "System", { notify = true, reason = source } = {}) {
        if (!player || player.typeId !== "minecraft:player") return { gained: 0, levels: 0, level: 0, xp: 0 };
        const numericAmount = Number(amount);
        if (!Number.isFinite(numericAmount) || numericAmount <= 0) return { gained: 0, levels: 0, level: this.getLevel(player), xp: this.getXp(player) };

        const safeSource = SOURCE_NAMES.has(source) ? source : "System";
        const maxLevel = ProgressionManager.getMaxLevel(player);
        if (this.getLevel(player) >= maxLevel) {
            // At Max Level XP no longer accumulates (Prestige raises the cap), but Leveling Mastery still learns.
            MasteryManager.addXp(player, "leveling", numericAmount * MASTERY.LEVELING_XP_RATIO);
            return { gained: 0, levels: 0, level: this.getLevel(player), xp: 0, capped: true };
        }

        const xpMod = getRuneCN()?.getXpModPercent(player) ?? 0;
        const perkXp = ProgressionManager.getPerkValue(player, "exp");
        const masteryXp = MasteryManager.getBonus(player, "xp_bonus");
        // Whole XP only: round to nearest, but any real gain is worth at least 1.
        // Prestige veteran bonus + Ascension bonus (the harder world pays more XP).
        const worldXp = ProgressionManager.getPrestigeXpBonus(player) + ProgressionManager.getAscensionXpBonus();
        const gained = Math.max(1, Math.round(numericAmount * (1 + (xpMod + perkXp + masteryXp + worldXp) / 100)));
        MasteryManager.addXp(player, "leveling", numericAmount * MASTERY.LEVELING_XP_RATIO);
        const bonusPoints = Math.max(0, Math.round(MasteryManager.getBonus(player, "points_per_level")));
        let level = this.getLevel(player);
        let xp = this.getXp(player) + gained;
        let points = this.getPoints(player);
        const startLevel = level;
        const levelUps = [];

        while (level < maxLevel && xp >= this.getMaxXp(level)) {
            xp -= this.getMaxXp(level);
            level++;
            points += CONFIG.POINTS_PER_LEVEL + bonusPoints;
            levelUps.push(level);
        }
        const reachedMax = level >= maxLevel;
        if (reachedMax) xp = 0;

        player.setDynamicProperty("stat_level", level);
        player.setDynamicProperty("stat_xp", xp);
        player.setDynamicProperty("stat_points", points);
        ProgressionManager.syncUnlocks(player);
        HudManager.markDirty(player);

        const result = { gained, levels: level - startLevel, level, xp, maxXp: this.getMaxXp(level), points };
        EventBus.emit("xp:gained", { player, amount: gained, source: safeSource, reason, result });

        for (const newLevel of levelUps) {
            const payload = { player, level: newLevel, pointsGained: CONFIG.POINTS_PER_LEVEL + bonusPoints, source: safeSource };
            EventBus.emit("progression:levelUp", payload);
            player.sendMessage(`§a[Status System] Level Up! You reached Level ${newLevel} (+${CONFIG.POINTS_PER_LEVEL + bonusPoints} Points)`);
            player.playSound("random.levelup");
        }

        if (reachedMax && levelUps.length) {
            player.sendMessage(`§6[Status System] You reached the Max Level (Lv.${maxLevel}).`);
        }
        if (notify && !reachedMax) this.notify(player, gained, safeSource);
        return result;
    }

    static notify(player, amount, source) {
        if (!player) return;
        const progress = this.getProgress(player);
        player.onScreenDisplay.setActionBar(`§a+${amount} Xp §ffrom ${source} §8( §e${progress.xp} §8/ §e${progress.maxXp} §8)`);
        player.playSound("random.orb");
    }

    static setXp(player, amount) {
        if (!player) return false;
        const maxXp = this.getMaxXp(this.getLevel(player));
        const xp = Math.max(0, Math.min(Math.floor(Number(amount) || 0), Math.max(0, maxXp - 1)));
        player.setDynamicProperty("stat_xp", xp);
        HudManager.markDirty(player);
        return true;
    }

    static setLevel(player, level, { preserveXp = false } = {}) {
        if (!player) return false;
        const nextLevel = Math.max(0, Math.floor(Number(level) || 0));
        player.setDynamicProperty("stat_level", nextLevel);
        if (!preserveXp) player.setDynamicProperty("stat_xp", 0);
        HudManager.markDirty(player);
        ProgressionManager.syncUnlocks(player);
        EventBus.emit("progression:levelSet", { player, level: nextLevel });
        return true;
    }

    static addStatPoints(player, amount) {
        if (!player) return false;
        const numeric = Math.floor(Number(amount) || 0);
        if (!numeric) return false;
        const next = Math.max(0, this.getPoints(player) + numeric);
        player.setDynamicProperty("stat_points", next);
        HudManager.markDirty(player);
        return true;
    }
}
