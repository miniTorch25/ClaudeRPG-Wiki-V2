// evolution_manager.js -- Mob Evolution: assigns a tier to new hostile mobs and runs the
// tier abilities. Keeps only config + ProgressionManager as imports so damage / kill /
// HP code can use it without cycles.
//
// Entity markers:   tag "crpg_evo" (query filter) + property "crpg:evo" = tier id
//                   property "crpg:evo_pw" = tier power scale, "crpg:mut" = Awaken mutation
//                   tag "crpg_summoned" = called by an Elite/Awakened zombie, never evolves

import { LootBonus } from "../systems/loot_bonus.js";
import { world, system, ItemStack } from "@minecraft/server";
import { EVOLUTION, AWAKEN_ABILITIES, ENCHANTED } from "../config/evolution_config.js";
import { ProgressionManager } from "./progression_manager.js";
import { MasteryManager } from "./mastery_manager.js";
import { MOB_SCALING } from "../config/progression_config.js";
import { XP_CONFIG } from "../config/xp_config.js";
import { isBoss } from "../config/mob_config.js";
import { isHpOnlyName } from "../systems/health_display_name.js";
import { SPECIAL, SPECIAL_BOSSES, evolvedName } from "../config/special_config.js";

const TAG_EVO = "crpg_evo";
const TAG_SUMMONED = "crpg_summoned";
const TAG_CALLED = "crpg_elite_called";
const TAG_HOT = "crpg_sculk_hot";
const TAG_BERSERK = "crpg_berserk";
const TAG_AW_CALLED = "crpg_awaken_called";
const TAG_BOSS_ENRAGE = "crpg_boss_enrage";
const PROP_TIER = "crpg:evo";
const PROP_POWER = "crpg:evo_pw";
const PROP_MUT = "crpg:mut";
// Enchanted modifier (separate from the tier, so it can pair with any tier except Core)
const TAG_ENCH = "crpg_ench";
const PROP_ENCH = "crpg:ench";
const PROP_SHIELD = "crpg:ench_shield";          // true while the shield is up
const PROP_SHIELD_READY = "crpg:ench_ready";      // ms timestamp the next shield appears
const PROP_AUTONAME = "crpg:autoname";            // true when the name tag was set by us (safe to rewrite)
const PROP_ANCHOR = ["crpg:ax", "crpg:ay", "crpg:az"];   // Core: where it must stay

const tickHooks = [];            // extra per-mob tick handlers (special_mob_manager registers here)
const tierCache = new Map();   // entityId -> tier info (entity may already be invalid on death)
const enchCache = new Set();   // entityIds known to be Enchanted (same reason)

function eligible(entity) {
    const id = entity?.typeId;
    if (!id || id === "minecraft:player") return false;
    if (isBoss(id) || MOB_SCALING.EXCLUDE.includes(id) || EVOLUTION.EXCLUDE.includes(id)) return false;
    return XP_CONFIG[id]?.type === "mob";
}

function abilityGroup(typeId) {
    for (const [key, g] of Object.entries(AWAKEN_ABILITIES)) if (g.types.includes(typeId)) return key;
    return null;
}

export class EvolutionManager {

    // ─── Tier lookup ─────────────────────────────────────────────────────────

    // { id, ...tier config, power, mut } or null
    static getTier(entity) {
        try {
            if (entity?.isValid) {
                const cached = tierCache.get(entity.id);
                if (cached && cached._t === system.currentTick) return cached.id ? cached : null;
                const id = entity.getDynamicProperty(PROP_TIER);
                if (typeof id !== "string" || !EVOLUTION.TIERS[id]) return null;
                const pw = entity.getDynamicProperty(PROP_POWER);
                const mut = entity.getDynamicProperty(PROP_MUT);
                const info = { id, ...EVOLUTION.TIERS[id], power: typeof pw === "number" ? pw : 1, mut: typeof mut === "string" ? mut : null, _t: system.currentTick };
                tierCache.set(entity.id, info);
                return info;
            }
        } catch (_) {}
        return tierCache.get(entity?.id) ?? null;
    }

    static getTierId(entity) { return this.getTier(entity)?.id ?? null; }

    // Stat bonus above x1 is scaled by the tier's power (Inferno: x3 in the Nether, x0 elsewhere)
    static _scaled(base, power) { return 1 + (base - 1) * power; }

    static getHpMult(entity) {
        const t = this.getTier(entity);
        if (!t) return 1;
        let m = this._scaled(t.hp, t.power);
        if (t.id === "awaken" && t.mut) {
            const mut = t.mutations[t.mut];
            if (mut?.hp) m *= mut.hp;
        }
        return m;
    }

    static getXpMult(entity) {
        const t = this.getTier(entity);
        const base = t ? this._scaled(t.xp, t.power) : 1;
        return this.isEnchanted(entity) ? base * ENCHANTED.xp : base;
    }

    // Extra damage (fraction) of a boss in an Enrage phase (Special Bosses). 0 when not enraged.
    static _bossEnrageBonus(entity) {
        try {
            if (!entity?.isValid || !entity.hasTag(TAG_BOSS_ENRAGE)) return 0;
            const phases = SPECIAL_BOSSES[entity.typeId]?.phases ?? [];
            let best = 0;
            for (const ph of phases) if (ph.enrage) best = Math.max(best, ph.enrage.damageBonus ?? 0);
            return best;
        } catch (_) { return 0; }
    }

    // Damage multiplier to players (1 = none), including situational bonuses.
    static getDamageMult(entity) {
        const t = this.getTier(entity);
        const enchMul = this.isEnchanted(entity) ? ENCHANTED.damage : 1;
        if (!t) return (1 + this._bossEnrageBonus(entity)) * enchMul;
        let m = this._scaled(t.damage, t.power) * enchMul;
        // Evolution x Ascension: every evolved mob also scales with the world's Ascension.
        m *= Math.min(EVOLUTION.ASC_DAMAGE.CAP, 1 + EVOLUTION.ASC_DAMAGE.PER_ASC * ProgressionManager.getAscension());
        try {
            if (t.id === "sculk" && entity.hasTag(TAG_HOT)) m += t.hotDamageBonus;
            if (t.id === "awaken") {
                const mut = t.mutations[t.mut];
                if (mut?.damage) m += mut.damage;
                if (entity.hasTag(TAG_BERSERK)) {
                    m += SPECIAL.RAGE.types.includes(entity.typeId) ? SPECIAL.RAGE.damageBonus : AWAKEN_ABILITIES.zombie.berserk.damageBonus;
                }
            }
        } catch (_) {}
        return m;
    }

    // Tiers that can be rolled on spawn for THIS mob (unlocked, not event-only, type-supported).
    static _poolFor(entity) {
        const asc = ProgressionManager.getAscension();
        return Object.entries(EVOLUTION.TIERS)
            .filter(([, t]) => !t.event && t.unlockAsc <= asc && (!t.types || t.types.includes(entity.typeId)) && !(t.exclude && t.exclude.includes(entity.typeId)) && (t.weight ?? 1) > 0)
            .map(([id]) => id);
    }

    static getUnlockedTiers() {
        const asc = ProgressionManager.getAscension();
        return Object.entries(EVOLUTION.TIERS).filter(([, t]) => !t.event && t.unlockAsc <= asc).map(([id]) => id);
    }

    // ─── Assignment (entitySpawn) ────────────────────────────────────────────

    static _apply(entity, tierId, power = 1) {
        entity.setDynamicProperty(PROP_TIER, tierId);
        entity.setDynamicProperty(PROP_POWER, power);
        entity.addTag(TAG_EVO);
        if (tierId === "awaken") {
            const keys = Object.keys(EVOLUTION.TIERS.awaken.mutations);
            entity.setDynamicProperty(PROP_MUT, keys[Math.floor(Math.random() * keys.length)]);
        }
        if (tierId === "core") {
            try { entity.addEffect("slowness", 60, { amplifier: EVOLUTION.TIERS.core.immobileAmp, showParticles: false }); } catch (_) {}
        }
        this._applyName(entity, tierId);
        system.runTimeout(() => { try { if (entity.isValid && (!entity.nameTag || isHpOnlyName(entity.nameTag))) this._applyName(entity, tierId); } catch (_) {} }, 5);
    }

    // "<Tier> <Mob>" (and an "Enchanted" prefix) name above the mob.
    // Never overwrites a name a player gave it; may rewrite a name we set ourselves.
    static _applyName(entity, tierId) {
        try {
            if (!SPECIAL.NAMING.ENABLED) return;
            if (entity.nameTag && !isHpOnlyName(entity.nameTag) && entity.getDynamicProperty(PROP_AUTONAME) !== true) return;   // an HP-only tag (Health Display) is not a real name
            const t = tierId ? EVOLUTION.TIERS[tierId] : null;
            const ench = this.isEnchanted(entity);
            if (!t && !ench) return;
            let mutName = null;
            if (tierId === "awaken") {
                const m = entity.getDynamicProperty(PROP_MUT);
                mutName = t.mutations?.[m]?.name ?? null;
            }
            let name = evolvedName(t ?? ENCHANTED, entity.typeId, mutName);
            if (t && ench) name = `§l${ENCHANTED.color}${ENCHANTED.name}§r ${name}`;
            entity.nameTag = name;
            entity.setDynamicProperty(PROP_AUTONAME, true);
        } catch (e) { console.warn(`[Evolution] name apply failed: ${e}`); }
    }

    // ─── Enchanted modifier ──────────────────────────────────────────────────

    static isEnchanted(entity) {
        try {
            if (entity?.isValid) {
                const v = entity.hasTag(TAG_ENCH);
                if (v) enchCache.add(entity.id);
                return v;
            }
        } catch (_) {}
        return enchCache.has(entity?.id);
    }

    static _applyEnchanted(entity) {
        if (this.getTierId(entity) === "core") return false;
        entity.addTag(TAG_EVO);   // shares the ability scan / area cap with evolved mobs
        entity.addTag(TAG_ENCH);
        entity.setDynamicProperty(PROP_ENCH, true);
        entity.setDynamicProperty(PROP_SHIELD, true);   // starts shielded
        enchCache.add(entity.id);
        this._applyName(entity, this.getTierId(entity));
        return true;
    }

    // Shield up? Lazily brings it back once its timer ran out.
    static _shieldUp(mob) {
        if (mob.getDynamicProperty(PROP_SHIELD) === true) return true;
        const ready = mob.getDynamicProperty(PROP_SHIELD_READY);
        if (typeof ready === "number" && Date.now() >= ready) {
            mob.setDynamicProperty(PROP_SHIELD, true);
            return true;
        }
        return false;
    }

    // Called by the combat pipeline for every entity-sourced hit. True = hit fully absorbed.
    static tryAbsorb(victim, attacker) {
        try {
            if (!victim?.isValid || victim.typeId === "minecraft:player" || !victim.hasTag(TAG_ENCH)) return false;
            if (!this._shieldUp(victim)) return false;
            victim.setDynamicProperty(PROP_SHIELD, false);
            victim.setDynamicProperty(PROP_SHIELD_READY, Date.now() + ENCHANTED.shieldIntervalMs);
            const at = { x: victim.location.x, y: victim.location.y + 1.0, z: victim.location.z };
            try { victim.dimension.spawnParticle("minecraft:totem_particle", at); } catch (_) {}
            try { victim.dimension.playSound("random.glass", at, { volume: 0.8 }); } catch (_) {}
            if (attacker?.typeId === "minecraft:player") {
                try { attacker.onScreenDisplay.setActionBar("§t✦ Enchanted shield blocked your hit"); } catch (_) {}
            }
            return true;
        } catch (_) { return false; }
    }

    static _tickEnchanted(mob) {
        if (!this._shieldUp(mob)) return;
        const base = Date.now() / 400;
        for (let i = 0; i < 3; i++) {
            const a = base + i * 2.094;
            try {
                mob.dimension.spawnParticle(ENCHANTED.shieldParticle, {
                    x: mob.location.x + Math.cos(a) * 0.7, y: mob.location.y + 1.0, z: mob.location.z + Math.sin(a) * 0.7,
                });
            } catch (_) {}
        }
    }

    // ─── Core: pinned in place ───────────────────────────────────────────────

    static _tickCore(mob, t) {
        mob.addEffect("slowness", 60, { amplifier: t.immobileAmp, showParticles: false });
        const [ax, ay, az] = PROP_ANCHOR.map((k) => mob.getDynamicProperty(k));
        if (typeof ax !== "number" || typeof ay !== "number" || typeof az !== "number") {
            if (mob.isOnGround) {
                const l = mob.location;
                mob.setDynamicProperty(PROP_ANCHOR[0], l.x);
                mob.setDynamicProperty(PROP_ANCHOR[1], l.y);
                mob.setDynamicProperty(PROP_ANCHOR[2], l.z);
            }
            return;
        }
        const l = mob.location;
        const dx = l.x - ax, dz = l.z - az;
        if (dx * dx + dz * dz > t.anchorSnap * t.anchorSnap || Math.abs(l.y - ay) > 1.5) {
            mob.teleport({ x: ax, y: ay, z: az });
            try { mob.clearVelocity(); } catch (_) {}
        }
    }

    // ─── Stellar Core: force-evolve ──────────────────────────────────────────

    // { options: [{ id, name, color }], error? }  — what a Stellar Core may do to this mob right now.
    static forceOptions(entity) {
        if (!entity?.isValid || !eligible(entity)) return { options: [], error: "ineligible" };
        const cur = this.getTierId(entity);
        if (cur === "core") return { options: [], error: "core" };
        const options = [];
        if (!cur) {
            for (const id of this._poolFor(entity)) {
                const t = EVOLUTION.TIERS[id];
                if (t.noForce) continue;
                options.push({ id, name: t.name, color: t.color });
            }
        }
        if (!this.isEnchanted(entity)) options.push({ id: "enchanted", name: ENCHANTED.name, color: ENCHANTED.color });
        return { options, error: options.length ? null : "nothing" };
    }

    static forceApply(entity, optionId) {
        try {
            if (!entity?.isValid) return false;
            if (optionId === "enchanted") return this._applyEnchanted(entity);
            const t = EVOLUTION.TIERS[optionId];
            if (!t || t.noForce || t.event || this.getTierId(entity)) return false;
            let power = 1;
            if (optionId === "inferno") power = entity.dimension.id === "minecraft:nether" ? t.netherPower : t.otherPower;
            this._apply(entity, optionId, power);
            tierCache.delete(entity.id);
            this.getTier(entity);
            return true;
        } catch (_) { return false; }
    }

    // Register a function (mob, tier, players) run for every evolved mob in the ability scan.
    static addTickHook(fn) { if (typeof fn === "function") tickHooks.push(fn); }

    // Sculk Potion: turns a mob into a Sculk Evolve regardless of the world's Ascension.
    // Returns "ok" | "already" | "ineligible" | "enchanted" | "locked" | "error". Only "ok" should consume the potion.
    // The mob is tagged crpg_potion_sculk so it never drops the guaranteed Echo Shards (anti-farm).
    static applySculkPotion(entity) {
        try {
            if (!entity?.isValid || !eligible(entity)) return "ineligible";
            if (this.isEnchanted(entity)) return "enchanted";
            const cur = this.getTier(entity);
            if (cur) {
                if (cur.id === "sculk") return "already";
                if (cur.event || cur.id === "core" || cur.noForce) return "locked";
            }
            this._apply(entity, "sculk", 1);
            entity.addTag("crpg_potion_sculk");
            tierCache.delete(entity.id);
            this.getTier(entity);
            return "ok";
        } catch (_) { return "error"; }
    }

    // Used by the Nightmare event to create an event-tier mob directly.
    static makeEvolved(entity, tierId) {
        try {
            if (tierId === "enchanted") { this._applyEnchanted(entity); return; }
            let power = 1;
            if (tierId === "inferno") {
                const t = EVOLUTION.TIERS.inferno;
                power = entity.dimension.id === "minecraft:nether" ? t.netherPower : t.otherPower;
            }
            this._apply(entity, tierId, power);
            tierCache.delete(entity.id);
        } catch (_) {}
    }

    static _areaFull(entity) {
        const nearby = entity.dimension.getEntities({
            tags: [TAG_EVO], location: entity.location, maxDistance: EVOLUTION.AREA_RADIUS, closest: EVOLUTION.AREA_CAP,
        }).length;
        return nearby >= EVOLUTION.AREA_CAP;
    }

    // Rolls + applies a tier. Returns the tier id or null.
    static _rollTier(entity, asc) {
        const chance = Math.min(EVOLUTION.CHANCE_MAX, EVOLUTION.CHANCE_BASE + EVOLUTION.CHANCE_PER_ASC * asc);
        if (Math.random() >= chance) return null;
        if (this._areaFull(entity)) return null;

        const pool = this._poolFor(entity);
        if (!pool.length) return null;
        let total = 0;
        for (const id of pool) total += EVOLUTION.TIERS[id].weight ?? 1;
        let roll = Math.random() * total, pick = pool[0];
        for (const id of pool) { roll -= EVOLUTION.TIERS[id].weight ?? 1; if (roll <= 0) { pick = id; break; } }

        let power = 1;
        if (pick === "inferno") {
            const t = EVOLUTION.TIERS.inferno;
            power = entity.dimension.id === "minecraft:nether" ? t.netherPower : t.otherPower;
        }
        this._apply(entity, pick, power);
        this.getTier(entity);   // fill cache
        return pick;
    }

    // Enchanted is its own roll: it works at Ascension 0 and stacks with any tier except Core.
    static _rollEnchanted(entity, asc) {
        const chance = Math.min(ENCHANTED.CHANCE_MAX, ENCHANTED.CHANCE_BASE + ENCHANTED.CHANCE_PER_ASC * asc);
        if (Math.random() >= chance) return;
        if (this._areaFull(entity)) return;
        this._applyEnchanted(entity);
    }

    static onSpawn(entity) {
        try {
            if (!entity?.isValid || !eligible(entity)) return;
            if (entity.hasTag(TAG_SUMMONED) || entity.hasTag(TAG_EVO)) return;
            const asc = ProgressionManager.getAscension();
            const picked = asc >= 1 ? this._rollTier(entity, asc) : null;
            if (picked !== "core") this._rollEnchanted(entity, asc);
        } catch (_) {}
    }

    // ─── Hits on players (called by the combat pipeline for evolved attackers) ──

    static onHitPlayer(attacker, victim) {
        try {
            const t = this.getTier(attacker);
            if (!t || !victim?.isValid) return;
            if (t.id === "inferno" && Math.random() < t.burnChance) {
                system.run(() => { try { if (victim.isValid) victim.setOnFire(t.burnSeconds, true); } catch (_) {} });
            } else if (t.id === "nightmare" && Math.random() < t.blindChance) {
                system.run(() => { try { if (victim.isValid) victim.addEffect("blindness", t.blindTicks, { amplifier: 0, showParticles: false }); } catch (_) {} });
            }
        } catch (_) {}
    }

    // ─── Abilities (every SCAN_INTERVAL_TICKS) ──────────────────────────────

    static _hpFraction(entity) {
        try {
            const vmax = entity.getDynamicProperty("crpg:vmax"), vhp = entity.getDynamicProperty("crpg:vhp");
            if (typeof vmax === "number" && typeof vhp === "number" && vmax > 0) return Math.max(0, Math.min(1, vhp / vmax));
            const h = entity.getComponent("minecraft:health");
            return h ? h.currentValue / h.effectiveMax : 1;
        } catch (_) { return 1; }
    }

    static _isNoisy(player) {
        try {
            if (player.isSprinting || player.isJumping) return true;
            const time = world.getTimeOfDay();
            if (player.dimension.id === "minecraft:overworld" && time >= 13000 && time <= 23000) return true;   // night
            const top = player.dimension.getTopmostBlock({ x: player.location.x, z: player.location.z });
            return !!top && top.location.y > player.location.y + 4;   // underground = dark
        } catch (_) { return false; }
    }

    static _nearest(mob, players) {
        let best = null, bestD = Infinity;
        for (const p of players) {
            if (!p.isValid || p.dimension.id !== mob.dimension.id) continue;
            const dx = p.location.x - mob.location.x, dy = p.location.y - mob.location.y, dz = p.location.z - mob.location.z;
            const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d < bestD) { bestD = d; best = p; }
        }
        return { player: best, dist: bestD };
    }

    // Per-mob cooldown in real ms (survives reloads, unlike system ticks).
    static _ready(mob, key, ms) {
        const k = `crpg:cd_${key}`;
        const last = mob.getDynamicProperty(k);
        const now = Date.now();
        if (typeof last === "number" && now - last < ms) return false;
        mob.setDynamicProperty(k, now);
        return true;
    }

    static _dirTo(mob, player) {
        const dx = player.location.x - mob.location.x, dz = player.location.z - mob.location.z;
        const len = Math.sqrt(dx * dx + dz * dz) || 1;
        return { x: dx / len, z: dz / len };
    }

    static tick(players) {
        const seen = new Set();
        for (const player of players) {
            let mobs;
            try {
                mobs = player.dimension.getEntities({ tags: [TAG_EVO], location: player.location, maxDistance: EVOLUTION.SCAN_RADIUS });
            } catch (_) { continue; }
            for (const mob of mobs) {
                if (seen.has(mob.id)) continue;
                seen.add(mob.id);
                try { this._tickMob(mob, players); } catch (_) {}
            }
        }
    }

    static _tickMob(mob, players) {
        if (!mob.isValid) return;
        const t = this.getTier(mob);
        const ench = this.isEnchanted(mob);
        if (!t && !ench) return;

        try { mob.dimension.spawnParticle(t?.particle ?? ENCHANTED.particle, { x: mob.location.x, y: mob.location.y + 1.2, z: mob.location.z }); } catch (_) {}
        if (ench) this._tickEnchanted(mob);
        // Self-heal: re-apply the name if something wiped it (name tags can be lost on chunk reload)
        if (!mob.nameTag || isHpOnlyName(mob.nameTag)) this._applyName(mob, t?.id ?? null);
        if (!t) return;

        if (t.id === "core") this._tickCore(mob, t);
        else if (t.id === "elite") this._tickElite(mob, t);
        else if (t.id === "sculk") this._tickSculk(mob, t, players);
        else if (t.id === "awaken") this._tickAwaken(mob, t, players);

        for (const hook of tickHooks) { try { hook(mob, t, players); } catch (_) {} }
    }

    static _callAllies(mob, count, message) {
        const { x, y, z } = mob.location;
        for (let i = 0; i < count; i++) {
            const ang = Math.random() * Math.PI * 2;
            try {
                const ally = mob.dimension.spawnEntity(mob.typeId, { x: x + Math.cos(ang) * 2, y, z: z + Math.sin(ang) * 2 });
                ally.addTag(TAG_SUMMONED);   // no Evolution tag: prevents chains
            } catch (_) {}
        }
        for (const p of mob.dimension.getPlayers({ location: mob.location, maxDistance: 24 })) p.sendMessage(message);
    }

    static _tickElite(mob, t) {
        const frac = this._hpFraction(mob);
        if (frac < t.enrageBelow) mob.addEffect("speed", 40, { amplifier: t.enrageSpeedAmp, showParticles: false });
        if (frac < t.callBelow && !mob.hasTag(TAG_CALLED)) {
            mob.addTag(TAG_CALLED);
            if (!t.callTypes.includes(mob.typeId)) return;
            this._callAllies(mob, t.callCount, "§c[Elite] §7An Elite mob calls for reinforcements!");
        }
    }

    static _tickSculk(mob, t, players) {
        const { player: best, dist } = this._nearest(mob, players);
        const noisy = best ? this._isNoisy(best) : false;
        const range = noisy ? t.senseRangeNoisy : t.senseRange;

        if (!best || dist > range) {
            if (mob.hasTag(TAG_HOT)) mob.removeTag(TAG_HOT);
            return;
        }
        if (noisy) {
            if (!mob.hasTag(TAG_HOT)) mob.addTag(TAG_HOT);
            mob.addEffect("speed", 40, { amplifier: t.hotSpeedAmp, showParticles: false });
        } else if (mob.hasTag(TAG_HOT)) mob.removeTag(TAG_HOT);

        // Sensed through walls: a small lurch toward the player when far enough away
        if (dist > 4 && mob.isOnGround) {
            const d = this._dirTo(mob, best);
            mob.applyImpulse({ x: d.x * t.nudge, y: 0.08, z: d.z * t.nudge });
        }
    }

    // ─── Awakened: mutation + per-mob-family unique abilities ───────────────

    static _tickAwaken(mob, t, players) {
        const mut = t.mutations[t.mut];
        if (mut?.speedAmp !== undefined) mob.addEffect("speed", 40, { amplifier: mut.speedAmp, showParticles: false });

        const group = abilityGroup(mob.typeId);
        if (!group) return;
        const cfg = AWAKEN_ABILITIES[group];
        const { player, dist } = this._nearest(mob, players);

        if (group === "zombie") {
            const frac = this._hpFraction(mob);
            if (frac < cfg.berserk.below) {
                if (!mob.hasTag(TAG_BERSERK)) mob.addTag(TAG_BERSERK);
                mob.addEffect("speed", 40, { amplifier: cfg.berserk.speedAmp, showParticles: false });
            }
            if (frac < cfg.call.below && !mob.hasTag(TAG_AW_CALLED)) {
                mob.addTag(TAG_AW_CALLED);
                this._callAllies(mob, cfg.call.count, "§b[Awakened] §7An Awakened mob rallies its horde!");
            }
            if (player && dist >= cfg.dash.minDist && dist <= cfg.dash.maxDist && mob.isOnGround && this._ready(mob, "dash", cfg.dash.cooldownMs)) {
                const d = this._dirTo(mob, player);
                mob.applyImpulse({ x: d.x * cfg.dash.push, y: cfg.dash.lift, z: d.z * cfg.dash.push });
            }
        } else if (group === "skeleton") {
            if (player && dist >= cfg.volley.minDist && dist <= cfg.volley.maxDist && this._ready(mob, "volley", cfg.volley.cooldownMs)) {
                this._volley(mob, player, cfg.volley);
            }
        } else if (group === "spider") {
            if (player && dist <= cfg.web.maxDist && this._ready(mob, "web", cfg.web.cooldownMs)) this._web(player, cfg.web);
            if (player && dist >= cfg.leap.minDist && dist <= cfg.leap.maxDist && mob.isOnGround && this._ready(mob, "leap", cfg.leap.cooldownMs)) {
                const d = this._dirTo(mob, player);
                mob.applyImpulse({ x: d.x * cfg.leap.push, y: cfg.leap.lift, z: d.z * cfg.leap.push });
            }
        }
    }

    // Two extra arrows fanned around the aim line, owned by the skeleton (so damage is attributed to it).
    static _volley(mob, player, v) {
        try {
            const from = { x: mob.location.x, y: mob.location.y + 1.5, z: mob.location.z };
            const to   = { x: player.location.x, y: player.location.y + 1.2, z: player.location.z };
            const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
            const len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
            for (const ang of [-v.spread, v.spread]) {
                const c = Math.cos(ang), s = Math.sin(ang);
                const ux = (dx * c - dz * s) / len, uz = (dx * s + dz * c) / len, uy = dy / len;
                const arrow = mob.dimension.spawnEntity("minecraft:arrow", { x: from.x + ux * 1.2, y: from.y + uy * 1.2, z: from.z + uz * 1.2 });
                const proj = arrow.getComponent("minecraft:projectile");
                if (proj) {
                    try { proj.owner = mob; } catch (_) {}
                    proj.shoot({ x: ux * v.speed, y: uy * v.speed, z: uz * v.speed });
                }
            }
        } catch (_) {}
    }

    // Cobweb at the player's feet for a short time.
    static _web(player, w) {
        try {
            const dim = player.dimension;
            const pos = { x: Math.floor(player.location.x), y: Math.floor(player.location.y), z: Math.floor(player.location.z) };
            const block = dim.getBlock(pos);
            if (!block || block.typeId !== "minecraft:air") return;
            block.setType("minecraft:web");
            system.runTimeout(() => {
                try { const b = dim.getBlock(pos); if (b?.typeId === "minecraft:web") b.setType("minecraft:air"); } catch (_) {}
            }, w.lifeTicks);
        } catch (_) {}
    }

    // ─── Kill (Geode gem drop, Awakened rare drops) ─────────────────────────

    static onKill(killEvent) {
        try {
            const victim = killEvent.victim;
            const tier = this.getTier(victim);
            const ench = this.isEnchanted(victim);
            const isWarden = victim.typeId === "minecraft:warden";
            if (!tier && !ench && !isWarden) return;
            tierCache.delete(victim.id);
            enchCache.delete(victim.id);
            if (!killEvent.isPlayerKill) return;

            const drops = [];
            const looting = LootBonus.lootingLevel(killEvent.killer);   // vanilla Looting on the killer's weapon
            // Gem Mastery: +x percentage points on Uncarved Gem drop chances of evolved mobs
            const gemBonus = MasteryManager.getBonus(killEvent.killer, "uncarved_drop") / 100;
            // Echo Shard: guaranteed from a Sculk Evolve and from the Warden. Sculk mobs made by a Sculk Potion drop none (anti-farm).
            if ((tier?.id === "sculk" || isWarden) && !victim.hasTag("crpg_potion_sculk")) {
                const sc = EVOLUTION.TIERS.sculk;
                const lo = Math.max(0, sc.shardMin), hi = Math.max(lo, sc.shardMax);
                const n = lo + Math.floor(Math.random() * (hi - lo + 1)) + LootBonus.extraCount(looting, "APPLY_EVO_SHARD");
                if (n > 0) drops.push({ id: "minecraft:echo_shard", count: n });
            }
            if (tier?.id === "geode" && Math.random() < LootBonus.scaleChance(tier.gemChance + gemBonus, looting, "APPLY_EVO_GEM")) drops.push({ id: "crpg:uncarved_gem", count: tier.gemCount ?? 1 });
            if (tier?.id === "awaken") {
                for (const d of tier.rareDrops) {
                    const isGem = d.id === "crpg:uncarved_gem";
                    if (Math.random() < LootBonus.scaleChance(d.chance + (isGem ? gemBonus : 0), looting, isGem ? "APPLY_EVO_GEM" : "APPLY_EVO_RARE")) drops.push({ id: d.id, count: d.min + Math.floor(Math.random() * (d.max - d.min + 1)) });
                }
            }
            // Core: 25% for exactly ONE of Augment Core / Stellar Core
            if (tier?.id === "core" && Math.random() < LootBonus.scaleChance(tier.dropChance, looting, "APPLY_EVO_CORE")) {
                drops.push({ id: tier.dropItems[Math.floor(Math.random() * tier.dropItems.length)], count: 1 });
            }
            // Enchanted: Enchant Essence and Augment Crystal are guaranteed
            if (ench) {
                drops.push({ id: "crpg:enchant_essence", count: ENCHANTED.essenceMin + Math.floor(Math.random() * (ENCHANTED.essenceMax - ENCHANTED.essenceMin + 1)) + LootBonus.extraCount(looting, "APPLY_EVO_ESSENCE") });
                drops.push({ id: "crpg:augment_crystal", count: ENCHANTED.crystalMin + Math.floor(Math.random() * (ENCHANTED.crystalMax - ENCHANTED.crystalMin + 1)) });
            }
            if (!drops.length) return;

            let dimension, location;
            try { dimension = victim.dimension; location = victim.location; }
            catch (_) {
                const k = killEvent.killer;
                if (!k?.isValid) return;
                dimension = k.dimension; location = k.location;
            }
            for (const d of drops) {
                try { dimension.spawnItem(new ItemStack(d.id, d.count), location); } catch (_) {}
            }
        } catch (_) {}
    }

    static trimCache() {
        if (tierCache.size > 500) tierCache.clear();
        if (enchCache.size > 500) enchCache.clear();
    }
}
