import { CONFIG } from "../config/config.js";
import { HudManager } from "./hud_manager.js";
import { XPManager } from "./xp_manager.js";
import { ProgressionManager } from "./progression_manager.js";

// RuneCN (Curse/Neutral rune modifiers) lazy loader — rune_combat.js imports
// StatsManager, so a static import here would be circular.
let _RuneCN = null;
function getRuneCN() {
    if (!_RuneCN) {
        import("../rune/rune_curseneutral.js").then((m) => { _RuneCN = m; }).catch(() => {});
    }
    return _RuneCN;
}

// Per-stat point caps (Phase 5/#13). Any stat not listed uses DEFAULT_STAT_CAP.
export const DEFAULT_STAT_CAP = 80;
export const STAT_CAPS = {
    mag: 256,
    wis: 48,
    con: 64,
    vit: 8,
};

export class StatsManager {
    // Base cap, raised by Prestige Stat Limit Break when a player is given.
    static getStatCap(statName, player = null) {
        const base = STAT_CAPS[statName] ?? DEFAULT_STAT_CAP;
        if (!player) return base;
        return Math.round(base * ProgressionManager.getStatCapMultiplier(player));
    }

    static getStat(player, statName, defaultValue = 0) {
        const value = player.getDynamicProperty(statName);
        if (statName === "stat_xp" && typeof value === "number") return Math.floor(value);   // XP is always whole
        return value !== undefined ? value : defaultValue;
    }

    static setStat(player, statName, value) {
        if (!player || typeof statName !== "string") return false;
        let numeric = Number(value);
        if (!Number.isFinite(numeric)) return false;
        if (statName === "stat_xp") numeric = Math.floor(numeric);
        player.setDynamicProperty(statName, numeric);
        HudManager.markDirty(player);
        return true;
    }

    static getPlayerData(player) {
        return {
            level:  this.getStat(player, "stat_level",  0),
            xp:     this.getStat(player, "stat_xp",     0),
            points: this.getStat(player, "stat_points", 0),
            str:    this.getStat(player, "stat_str",    0),
            def:    this.getStat(player, "stat_def",    0),
            agi:    this.getStat(player, "stat_agi",    0),
            psi:    this.getStat(player, "stat_psi",    0),
            exc:    this.getStat(player, "stat_exc",    0),
            mag:    this.getStat(player, "stat_mag",    0),
            wis:    this.getStat(player, "stat_wis",    0),
            con:    this.getStat(player, "stat_con",    0),
            vit:    this.getStat(player, "stat_vit",    0)
        };
    }

    static getMaxXp(level) {
        return XPManager.getMaxXp(level);
    }

    // Backward-compatible facade. XPManager is now the single owner of XP
    // mutation and level progression. Existing callers can continue using
    // StatsManager.addXp during the migration.
    static addXp(player, amount, source = "System", options = {}) {
        return XPManager.addXp(player, amount, source, options);
    }

    static addStatPoint(player, statName, amount = 1) {
        const points = this.getStat(player, "stat_points", 0);
        if (points < amount) return false;

        const current = this.getStat(player, `stat_${statName}`, 0);
        const cap     = this.getStatCap(statName, player);
        if (current >= cap) return false;
        const applied = Math.min(amount, cap - current);

        this.setStat(player, `stat_${statName}`, current + applied);
        this.setStat(player, "stat_points", points - applied);
        this._afterStatMutation(player);
        return true;
    }

    static removeStatPoint(player, statName, amount = 1) {
        const current = this.getStat(player, `stat_${statName}`, 0);
        if (current < amount) return false;

        const points = this.getStat(player, "stat_points", 0);
        this.setStat(player, `stat_${statName}`, current - amount);
        this.setStat(player, "stat_points", points + amount);
        this._afterStatMutation(player);
        return true;
    }

    // All-or-nothing on Points budget, but each stat is silently clamped to its
    // cap (Phase 5/#13) before the budget check, so no Points are ever spent
    // on headroom a stat doesn't have. Returns the actual Points spent (falsy
    // if nothing could be applied), so callers can report the real amount.
    // allocations is an object like { str: 3, def: 0, agi: 5, ... }
    static addMultipleStatPoints(player, allocations) {
        const clamped = {};
        let total = 0;
        for (const [statName, amount] of Object.entries(allocations)) {
            if (!amount) continue;
            const current = this.getStat(player, `stat_${statName}`, 0);
            const cap     = this.getStatCap(statName, player);
            const applied = Math.max(0, Math.min(amount, cap - current));
            if (applied > 0) { clamped[statName] = applied; total += applied; }
        }
        if (total <= 0) return false;

        const points = this.getStat(player, "stat_points", 0);
        if (total > points) return false;

        for (const [statName, amount] of Object.entries(clamped)) {
            const current = this.getStat(player, `stat_${statName}`, 0);
            this.setStat(player, `stat_${statName}`, current + amount);
        }

        this.setStat(player, "stat_points", points - total);
        this._afterStatMutation(player);
        return total;
    }

    // All-or-nothing bulk removal: if any stat doesn't have enough points to
    // remove, nothing changes. Refunds every removed point back to Points.
    // allocations is an object like { str: 3, def: 0, agi: 5, ... }
    static removeMultipleStatPoints(player, allocations) {
        const total = Object.values(allocations).reduce((sum, val) => sum + (val ?? 0), 0);
        if (total <= 0) return false;

        for (const [statName, amount] of Object.entries(allocations)) {
            if (!amount) continue;
            const current = this.getStat(player, `stat_${statName}`, 0);
            if (amount > current) return false;
        }

        for (const [statName, amount] of Object.entries(allocations)) {
            if (!amount) continue;
            const current = this.getStat(player, `stat_${statName}`, 0);
            this.setStat(player, `stat_${statName}`, current - amount);
        }

        const points = this.getStat(player, "stat_points", 0);
        this.setStat(player, "stat_points", points + total);
        this._afterStatMutation(player);
        return true;
    }

    static _afterStatMutation(player) {
        // Derived resources are owned by their managers. Lazy imports avoid
        // circular dependencies during startup.
        import("./hp_manager.js").then(({ HPManager }) => HPManager.recalcMaxHP(player)).catch(() => {});
        import("./mana_manager.js").then(({ ManaManager }) => {
            const { mana, maxMana } = ManaManager.getMana(player);
            if (mana > maxMana) ManaManager.setMana(player, maxMana);
        }).catch(() => {});
        HudManager.markDirty(player);
    }

    // Reset All: returns every allocated stat point to the Points pool.
    // Level and Xp are untouched. Returns the number of points refunded.
    static refundAllStats(player) {
        const names = ["str", "def", "agi", "psi", "exc", "mag", "wis", "con", "vit"];
        let refunded = 0;
        for (const name of names) {
            const value = Math.max(0, this.getStat(player, `stat_${name}`, 0));
            refunded += value;
            this.setStat(player, `stat_${name}`, 0);
        }
        this.setStat(player, "stat_points", this.getStat(player, "stat_points", 0) + refunded);
        this._afterStatMutation(player);
        return refunded;
    }

    // Delete All: wipes Level, Xp, Points and every stat.
    static resetAllStats(player) {
        for (const key of ["stat_level", "stat_xp", "stat_points",
                            "stat_str", "stat_def", "stat_agi", "stat_psi",
                            "stat_exc", "stat_mag", "stat_wis",
                            "stat_con", "stat_vit"]) {
            this.setStat(player, key, 0);
        }
        this.setStat(player, "stat_mana", 50);
        this._afterStatMutation(player);
    }
}
