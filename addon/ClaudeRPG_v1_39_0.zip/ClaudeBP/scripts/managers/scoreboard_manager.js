import { world } from "@minecraft/server";
import { CONFIG } from "../config/config.js";
import { StatsManager } from "./stats_manager.js";
import { HPManager } from "./hp_manager.js";

// Last values written per player, so unchanged stats cost no scoreboard writes.
const lastSynced = new Map();

export class ScoreboardManager {
    static forget(playerId) { lastSynced.delete(playerId); }

    static setupObjectives() {
        for (const objectiveId of Object.values(CONFIG.SCOREBOARDS)) {
            if (!world.scoreboard.getObjective(objectiveId)) {
                world.scoreboard.addObjective(objectiveId, objectiveId);
            }
        }
    }

    static readScore(objective, player) {
        if (!objective) return undefined;
        try {
            return objective.getScore(player);
        } catch {
            return undefined;
        }
    }

    // Syncs Lv / Exp / Max_exp scoreboards with the player's real stats.
    // Bug fix 0.3: guard against null objectives (can occur if syncPlayer() is called
    // before setupObjectives() has run — e.g. on the first few ticks after world load).
    // setScore() on a null objective throws "TypeError: not a function".
    static syncPlayer(player) {
        const levelObjective  = world.scoreboard.getObjective(CONFIG.SCOREBOARDS.level);
        const expObjective    = world.scoreboard.getObjective(CONFIG.SCOREBOARDS.exp);
        const maxExpObjective = world.scoreboard.getObjective(CONFIG.SCOREBOARDS.maxExp);

        // If objectives are not yet ready, skip silently — the next tick will retry.
        if (!levelObjective || !expObjective || !maxExpObjective) return;

        // Dynamic properties / managers are the authoritative RPG data store.
        // Scoreboards are presentation/export only; they are never read back
        // into the player model here. This prevents external scoreboard edits
        // from silently overwriting persistent RPG state.
        const level = StatsManager.getStat(player, "stat_level", 0);
        const xp    = StatsManager.getStat(player, "stat_xp",    0);
        const maxXp = StatsManager.getMaxXp(level);
        const key = `${level}|${xp}|${maxXp}`;
        if (lastSynced.get(player.id) !== key) {
            levelObjective.setScore(player, level);
            expObjective.setScore(player, xp);
            maxExpObjective.setScore(player, maxXp);
            lastSynced.set(player.id, key);
        }

        // RPG HP scoreboards
        HPManager.syncScoreboards(player);
    }

    static syncAll() {
        for (const player of world.getAllPlayers()) {
            this.syncPlayer(player);
        }
    }
}
