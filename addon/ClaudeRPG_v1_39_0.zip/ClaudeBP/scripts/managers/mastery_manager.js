// mastery_manager.js -- Mastery XP, levels and bonuses (v2: per-line curves, random rolled values).
// Dependency-light on purpose (config + ProgressionManager only) so combat, rune, gem and
// fishing code can import it.

import { MASTERY } from "../config/mastery_config.js";
import { ProgressionManager } from "./progression_manager.js";
import { newSeed, rolledValue } from "../systems/mastery_roll.js";
import { AchievementManager } from "../systems/achievement_manager.js";

// New key prefix on purpose: Mastery v1 progress is ignored (reset), as agreed.
const XP_KEY   = (line) => `mastery2_xp_${line}`;
const SEED_KEY = (line) => `mastery2_seed_${line}`;
const PATH_KEY = (line) => `mastery2_path_${line}`;
const PATH_AT  = (line) => `mastery2_pathat_${line}`;   // ms timestamp of the last path switch
const OFF_KEY  = (line) => `mastery2_off_${line}`;      // JSON array of switched-off effect keys

// effectId -> [{ line, path|null, effect }]  (several lines/paths may feed one id)
const EFFECT_INDEX = (() => {
    const idx = {};
    const add = (id, line, path, effect) => { (idx[id] ??= []).push({ line, path, effect }); };
    for (const [line, def] of Object.entries(MASTERY.LINES)) {
        for (const [id, e] of Object.entries(def.effects ?? {})) if (!def.paths) add(id, line, null, e);
        for (const [pid, p] of Object.entries(def.paths ?? {})) {
            for (const [id, e] of Object.entries(p.effects)) add(id, line, pid, e);
        }
    }
    return idx;
})();

const lineMax = (line) => MASTERY.LINES[line]?.maxLevel ?? 0;

// Total XP needed to REACH level L on a line.
function cumulativeXp(line, level) {
    const x = MASTERY.LINES[line]?.xp ?? { base: 1000, per: 500 };
    return x.base * level + (x.per * level * (level - 1)) / 2;
}

const travelState = new Map();   // playerId -> { x, z, dim, carry }

export class MasteryManager {

    // ─── State ───────────────────────────────────────────────────────────────

    static isUnlocked(player, line) {
        const def = MASTERY.LINES[line];
        if (!def) return false;
        const req = def.requires ?? {};
        if ((req.prestige ?? 0) > ProgressionManager.getPrestige(player)) return false;
        if (req.feature && !ProgressionManager.canUse(player, req.feature)) return false;
        return true;
    }

    static requirementText(line) {
        const req = MASTERY.LINES[line]?.requires ?? {};
        const parts = [];
        if (req.prestige) parts.push(`Prestige ${req.prestige}`);
        if (req.feature) parts.push(`${ProgressionManager.requirementText(req.feature)}`);
        return parts.join(" · ");
    }

    // Total XP needed to reach a level (used by admin tools).
    static xpForLevel(level, line) {
        return cumulativeXp(line, Math.max(0, Math.min(lineMax(line), level)));
    }

    // Admin: write raw XP, bypassing the unlock check and level-up messages.
    static adminSetXp(player, line, xp) {
        if (!player || !MASTERY.LINES[line]) return false;
        player.setDynamicProperty(XP_KEY(line), Math.max(0, Number(xp) || 0));
        this._refresh(player, line);
        return true;
    }

    static getXp(player, line) {
        const v = player?.getDynamicProperty(XP_KEY(line));
        return typeof v === "number" && Number.isFinite(v) ? Math.max(0, v) : 0;
    }

    static getLevel(player, line) {
        const xp = this.getXp(player, line);
        const max = lineMax(line);
        let lv = 0;
        while (lv < max && xp >= cumulativeXp(line, lv + 1)) lv++;
        return lv;
    }

    // { level, into, need, max }  progress inside the current level
    static getProgress(player, line) {
        const xp = this.getXp(player, line);
        const level = this.getLevel(player, line);
        if (level >= lineMax(line)) return { level, into: 0, need: 0, max: true };
        const x = MASTERY.LINES[line].xp;
        return { level, into: Math.floor(xp - cumulativeXp(line, level)), need: x.base + x.per * level, max: false };
    }

    // ─── Tier / feature unlocks (Chorus, Gem, Rune) ───────────────────────────

    // True when `id` is open for this player. Ids that are not in the line's unlock list are always open
    // (Echo, Common gems, Tier 1 runes). Listed ids need the line unlocked and the level reached.
    static isUnlockOpen(player, line, id) {
        const u = (MASTERY.LINES[line]?.unlocks ?? []).find((x) => x.id === id);
        if (!u) return true;
        if (!this.isUnlocked(player, line)) return false;
        return this.getLevel(player, line) >= u.level;
    }
    static isGemTierOpen(player, tierId) { return this.isUnlockOpen(player, "gem", tierId); }
    static isRuneTierOpen(player, tier)  { return this.isUnlockOpen(player, "rune", `t${tier}`); }
    static unlockLevel(line, id) { return (MASTERY.LINES[line]?.unlocks ?? []).find((x) => x.id === id)?.level ?? 0; }
    // First still-locked unlock of a line: { name, level } or null.
    static nextUnlock(player, line) {
        for (const u of MASTERY.LINES[line]?.unlocks ?? []) if (!this.isUnlockOpen(player, line, u.id)) return { name: u.name, level: u.level };
        return null;
    }

    // ─── Rolled values ───────────────────────────────────────────────────────

    // The player's stored roll seed for a line (created on first use, never changes).
    static getSeed(player, line) {
        const v = player?.getDynamicProperty(SEED_KEY(line));
        if (typeof v === "number" && v > 0) return v;
        const seed = newSeed();
        try { player?.setDynamicProperty(SEED_KEY(line), seed); } catch (_) {}
        return seed;
    }

    // Admin: forget the rolls of a line (new seed next time).
    static adminRerollSeed(player, line) {
        try { player.setDynamicProperty(SEED_KEY(line), newSeed()); return true; } catch (_) { return false; }
    }

    // Active path of a line ("" / null = none picked yet). Switching rules come in phase 3.
    static getPath(player, line) {
        const def = MASTERY.LINES[line];
        if (!def?.paths) return null;
        const v = player?.getDynamicProperty(PATH_KEY(line));
        return typeof v === "string" && def.paths[v] ? v : null;
    }

    // Pick / switch the path of a line. Free, but once per PATH_SWITCH_COOLDOWN_SEC (first pick is free).
    // -> { ok, reason?, wait? (seconds left) }
    static setPath(player, line, pathId) {
        const def = MASTERY.LINES[line];
        if (!def?.paths?.[pathId]) return { ok: false, reason: "unknown_path" };
        if (!this.isUnlocked(player, line)) return { ok: false, reason: "locked" };
        const cur = this.getPath(player, line);
        if (cur === pathId) return { ok: false, reason: "same" };
        if (cur) {
            const wait = this.pathCooldownLeft(player, line);
            if (wait > 0) return { ok: false, reason: "cooldown", wait };
        }
        player.setDynamicProperty(PATH_KEY(line), pathId);
        player.setDynamicProperty(PATH_AT(line), Date.now());
        AchievementManager.event(player, cur ? "path_switched" : "path_chosen");
        return { ok: true };
    }

    // Seconds left before the path can be changed again (0 = ready).
    static pathCooldownLeft(player, line) {
        const at = player?.getDynamicProperty(PATH_AT(line));
        if (typeof at !== "number") return 0;
        const left = MASTERY.PATH_SWITCH_COOLDOWN_SEC - (Date.now() - at) / 1000;
        return left > 0 ? Math.ceil(left) : 0;
    }

    // Admin: set a path ignoring cooldown, or clear it (pathId = null).
    static adminSetPath(player, line, pathId) {
        const def = MASTERY.LINES[line];
        if (!def?.paths) return false;
        if (pathId && !def.paths[pathId]) return false;
        player.setDynamicProperty(PATH_KEY(line), pathId ?? undefined);
        player.setDynamicProperty(PATH_AT(line), undefined);
        return true;
    }

    // ─── Ability toggles (per effect) ─────────────────────────────────────────

    static _toggleKey(path, id) { return path ? `${path}.${id}` : id; }

    static _offSet(player, line) {
        try {
            const raw = player?.getDynamicProperty(OFF_KEY(line));
            return new Set(typeof raw === "string" ? JSON.parse(raw) : []);
        } catch (_) { return new Set(); }
    }

    static canToggle(line, path, id) {
        const def = MASTERY.LINES[line];
        const e = path ? def?.paths?.[path]?.effects?.[id] : def?.effects?.[id];
        return !!e && e.toggle !== false;
    }

    static isEffectEnabled(player, line, path, id) {
        if (!this.canToggle(line, path, id)) return true;
        return !this._offSet(player, line).has(this._toggleKey(path, id));
    }

    static setEffectEnabled(player, line, path, id, enabled) {
        if (!this.canToggle(line, path, id)) return false;
        const set = this._offSet(player, line);
        const k = this._toggleKey(path, id);
        if (enabled) set.delete(k); else set.add(k);
        player.setDynamicProperty(OFF_KEY(line), set.size ? JSON.stringify([...set]) : undefined);
        this._refresh(player, line);
        return true;
    }

    // Everything the GUI needs for one line: active path + each effect with value and on/off state.
    static describeLine(player, line) {
        const def = MASTERY.LINES[line];
        if (!def) return null;
        const level = this.getLevel(player, line);
        const path = this.getPath(player, line);
        const rows = [];
        const add = (pid, effects) => {
            for (const [id, e] of Object.entries(effects)) {
                rows.push({
                    id, path: pid, name: e.name, unit: e.unit ?? "", level,
                    value: this.valueAt(player, line, pid, id, level),
                    full: e.kind === "fixed" ? e.per * def.maxLevel : e.max,
                    toggle: e.toggle !== false,
                    enabled: this.isEffectEnabled(player, line, pid, id),
                });
            }
        };
        if (!def.paths) add(null, def.effects ?? {});
        else if (path) add(path, def.paths[path].effects);
        return { line, level, maxLevel: def.maxLevel, path, hasPaths: !!def.paths, rows,
                 unlocks: (def.unlocks ?? []).map((u) => ({ ...u, open: level >= u.level })) };
    }

    static _key(line, path, id) { return `${line}.${path ?? "-"}.${id}`; }

    // Value of one effect of one line at a level, with this player's rolls.
    static valueAt(player, line, path, id, level) {
        const def = MASTERY.LINES[line];
        const e = path ? def?.paths?.[path]?.effects?.[id] : def?.effects?.[id];
        if (!e) return 0;
        return rolledValue(this.getSeed(player, line), this._key(line, path, id), e, level, def.maxLevel);
    }

    // Extra item levels this player's Mastery grants to Rune skills (whole number, 0..4).
    // Per player: the same item shows and plays at a different level for each holder.
    // (Gems have no levels: see getGemPotency.)
    static getItemLevelBonus(player, kind) {
        return kind === "gem" ? 0 : Math.max(0, Math.round(this.getBonus(player, "rune_level")));
    }

    // Gem Potency: % boost to the power numbers of every Gem skill (0..20, whole number).
    static getGemPotency(player) {
        return Math.max(0, Math.round(this.getBonus(player, "gem_potency")));
    }

    // Bonus of one effect id, summed over every line/path that feeds it. 0 while a line is locked
    // or (pathed lines) while no path is picked / the effect belongs to another path.
    static getBonus(player, effectId) {
        const sources = EFFECT_INDEX[effectId];
        if (!sources || !player) return 0;
        let total = 0;
        for (const { line, path, effect } of sources) {
            if (!this.isUnlocked(player, line)) continue;
            if (path && this.getPath(player, line) !== path) continue;
            if (!this.isEffectEnabled(player, line, path, effectId)) continue;
            const lv = this.getLevel(player, line);
            if (lv <= 0) continue;
            total += rolledValue(this.getSeed(player, line), this._key(line, path, effectId), effect, lv, lineMax(line));
        }
        return Math.round(total * 100) / 100;
    }

    // ─── Gaining XP ──────────────────────────────────────────────────────────

    static addXp(player, line, amount) {
        if (!player?.isValid || !(amount > 0) || !this.isUnlocked(player, line)) return false;
        const before = this.getLevel(player, line);
        // XP keeps counting after max level (no cap) -- it works as a lifetime statistic score.
        player.setDynamicProperty(XP_KEY(line), this.getXp(player, line) + amount);
        const after = this.getLevel(player, line);
        if (after > before) { this._announce(player, line, before, after); this._refresh(player, line); }
        return true;
    }

    // Things that cache a Mastery value must recompute when it changes (Defense -> max HP).
    static _refresh(player, line) {
        if (line !== "defense") return;
        import("./hp_manager.js").then(({ HPManager }) => HPManager.recalcMaxHP(player)).catch(() => {});
    }

    // Level-up message with what each active effect gained.
    static _announce(player, line, before, after) {
        const def = MASTERY.LINES[line];
        const max = lineMax(line);
        const gains = [];
        const path = this.getPath(player, line);
        const groups = [[null, def.paths ? {} : def.effects], ...(path ? [[path, def.paths[path].effects]] : [])];
        for (const [pid, effects] of groups) {
            for (const [id, e] of Object.entries(effects)) {
                const d = this.valueAt(player, line, pid, id, after) - this.valueAt(player, line, pid, id, before);
                if (Math.abs(d) < 0.005) continue;
                const val = Math.round(d * 100) / 100;
                gains.push(`${e.name} ${val >= 0 ? "+" : ""}${val}${e.unit ?? ""}`);
            }
        }
        for (const u of def.unlocks ?? []) if (u.level > before && u.level <= after) gains.push(`§aUnlocked: ${u.name}`);
        player.sendMessage(`${def.icon}[Mastery] ${def.name} Mastery reached Lv.${after}${after >= max ? " (MAX)" : ""}!` +
            (gains.length ? `\n§7  ${gains.join("§8, §7")}` : ""));
        try { player.playSound("random.levelup", { volume: 0.6 }); } catch (_) {}
    }

    // ─── XP hooks ────────────────────────────────────────────────────────────

    // KillEvent from KillManager.
    static onKill(ev) {
        const killer = ev?.killer;
        if (!killer || ev.isPlayerVictim || !(ev.mobXp > 0)) return;
        const ranged = !!ev.damageSource?.damagingProjectile;
        const xp = ev.mobXp * (1 + ProgressionManager.getAscensionXpBonus() / 100);   // harder world pays more
        this.addXp(killer, ranged ? "ranged" : "melee", xp);
        try {
            if (ev.weapon?.getDynamicProperty("crpg:rune_id")) this.addXp(killer, "rune", xp);
        } catch (_) {}
    }

    static onCrit(player, line = "melee") { this.addXp(player, line, MASTERY.CRIT_XP); }

    // Every 20 ticks. Distance moved since the last sample becomes Travel XP.
    static tickTravel(players) {
        for (const p of players) {
            try {
                if (!p.isValid) continue;
                const loc = p.location, dim = p.dimension.id;
                const last = travelState.get(p.id);
                if (!last || last.dim !== dim) { travelState.set(p.id, { x: loc.x, z: loc.z, dim, carry: last?.carry ?? 0 }); continue; }
                const dx = loc.x - last.x, dz = loc.z - last.z;
                const dist = Math.sqrt(dx * dx + dz * dz);
                last.x = loc.x; last.z = loc.z;
                if (dist < 0.3 || dist > MASTERY.TRAVEL_MAX_STEP) continue;
                if (!this.isUnlocked(p, "travel")) continue;
                let mult = 1;
                if (dim === "minecraft:nether") mult *= MASTERY.TRAVEL_NETHER_MULT;
                if (p.isGliding) mult *= MASTERY.TRAVEL_GLIDE_MULT;
                last.carry += dist * MASTERY.TRAVEL_XP_PER_BLOCK * mult;
                if (last.carry >= 1) {
                    const whole = Math.floor(last.carry);
                    last.carry -= whole;
                    this.addXp(p, "travel", whole);
                }
            } catch (_) {}
        }
    }

    // A fishing catch was paid (category: fish | junk | treasure). Adds XP and bonus rolls.
    static onFish(player, catchXp, category) {
        this.addXp(player, "fishing", catchXp * MASTERY.FISHING_XP_MULT);
        try {
            const { x, y, z } = player.location;
            const at = `${x.toFixed(2)} ${(y + 1).toFixed(2)} ${z.toFixed(2)}`;
            if (category === "fish" && Math.random() * 100 < this.getBonus(player, "bonus_fish")) {
                player.dimension.runCommand(`loot spawn ${at} loot "gameplay/fishing/fish"`);
            }
            if (Math.random() * 100 < this.getBonus(player, "fishing_luck")) {
                player.dimension.runCommand(`loot spawn ${at} loot "gameplay/fishing/treasure"`);
            }
        } catch (_) {}
    }

    // Mastery v1 saved progress under "mastery_*" keys. v2 ignores it; this frees the space once per player.
    static cleanupOldData(player) {
        try {
            for (const id of player.getDynamicPropertyIds()) {
                if (id.startsWith("mastery_")) player.setDynamicProperty(id, undefined);
            }
        } catch (_) {}
    }

    static forgetPlayer(id) { travelState.delete(id); }
}
