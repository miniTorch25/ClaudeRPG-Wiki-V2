// prestige_manager.js -- performs a Prestige.
// Reset: Level, XP, Points and every stat (mana back to base). Kept forever: level-gate
// unlocks, Augment/Gem/Rune/Chorus data on items, perks, Prestige count.
// Gain: +Max Level, Stat Limit Break, and one Perk pick.

import { world } from "@minecraft/server";
import { ProgressionManager } from "./progression_manager.js";
import { StatsManager } from "./stats_manager.js";
import { HPManager } from "./hp_manager.js";
import { ManaManager } from "./mana_manager.js";
import { HudManager } from "./hud_manager.js";
import { EventBus } from "../core/event_bus.js";
import { PROG_KEYS, PRESTIGE_KEYS } from "../config/progression_config.js";
import { CostManager } from "./cost_manager.js";
import { AchievementManager } from "../systems/achievement_manager.js";

export class PrestigeManager {

    static canPrestige(player) {
        return ProgressionManager.isMaxLevel(player);
    }

    static perform(player) {
        if (!this.canPrestige(player)) return { success: false, reason: "not_max_level" };

        // Pay the cost item first; nothing is taken if the player cannot afford it.
        const cost = CostManager.prestigeStatus(player, ProgressionManager.getPrestige(player));
        if (!cost.ok) return { success: false, reason: "cost", need: cost.need, have: cost.have, name: cost.name };
        if (!CostManager.consume(player, cost.item, cost.need)) return { success: false, reason: "cost", need: cost.need, have: cost.have, name: cost.name };
        AchievementManager.event(player, "sigil_uses");

        // Level unlocks must be recorded BEFORE Level is reset.
        ProgressionManager.syncUnlocks(player);

        const next = ProgressionManager.getPrestige(player) + 1;
        player.setDynamicProperty(PROG_KEYS.PRESTIGE, next);
        player.setDynamicProperty(PRESTIGE_KEYS.PENDING, ProgressionManager.getPendingPerks(player) + 1);

        StatsManager.resetAllStats(player);   // Level, XP, Points, all stats, mana -> base

        // Refresh derived values; a failure here must not undo the Prestige itself.
        try { HPManager.recalcMaxHP(player); HPManager.setHP(player, HPManager.getMaxHP(player)); } catch (e) { console.warn(`[Prestige] HP refresh failed: ${e}`); }
        try { ManaManager.setMana(player, ManaManager.getMaxMana(player)); } catch (e) { console.warn(`[Prestige] Mana refresh failed: ${e}`); }
        try { HudManager.markDirty(player); } catch (_) {}

        EventBus.emit("progression:prestige", { player, prestige: next });
        world.sendMessage(`§6[Prestige] §e${player.name} §6reached §fPrestige ${next}§6! Max Level is now §f${ProgressionManager.getMaxLevel(player)}§6.`);
        player.playSound("random.totem");
        return { success: true, prestige: next };
    }

    // Applies a chosen perk and refreshes derived values.
    static choosePerk(player, perkId) {
        if (!ProgressionManager.addPerkPick(player, perkId)) return false;
        HPManager.recalcMaxHP(player);
        ManaManager.setMana(player, Math.min(ManaManager.getMana(player).mana, ManaManager.getMaxMana(player)));
        HudManager.markDirty(player);
        return true;
    }
}
