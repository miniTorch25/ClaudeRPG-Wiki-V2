import { XPManager } from "./xp_manager.js";
import { XpNotifier } from "./xp_notifier.js";
import { XP_CONFIG } from "../config/xp_config.js";

export class ConsumeXpManager {
    static handleCompleteUse(event) {
        const { source: player, itemStack } = event;
        if (!player || player.typeId !== "minecraft:player") return;

        const config = XP_CONFIG[itemStack.typeId];
        if (!config || config.type !== "consume") return;

        XPManager.addXp(player, config.xp, "Eating", { notify: false });
        XpNotifier.notify(player, config.xp, "Eating");
    }
}
