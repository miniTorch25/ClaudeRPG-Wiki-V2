// EquipmentManager — single read/coordination boundary for equipped RPG items.
// Item-specific mechanics (Runes/Gems/Augments) remain owned by their systems;
// this manager owns the definition of the player's current equipment loadout.
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { ItemRestrictionManager } from "../systems/item_restriction.js";
import { Logger } from "../core/logger.js";

const EQUIPMENT_SLOTS = [
    [EquipmentSlot.Mainhand, "mainhand"],
    [EquipmentSlot.Offhand, "offhand"],
    [EquipmentSlot.Head, "head"],
    [EquipmentSlot.Chest, "chest"],
    [EquipmentSlot.Legs, "legs"],
    [EquipmentSlot.Feet, "feet"]
];

function safeItem(slot) {
    try { return slot?.hasItem() ? slot.getItem() : null; } catch { return null; }
}

export class EquipmentManager {
    static getEquippable(player) {
        return player?.getComponent(EntityComponentTypes.Equippable) ?? null;
    }

    static getSlot(player, slot) {
        return this.getEquippable(player)?.getEquipmentSlot(slot) ?? null;
    }

    static getItem(player, slot) {
        return safeItem(this.getSlot(player, slot));
    }

    static getMainhand(player) { return this.getItem(player, EquipmentSlot.Mainhand); }
    static getOffhand(player) { return this.getItem(player, EquipmentSlot.Offhand); }

    static getArmor(player) {
        const armor = {};
        for (const [slot, name] of EQUIPMENT_SLOTS.slice(2)) armor[name] = this.getItem(player, slot);
        return armor;
    }

    // Returns a stable, read-only description of the current loadout.
    static getLoadout(player) {
        const result = {};
        for (const [slot, name] of EQUIPMENT_SLOTS) {
            const item = this.getItem(player, slot);
            result[name] = item ? {
                typeId: item.typeId,
                amount: item.amount,
                definition: ITEM_REQUIREMENTS[item.typeId] ?? null
            } : null;
        }
        return result;
    }

    // Hash only data relevant to an equipment change. Dynamic properties are
    // included so Rune/Gem/Augment modifications invalidate the loadout cache.
    static getLoadoutHash(player) {
        const parts = [];
        for (const [slot, name] of EQUIPMENT_SLOTS) {
            const item = this.getItem(player, slot);
            if (!item) { parts.push(`${name}:empty`); continue; }
            let props = "";
            try {
                // Known RPG item properties. Unknown properties are intentionally
                // not enumerated because the Script API does not expose a safe
                // generic dynamic-property key iterator for ItemStack.
                const keys = [
                    "crpg:rune_id", "gem_slot1", "gem_slot2", "gem_skill1", "gem_skill2",
                    "add_atkdmg", "add_chain", "add_chainchance", "add_chaindmg",
                    "add_movespeed", "add_armor", "add_health", "add_evasion",
                    "add_mana", "add_manaregen", "add_vein", "add_scavenging", "add_stunt", "add_luck"
                ];
                props = keys.map(k => `${k}=${item.getDynamicProperty(k) ?? ""}`).join(",");
                props += `|lore=${item.getLore().join("\\n")}`;
            } catch { /* keep the typeId-only fallback */ }
            parts.push(`${name}:${item.typeId}:${item.amount}:${props}`);
        }
        return parts.join(";");
    }

    static getDefinition(itemOrSlot) {
        if (!itemOrSlot) return null;
        const typeId = itemOrSlot.typeId ?? itemOrSlot.getItem?.()?.typeId;
        return typeId ? (ITEM_REQUIREMENTS[typeId] ?? null) : null;
    }

    static getEquippedType(player, slot) {
        return this.getItem(player, slot)?.typeId ?? null;
    }

    static isEquipped(player, typeId, slot = null) {
        if (slot) return this.getEquippedType(player, slot) === typeId;
        return EQUIPMENT_SLOTS.some(([slotId]) => this.getEquippedType(player, slotId) === typeId);
    }

    // Central equipment refresh hook. It does not own Rune/Gem/Augment effects;
    // it asks their existing owners to update item representation/restrictions.
    static refresh(player, refreshInventory = true) {
        if (!player) return false;
        return Logger.guard("equipment refresh", () => {
            ItemRestrictionManager.checkPlayerEquipment(player, refreshInventory);
            return true;
        }, false);
    }

    static getSlotNames() {
        return EQUIPMENT_SLOTS.map(([, name]) => name);
    }
}
