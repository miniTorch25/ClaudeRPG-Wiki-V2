import { ProgressionManager } from "./progression_manager.js";
import { StatsManager } from "./stats_manager.js";
import { AugmentManager } from "../systems/augment.js";
import { HudManager } from "./hud_manager.js";
import { MasteryManager } from "./mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { AchievementManager } from "../systems/achievement_manager.js";

const BASE_MAX_MANA   = 50;
const MANA_PER_MAG    = 10;
const BASE_MANA_REGEN = 1;
const REGEN_PER_WIS   = 1;

// GemAbility lazy loader (gem_ability.js imports ManaManager — keep lazy to avoid circular import)
let _GemAbility = null;
function getGemAbility() {
    if (!_GemAbility) {
        import("../systems/gem_ability.js").then((m) => { _GemAbility = m.GemAbility; }).catch(() => {});
    }
    return _GemAbility;
}

// RuneCN (Curse/Neutral rune modifiers) lazy loader — same circular-import
// reason as GemAbility above (rune_combat.js imports ManaManager).
let _RuneCN = null;
function getRuneCN() {
    if (!_RuneCN) {
        import("../rune/rune_curseneutral.js").then((m) => { _RuneCN = m; }).catch(() => {});
    }
    return _RuneCN;
}

export class ManaManager {
    static getMaxMana(player) {
        const mag       = StatsManager.getStat(player, "stat_mag", 0);
        const bonusMana = AugmentManager.getEquippedTotal(player, "mana");
        const gemMana   = getGemAbility()?.getGemManaBonus(player) ?? 0;
        const base      = BASE_MAX_MANA + (mag * MANA_PER_MAG) + bonusMana + gemMana + ProgressionManager.getPerkValue(player, "max_mana") + MasteryManager.getBonus(player, "max_mana");
        const manaPct   = getRuneCN()?.getManaModPercent(player) ?? 0;
        return Math.max(1, Math.round(base * (1 + manaPct / 100)));
    }

    static getRegenPerSecond(player) {
        const wis        = StatsManager.getStat(player, "stat_wis", 0);
        const bonusRegen = AugmentManager.getEquippedTotal(player, "manaRegen");
        const gemRegen   = getGemAbility()?.getGemManaRegenBonus(player) ?? 0;
        const base       = BASE_MANA_REGEN + (wis * REGEN_PER_WIS) + bonusRegen + gemRegen + MasteryManager.getBonus(player, "mana_regen");
        const regenPct   = getRuneCN()?.getManaRegenModPercent(player) ?? 0;
        return base * (1 + regenPct / 100);
    }

    // Returns current mana clamped to max (handles cases where max shrank after unequipping)
    static getMana(player) {
        const maxMana = this.getMaxMana(player);
        const mana    = Math.min(StatsManager.getStat(player, "stat_mana", BASE_MAX_MANA), maxMana);
        return { mana, maxMana };
    }

    // Set mana to an exact value, clamped 0..maxMana, and mark HUD dirty
    static setMana(player, value) {
        const maxMana  = this.getMaxMana(player);
        const clamped  = Math.max(0, Math.min(maxMana, Math.round(value)));
        StatsManager.setStat(player, "stat_mana", clamped);
        HudManager.markDirty(player);
    }

    // Returns true if player has at least `amount` mana
    static canConsume(player, amount) {
        const { mana } = this.getMana(player);
        return mana >= amount;
    }

    // Deducts `amount` from mana (scaled up by Overload if equipped).
    // Returns true on success, false if insufficient.
    static consume(player, amount) {
        const costPct = getRuneCN()?.getManaCostModPercent(player) ?? 0;
        const gemCut  = getGemAbility()?.getGemManaCostReduction(player) ?? 0;   // Ascended Mind: -% on every skill
        const scaled  = Math.round(amount * (1 + costPct / 100) * (1 - Math.min(90, gemCut) / 100));
        const { mana } = this.getMana(player);
        if (mana < scaled) return false;
        this.setMana(player, mana - scaled);
        AchievementManager.add(player, "mana_spent", scaled);
        if (mana - scaled <= 0) AchievementManager.event(player, "mana_empty");
        MasteryManager.addXp(player, "magic", scaled * MASTERY.MAGIC_XP_PER_MANA);
        return true;
    }

    static regenTick(player) {
        const { mana, maxMana } = this.getMana(player);
        if (mana >= maxMana) return; // nothing to regen, skip dirty mark
        const regen = this.getRegenPerSecond(player);
        this.setMana(player, mana + regen);
    }
}
