// CooldownManager — timestamp-based cooldown stored in player dynamic properties.
//
// Usage:
//   CooldownManager.isReady(player, "stormcall")           → true/false
//   CooldownManager.start(player, "stormcall", 15)         → starts a 15s cooldown
//   CooldownManager.getRemainingSeconds(player, "stormcall") → seconds left (0 if ready)
//
// Keys are namespaced automatically as "cd_{key}" on the player so they never
// collide with other dynamic properties.

import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { RUNE_PROP_KEY } from "../rune/rune_registry.js";
import { RUNE_CONFIG, useRuneLevelOf } from "../config/rune_config.js";
import { MasteryManager } from "./mastery_manager.js";

const PREFIX = "cd_";

// GemAbility lazy loader (gem_ability.js imports this module; Lucid Mind = -% Rune / Gem cooldowns)
let _GemAbility = null;
function _getGemCooldownReduction(player, key) {
    if (String(key).startsWith("chorus")) return 0;   // Chorus has its own cooldown rules
    if (!_GemAbility) {
        import("../systems/gem_ability.js").then((m) => { _GemAbility = m.GemAbility; }).catch(() => {});
        return 0;
    }
    try { return (_GemAbility.getGemCooldownReduction(player) ?? 0) / 100; } catch { return 0; }
}

// Reads the mainhand-equipped rune ID directly (no import from rune_manager.js,
// to avoid a circular dependency: rune_manager -> rune_combat -> cooldown_manager).
function _getMainhandRuneId(player) {
    const equipment = player.getComponent(EntityComponentTypes.Equippable);
    const slot      = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
    if (!slot?.hasItem()) return null;
    return slot.getItem().getDynamicProperty(RUNE_PROP_KEY) ?? null;
}

// Resonance (absorbed Resilience): -10% (configurable) to all rune cooldowns, whenever equipped.
function _getResilienceReduction(player) {
    if (_getMainhandRuneId(player) !== "resonance") return 0;
    useRuneLevelOf(player);
    return RUNE_CONFIG.resonance?.cooldownReduction ?? 0;
}

export class CooldownManager {
    // Returns true if the cooldown has expired (or was never started).
    static isReady(player, key) {
        const expiresAt = player.getDynamicProperty(`${PREFIX}${key}`) ?? 0;
        return Date.now() >= expiresAt;
    }

    // Starts a cooldown of `seconds` duration. Overwrites any running cooldown.
    // Applies the Resonance rune's cooldownReduction, if equipped.
    static start(player, key, seconds) {
        const reduction  = _getResilienceReduction(player);
        // Rune Cooldown Reduce (Rune Mastery): only while a Rune weapon is in hand
        const resonance  = _getMainhandRuneId(player) ? MasteryManager.getBonus(player, "rune_cooldown") / 100 : 0;
        const totalRed   = Math.min(0.9, reduction + resonance + _getGemCooldownReduction(player, key));
        const finalSecs  = totalRed > 0 ? seconds * (1 - totalRed) : seconds;
        player.setDynamicProperty(`${PREFIX}${key}`, Date.now() + finalSecs * 1000);
    }

    // Returns seconds remaining on the cooldown, or 0 if already ready.
    static getRemainingSeconds(player, key) {
        const expiresAt = player.getDynamicProperty(`${PREFIX}${key}`) ?? 0;
        const remaining = (expiresAt - Date.now()) / 1000;
        return remaining > 0 ? Math.ceil(remaining) : 0;
    }

    // Shortens a running cooldown by `seconds` (clears it if that finishes it).
    static reduce(player, key, seconds) {
        const prop = `${PREFIX}${key}`;
        const expiresAt = player.getDynamicProperty(prop) ?? 0;
        if (!expiresAt) return;
        const next = expiresAt - seconds * 1000;
        player.setDynamicProperty(prop, next <= Date.now() ? undefined : next);
    }

    // Clears a cooldown immediately (ready now).
    static clear(player, key) {
        player.setDynamicProperty(`${PREFIX}${key}`, undefined);
    }
}
