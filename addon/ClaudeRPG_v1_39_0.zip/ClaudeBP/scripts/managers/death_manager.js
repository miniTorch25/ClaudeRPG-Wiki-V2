// death_manager.js — handles RPG death (HP reaching 0).
//
// Flow:
//   HPManager._triggerDeath() → DeathManager.onRpgDeath()
//     → check Undying Rune / Undying Gem ability
//     → if no save: apply vanilla kill + drop inventory
//     → on respawn: restore HP to max + reset flags

import { world, system, EntityComponentTypes } from "@minecraft/server";
import { HPManager } from "./hp_manager.js";
import { withSuppressed } from "./damage_manager.js";
import { HudManager } from "./hud_manager.js";
import { RUNE_PROP_KEY } from "../rune/rune_registry.js";
import { RUNE_CONFIG, useRuneLevelOf } from "../config/rune_config.js";
import { XPManager } from "./xp_manager.js";
import { KillManager } from "./kill_manager.js";
import { rollChaosEchoOnRespawn } from "../rune/rune_curseneutral.js";
import { EventBus } from "../core/event_bus.js";
import { AchievementManager } from "../systems/achievement_manager.js";

const _deathSaves = [];   // [(player, context) => boolean] — return true when the death was prevented

export class DeathManager {

    // Registers a death-save (Chorus Revive). Saves run before the Undying Rune / Gem checks.
    // A save must restore HP and clear the death lock itself, then return true.
    static addDeathSave(fn) {
        if (typeof fn === "function" && !_deathSaves.includes(fn)) _deathSaves.push(fn);
    }

    // Called by HPManager when RPG HP hits 0.
    static onRpgDeath(player, context = null) {
        if (!player.isValid) return;
        EventBus.emit("player:rpgDeath:handling", { player, context });

        // ── Death-saves (Chorus Revive) ────────────────────────────────────
        for (const save of _deathSaves) {
            try { if (save(player, context)) { AchievementManager.event(player, "death_denied"); return; } } catch (e) { console.warn(`[DeathManager] death-save failed: ${e}`); }
        }

        // ── Undying Rune check ────────────────────────────────────────────
        // Rune "undying_rune": survive first death per respawn at 1 HP.
        const equip    = player.getComponent(EntityComponentTypes.Equippable);
        const mhSlot   = equip?.getEquipmentSlot("Mainhand");
        const runeId   = mhSlot?.getItem?.()?.getDynamicProperty(RUNE_PROP_KEY) ?? null;
        const hasUndyingRune = runeId === "undying_rune";
        const usedFlag       = player.getDynamicProperty("rune_undying_used") ?? false;

        if (hasUndyingRune && !usedFlag) {
            player.setDynamicProperty("rune_undying_used", true);
            AchievementManager.event(player, "death_denied");
            HPManager.setHP(player, 1);
            HPManager.clearDeathLock(player);
            player.sendMessage("§5[Undying] §fYou cheated death!");
            player.playSound("random.totem");
            player.onScreenDisplay.setActionBar("§5✦ Undying ✦ Survived!");
            return;
        }

        // ── Undying Gem ability check ─────────────────────────────────────
        // GemAbility.hasAbility() checks installed gems across all armor slots.
        import("../systems/gem_ability.js").then(({ GemAbility }) => {
            if (GemAbility.hasAbility(player, "undying") &&
                !player.getDynamicProperty("gem_undying_used")) {
                player.setDynamicProperty("gem_undying_used", true);
                AchievementManager.event(player, "death_denied");
                HPManager.setHP(player, 1);
                HPManager.clearDeathLock(player);
                player.sendMessage("§6[Undying Gem] §fYou refuse to fall!");
                player.playSound("random.totem");
                player.onScreenDisplay.setActionBar("§6✦ Undying Gem ✦ Survived!");
                return;
            }

            // ── No save — apply actual death ─────────────────────────────
            this._executeKill(player);
        }).catch(() => {
            // GemAbility unavailable — skip gem check, just kill
            this._executeKill(player);
        });
    }

    // Executes the actual kill: forces vanilla death so death screen + drops fire.
    static _executeKill(player) {
        if (!player.isValid) return;

        // Curse "Toll of the Fallen": drop extra random items from the inventory and lose a share of your XP.
        try {
            const equip  = player.getComponent(EntityComponentTypes.Equippable);
            const runeId = equip?.getEquipmentSlot("Mainhand")?.getItem?.()?.getDynamicProperty(RUNE_PROP_KEY) ?? null;
            if (runeId === "toll_of_the_fallen") {
                useRuneLevelOf(player);   // curse: level comes from the rune alone
                const c = RUNE_CONFIG.toll_of_the_fallen;
                const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
                if (inv) {
                    for (let n = 0; n < Math.max(1, Math.round(c.extraDrops)); n++) {
                        const filled = [];
                        for (let i = 0; i < inv.size; i++) {
                            if (inv.getItem(i)) filled.push(i);
                        }
                        if (filled.length === 0) break;
                        const slot = filled[Math.floor(Math.random() * filled.length)];
                        const item = inv.getItem(slot);
                        player.dimension.spawnItem(item.clone(), player.location);
                        inv.setItem(slot, undefined);   // the dropped item leaves the inventory
                    }
                }
                const xp = XPManager.getXp(player);
                if (xp > 0) XPManager.setXp(player, Math.floor(xp * (1 - c.xpLossPct / 100)));
            }
        } catch (_) {}

        // Do not use applyDamage here: it would re-enter CombatPipeline.
        // kill @s still fires its own entityHurt event on the player, so mark it
        // suppressed for that call or CombatPipeline will intercept and cancel it,
        // leaving RPG HP at 0 with no actual death.
        try { withSuppressed(player.id, () => player.runCommand("kill @s")); } catch (_) {}
    }

    // ── Respawn handler ───────────────────────────────────────────────────────
    // Called from main.js playerSpawn (initialSpawn = false = respawn).
    static onRespawn(player) {
        // Reset death-save flags
        player.setDynamicProperty("rune_undying_used", false);
        player.setDynamicProperty("gem_undying_used",  false);

        // Curse "Chaos Echo": re-roll the ± damage modifier for this new life
        rollChaosEchoOnRespawn(player);

        // Recalc and restore HP to full
        HPManager.recalcMaxHP(player);
        HPManager.setHP(player, HPManager.getMaxHP(player));
        HPManager.clearDeathLock(player);
        HudManager.markDirty(player);
    }
}
