import { XPManager } from "./xp_manager.js";
import { XpNotifier } from "./xp_notifier.js";
import { XP_CONFIG } from "../config/xp_config.js";
import { MasteryManager } from "./mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { onBlockBroken } from "../systems/achievement_hooks.js";

const TOOL_RE = /_(pickaxe|axe|shovel|hoe)$/;

export class MineXpManager {
    static handleBreak(event) {
            const { player, brokenBlockPermutation } = event;
            const blockTypeId = brokenBlockPermutation?.type?.id;
            if (!blockTypeId) return;
            onBlockBroken(player, brokenBlockPermutation);

            // Gathering Mastery: any block broken with a tool
            try {
                const held = player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand)?.typeId;
                if (held && TOOL_RE.test(held)) MasteryManager.addXp(player, "gathering", MASTERY.GATHER_XP_PER_BLOCK);
            } catch (_) {}

            const config = XP_CONFIG[blockTypeId];
            if (!config || config.type !== "block") return;

            XPManager.addXp(player, config.xp, "Mining", { notify: false });
            XpNotifier.notify(player, config.xp, "Mining");
    }
}
