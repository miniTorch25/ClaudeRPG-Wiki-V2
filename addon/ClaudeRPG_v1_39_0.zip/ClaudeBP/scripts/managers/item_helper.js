// Safely gives an ItemStack to a player.
// If the inventory is full, the leftover is spawned at the player's feet
// so items are never silently lost (e.g. Redeem rewards, Gem returns).
//
// Returns { added: number, dropped: number } so callers can react.
export function giveItemSafely(player, itemStack) {
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) {
        // No inventory component at all – spawn at feet as fallback
        player.dimension.spawnItem(itemStack, player.location);
        return { added: 0, dropped: itemStack.amount };
    }

    const leftover = inventory.addItem(itemStack);

    if (leftover) {
        // Inventory was full – drop remainder at player's location
        player.dimension.spawnItem(leftover, player.location);
        return { added: itemStack.amount - leftover.amount, dropped: leftover.amount };
    }

    return { added: itemStack.amount, dropped: 0 };
}


// Returns the Resource Pack texture path used by an ItemStack in GUI buttons.
// The RP follows Minecraft's conventional item texture naming, so both
// vanilla items and this add-on's custom items can use the same helper.
export function getItemIconPath(itemOrTypeId) {
    const typeId = typeof itemOrTypeId === "string"
        ? itemOrTypeId
        : itemOrTypeId?.typeId;
    if (!typeId) return undefined;

    const shortId = typeId.includes(":") ? typeId.split(":", 2)[1] : typeId;
    // Spears use the addon's own icons (vanilla spear texture names are unreliable).
    if (shortId.endsWith("_spear") && SPEAR_ICONS.has(shortId)) return `textures/icons/spears/${shortId}`;
    const isVanilla = !typeId.includes(":") || typeId.startsWith("minecraft:");
    return `textures/items/${isVanilla ? vanillaTextureName(shortId) : shortId}`;
}

const SPEAR_ICONS = new Set(["wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"].map((t) => `${t}_spear`));

// A few vanilla items use a different texture file name than their item id:
// wooden_* -> wood_*, golden_* -> gold_* (tools, weapons, armor), plus some one-offs.
// Without this the button shows the purple/black "missing texture" square.
const VANILLA_TEXTURE_ALIASES = {
    golden_apple:       "apple_golden",
    golden_carrot:      "carrot_golden",
    bow:                "bow_standby",
    crossbow:           "crossbow_standby",
    fishing_rod:        "fishing_rod_uncast",
};

function vanillaTextureName(shortId) {
    if (VANILLA_TEXTURE_ALIASES[shortId]) return VANILLA_TEXTURE_ALIASES[shortId];
    if (shortId.startsWith("wooden_")) return "wood_" + shortId.slice(7);
    if (shortId.startsWith("golden_")) return "gold_" + shortId.slice(7);
    return shortId;
}
