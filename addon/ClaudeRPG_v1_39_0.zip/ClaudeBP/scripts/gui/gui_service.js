import { Logger } from "../core/logger.js";

// UI infrastructure only: it owns form presentation/session state, never gameplay data.
const activeForms = new Map();

export const GuiService = {
    isOpen(player) {
        return !!player && activeForms.has(player.id);
    },

    current(player) {
        return player ? activeForms.get(player.id) ?? null : null;
    },

    async show(player, form, screen = "unknown") {
        if (!player || !form) return { canceled: true, blocked: true };
        const id = player.id;
        const previous = activeForms.get(id);
        if (previous) {
            return { canceled: true, blocked: true, screen: previous.screen };
        }

        const session = { screen, openedAt: Date.now() };
        activeForms.set(id, session);
        try {
            const response = await form.show(player);
            return response;
        } catch (error) {
            Logger.error(`GUI failed: ${screen}`, error);
            return { canceled: true, error };
        } finally {
            if (activeForms.get(id) === session) activeForms.delete(id);
        }
    },

    clear(playerOrId) {
        const id = typeof playerOrId === "string" ? playerOrId : playerOrId?.id;
        if (id) activeForms.delete(id);
    },

    clearAll() {
        activeForms.clear();
    },
};
