import { GuiManager } from "./gui_manager.js";
import { RuneCreativeGui } from "../systems/rune_creative_gui.js";
import { UltenchGui } from "../systems/ultench_gui.js";
import { ReforgeManager } from "../systems/reforge.js";
import { RedeemManager } from "../systems/redeem.js";
import { KnowledgeManager } from "../systems/knowledge_book.js";
import { ChorusGui } from "../systems/chorus_gui.js";
import { ScriptToolGui } from "../systems/script_tool_gui.js";
import { AchievementGui } from "../systems/achievement_gui.js";
import { GuideQuestGui } from "../systems/guide_quest_gui.js";
import { WaypointGui } from "../systems/waypoint_gui.js";
import { DiscoveryGui } from "../systems/discovery_gui.js";
import { SettingsGui } from "../systems/settings_gui.js";
import { ToastComposerGui } from "../systems/toast_composer_gui.js";
import { Logger } from "../core/logger.js";

const ROUTES = Object.freeze({
    status: player => GuiManager.openStatusMenu(player),
    gem: player => UltenchGui.openMain(player),
    rune_creative: player => RuneCreativeGui.openMain(player),
    reforge: player => ReforgeManager.openReforgeMenu(player),
    redeem: player => RedeemManager.openRedeemMenu(player),
    knowledge: player => KnowledgeManager.openMainMenu(player),
    ultench: player => UltenchGui.openMain(player),
    chorus: player => ChorusGui.openSetView(player),
    achievements: player => AchievementGui.openMain(player),
    guide: player => GuideQuestGui.openMain(player),
    waypoints: player => WaypointGui.openManage(player),
    discovery: player => DiscoveryGui.openMain(player),
    settings: player => SettingsGui.open(player),
    toast: player => ToastComposerGui.open(player),
    script_tool: player => ScriptToolGui.openMain(player, (route) => GuiRouter.open(player, route)),
});

export const GuiRouter = {
    open(player, route) {
        const handler = ROUTES[route];
        if (!handler) {
            Logger.warn(`Unknown GUI route: ${route}`);
            return false;
        }
        try {
            handler(player);
            return true;
        } catch (error) {
            Logger.error(`GUI route failed: ${route}`, error);
            return false;
        }
    },

    has(route) {
        return typeof ROUTES[route] === "function";
    },
};
