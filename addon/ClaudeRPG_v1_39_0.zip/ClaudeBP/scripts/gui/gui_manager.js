import { GuiService } from "../gui/gui_service.js";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { StatsManager } from "../managers/stats_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { ChorusGui } from "../systems/chorus_gui.js";
import { PrestigeGui } from "../systems/prestige_gui.js";
import { AscensionGui } from "../systems/ascension_gui.js";
import { MasteryGui } from "../systems/mastery_gui.js";
import { GuideQuest } from "../systems/guide_quest.js";
import { GuideQuestGui } from "../systems/guide_quest_gui.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { ManaManager } from "../managers/mana_manager.js";
import { AugmentManager } from "../systems/augment.js";
import { GemAbility } from "../systems/gem_ability.js";
import { GemState } from "../systems/gem_state.js";
import { AchievementGui } from "../systems/achievement_gui.js";
import { AchievementManager } from "../systems/achievement_manager.js";
import { onMenuOpened } from "../systems/achievement_hooks.js";

const STAT_NAMES = ["str", "def", "agi", "psi", "exc", "mag", "wis", "con", "vit"];

export class GuiManager {

    // 1. Status Menu
    // "████████████░░░░░░░░ 60%" — 20 cells, filled part green, empty part dark gray.
    static buildProgressBar(current, max, cells = 20) {
        const ratio  = max > 0 ? Math.min(1, Math.max(0, current / max)) : 0;
        const filled = Math.floor(ratio * cells);
        return `§a${"|".repeat(filled)}§8${"|".repeat(cells - filled)} §f${Math.floor(ratio * 100)}\uE21F`;
    }

    // Status Menu = a short list of categories (like the Knowledge Book); each opens its own page.
    static buildStatusBody(player) {
        const data   = StatsManager.getPlayerData(player);
        const maxXp  = StatsManager.getMaxXp(data.level);
        const { mana, maxMana } = ManaManager.getMana(player);
        return `§f=== §ePlayer Status §f===\n\n` +
            `§a\uE207 Level: §f${data.level} §8/ ${ProgressionManager.getMaxLevel(player)}\n` +
            `§3\uE208 Xp: §f${data.xp} / ${maxXp}\n` +
            `${this.buildProgressBar(data.xp, maxXp)}\n` +
            `§w\uE205 Mana: §f${mana} / ${maxMana}\n` +
            `§d\uE209 Points remaining: §f${data.points}`;
    }

    static openStatusMenu(player) {
        onMenuOpened(player, "status");
        const form = new ActionFormData()
            .title("§l§1STATUS MENU")
            .body(this.buildStatusBody(player) + "\n\n§8Pick a category.")
            .button("§2Character & Gear\n§8[Stats Manager, Total Statistics, Chorus]", "textures/icons/gear")
            .button(`§6Progression\n§8[Prestige P${ProgressionManager.getPrestige(player)}${ProgressionManager.getPendingPerks(player) > 0 ? " · Perk waiting" : ""}, Mastery, Ascension, Achievements]`, "textures/icons/prestige")
            .button("§4Reset & Delete\n§8[Refund Points or erase everything]", "textures/icons/trash_can");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            this.openStatusCategory(player, ["char", "prog", "data"][response.selection]);
        }).catch((error) => console.warn(`[Status System] Failed to open Status Menu: ${error}`));
    }

    static openStatusCategory(player, id) {
        const back = () => this.openStatusCategory(player, id);
        const form = new ActionFormData();
        let entries = [];
        if (id === "char") {
            form.title("§l§2CHARACTER & GEAR").body("§7Your stats and armor sets.");
            entries = [
                ["§2Stats Manager\n§8[Add, Remove, Custom Allocation]", "textures/icons/gear",        () => this.openStatsManagerMenu(player)],
                ["§9Total Statistics\n§8[View all player stats]",       "textures/icons/total_stats", () => this.openAugmentStatsMenu(player)],
                ["§dChorus\n§8[Armor element set effects]",             "textures/icons/chorus",      () => ChorusGui.openSetView(player, back)],
            ];
        } else if (id === "prog") {
            form.title("§l§6PROGRESSION").body("§7Long-term growth.");
            entries = [
                [`§6Prestige\n§8[P${ProgressionManager.getPrestige(player)}${ProgressionManager.getPendingPerks(player) > 0 ? " · Perk waiting" : ""}]`, "textures/icons/prestige", () => PrestigeGui.openMenu(player, back)],
                [ProgressionManager.getPrestige(player) >= 1 ? "§bMastery\n§8[Permanent skills]" : "§8Mastery §c[Locked]\n§8Prestige 1", "textures/icons/mastery", () => MasteryGui.openMenu(player, back)],
                [`§4Ascension\n§8[World: Asc ${ProgressionManager.getAscension()}]`, "textures/icons/ascension", () => AscensionGui.openMenu(player, back)],
                [`§aGuide Quest\n§8[${GuideQuest.doneCount(player)} / ${GuideQuest.requiredCount} steps]`, "textures/icons/progression", () => GuideQuestGui.openMain(player, back)],
                [`§eAchievements\n§8[${AchievementManager.unlockedCount(player)} / ${AchievementManager.engine.total}]`, "textures/icons/achievement", () => AchievementGui.openMain(player, back)],
            ];
        } else {
            form.title("§l§4RESET & DELETE").body("§cDangerous: these change your character. Each asks for confirmation.");
            entries = [
                ["§6Reset All\n§8[Refunds all stats as Points]",        "textures/icons/blue_reroll", () => this.openResetConfirmMenu(player)],
                ["§4Delete All\n§8[Erases Level, Stats, Points, Xp]",   "textures/icons/trash_can",   () => this.openDeleteConfirmMenu(player)],
            ];
        }
        for (const [label, icon] of entries) form.button(label, icon);
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            if (response.selection >= entries.length) return this.openStatusMenu(player);
            entries[response.selection][2]();
        }).catch((error) => console.warn(`[Status System] Failed to open Status category: ${error}`));
    }

    // 1b. Stats Manager — all stat values plus Add / Remove / Custom Allocation.
    static openStatsManagerMenu(player) {
        onMenuOpened(player, "stats_manager");
        const data = StatsManager.getPlayerData(player);

        const form = new ActionFormData()
            .title("§l§2STATS MANAGER")
            .body(
                `§d\uE209 Points remaining: §f${data.points}\n\n` +
                `§c\uE200 Str (Strength): §f${data.str}\n` +
                `§a\uE201 Def (Defense): §f${data.def}\n` +
                `§b\uE202 Agi (Agility): §f${data.agi}\n` +
                `§u\uE203 Psi (Psionic): §f${data.psi}\n` +
                `§6\uE204 Exc (Excavation): §f${data.exc}\n` +
                `§w\uE205 Mag (Magic): §f${data.mag}\n` +
                `§f\uE206 Wis (Wisdom): §f${data.wis}\n` +
                `§4\uE20D Con (Constitution): §f${data.con}\n` +
                `§4\uE20C Vit (Vitality): §f${data.vit}`
            )
            .button("§2Add Stats\n§8[Uses Points]",                    "textures/icons/green_plus")
            .button("§cRemove Stats\n§8[Refunds Points]",              "textures/icons/red_minus")
            .button("§bCustom Allocation\n§8[Multiple stats at once]", "textures/icons/gear")
            .button("§8< Back",                                        "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            switch (response.selection) {
                case 0: this.openAddStatMenu(player);          break;
                case 1: this.openRemoveStatMenu(player);       break;
                case 2: this.openCustomAllocationMenu(player); break;
                case 3: this.openStatusCategory(player, "char"); break;
            }
        }).catch((error) => console.warn(`[Status System] Failed to open Stats Manager Menu: ${error}`));
    }

    // 2. Total Statistics — complete numeric snapshot of the player's current RPG stats.
    // Every registered value is shown, including 0 and negative values.
    // `viewer` is who sees the GUI (defaults to `player`); pass readOnly to hide
    // the Augment Setting button and skip back to the view-only Status Menu instead
    // (used by the Insight Lens to inspect another player).
    static async openAugmentStatsMenu(player, { viewer = player, readOnly = false } = {}) {
        if (!readOnly) { onMenuOpened(viewer, "total_stats"); AchievementManager.event(viewer, "stats_opened"); }
        try {
            const data = StatsManager.getPlayerData(player);
            const { mana, maxMana } = ManaManager.getMana(player);
            const hpManager = await import("../managers/hp_manager.js");
            const HPManager = hpManager.HPManager;

            // Rune continuous modifiers are loaded lazily because the rune system
            // has circular dependencies with the combat/stat managers.
            const [RuneCN, RuneManager, RuneRegistry] = await Promise.all([
                import("../rune/rune_curseneutral.js"),
                import("../rune/rune_manager.js"),
                import("../rune/rune_registry.js"),
            ]);

            const runeId = RuneManager.getEquippedRuneId(player);
            const runeMeta = runeId ? RuneRegistry.getRuneMeta(runeId) : null;

            const aug = AugmentManager.getAllEquippedTotals(player);
            const gemAbilities = [...GemAbility.getAbilities(player)];
            const gemArmor = GemAbility.getGemArmorBonus(player);
            const gemMana = GemAbility.getGemManaBonus(player);
            const gemSpeed = GemAbility.getGemSpeedBonus(player);

            const runeHpPct = RuneCN.getHpModPercent(player);
            const runeManaPct = RuneCN.getManaModPercent(player);
            const runeSpeedPct = RuneCN.getSpeedModPercent(player);
            const runeManaRegenPct = RuneCN.getManaRegenModPercent(player);
            const runeXpPct = RuneCN.getXpModPercent(player);
            const runeDamageDealtPct = RuneCN.getDamageDealtPercent(player);
            const runeDamageTakenPct = RuneCN.getDamageTakenPercent(player);
            const runeManaCostPct = RuneCN.getManaCostModPercent(player);
            const runeHealReceivedPct = (RuneCN.getHealReceivedMultiplier(player) - 1) * 100;

            const hp = HPManager.getHP(player);
            const maxHp = HPManager.getMaxHP(player);
            const hpRegen = HPManager.getRegenPerSecond(player);
            const manaRegen = ManaManager.getRegenPerSecond(player);

            // Mastery (same formulas as the combat / movement code)
            const mArmor = MasteryManager.getBonus(player, "armor");
            const damageReduction = Math.min(((aug.armor ?? 0) + gemArmor + mArmor) * 4, 60);
            const evasion = (aug.evasion ?? 0) + GemAbility.getGemEvasionBonus(player) + MasteryManager.getBonus(player, "evasion");
            const dimId = player.dimension?.id ?? "minecraft:overworld";
            const dimKey = dimId === "minecraft:nether" ? "move_speed_nether" : dimId === "minecraft:the_end" ? "move_speed_end" : "move_speed_overworld";
            const mSpeed = MasteryManager.getBonus(player, "move_speed") + MasteryManager.getBonus(player, dimKey);
            const movementSpeed = Math.max(MASTERY.MOVE_SPEED_FLOOR_PCT,
                (aug.movementSpeed ?? 0) + gemSpeed + runeSpeedPct + ProgressionManager.getPerkValue(player, "move_speed") + mSpeed);
            const mb = (id) => MasteryManager.getBonus(player, id);

            // Mastery section: every unlocked line with its active abilities
            const masteryLines = [];
            for (const [lineId, def] of Object.entries(MASTERY.LINES)) {
                if (!MasteryManager.isUnlocked(player, lineId)) continue;
                const d = MasteryManager.describeLine(player, lineId);
                const tag = def.paths ? (d.path ? ` [${def.paths[d.path].name}]` : " [no path]") : "";
                masteryLines.push(`${def.icon}• ${def.name}${tag} §fLv.${d.level}/${d.maxLevel}`);
                for (const r of d.rows) {
                    const v = Math.round(r.value * 100) / 100;
                    masteryLines.push(`   §7${r.name}: §f${v >= 0 ? "+" : ""}${v}${r.unit}${r.enabled ? "" : " §c[OFF]"}`);
                }
                for (const u of d.unlocks) if (u.open) masteryLines.push(`   §a✔ §7${u.name}`);
            }
            if (!masteryLines.length) masteryLines.push("§8Unlocks at Prestige 1");

            const guardianStacks = GemState.getGuardianStacks(player.id);

            const n = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
            const signed = (value, suffix = "") => {
                const v = n(value);
                return `${v >= 0 ? "+" : ""}${v}${suffix}`;
            };
            const plain = (value, suffix = "") => `${n(value)}${suffix}`;
            const pct = (value) => signed(value, "\uE21F");

            const line = (icon, label, value) => `${icon}${label}: §f${value}`;

            const lines = [
                "§f=== §eCore Progression §f===",
                line("§a• ", "Level", `${plain(data.level)} / ${ProgressionManager.getMaxLevel(player)}`),
                line("§3• ", "XP", `${plain(data.xp)} / ${plain(data.level >= 0 ? StatsManager.getMaxXp(data.level) : 0)}`),
                line("§d• ", "Stat Points", plain(data.points)),
                line("§6• ", "Prestige", plain(ProgressionManager.getPrestige(player))),
                line("§4• ", "World Ascension", plain(ProgressionManager.getAscension())),
                "",
                "§f=== §eBase Attributes §f===",
                line("§c• ", "Strength (Str)", plain(data.str)),
                line("§a• ", "Defense (Def)", plain(data.def)),
                line("§b• ", "Agility (Agi)", plain(data.agi)),
                line("§u• ", "Psionic (Psi)", plain(data.psi)),
                line("§6• ", "Excavation (Exc)", plain(data.exc)),
                line("§w• ", "Magic (Mag)", plain(data.mag)),
                line("§f• ", "Wisdom (Wis)", plain(data.wis)),
                line("§4• ", "Constitution (Con)", plain(data.con)),
                line("§4• ", "Vitality (Vit)", plain(data.vit)),
                "",
                "§f=== §eRPG Resources §f===",
                line("§c• ", "HP", `${plain(hp)} / ${plain(maxHp)}`),
                line("§c• ", "HP Regen", plain(hpRegen, "/s")),
                line("§b• ", "Mana", `${plain(mana)} / ${plain(maxMana)}`),
                line("§b• ", "Mana Regen", plain(manaRegen, "/s")),
                "",
                "§f=== §eCombat / Defense §f===",
                line("§c• ", "Attack Damage Bonus", signed(aug.attackDamage ?? 0)),
                line("§6• ", "Damage Dealt Modifier", pct(runeDamageDealtPct)),
                line("§4• ", "Damage Taken Modifier", pct(runeDamageTakenPct)),
                line("§a• ", "Damage Reduction", pct(damageReduction)),
                line("§b• ", "Evasion", pct(evasion)),
                line("§d• ", "Movement Speed", pct(movementSpeed)),
                line("§c• ", "Melee Crit Chance / Damage", `${pct(mb("melee_crit_chance"))} / ${pct(mb("melee_crit_damage"))}`),
                line("§a• ", "Ranged Crit Chance / Damage", `${pct(mb("ranged_crit_chance"))} / ${pct(mb("ranged_crit_damage"))}`),
                line("§c• ", "Mastery Attack Damage", signed(mb("melee_attack_damage"))),
                "",
                "§f=== §eMastery §f===",
                ...masteryLines,
                "",
                "§f=== §eEquipped Augment Totals §f===",
                line("§c• ", "Attack Damage", signed(aug.attackDamage ?? 0)),
                line("§9• ", "Chain Attack", signed(aug.chainAttack ?? 0)),
                line("§9• ", "Chain Chance", pct(aug.chainChance ?? 0)),
                line("§9• ", "Chain Damage", pct(aug.chainDamage ?? 0)),
                line("§d• ", "Movement Speed", pct(aug.movementSpeed ?? 0)),
                line("§5• ", "Stunt", pct(aug.stunt ?? 0)),
                line("§2• ", "Scavenging", pct(aug.scavenging ?? 0)),
                line("§6• ", "Vein", signed(aug.vein ?? 0)),
                line("§e• ", "Luck", pct(aug.luck ?? 0)),
                line("§7• ", "Armor Augment", signed(aug.armor ?? 0)),
                line("§c• ", "Health Augment", signed(aug.health ?? 0)),
                line("§b• ", "Evasion Augment", pct(aug.evasion ?? 0)),
                line("§3• ", "Mana Augment", signed(aug.mana ?? 0)),
                line("§b• ", "Mana Regen Augment", signed(aug.manaRegen ?? 0, "/s")),
                "",
                "§f=== §eGem Bonuses §f===",
                line("§a• ", "Gem Armor", signed(gemArmor)),
                line("§b• ", "Gem Max Mana", signed(gemMana)),
                line("§d• ", "Gem Movement Speed", pct(gemSpeed)),
                line("§e• ", "Active Gem Abilities", plain(gemAbilities.length)),
                line("§b• ", "Guardian Shield Stacks", plain(guardianStacks)),
                `§7• Active: §f${gemAbilities.length ? gemAbilities.join(", ") : "None"}`,
                "",
                "§f=== §eRune Modifiers §f===",
                `§5• Rune: §f${runeId ? (runeMeta?.name ?? runeId) : "None"}`,
                `§5• Category: §f${runeMeta?.category ?? "None"}`,
                line("§c• ", "Max HP Modifier", pct(runeHpPct)),
                line("§b• ", "Max Mana Modifier", pct(runeManaPct)),
                line("§d• ", "Movement Speed Modifier", pct(runeSpeedPct)),
                line("§b• ", "Mana Regen Modifier", pct(runeManaRegenPct)),
                line("§a• ", "XP Gain Modifier", pct(runeXpPct)),
                line("§c• ", "Damage Dealt Modifier", pct(runeDamageDealtPct)),
                line("§4• ", "Damage Taken Modifier", pct(runeDamageTakenPct)),
                line("§b• ", "Mana Cost Modifier", pct(runeManaCostPct)),
                line("§a• ", "Healing Received Modifier", pct(runeHealReceivedPct)),
            ];

            const form = new ActionFormData()
                .title("§l§9Total Statistics")
                .body(lines.join("\n"));
            if (!readOnly) form.button("§bAugment Setting\n§8[Turn stats on/off]", "textures/icons/gear");
            form.button("§8< Back", "textures/icons/back");

            GuiService.show(viewer, form, "gui.gui_manager.js").then((response) => {
                if (response.canceled) return;
                if (readOnly) {
                    this.openViewOnlyStatusMenu(viewer, player);
                    return;
                }
                response.selection === 0
                    ? this.openAugmentSettingsMenu(player)
                    : this.openStatusCategory(player, "char");
            }).catch((error) => console.warn(`[Status System] Failed to open Total Statistics Menu: ${error}`));
        } catch (error) {
            console.warn(`[Status System] Failed to build Total Statistics Menu: ${error}`);
            if (readOnly) this.openViewOnlyStatusMenu(viewer, player); else this.openStatusMenu(player);
        }
    }

    // 2b. Insight Lens — read-only Status Menu for inspecting another player.
    // `viewer` is the Insight Lens holder; `target` is the player being inspected.
    static openViewOnlyStatusMenu(viewer, target) {
        const data  = StatsManager.getPlayerData(target);
        const maxXp = StatsManager.getMaxXp(data.level);
        const { mana, maxMana } = ManaManager.getMana(target);

        const form = new ActionFormData()
            .title(`§l§1STATUS — ${target.name}`)
            .body(
                `§f=== §e${target.name}'s Status §f===\n\n` +
                `§a\uE207 Level: §f${data.level}\n` +
                `§3\uE208 Xp: §f${data.xp} / ${maxXp}\n` +
                `§w\uE205 Mana: §f${mana} / ${maxMana}\n\n` +
                `§c\uE200 Str (Strength): §f${data.str}\n` +
                `§a\uE201 Def (Defense): §f${data.def}\n` +
                `§b\uE202 Agi (Agility): §f${data.agi}\n` +
                `§u\uE203 Psi (Psionic): §f${data.psi}\n` +
                `§6\uE204 Exc (Excavation): §f${data.exc}\n` +
                `§w\uE205 Mag (Magic): §f${data.mag}\n` +
                `§f\uE206 Wis (Wisdom): §f${data.wis}\n` +
                `§4\uE20D Con (Constitution): §f${data.con}\n` +
                `§4\uE20C Vit (Vitality): §f${data.vit}`
            )
            .button("§9Total Statistics\n§8[View all stats]", "textures/icons/total_stats");

        GuiService.show(viewer, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            if (response.selection === 0) this.openAugmentStatsMenu(target, { viewer, readOnly: true });
        }).catch((error) => console.warn(`[Insight Lens] Failed to open view-only Status Menu: ${error}`));
    }

    // 3. Augment Settings (toggle individual stats on/off)
    static openAugmentSettingsMenu(player) {
        const statNames = AugmentManager.getAllStatNames();

        const form = new ActionFormData()
            .title("§l§9Augment Setting")
            .body("§7Turn Augment stats you don't want to use off, or back on.");

        for (const statName of statNames) {
            const def      = AugmentManager.findDisplayDef(statName);
            const disabled = AugmentManager.isStatDisabled(player, statName);
            form.button(`§f${def?.label ?? statName} ${disabled ? "§c[Off]" : "§a[On]"}`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled || response.selection === statNames.length) {
                return this.openAugmentStatsMenu(player);
            }
            const statName = statNames[response.selection];
            AugmentManager.setStatDisabled(player, statName, !AugmentManager.isStatDisabled(player, statName));
            this.openAugmentSettingsMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Augment Setting Menu: ${error}`));
    }

    // 4. Add Stats (one point at a time)
    static openAddStatMenu(player) {
        const data = StatsManager.getPlayerData(player);
        const form = new ActionFormData()
            .title("§l§2Add Stats")
            .body(`§dPoints remaining: §d${data.points}`)
            .button(`§c+ Str §8(current: ${data.str})`)
            .button(`§a+ Def §8(current: ${data.def})`)
            .button(`§b+ Agi §8(current: ${data.agi})`)
            .button(`§u+ Psi §8(current: ${data.psi})`)
            .button(`§6+ Exc §8(current: ${data.exc})`)
            .button(`§w+ Mag §8(current: ${data.mag})`)
            .button(`§f+ Wis §8(current: ${data.wis})`)
            .button(`§4+ Con §8(current: ${data.con})`)
            .button(`§4+ Vit §8(current: ${data.vit})`)
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled || response.selection === STAT_NAMES.length) return this.openStatsManagerMenu(player);

            const selectedStat = STAT_NAMES[response.selection];
            if (StatsManager.addStatPoint(player, selectedStat, 1)) {
                player.sendMessage(`§aIncreased §e${selectedStat.toUpperCase()} §asuccessfully!`);
                player.playSound("random.orb");
            } else if (StatsManager.getStat(player, `stat_${selectedStat}`, 0) >= StatsManager.getStatCap(selectedStat, player)) {
                player.sendMessage(`§cThis stat is already at its cap (${StatsManager.getStatCap(selectedStat, player)})!`);
            } else {
                player.sendMessage("§cYou don't have enough Points!");
            }
            this.openAddStatMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Add Stat Menu: ${error}`));
    }

    // 5. Remove Stats (refund one point at a time)
    static openRemoveStatMenu(player) {
        const data = StatsManager.getPlayerData(player);
        const form = new ActionFormData()
            .title("§l§cRemove Stats")
            .body(`§dPoints remaining: §d${data.points}`)
            .button(`§c- Str §8(current: ${data.str})`)
            .button(`§a- Def §8(current: ${data.def})`)
            .button(`§b- Agi §8(current: ${data.agi})`)
            .button(`§u- Psi §8(current: ${data.psi})`)
            .button(`§6- Exc §8(current: ${data.exc})`)
            .button(`§w- Mag §8(current: ${data.mag})`)
            .button(`§f- Wis §8(current: ${data.wis})`)
            .button(`§4- Con §8(current: ${data.con})`)
            .button(`§4- Vit §8(current: ${data.vit})`)
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled || response.selection === STAT_NAMES.length) return this.openStatsManagerMenu(player);

            const selectedStat = STAT_NAMES[response.selection];
            if (StatsManager.removeStatPoint(player, selectedStat, 1)) {
                player.sendMessage(`§eLowered §c${selectedStat.toUpperCase()} §eand refunded the Point!`);
                player.playSound("random.pop");
            } else {
                player.sendMessage("§cThis stat can't be lowered any further (must stay above 0)!");
            }
            this.openRemoveStatMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Remove Stat Menu: ${error}`));
    }

    // 6. Custom Allocation chooser — Add multiple / Remove multiple
    static openCustomAllocationMenu(player) {
        const form = new ActionFormData()
            .title("§l§bCustom Allocation")
            .body("§7Adjust several stats at once, then confirm all changes together.")
            .button("§2Add Multiple\n§8[Uses Points]",    "textures/icons/green_up_arrow")
            .button("§cRemove Multiple\n§8[Refunds Points]", "textures/icons/red_down_arrow")
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled || response.selection === 2) return this.openStatsManagerMenu(player);
            response.selection === 0 ? this.openCustomAddMenu(player) : this.openCustomRemoveMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Custom Allocation Menu: ${error}`));
    }

    // 6a. Custom Add (multiple stats at once via sliders)
    static openCustomAddMenu(player) {
        const data      = StatsManager.getPlayerData(player);
        const maxPoints = Math.min(Math.max(data.points, 0), 16);

        if (maxPoints <= 0) {
            player.sendMessage("§cYou don't have any Points to allocate!");
            return this.openCustomAllocationMenu(player);
        }

        const form = new ModalFormData()
            .title(`§l§2Add Multiple §d(Points: ${data.points})`)
            .slider("§cStr", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§aDef", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§bAgi", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§uPsi", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§6Exc", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§wMag", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§fWis", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§4Con", 0, maxPoints, { valueStep: 1, defaultValue: 0 })
            .slider("§4Vit", 0, maxPoints, { valueStep: 1, defaultValue: 0 });

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return this.openCustomAllocationMenu(player);

            const [str, def, agi, psi, exc, mag, wis, con, vit] = response.formValues;
            const allocations = { str, def, agi, psi, exc, mag, wis, con, vit };
            const requested    = str + def + agi + psi + exc + mag + wis + con + vit;

            if (requested <= 0) return this.openStatsManagerMenu(player);

            const applied = StatsManager.addMultipleStatPoints(player, allocations);
            if (applied) {
                player.sendMessage(
                    applied < requested
                        ? `§aAllocated §e${applied} Points §a(some stats hit their cap)!`
                        : `§aAllocated §e${applied} Points §asuccessfully!`
                );
                player.playSound("random.orb");
            } else {
                player.sendMessage("§cYou don't have enough Points for that allocation!");
            }
            this.openStatsManagerMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Custom Add Menu: ${error}`));
    }

    // 6b. Custom Remove (multiple stats at once via sliders, refunds Points)
    static openCustomRemoveMenu(player) {
        const data = StatsManager.getPlayerData(player);
        const cap  = (v) => Math.min(v, 16);

        const form = new ModalFormData()
            .title(`§l§cRemove Multiple §d(Points: ${data.points})`)
            .slider(`§cStr §8(${data.str})`, 0, cap(data.str), { valueStep: 1, defaultValue: 0 })
            .slider(`§aDef §8(${data.def})`, 0, cap(data.def), { valueStep: 1, defaultValue: 0 })
            .slider(`§bAgi §8(${data.agi})`, 0, cap(data.agi), { valueStep: 1, defaultValue: 0 })
            .slider(`§uPsi §8(${data.psi})`, 0, cap(data.psi), { valueStep: 1, defaultValue: 0 })
            .slider(`§6Exc §8(${data.exc})`, 0, cap(data.exc), { valueStep: 1, defaultValue: 0 })
            .slider(`§wMag §8(${data.mag})`, 0, cap(data.mag), { valueStep: 1, defaultValue: 0 })
            .slider(`§fWis §8(${data.wis})`, 0, cap(data.wis), { valueStep: 1, defaultValue: 0 })
            .slider(`§4Con §8(${data.con})`, 0, cap(data.con), { valueStep: 1, defaultValue: 0 })
            .slider(`§4Vit §8(${data.vit})`, 0, cap(data.vit), { valueStep: 1, defaultValue: 0 });

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return this.openCustomAllocationMenu(player);

            const [str, def, agi, psi, exc, mag, wis, con, vit] = response.formValues;
            const allocations = { str, def, agi, psi, exc, mag, wis, con, vit };
            const total       = str + def + agi + psi + exc + mag + wis + con + vit;

            if (total <= 0) return this.openStatsManagerMenu(player);

            if (StatsManager.removeMultipleStatPoints(player, allocations)) {
                player.sendMessage(`§eLowered §c${total} stat points §eand refunded them!`);
                player.playSound("random.pop");
            } else {
                player.sendMessage("§cOne or more of those stats can't be lowered that much!");
            }
            this.openStatsManagerMenu(player);
        }).catch((error) => console.warn(`[Status System] Failed to open Custom Remove Menu: ${error}`));
    }

    // 7. Reset confirmation — refunds every allocated stat point back to Points.
    static openResetConfirmMenu(player) {
        const data     = StatsManager.getPlayerData(player);
        const refunded = STAT_NAMES.reduce((sum, name) => sum + Math.max(0, data[name] ?? 0), 0);
        const form = new ActionFormData()
            .title("§l§6Confirm Reset")
            .body(
                `§eReset all stats back into Points?\n\n` +
                `§7Every stat returns to 0 and §f${refunded} Point(s) §7are refunded.\n` +
                `§7Your Level, Xp, and current Points are kept.`
            )
            .button("§6Confirm Reset")
            .button("§8Cancel");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            if (response.selection === 0) {
                const gained = StatsManager.refundAllStats(player);
                AchievementManager.event(player, "reset_all_uses");
                player.sendMessage(`§6All stats have been reset! §f+${gained} Point(s) §6refunded.`);
                player.playSound("random.orb");
            }
            this.openStatusCategory(player, "data");
        }).catch((error) => console.warn(`[Status System] Failed to open Reset Confirm Menu: ${error}`));
    }

    // 8. Delete All confirmation — permanent wipe of Level, Stats, Points and Xp.
    static openDeleteConfirmMenu(player) {
        const form = new ActionFormData()
            .title("§l§4Confirm Delete All")
            .body(
                "§cAre you sure you want to DELETE everything?\n\n" +
                "§4*This permanently erases your Level, Stats, Points, and Xp back to 0. Nothing is refunded!"
            )
            .button("§4Confirm Delete All")
            .button("§8Cancel");

        GuiService.show(player, form, "gui.gui_manager.js").then((response) => {
            if (response.canceled) return;
            if (response.selection === 0) {
                StatsManager.resetAllStats(player);
                AchievementManager.event(player, "delete_all_uses");
                player.sendMessage("§cAll of your Level, Stats, Points, and Xp have been deleted!");
                player.playSound("random.glass");
            } else {
                this.openStatusCategory(player, "data");
            }
        }).catch((error) => console.warn(`[Status System] Failed to open Delete Confirm Menu: ${error}`));
    }
}
