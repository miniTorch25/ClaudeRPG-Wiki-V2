import { GuiService } from "../gui/gui_service.js";
// ultench_gui.js — Ultimate Enchanter GUI
//
// Opened when player right-clicks crpg:ultimate_enchanter block.
// Sections:
//   (Rune Enchanting / Remove moved to the Anvil > Rune page — see rune_anvil_gui.js)
//   3. Gem Transmute (Random)  — rerolls gem tier in socket (random weight)
//   4. Gem Transmute (Upgrade) — upgrades gem one tier up
//   5. Gem Enchanting    — choose a specific skill for an installed gem

import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { EntityComponentTypes, EquipmentSlot, ItemStack } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { GemManager, GEM_TIERS, GEM_ITEM_MAP, SOCKET_LEVELS, ENGRAVE_RATES, GEM_MAG_REQ,
         CARVE_TABLE, GEM_DUST_ID, GEM_TIER_SKILLS } from "./gem_manager.js";
import { GEM_CATEGORY_NAME } from "./gem_registry.js";
import { GEM_ENCHANT_MODE } from "../config/gem_ability_config.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { StatsManager } from "../managers/stats_manager.js";
import { ManaManager } from "../managers/mana_manager.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { VanillaEnchantManager } from "./vanilla_enchant.js";
import { displayName } from "./rarity_name.js";
import { ChorusGui } from "./chorus_gui.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { onGemEnchant, onUltenchUse } from "./achievement_hooks.js";
import { GuideQuest } from "./guide_quest.js";
import { onMenuOpened } from "./achievement_hooks.js";

// ─── Costs ───────────────────────────────────────────────────────────────────
// Single-material economy: every action costs ONE material type, paid in bulk.
//   Gem   -> Gem Dust only
//   Chorus-> Resonant Ink only (see config/chorus_config.js)
// Genesis Ink is no longer spent on any action (it is only a crafting step
// toward Transcendent Ink).
// Gem Transmute (Random):   tier x 8 Gem Dust.
// Gem Transmute (Upgrade):  tier x 18 Gem Dust.
// Gem Enchanting:           tier x 12 Gem Dust.
// Gem Remove:               3x Gem Dust.


const GEM_TX_RAND_DUST_PER_T = 8;
const GEM_TX_UP_DUST_PER_T   = 18;
const GEM_ENCH_DUST_PER_T    = 12;
const GEM_REMOVE_DUST_COST   = 3;

// Gem typeIds the player can install (no Random Gem — that system is retired)
// Ported from gem_gui.js (Phase 2 — Socket Drilling/Insert/Remove moved into Ultench)
const INSTALLABLE_GEM_IDS = [
    "crpg:common_gem",
    "crpg:uncommon_gem",
    "crpg:rare_gem",
    "crpg:unique_gem",
    "crpg:legend_gem",
    "crpg:epic_gem",
    "crpg:myth_gem",
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function countInv(player, typeId) {
    return GemManager.countItem(player, typeId);
}

function consumeInv(player, typeId, amount = 1) {
    for (let i = 0; i < amount; i++) {
        if (!GemManager.consumeItem(player, typeId)) return false;
    }
    return true;
}

function getMainhandSlot(player) {
    return player
        .getComponent(EntityComponentTypes.Equippable)
        ?.getEquipmentSlot(EquipmentSlot.Mainhand);
}

function getArmorSlots(player) {
    const results   = [];
    const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const equipment = player.getComponent(EntityComponentTypes.Equippable);
    const armorEquipSlots = [
        EquipmentSlot.Head, EquipmentSlot.Chest,
        EquipmentSlot.Legs, EquipmentSlot.Feet, EquipmentSlot.Offhand
    ];

    if (inventory) {
        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (!slot.hasItem()) continue;
            if (ITEM_REQUIREMENTS[slot.typeId]?.type === "armor")
                results.push({ kind: "inventory", index: i });
        }
    }
    if (equipment) {
        for (const es of armorEquipSlots) {
            const slot = equipment.getEquipmentSlot(es);
            if (!slot?.hasItem()) continue;
            if (ITEM_REQUIREMENTS[slot.typeId]?.type === "armor")
                results.push({ kind: "equipment", equipSlot: es });
        }
    }
    return results;
}

function resolveSlot(player, ref) {
    if (ref.kind === "inventory")
        return player.getComponent(EntityComponentTypes.Inventory)?.container?.getSlot(ref.index);
    return player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(ref.equipSlot);
}

function armorLabel(slot) {
    const item = slot.getItem();
    return displayName(item);
}

// Upgrade gem tier one step, returns new tierId or null if already max
function upgradeTier(currentTierId, player = null) {
    const idx = GEM_TIERS.findIndex((t) => t.id === currentTierId);
    if (idx < 0 || idx >= GEM_TIERS.length - 1) return null;
    const next = GEM_TIERS[idx + 1].id;
    if (player && !MasteryManager.isGemTierOpen(player, next)) return null;   // locked by Gem Mastery
    return next;
}

// ─── UltenchGui ──────────────────────────────────────────────────────────────

export class UltenchGui {

    // 0. Main menu
    static openMain(player) {
        onMenuOpened(player, "ultench");
        const dust   = countInv(player, GEM_DUST_ID);
        const echo   = countInv(player, "crpg:resonant_ink");

        const form = new ActionFormData()
            .title("§l§5Ultimate Enchanter")
            .body(`§7Gem Dust: §f${dust}   §7Resonant Ink: §f${echo}`)
            // Order = the order things unlock: Vanilla (always) -> Chorus -> Gem. (Runes moved to the Anvil.)
            .button("§bVanilla Enchant\n§8[Uses Enchant Essence]",            "textures/icons/gem_enchant")
            .button(ProgressionManager.canUse(player, "chorus")
                ? "§dChorus\n§8[Roll, Lock, Remove Elements]"
                : `§8Chorus §c[Locked]\n§8${ProgressionManager.requirementText("chorus")}`,        "textures/icons/chorus")
            .button(ProgressionManager.canUse(player, "gem")
                ? "§5Gem\n§8[Transmute, Enchant, Socket]"
                : `§8Gem §c[Locked]\n§8${ProgressionManager.requirementText("gem")}`,              "textures/icons/gem")
            .button("§8< Close",                                              "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: VanillaEnchantManager.open(player, () => this.openMain(player)); break;
                case 1: if (ProgressionManager.guard(player, "chorus")) ChorusGui.openMenu(player, () => this.openMain(player)); break;
                case 2: if (ProgressionManager.guard(player, "gem"))  this.openGemMenu(player);  break;
            }
        }).catch((e) => console.warn(`[Ultench] Main menu error: ${e}`));
    }

    // ─── Category: GEM ───────────────────────────────────────────────────────

    static openGemMenu(player) {
        const form = new ActionFormData()
            .title("§l§5Ultench — Gem")
            .body("§7Choose a Gem action.")
            .button("§6Engrave Socket\n§8[Open a Gem socket]",              "textures/items/engraver")
            .button("§aInsert Gem\n§8[Socket a Gem]",                       "textures/icons/blue_down_arrow")
            .button("§cRemove Gem\n§8[Retrieve Gem]",                       "textures/icons/trash_can")
            .button("§5Gem Transmute §8(Random)\n§8[Rerolls gem tier]",     "textures/icons/gem_transmute")
            .button("§dGem Transmute §8(Upgrade)\n§8[One tier higher]",     "textures/icons/blue_up_arrow")
            .button("§aGem Enchanting\n§8[Choose gem skill]",               "textures/icons/gem_enchant")
            .button("§8< Back",                                             "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: this.openEngraveSelectArmor(player);           break;
                case 1: this.openInstallSelectArmor(player);           break;
                case 2: this.openRemoveSelectArmor(player);            break;
                case 3: this.openGemTransmuteArmor(player, "random");  break;
                case 4: this.openGemTransmuteArmor(player, "upgrade"); break;
                case 5: this.openGemEnchantArmor(player);              break;
                case 6: this.openMain(player);                         break;
            }
        }).catch((e) => console.warn(`[Ultench] Gem menu error: ${e}`));
    }

    // ─── 3 & 4. GEM TRANSMUTE ────────────────────────────────────────────────

    static openGemTransmuteArmor(player, mode) {
        const armors = getArmorSlots(player);
        if (armors.length === 0) {
            player.sendMessage("§cNo armor found!");
            return this.openMain(player);
        }

        const title = mode === "random"
            ? "§l§5Gem Transmute (Random) — Armor"
            : "§l§dGem Transmute (Upgrade) — Armor";

        const form = new ActionFormData().title(title);
        for (const ref of armors) {
            const slot   = resolveSlot(player, ref);
            const states = GemManager.getSlotStates(slot);
            const hasGem = states.some((s) => s !== "locked" && s !== "empty");
            form.button(
                `§f${armorLabel(slot)}\n` +
                (hasGem ? "§aHas Gem to transmute" : "§8No Gem installed"),
                getItemIconPath(slot.getItem())
            );
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled || r.selection === armors.length) return this.openMain(player);
            this.openGemTransmuteSocket(player, armors[r.selection], mode);
        }).catch((e) => console.warn(`[Ultench] Transmute armor error: ${e}`));
    }

    static openGemTransmuteSocket(player, ref, mode) {
        const slot   = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const states   = GemManager.getSlotStates(slot);
        const gemSlots = states
            .map((s, i) => ({ index: i, state: s }))
            .filter(({ state }) => state !== "locked" && state !== "empty");

        if (gemSlots.length === 0) {
            player.sendMessage("§cNo installed Gems to transmute here.");
            return this.openGemTransmuteArmor(player, mode);
        }

        const dust   = countInv(player, GEM_DUST_ID);
        const title  = mode === "random"
            ? "§l§5Gem Transmute (Random)"
            : "§l§dGem Transmute (Upgrade)";

        const form = new ActionFormData().title(title);
        for (const { index, state } of gemSlots) {
            const tier    = GEM_TIERS.find((t) => t.id === state);
            const tierIdx = GEM_TIERS.findIndex((t) => t.id === state);
            const dc = mode === "random"
                ? (tierIdx + 1) * GEM_TX_RAND_DUST_PER_T
                : (tierIdx + 1) * GEM_TX_UP_DUST_PER_T;
            const canAfford = dust >= dc;
            const upgradeTarget = mode === "upgrade" ? upgradeTier(state, player) : null;
            const upgradeNote   = mode === "upgrade"
                ? (upgradeTarget
                    ? ` -> ${GEM_TIERS.find((t) => t.id === upgradeTarget)?.label ?? "?"}`
                    : " §8(Max tier)")
                : "";

            form.button(
                `${canAfford ? "" : "§8"}Socket ${index + 1}: ` +
                `${tier?.color ?? "§f"}${tier?.label ?? state} Gem${upgradeNote}\n` +
                `§8${dc}× Gem Dust`,
                tier?.itemId ? getItemIconPath(tier.itemId) : undefined
            );
        }
        form.button("§8< Back", "textures/icons/back");
        form.body(`§7Gem Dust: §f${dust}`);

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled || r.selection === gemSlots.length) {
                return this.openGemTransmuteArmor(player, mode);
            }

            const { index: si, state } = gemSlots[r.selection];
            const tierIdx = GEM_TIERS.findIndex((t) => t.id === state);
            const dc = mode === "random"
                ? (tierIdx + 1) * GEM_TX_RAND_DUST_PER_T
                : (tierIdx + 1) * GEM_TX_UP_DUST_PER_T;

            if (dust < dc) {
                player.sendMessage(`§c[Transmute] Need §f${dc}× Gem Dust§c.`);
                return this.openGemTransmuteSocket(player, ref, mode);
            }

            let newTierId;
            if (mode === "random") {
                newTierId = GemManager.randomCarve(player);
            } else {
                newTierId = upgradeTier(state, player);
                if (!newTierId) {
                    player.sendMessage("§c[Transmute] This Gem cannot go higher (maximum tier, or the next tier is locked by Gem Mastery).");
                    return this.openGemTransmuteSocket(player, ref, mode);
                }
            }

            consumeInv(player, GEM_DUST_ID, dc);

            GemManager.setSlotState(slot, si, newTierId);
            GemManager.clearSlotSkill(slot, si);   // skill resets on transmute
            onUltenchUse(player);
            ItemRestrictionManager.updateSlotLore(slot, player);

            const oldTier = GEM_TIERS.find((t) => t.id === state);
            const newTier = GEM_TIERS.find((t) => t.id === newTierId);
            player.sendMessage(
                `§5[Transmute] §7${oldTier?.label ?? state} -> ` +
                `${newTier?.color ?? "§f"}${newTier?.label ?? newTierId} Gem!`
            );
            player.playSound("random.orb");
            this.openMain(player);
        }).catch((e) => console.warn(`[Ultench] Transmute socket error: ${e}`));
    }

    // ─── 5. GEM ENCHANTING ───────────────────────────────────────────────────

    static openGemEnchantArmor(player) {
        const armors = getArmorSlots(player);
        if (armors.length === 0) {
            player.sendMessage("§cNo armor found!");
            return this.openMain(player);
        }

        const form = new ActionFormData().title("§l§aGem Enchanting — Armor");
        for (const ref of armors) {
            const slot   = resolveSlot(player, ref);
            const states = GemManager.getSlotStates(slot);
            const hasGem = states.some((s) => s !== "locked" && s !== "empty");
            form.button(
                `§f${armorLabel(slot)}\n` +
                (hasGem ? "§aHas Gem to enchant" : "§8No Gem installed"),
                getItemIconPath(slot.getItem())
            );
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled || r.selection === armors.length) return this.openMain(player);
            this.openGemEnchantSocket(player, armors[r.selection]);
        }).catch((e) => console.warn(`[Ultench] Gem enchant armor error: ${e}`));
    }

    static openGemEnchantSocket(player, ref) {
        const slot   = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const states   = GemManager.getSlotStates(slot);
        const gemSlots = states
            .map((s, i) => ({ index: i, state: s }))
            .filter(({ state }) => state !== "locked" && state !== "empty");

        if (gemSlots.length === 0) {
            player.sendMessage("§cNo installed Gems here.");
            return this.openGemEnchantArmor(player);
        }

        const form = new ActionFormData().title("§l§aGem Enchanting — Socket");
        for (const { index, state } of gemSlots) {
            const tier  = GEM_TIERS.find((t) => t.id === state);
            const skill = GemManager.getSlotSkill(slot, index);
            form.button(
                `Socket ${index + 1}: ${tier?.color ?? "§f"}${tier?.label ?? state} Gem\n` +
                (skill ? `§8Skill: §f${skill}` : "§8Unenchanted"),
                tier?.itemId ? getItemIconPath(tier.itemId) : undefined
            );
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled || r.selection === gemSlots.length) {
                return this.openGemEnchantArmor(player);
            }
            const { index: si, state } = gemSlots[r.selection];
            this.openGemEnchantSkill(player, ref, si, state);
        }).catch((e) => console.warn(`[Ultench] Gem enchant socket error: ${e}`));
    }

    static openGemEnchantSkill(player, ref, socketIndex, tierId) {
        const slot     = resolveSlot(player, ref);
        if (!slot?.hasItem()) return this.openMain(player);

        const tierIdx  = GEM_TIERS.findIndex((t) => t.id === tierId);
        const dc       = (tierIdx + 1) * GEM_ENCH_DUST_PER_T;
        const dust     = countInv(player, GEM_DUST_ID);
        const skills   = GemManager.getEligibleSkills(tierId, slot.typeId);   // what THIS armor piece can carry
        const cat      = GEM_CATEGORY_NAME[GemManager.getArmorCategory(slot.typeId)] ?? "this armor";
        const curSkill = GemManager.getSlotSkill(slot, socketIndex);
        const tier     = GEM_TIERS.find((t) => t.id === tierId);
        const random   = GEM_ENCHANT_MODE !== "choose";

        const form = new ActionFormData()
            .title("§l§aGem Enchanting — Ability")
            .body(
                `§7Gem: ${tier?.color ?? "§f"}${tier?.label ?? tierId}  §8(${cat} armor)\n` +
                `§7Current ability: ${curSkill ? `§f${curSkill}` : "§8None"}\n\n` +
                `§7Cost per enchant: §f${dc}× Gem Dust\n` +
                `§7Have: §f${dust}× Gem Dust\n\n` +
                `§7${cat} can roll (${skills.length}):\n§f${skills.join("§8, §f")}\n\n` +
                (random ? "§8Rolling picks one at random and replaces the current ability."
                        : "§8Choosing a new ability replaces the existing one.")
            );

        if (random) form.button(`§aRoll Ability\n§8${dc}× Gem Dust`);
        else for (const skill of skills) {
            const isCurrent = skill === curSkill;
            form.button(`${isCurrent ? "§a✓ " : ""}§f${skill}${isCurrent ? " §8(current)" : ""}`);
        }
        form.button("§8< Back", "textures/icons/back");
        const backIndex = random ? 1 : skills.length;

        GuiService.show(player, form, "systems.ultench_gui.js").then((r) => {
            if (r.canceled || r.selection === backIndex) {
                return this.openGemEnchantSocket(player, ref);
            }
            if (skills.length === 0) {
                player.sendMessage("§c[Gem Enchanting] This armor cannot carry an ability from that Gem.");
                return this.openGemEnchantSkill(player, ref, socketIndex, tierId);
            }

            const chosenSkill = random ? GemManager.rollSkill(tierId, slot.typeId, curSkill) : skills[r.selection];
            if (!chosenSkill) return this.openGemEnchantSkill(player, ref, socketIndex, tierId);
            if (dust < dc) {
                player.sendMessage(`§c[Gem Enchanting] Need §f${dc}× Gem Dust§c.`);
                return this.openGemEnchantSkill(player, ref, socketIndex, tierId);
            }

            consumeInv(player, GEM_DUST_ID, dc);

            GemManager.setSlotSkill(slot, socketIndex, chosenSkill);
            ItemRestrictionManager.updateSlotLore(slot, player);
            onGemEnchant(player, tierId);

            player.sendMessage(
                `§a[Gem Enchanting] §f${tier?.color ?? ""}${tier?.label ?? tierId} Gem ` +
                `§agained §f${chosenSkill}§a!`
            );
            player.playSound("random.levelup");
            this.openMain(player);
        }).catch((e) => console.warn(`[Ultench] Gem enchant skill error: ${e}`));
    }

    // ─── 6. ENGRAVE SOCKET (ported from gem_gui.js — Phase 2) ─────────────────

    static openEngraveSelectArmor(player) {
        const armors = getArmorSlots(player);
        if (armors.length === 0) {
            player.sendMessage("§cNo armor found in your inventory or equipment!");
            return this.openMain(player);
        }

        const form = new ActionFormData().title("§l§6Engrave — Select Armor");
        for (const ref of armors) {
            const slot   = resolveSlot(player, ref);
            const states = GemManager.getSlotStates(slot);
            const s1     = states[0] === "locked" ? "§8●" : "§a●";
            form.button(`§f${armorLabel(slot)}\n${s1}`, getItemIconPath(slot.getItem()));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === armors.length) {
                return this.openMain(player);
            }
            this.openEngraveSelectSocket(player, armors[response.selection]);
        }).catch((e) => console.warn(`[Ultench] Engrave armor select error: ${e}`));
    }

    static openEngraveSelectSocket(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const level  = StatsManager.getStat(player, "stat_level", 0);
        const states = GemManager.getSlotStates(slot);

        let engraverDur = "§cNone!";
        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (inv) {
            let hasEternal = false;
            for (let i = 0; i < inv.size; i++) {
                const s = inv.getSlot(i);
                if (s.hasItem() && s.typeId === "crpg:eternal_engraver") { hasEternal = true; break; }
            }
            if (hasEternal) {
                engraverDur = "§6Eternal (Free)";
            } else {
                for (let i = 0; i < inv.size; i++) {
                    const s = inv.getSlot(i);
                    if (s.hasItem() && s.typeId === "crpg:engraver") {
                        try {
                            const dur = s.getItem().getComponent("minecraft:durability");
                            if (dur) engraverDur = `§f${dur.maxDurability - dur.damage}/${dur.maxDurability}`;
                        } catch { engraverDur = "§7?"; }
                        break;
                    }
                }
            }
        }

        const form = new ActionFormData()
            .title("§l§6Engrave — Select Socket")
            .body(
                `§7Engraver: ${engraverDur}\n` +
                `§7Durability is consumed even on failure.\n\n` +
                `§7Socket 1: §f${Math.round(GemManager.getEngraveRate(player, 0) * 100)}\uE21F success §8(${ProgressionManager.requirementText("gem")})`
            );

        for (let i = 0; i < SOCKET_LEVELS.length; i++) {
            const state    = states[i];
            const required = SOCKET_LEVELS[i];
            let btnLabel;
            if (state !== "locked") {
                btnLabel = `§8Socket ${i + 1}: §8Already opened`;
            } else if (!ProgressionManager.canUse(player, "gem")) {
                btnLabel = `§8Socket ${i + 1}: §c${ProgressionManager.requirementText("gem")} required`;
            } else {
                btnLabel = `§aSocket ${i + 1}: §fEngrave (${Math.round(GemManager.getEngraveRate(player, i) * 100)}\uE21F)`;
            }
            form.button(btnLabel);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === SOCKET_LEVELS.length) {
                return this.openEngraveSelectArmor(player);
            }
            const socketIndex = response.selection;
            const state       = GemManager.getSlotState(slot, socketIndex);
            const required    = SOCKET_LEVELS[socketIndex];

            if (state !== "locked") {
                player.sendMessage("§cThis socket is already opened!");
                return this.openEngraveSelectSocket(player, ref);
            }
            if (!ProgressionManager.canUse(player, "gem")) {
                player.sendMessage(`§cYou need ${ProgressionManager.requirementText("gem")} to engrave this socket!`);
                return this.openEngraveSelectSocket(player, ref);
            }
            // Bug fix (Phase 4/#9): an Eternal Engraver alone used to fail this
            // check because only crpg:engraver was counted. It now qualifies too.
            if (GemManager.countItem(player, "crpg:engraver") === 0 &&
                GemManager.countItem(player, "crpg:eternal_engraver") === 0) {
                player.sendMessage("§cYou need an Engraver in your inventory!");
                return this.openEngraveSelectSocket(player, ref);
            }

            const result = GemManager.engrave(player, slot, socketIndex);
            if (result.broke)    player.sendMessage("§cYour Engraver broke!");
            if (result.success) {
                ItemRestrictionManager.updateSlotLore(slot, player);
                GuideQuest.flag(player, "socket_engraved");
                player.sendMessage(`§aSocket ${socketIndex + 1} engraved successfully!`);
                player.playSound("random.anvil_use");
            } else {
                player.sendMessage(`§cEngrave failed! §8(${Math.round(GemManager.getEngraveRate(player, socketIndex) * 100)}\uE21F chance)`);
                player.playSound("note.bass");
            }
            this.openEngraveSelectSocket(player, ref);
        }).catch((e) => console.warn(`[Ultench] Engrave socket select error: ${e}`));
    }

    // ─── 7. INSERT GEM (ported from gem_gui.js — Phase 2) ─────────────────────

    static openInstallSelectArmor(player) {
        const armors = getArmorSlots(player);
        if (armors.length === 0) {
            player.sendMessage("§cNo armor found!");
            return this.openMain(player);
        }

        const form = new ActionFormData().title("§l§aInsert Gem — Select Armor");
        for (const ref of armors) {
            const slot     = resolveSlot(player, ref);
            const states   = GemManager.getSlotStates(slot);
            const hasEmpty = states.includes("empty");
            form.button(`§f${armorLabel(slot)}\n${hasEmpty ? "§aHas empty socket" : "§8No empty socket"}`, getItemIconPath(slot.getItem()));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === armors.length) {
                return this.openMain(player);
            }
            this.openInstallSelectSocket(player, armors[response.selection]);
        }).catch((e) => console.warn(`[Ultench] Install armor select error: ${e}`));
    }

    static openInstallSelectSocket(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const states      = GemManager.getSlotStates(slot);
        const emptySockets = states
            .map((s, i) => ({ index: i, state: s }))
            .filter(({ state }) => state === "empty");

        if (emptySockets.length === 0) {
            player.sendMessage("§cThis armor has no empty sockets! Engrave first.");
            return this.openInstallSelectArmor(player);
        }

        const form = new ActionFormData().title("§l§aInsert Gem — Select Socket");
        for (const { index } of emptySockets) {
            form.button(`§aSocket ${index + 1} §8(Empty)`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === emptySockets.length) {
                return this.openInstallSelectArmor(player);
            }
            this.openInstallSelectGem(player, ref, emptySockets[response.selection].index);
        }).catch((e) => console.warn(`[Ultench] Install socket select error: ${e}`));
    }

    static openInstallSelectGem(player, ref, socketIndex) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const mag       = StatsManager.getStat(player, "stat_mag", 0);
        const available = INSTALLABLE_GEM_IDS.filter((id) => GemManager.countItem(player, id) > 0);
        if (available.length === 0) {
            player.sendMessage("§cYou don't have any Gems in your inventory!");
            return this.openInstallSelectSocket(player, ref);
        }

        const form = new ActionFormData()
            .title("§l§aInsert Gem — Select Gem")
            .body(`§7Your Mag: §f+${mag}  §8(Required varies by tier)`);

        for (const gemId of available) {
            const count  = GemManager.countItem(player, gemId);
            const tierId = GEM_ITEM_MAP[gemId];
            const tier   = GEM_TIERS.find((t) => t.id === tierId);
            const tIdx   = GEM_TIERS.findIndex((t) => t.id === tierId);
            const magReq = GEM_MAG_REQ[tIdx] ?? 0;
            const canUse = mag >= magReq;
            const label  = tier
                ? `${canUse ? tier.color : "§8"}${tier.label} Gem\n§8x${count} §8(Mag +${magReq}${canUse ? "" : " §c✗"})`
                : `§8Unknown\n§8x${count}`;
            form.button(label);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === available.length) {
                return this.openInstallSelectSocket(player, ref);
            }

            const gemId  = available[response.selection];
            const tierId = GEM_ITEM_MAP[gemId];
            const tIdx   = GEM_TIERS.findIndex((t) => t.id === tierId);
            const magReq = GEM_MAG_REQ[tIdx] ?? 0;

            if (mag < magReq) {
                player.sendMessage(`§c[Gem] Insufficient Mag! Need +${magReq}, have +${mag}.`);
                return this.openInstallSelectGem(player, ref, socketIndex);
            }

            const result = GemManager.installGem(player, slot, socketIndex, gemId);
            if (!result) {
                player.sendMessage("§cInstallation failed!");
                return this.openInstallSelectGem(player, ref, socketIndex);
            }

            const tier = GEM_TIERS.find((t) => t.id === result);
            ItemRestrictionManager.updateSlotLore(slot, player);
            GuideQuest.flag(player, "gem_inserted");
            player.sendMessage(`§a${tier?.color ?? ""}${tier?.label ?? result} Gem §ainstalled in Socket ${socketIndex + 1}!`);
            player.playSound("random.orb");
            this.openMain(player);
        }).catch((e) => console.warn(`[Ultench] Install gem select error: ${e}`));
    }

    // ─── 8. REMOVE GEM (ported from gem_gui.js — Phase 2) ──────────────────────

    static openRemoveSelectArmor(player) {
        const armors = getArmorSlots(player);
        if (armors.length === 0) {
            player.sendMessage("§cNo armor found!");
            return this.openMain(player);
        }

        const form = new ActionFormData().title("§l§cRemove Gem — Select Armor");
        for (const ref of armors) {
            const slot   = resolveSlot(player, ref);
            const states = GemManager.getSlotStates(slot);
            const hasGem = states.some((s) => s !== "locked" && s !== "empty");
            form.button(`§f${armorLabel(slot)}\n${hasGem ? "§aHas installed Gem" : "§8No Gem installed"}`, getItemIconPath(slot.getItem()));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === armors.length) {
                return this.openMain(player);
            }
            this.openRemoveSelectSocket(player, armors[response.selection]);
        }).catch((e) => console.warn(`[Ultench] Remove armor select error: ${e}`));
    }

    static openRemoveSelectSocket(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cItem no longer available!");
            return this.openMain(player);
        }

        const states   = GemManager.getSlotStates(slot);
        const gemSlots = states
            .map((s, i) => ({ index: i, state: s }))
            .filter(({ state }) => state !== "locked" && state !== "empty");

        if (gemSlots.length === 0) {
            player.sendMessage("§cThis armor has no installed Gems!");
            return this.openRemoveSelectArmor(player);
        }

        const dust = countInv(player, GEM_DUST_ID);
        const form = new ActionFormData()
            .title("§l§cRemove Gem — Select Socket")
            .body(`§7Removal cost: §f${GEM_REMOVE_DUST_COST}× Gem Dust  §8(have: ${dust})`);
        for (const { index, state } of gemSlots) {
            const tier  = GEM_TIERS.find((t) => t.id === state);
            const label = tier ? `${tier.color}${tier.label} Gem` : "§8Unknown";
            form.button(`§fSocket ${index + 1}: ${label}`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.ultench_gui.js").then((response) => {
            if (response.canceled || response.selection === gemSlots.length) {
                return this.openRemoveSelectArmor(player);
            }

            const { index: socketIndex } = gemSlots[response.selection];
            const dust = countInv(player, GEM_DUST_ID);
            if (dust < GEM_REMOVE_DUST_COST) {
                player.sendMessage(`§c[Gem] Removing a Gem costs §f${GEM_REMOVE_DUST_COST}× Gem Dust §c(have: ${dust}).`);
                return this.openRemoveSelectSocket(player, ref);
            }

            const gemItem = GemManager.removeGem(player, slot, socketIndex);
            if (!gemItem) {
                player.sendMessage("§cFailed to remove gem!");
                return this.openRemoveSelectSocket(player, ref);
            }
            consumeInv(player, GEM_DUST_ID, GEM_REMOVE_DUST_COST);
            onUltenchUse(player);

            const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
            if (inv && inv.emptySlotsCount > 0) inv.addItem(gemItem);
            else player.dimension.spawnItem(gemItem, player.location);

            ItemRestrictionManager.updateSlotLore(slot, player);
            player.sendMessage(`§aGem removed from Socket ${socketIndex + 1}!`);
            player.playSound("random.pop");
            this.openMain(player);
        }).catch((e) => console.warn(`[Ultench] Remove socket select error: ${e}`));
    }
}
