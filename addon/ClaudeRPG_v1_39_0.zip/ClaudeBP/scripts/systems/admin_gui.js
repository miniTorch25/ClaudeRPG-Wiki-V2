// admin_gui.js -- the Admin panel (Admin tag required): Player Tools, World Tools,
// Config Editor and Audit Log. Opened with  /scriptevent status:admin
// Close the chat window after running the command; the panel retries until it can show.

import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world, system } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { AdminManager, GROUPS } from "../managers/admin_manager.js";
import { AdminOps, STAT_NAMES, MOB_TYPES } from "./admin_ops.js";
import { AchievementAdmin } from "./achievement_admin.js";
import { AchievementManager } from "./achievement_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { StatsManager } from "../managers/stats_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { EVOLUTION, ENCHANTED } from "../config/evolution_config.js";
import { PROGRESSION } from "../config/progression_config.js";

const SCREEN = "systems.admin_gui.js";

// Shows a form; when the player's chat window is still open it waits and retries.
function show(player, form, tries = 0) {
    return GuiService.show(player, form, SCREEN).then((r) => {
        if (r.canceled && r.cancelationReason === "UserBusy" && tries < 40) {
            return new Promise((resolve) => system.runTimeout(() => resolve(show(player, form, tries + 1)), 5));
        }
        return r;
    });
}

const guardAdmin = (admin) => {
    if (AdminManager.isAdmin(admin)) return true;
    try { admin.sendMessage("§c[Admin] You no longer have the Admin tag."); } catch (_) {}
    return false;
};
const say = (admin, results) => {
    for (const r of [].concat(results)) if (r?.text) admin.sendMessage(r.text);
};
const err = (label, e) => console.warn(`[AdminGui] ${label}: ${e}`);
const num = (text) => (String(text ?? "").trim() === "" ? null : text);

export const AdminGui = {

    // ═══ Main ═════════════════════════════════════════════════════════════
    openMain(admin) {
        if (!guardAdmin(admin)) return;
        const form = new ActionFormData()
            .title("§l§cADMIN PANEL")
            .body(`§7Signed in as §f${admin.name}\n§7World Ascension §f${ProgressionManager.getAscension()}  §7Config overrides §f${AdminManager.overrideCount()}\n§8Every action is written to the Audit Log.`)
            .button("§bPlayer Tools\n§8[Level, Stats, Prestige, Mastery...]", "textures/icons/admin")
            .button("§4World Tools\n§8[Ascension, spawn / purge mobs]", "textures/icons/ascension")
            .button("§6Config Editor\n§8[Edit game numbers live]", "textures/icons/gear")
            .button("§7Audit Log", "textures/items/knowledge_book")
            .button("§8Close");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: return this.pickPlayer(admin);
                case 1: return this.openWorld(admin);
                case 2: return this.openConfigGroups(admin);
                case 3: return this.openLog(admin);
            }
        }).catch((e) => err("main", e));
    },

    // ═══ Player Tools ═════════════════════════════════════════════════════
    pickPlayer(admin) {
        if (!guardAdmin(admin)) return;
        const players = world.getAllPlayers().sort((a, b) => (a.id === admin.id ? -1 : b.id === admin.id ? 1 : a.name.localeCompare(b.name)));
        const form = new ActionFormData().title("§l§bChoose a player").body("§7Who do you want to edit?");
        for (const p of players) form.button(p.id === admin.id ? `§f${p.name} §8(you)` : `§f${p.name}`);
        form.button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            if (r.selection >= players.length) return this.openMain(admin);
            this.playerMenu(admin, players[r.selection]);
        }).catch((e) => err("pick", e));
    },

    _alive(admin, target) {
        if (target?.isValid) return true;
        admin.sendMessage("§c[Admin] That player is no longer online.");
        this.pickPlayer(admin);
        return false;
    },

    playerMenu(admin, target) {
        if (!guardAdmin(admin) || !this._alive(admin, target)) return;
        const form = new ActionFormData()
            .title(`§l§b${target.name}`)
            .body(AdminOps.summary(target))
            .button("§fLevel / XP / Points", "textures/icons/progression")
            .button("§fStats", "textures/icons/total_stats")
            .button("§6Prestige & Perks", "textures/icons/prestige")
            .button("§bMastery", "textures/icons/mastery")
            .button("§dLevel unlocks")
            .button("§aUtilities\n§8[Heal, Insomnia, Resets]")
            .button("§eAchievements\n§8[Grant, revoke, set counter]")
            .button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: return this.levelForm(admin, target);
                case 1: return this.statsForm(admin, target);
                case 2: return this.prestigeForm(admin, target);
                case 3: return this.masteryMenu(admin, target);
                case 4: return this.unlocksForm(admin, target);
                case 5: return this.utilities(admin, target);
                case 6: return this.achievementMenu(admin, target);
                case 7: return this.pickPlayer(admin);
            }
        }).catch((e) => err("player menu", e));
    },

    levelForm(admin, target) {
        if (!this._alive(admin, target)) return;
        const form = new ModalFormData()
            .title("§lLevel / XP / Points")
            .dropdown("Mode", ["Set", "Add"], { defaultValueIndex: 0 })
            .textField(`Level (now ${ProgressionManager.getLevel(target)}, max ${ProgressionManager.getMaxLevel(target)})`, "leave empty to skip")
            .textField(`XP (now ${Math.floor(StatsManager.getStat(target, "stat_xp", 0))})`, "leave empty to skip")
            .textField(`Points (now ${StatsManager.getStat(target, "stat_points", 0)})`, "leave empty to skip");
        show(admin, form).then((r) => {
            if (r.canceled) return this.playerMenu(admin, target);
            const [modeIdx, lvl, xp, pts] = r.formValues;
            const mode = modeIdx === 1 ? "add" : "set";
            const out = [];
            if (num(lvl) !== null) out.push(AdminOps.level(admin, target, mode, lvl));
            if (num(xp) !== null)  out.push(AdminOps.xp(admin, target, mode, xp));
            if (num(pts) !== null) out.push(AdminOps.points(admin, target, mode, pts));
            say(admin, out);
            this.playerMenu(admin, target);
        }).catch((e) => err("level form", e));
    },

    statsForm(admin, target) {
        if (!this._alive(admin, target)) return;
        const current = STAT_NAMES.map((s) => StatsManager.getStat(target, `stat_${s}`, 0));
        const form = new ModalFormData().title("§lStats §8(set exact values)");
        STAT_NAMES.forEach((s, i) => form.textField(`${s.toUpperCase()} §8(cap ${StatsManager.getStatCap(s, target)})`, String(current[i]), { defaultValue: String(current[i]) }));
        show(admin, form).then((r) => {
            if (r.canceled) return this.playerMenu(admin, target);
            const out = [];
            STAT_NAMES.forEach((s, i) => {
                const v = String(r.formValues[i] ?? "").trim();
                if (v !== "" && Number(v) !== current[i]) out.push(AdminOps.stat(admin, target, s, v));
            });
            if (!out.length) admin.sendMessage("§7[Admin] No stat changed.");
            say(admin, out);
            this.playerMenu(admin, target);
        }).catch((e) => err("stats form", e));
    },

    prestigeForm(admin, target) {
        if (!this._alive(admin, target)) return;
        const form = new ModalFormData()
            .title("§lPrestige & Perks")
            .textField("Prestige", "number", { defaultValue: String(ProgressionManager.getPrestige(target)) })
            .textField("Waiting Perk picks", "number", { defaultValue: String(ProgressionManager.getPendingPerks(target)) })
            .toggle("Clear ALL picked Perks", { defaultValue: false });
        show(admin, form).then((r) => {
            if (r.canceled) return this.playerMenu(admin, target);
            const [pres, picks, clear] = r.formValues;
            const out = [];
            if (clear) out.push(AdminOps.clearPerks(admin, target));
            if (num(pres) !== null && Number(pres) !== ProgressionManager.getPrestige(target)) out.push(AdminOps.prestige(admin, target, pres));
            if (num(picks) !== null && !clear && Number(picks) !== ProgressionManager.getPendingPerks(target)) out.push(AdminOps.perks(admin, target, "set", picks));
            if (!out.length) admin.sendMessage("§7[Admin] Nothing changed.");
            say(admin, out);
            this.playerMenu(admin, target);
        }).catch((e) => err("prestige form", e));
    },

    masteryMenu(admin, target) {
        if (!this._alive(admin, target)) return;
        const lines = Object.entries(MASTERY.LINES);
        const form = new ActionFormData().title("§l§bMastery").body("§7Choose a line to edit.");
        for (const [id, def] of lines) {
            const state = MasteryManager.isUnlocked(target, id) ? "" : " §c(locked)";
            form.button(`${def.icon}${def.name} §fLv.${MasteryManager.getLevel(target, id)}${state}\n§8${Math.floor(MasteryManager.getXp(target, id))} XP`, `textures/icons/mastery_lines/${id}`);
        }
        form.button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            if (r.selection >= lines.length) return this.playerMenu(admin, target);
            this.masteryForm(admin, target, lines[r.selection][0]);
        }).catch((e) => err("mastery menu", e));
    },

    masteryForm(admin, target, line) {
        if (!this._alive(admin, target)) return;
        const def = MASTERY.LINES[line];
        const pathIds = def.paths ? Object.keys(def.paths) : [];
        const pathOpts = ["(keep)", "none", ...pathIds];
        const form = new ModalFormData()
            .title(`§l${def.name} Mastery`)
            .textField(`Set Level (now ${MasteryManager.getLevel(target, line)}, max ${def.maxLevel})`, "leave empty to skip")
            .textField("Add XP (negative removes)", "leave empty to skip")
            .toggle("Re-roll this line's random values", { defaultValue: false });
        if (pathIds.length) form.dropdown(`Path (now ${MasteryManager.getPath(target, line) ?? "none"})`, pathOpts, { defaultValueIndex: 0 });
        show(admin, form).then((r) => {
            if (r.canceled) return this.masteryMenu(admin, target);
            const [lvl, xp, reroll, pathIdx] = r.formValues;
            const out = [];
            if (num(lvl) !== null) out.push(AdminOps.masteryLevel(admin, target, line, lvl));
            if (num(xp) !== null)  out.push(AdminOps.masteryXp(admin, target, line, xp));
            if (reroll) out.push(AdminOps.masteryReroll(admin, target, line));
            if (pathIds.length && pathIdx > 0) out.push(AdminOps.masteryPath(admin, target, line, pathOpts[pathIdx]));
            say(admin, out);
            this.masteryMenu(admin, target);
        }).catch((e) => err("mastery form", e));
    },

    unlocksForm(admin, target) {
        if (!this._alive(admin, target)) return;
        // Feature gates are Prestige / Ascension based now: show them read-only (change them with set prestige / set ascension).
        const rows = Object.entries(PROGRESSION.FEATURES).map(([id, d]) => {
            const ok = ProgressionManager.canUse(target, id);
            return `${ok ? "\u00a7a\u2714" : "\u00a7c\u2718"} \u00a7f${d.name} \u00a78(${ProgressionManager.requirementText(id)})`;
        });
        const form = new ActionFormData()
            .title("\u00a7lFeature gates")
            .body(`\u00a77${target.name}\n\n${rows.join("\n")}\n\n\u00a78Gates use Prestige / Ascension. Change them with set prestige / set ascension, or in the Config Editor.`)
            .button("\u00a78< Back");
        show(admin, form).then(() => this.playerMenu(admin, target)).catch((e) => err("unlocks form", e));
    },

    utilities(admin, target) {
        if (!this._alive(admin, target)) return;
        const form = new ActionFormData()
            .title("§l§aUtilities")
            .body(`§7Target: §f${target.name}`)
            .button("§aFull heal (HP + Mana)")
            .button("§fSet insomnia days")
            .button("§cClear all Perks")
            .button("§4Reset Level, XP, Points & stats")
            .button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: say(admin, AdminOps.heal(admin, target)); return this.utilities(admin, target);
                case 1: return this.insomniaForm(admin, target);
                case 2: return this.confirm(admin, `§cRemove every picked Perk and waiting pick from §f${target.name}§c?`, () => say(admin, AdminOps.clearPerks(admin, target)), () => this.utilities(admin, target));
                case 3: return this.confirm(admin, `§cReset Level, XP, Points and ALL stats of §f${target.name}§c to 0? Prestige, Perks and Mastery stay.`, () => say(admin, AdminOps.resetStats(admin, target)), () => this.utilities(admin, target));
                case 4: return this.playerMenu(admin, target);
            }
        }).catch((e) => err("utilities", e));
    },

    insomniaForm(admin, target) {
        if (!this._alive(admin, target)) return;
        const form = new ModalFormData().title("§lInsomnia").textField("Days without sleep", "0 - 1000", { defaultValue: "0" });
        show(admin, form).then((r) => {
            if (!r.canceled) say(admin, AdminOps.insomnia(admin, target, r.formValues[0]));
            this.utilities(admin, target);
        }).catch((e) => err("insomnia", e));
    },

    // ═══ Shared confirm ═══════════════════════════════════════════════════
    // onYes runs the action; the panel then returns to onBack.
    confirm(admin, text, onYes, onBack) {
        const form = new ActionFormData().title("§l§cConfirm").body(text).button("§cYes, do it").button("§8Cancel");
        show(admin, form).then((r) => {
            if (!r.canceled && r.selection === 0) { try { onYes(); } catch (e) { err("confirm action", e); } }
            if (onBack) onBack();
        }).catch((e) => err("confirm", e));
    },

    // ═══ World Tools ══════════════════════════════════════════════════════
    openWorld(admin) {
        if (!guardAdmin(admin)) return;
        const form = new ActionFormData()
            .title("§l§4World Tools")
            .body(`§7World Ascension: §c${ProgressionManager.getAscension()}`)
            .button("§4Set World Ascension", "textures/icons/ascension")
            .button("§dSpawn evolved mob\n§8[Test a tier in front of you]", "textures/icons/mob_evolution")
            .button("§cPurge evolved mobs nearby", "textures/icons/trash_can")
            .button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: return this.ascensionForm(admin);
                case 1: return this.spawnForm(admin);
                case 2: return this.purgeForm(admin);
                case 3: return this.openMain(admin);
            }
        }).catch((e) => err("world", e));
    },

    ascensionForm(admin) {
        const current = ProgressionManager.getAscension();
        const form = new ModalFormData().title("§lWorld Ascension").textField(`Ascension (now ${current}) — affects EVERY player`, "number", { defaultValue: String(current) });
        show(admin, form).then((r) => {
            if (r.canceled) return this.openWorld(admin);
            const raw = r.formValues[0];
            const n = Number(raw);
            if (Number.isFinite(n) && n < current) {
                return this.confirm(admin, `§cLower the world from Ascension ${current} to ${Math.round(n)}? Everyone is affected at once.`, () => say(admin, AdminOps.ascension(admin, raw)), () => this.openWorld(admin));
            }
            say(admin, AdminOps.ascension(admin, raw));
            this.openWorld(admin);
        }).catch((e) => err("ascension form", e));
    },

    spawnForm(admin) {
        const tiers = [...Object.entries(EVOLUTION.TIERS), ["enchanted", ENCHANTED]];
        const form = new ModalFormData()
            .title("§lSpawn evolved mob")
            .dropdown("Tier", tiers.map(([, t]) => t.name), { defaultValueIndex: 0 })
            .dropdown("Mob", MOB_TYPES.map((m) => m.replace("minecraft:", "")), { defaultValueIndex: 0 })
            .textField("Count (1 - 10)", "1", { defaultValue: "1" });
        show(admin, form).then((r) => {
            if (!r.canceled) {
                const [ti, mi, count] = r.formValues;
                say(admin, AdminOps.spawn(admin, tiers[ti][0], MOB_TYPES[mi], count));
            }
            this.openWorld(admin);
        }).catch((e) => err("spawn form", e));
    },

    purgeForm(admin) {
        const form = new ModalFormData().title("§lPurge evolved mobs").textField("Radius in blocks (4 - 256)", "48", { defaultValue: "48" });
        show(admin, form).then((r) => {
            if (!r.canceled) say(admin, AdminOps.purge(admin, r.formValues[0]));
            this.openWorld(admin);
        }).catch((e) => err("purge form", e));
    },

    // === Achievements (per player) ===
    achievementMenu(admin, target) {
        if (!guardAdmin(admin) || !this._alive(admin, target)) return;
        const form = new ActionFormData()
            .title(`§l§e${target.name} §8Achievements`)
            .body(AchievementAdmin.info(target).text + "\n§8System switch: Config Editor > Achievements")
            .button("§aGrant one\n§8[by id, e.g. CB01]")
            .button("§cRevoke one\n§8[by id]")
            .button("§bSet a counter\n§8[progress value]")
            .button("§aGrant ALL")
            .button("§4Reset ALL progress")
            .button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            const again = () => this.achievementMenu(admin, target);
            switch (r.selection) {
                case 0: return this.achievementId(admin, target, "Grant", (id) => AchievementAdmin.grant(admin, target, id), again);
                case 1: return this.achievementId(admin, target, "Revoke", (id) => AchievementAdmin.revoke(admin, target, id), again);
                case 2: return this.achievementCounter(admin, target, again);
                case 3: return this.confirm(admin, "§cGrant EVERY Achievement to " + target.name + "?", () => { say(admin, AchievementAdmin.grant(admin, target, "all")); again(); });
                case 4: return this.confirm(admin, "§cReset ALL Achievement progress of " + target.name + "?", () => { say(admin, AchievementAdmin.reset(admin, target)); again(); });
                case 5: return this.playerMenu(admin, target);
            }
        }).catch((e) => err("achievement menu", e));
    },

    achievementId(admin, target, verb, run, again) {
        const form = new ModalFormData().title(`§l${verb} Achievement`).textField("Achievement id (CB01, MN05, MC12 ...)", "id");
        show(admin, form).then((r) => {
            if (r.canceled) return again();
            const id = String(r.formValues?.[0] ?? "").trim();
            if (id) say(admin, run(id));
            again();
        }).catch((e) => err("achievement id", e));
    },

    achievementCounter(admin, target, again) {
        const form = new ModalFormData().title("§lSet counter")
            .textField("Counter name (e.g. melee_hits, blocks_mined)", "counter")
            .textField("Value", "number");
        show(admin, form).then((r) => {
            if (r.canceled) return again();
            const [k, v] = (r.formValues ?? []).map((x) => String(x ?? "").trim());
            if (k && v !== "") say(admin, AchievementAdmin.setCounter(admin, target, k, v));
            again();
        }).catch((e) => err("achievement counter", e));
    },

    // ═══ Config Editor ════════════════════════════════════════════════════
    openConfigGroups(admin) {
        if (!guardAdmin(admin)) return;
        const form = new ActionFormData()
            .title("§l§6Config Editor")
            .body(`§7Edit game numbers live. Changes apply at once and are kept after restarts.\n§7Active overrides: §f${AdminManager.overrideCount()}`);
        for (const g of GROUPS) {
            const entries = AdminManager.entriesOf(g.id);
            const changed = entries.filter((e) => AdminManager.isOverridden(e.id)).length;
            form.button(`§f${g.label}\n§8${entries.length} values${changed ? ` §6(${changed} changed)` : ""}`);
        }
        form.button("§cReset ALL overrides");
        form.button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            if (r.selection < GROUPS.length) return this.openConfigGroup(admin, GROUPS[r.selection].id);
            if (r.selection === GROUPS.length) {
                return this.confirm(admin, `§cReset all ${AdminManager.overrideCount()} config override(s) to the defaults from the config files?`, () => say(admin, AdminOps.configResetAll(admin)), () => this.openConfigGroups(admin));
            }
            this.openMain(admin);
        }).catch((e) => err("config groups", e));
    },

    openConfigGroup(admin, groupId) {
        const group = GROUPS.find((g) => g.id === groupId);
        const entries = AdminManager.entriesOf(groupId);
        const form = new ActionFormData().title(`§l§6${group.label}`).body("§7Pick a value to edit. §6*§7 = changed from default.");
        for (const e of entries) {
            form.button(`§f${e.label}\n§8${AdminManager.format(e)}${AdminManager.isOverridden(e.id) ? " §6*" : ""}  §8(default ${AdminManager.format(e, e.def)})`);
        }
        form.button("§8< Back");
        show(admin, form).then((r) => {
            if (r.canceled) return;
            if (r.selection >= entries.length) return this.openConfigGroups(admin);
            this.configEntryForm(admin, entries[r.selection]);
        }).catch((e) => err("config group", e));
    },

    configEntryForm(admin, entry) {
        const form = new ModalFormData().title(`§l${entry.label}`);
        if (entry.kind === "enum") {
            form.dropdown(`Value §8(now ${AdminManager.format(entry)}, default ${AdminManager.format(entry, entry.def)})`, entry.options, { defaultValueIndex: Math.max(0, entry.options.indexOf(entry.obj[entry.key])) });
        } else {
            form.textField(`Value §8(default ${AdminManager.format(entry, entry.def)}; ${AdminManager.describeRange(entry)})`, "number", { defaultValue: AdminManager.format(entry) });
        }
        form.toggle("Reset to default", { defaultValue: false });
        show(admin, form).then((r) => {
            if (r.canceled) return this.openConfigGroup(admin, entry.group);
            const [value, reset] = r.formValues;
            if (reset) say(admin, AdminOps.configReset(admin, entry.id));
            else {
                const raw = entry.kind === "enum" ? entry.options[value] : value;
                if (String(raw) !== AdminManager.format(entry)) say(admin, AdminOps.configSet(admin, entry.id, raw));
                else admin.sendMessage("§7[Admin] Value unchanged.");
            }
            this.openConfigGroup(admin, entry.group);
        }).catch((e) => err("config entry", e));
    },

    // ═══ Audit Log ════════════════════════════════════════════════════════
    openLog(admin) {
        if (!guardAdmin(admin)) return;
        const rows = AdminManager.getLog().slice().reverse();
        const body = rows.length
            ? rows.map((x) => `§8${new Date(x.t).toISOString().slice(5, 16).replace("T", " ")} UTC §7${x.who}\n§f${x.text}`).join("\n\n")
            : "§7No actions logged yet.";
        const form = new ActionFormData().title("§lAudit Log §8(last 20)").body(body).button("§8< Back");
        show(admin, form).then((r) => { if (!r.canceled) this.openMain(admin); }).catch((e) => err("log", e));
    },
};
