// rune_creative_gui.js — Creative Mode Rune Tool
//
// Opened from Script Tool > Creative & Admin (Creative mode only).
// The player holds the Script Tool, so this menu never touches the mainhand: you pick the TARGET ITEM from a list of
// the weapons / tools in your inventory, then a Rune, then a level, and it is written straight into that inventory slot.
//
//   - Any Rune can be forced onto any weapon or tool, even a Rune of the wrong type (a Bow rune on a Sword).
//     A wrong-type Rune stays on the item but never works; you get a warning, and the Lore says so.
//   - "Give Rune item" hands you a ready Rune item (any rune, any level) to test the Anvil > Rune page.
// Free, no cooldown, no limit.

import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { GameMode, EntityComponentTypes } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { RUNE_REGISTRY, RUNE_PROP_KEY, RUNE_VER_KEY, RUNE_VER, RUNE_FORCED_KEY, runeFitsItem } from "../rune/rune_registry.js";
import { POOLS } from "../config/rune_catalog.js";
import { RUNE_GRADES } from "../config/rune_item_config.js";
import { formatRuneName } from "../rune/rune_lore.js";
import { createRuneItem, applyRuneToItem, giveRuneItem } from "../rune/rune_item.js";
import { canHoldRune, getCategoryLabel } from "../config/item_category_config.js";
import { RUNE_LEVEL_PROP_KEY, MAX_LEVEL, LEVEL_LABEL, DEFAULT_LEVEL, clampLevel } from "../config/level_config.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { displayName } from "./rarity_name.js";

const SRC = "systems.rune_creative_gui.js";
const TIER_COLOR = { 1: "§f", 2: "§e", 3: "§a", 4: "§3", 5: "§9", 6: "§u", 7: "§4" };
const LEVEL_BUTTONS = [
    ["§fLv 1", "x0.25"], ["§eLv 2", "x0.5"], ["§6Lv 3", "x0.75"], ["§dLv 4", "base"],
    ["§cLv 5", "x1.25"], ["§4Lv 6", "x1.5"], ["§5Lv 7", "x2"], ["§bLv 8", "x2.5"],
];

const getInv = (player) => player.getComponent(EntityComponentTypes.Inventory)?.container;
const isCreative = (player) => player.getGameMode() === GameMode.Creative;

// Weapons / tools in the inventory that can hold a Rune: [{ index, item }]
function listTargets(player) {
    const inv = getInv(player);
    const out = [];
    if (!inv) return out;
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (it && canHoldRune(it.typeId)) out.push({ index: i, item: it });
    }
    return out;
}

function backToScriptTool(player) {
    import("../gui/gui_router.js").then((m) => m.GuiRouter.open(player, "script_tool")).catch(() => {});
}

function runeOf(item) {
    const id = item.getDynamicProperty(RUNE_PROP_KEY);
    return typeof id === "string" && RUNE_REGISTRY[id] ? id : null;
}

function refreshLore(player, index) {
    try { ItemRestrictionManager.updateSlotLore(getInv(player).getSlot(index), player); } catch (_) { /* slot changed */ }
}

export class RuneCreativeGui {

    // ── 1. Target item list ──────────────────────────────────────────────────
    static openMain(player) {
        if (!isCreative(player)) {
            player.sendMessage("§c[Rune Tool] This tool only works in Creative Mode!");
            return;
        }
        const targets = listTargets(player);
        const form = new ActionFormData()
            .title("§l§5Rune Creative")
            .body(targets.length
                ? "§7Pick the weapon or tool to put a Rune on.\n§8Any Rune can be forced on; a wrong-type Rune will not work."
                : "§cNo weapons or tools in your inventory.\n§8You can still give yourself a Rune item below.");
        for (const t of targets) {
            const rune = runeOf(t.item);
            const lv = clampLevel(t.item.getDynamicProperty(RUNE_LEVEL_PROP_KEY) ?? DEFAULT_LEVEL);
            const tag = rune ? `§d${formatRuneName(rune)} ${LEVEL_LABEL[lv]}${runeFitsItem(rune, t.item.typeId) ? "" : " §c[wrong type]"}` : "§8no rune";
            form.button(`§f${displayName(t.item)}\n§8${getCategoryLabel(t.item.typeId, "en", t.item)} · ${tag}`, getItemIconPath(t.item));
        }
        form.button("§dGive Rune item\n§8[Any Rune, any level, as an item]", "textures/icons/rune");
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection < targets.length) return this.openItem(player, targets[r.selection].index);
            if (r.selection === targets.length) return this.openPools(player, { mode: "give" });
            backToScriptTool(player);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    // ── 2. One item: install or remove ───────────────────────────────────────
    static openItem(player, index) {
        const it = getInv(player)?.getItem(index);
        if (!it || !canHoldRune(it.typeId)) return this.openMain(player);
        const rune = runeOf(it);
        const form = new ActionFormData()
            .title(`§l§5${displayName(it)}`)
            .body(`§7${getCategoryLabel(it.typeId, "en", it)}\n§7Rune: ${rune ? `§d${formatRuneName(rune)}` : "§8none"}`)
            .button("§aInstall a Rune\n§8[Replaces the current one]", "textures/icons/rune");
        if (rune) form.button("§cRemove Rune\n§8[Delete it]", "textures/icons/trash_can");
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection === 0) return this.openPools(player, { mode: "install", index });
            if (rune && r.selection === 1) return this.removeRune(player, index);
            this.openMain(player);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    static removeRune(player, index) {
        const inv = getInv(player);
        const it = inv?.getItem(index);
        if (it) {
            for (const k of [RUNE_PROP_KEY, RUNE_VER_KEY, RUNE_FORCED_KEY, RUNE_LEVEL_PROP_KEY]) it.setDynamicProperty(k, undefined);
            inv.setItem(index, it);
            refreshLore(player, index);
            player.sendMessage("§c[Rune Creative] Rune removed.");
        }
        this.openItem(player, index);
    }

    // ── 3. Pick a Rune type (pool) ───────────────────────────────────────────
    static openPools(player, ctx) {
        const target = ctx.mode === "install" ? getInv(player)?.getItem(ctx.index) : null;
        if (ctx.mode === "install" && !target) return this.openMain(player);
        const pools = Object.keys(POOLS).map((id) => {
            const ids = Object.keys(RUNE_REGISTRY).filter((r) => RUNE_REGISTRY[r].category === id);
            const fits = target ? ids.some((r) => runeFitsItem(r, target.typeId)) : null;
            return { id, ids, fits };
        });
        // Types that fit the item first
        if (target) pools.sort((a, b) => Number(b.fits) - Number(a.fits));

        const form = new ActionFormData()
            .title(ctx.mode === "give" ? "§l§dGive Rune item" : "§l§aInstall a Rune")
            .body(ctx.mode === "give" ? "§7Pick the Rune type." : `§7Item: §f${displayName(target)}\n§a✔ §7fits this item   §c✖ §7wrong type (will not work)`);
        for (const p of pools) {
            const mark = target ? (p.fits ? "§a✔ " : "§c✖ ") : "";
            form.button(`${mark}§f${POOLS[p.id].label}\n§8${p.ids.length} runes`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection >= pools.length) return ctx.mode === "give" ? this.openMain(player) : this.openItem(player, ctx.index);
            this.openRunes(player, ctx, pools[r.selection].id);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    // ── 4. Pick the Rune ─────────────────────────────────────────────────────
    static openRunes(player, ctx, pool) {
        const target = ctx.mode === "install" ? getInv(player)?.getItem(ctx.index) : null;
        const ids = Object.keys(RUNE_REGISTRY)
            .filter((id) => RUNE_REGISTRY[id].category === pool)
            .sort((a, b) => RUNE_REGISTRY[a].tier - RUNE_REGISTRY[b].tier);
        const form = new ActionFormData().title(`§l§d${POOLS[pool].label} Runes`)
            .body(target && !ids.some((id) => runeFitsItem(id, target.typeId)) ? "§c✖ These runes do not match this item. You will be warned before installing." : "§7Pick a Rune.");
        for (const id of ids) {
            const m = RUNE_REGISTRY[id];
            const mark = target ? (runeFitsItem(id, target.typeId) ? "§a✔ " : "§c✖ ") : "";
            form.button(`${mark}${m.kind === "curse" ? "§c" : TIER_COLOR[m.tier]}${m.name}\n§8T${m.tier} · ${m.kind === "curse" ? "Curse" : POOLS[pool].label}`, "textures/icons/rune");
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection >= ids.length) return this.openPools(player, ctx);
            this.openLevelPick(player, ctx, pool, ids[r.selection]);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    // ── 5. Pick the level ────────────────────────────────────────────────────
    static openLevelPick(player, ctx, pool, runeId) {
        const form = new ActionFormData()
            .title(`§l§d${formatRuneName(runeId)}`)
            .body("§7Choose the Rune level:");
        for (const [name, note] of LEVEL_BUTTONS) form.button(`${name} §8(${note})`);
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection >= MAX_LEVEL) return this.openRunes(player, ctx, pool);
            const level = r.selection + 1;
            if (ctx.mode === "give") return this.giveRune(player, runeId, level);
            this.installRune(player, ctx.index, runeId, level);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    // ── 6a. Install (warns on a wrong-type Rune) ─────────────────────────────
    static installRune(player, index, runeId, level) {
        const it = getInv(player)?.getItem(index);
        if (!it || !canHoldRune(it.typeId)) return this.openMain(player);
        if (runeFitsItem(runeId, it.typeId)) {
            this.doInstall(player, index, runeId, level, true);
            return this.openItem(player, index);
        }
        const form = new MessageFormData()
            .title("§l§c⚠ Wrong Rune type")
            .body(`§f${formatRuneName(runeId)} §7(${POOLS[RUNE_REGISTRY[runeId].category].label}) §7does not match §f${displayName(it)} §7(${getCategoryLabel(it.typeId, "en", it)}).\n\n§cThe Rune will be installed but it will NOT work on this item.\n§7Install anyway?`)
            .button1("§cInstall anyway").button2("§8Cancel");
        GuiService.show(player, form, SRC).then((r) => {
            if (!r.canceled && r.selection === 0) this.doInstall(player, index, runeId, level, false);
            this.openItem(player, index);
        }).catch((e) => console.warn(`[RuneCreative] ${e}`));
    }

    static doInstall(player, index, runeId, level, fits) {
        const inv = getInv(player);
        const it = inv?.getItem(index);
        if (!it) return;
        it.setDynamicProperty(RUNE_PROP_KEY, runeId);
        it.setDynamicProperty(RUNE_VER_KEY, RUNE_VER);
        it.setDynamicProperty(RUNE_LEVEL_PROP_KEY, clampLevel(level));
        it.setDynamicProperty(RUNE_FORCED_KEY, fits ? undefined : true);
        inv.setItem(index, it);
        refreshLore(player, index);
        if (fits) {
            player.sendMessage(`§a[Rune Creative] Installed §f${formatRuneName(runeId)} §a${LEVEL_LABEL[clampLevel(level)]} on §f${displayName(it)}§a.`);
        } else {
            player.sendMessage(`§e[Rune Creative] ⚠ §f${formatRuneName(runeId)} §ewas installed on §f${displayName(it)}§e, but it is the wrong type for this item. §cThe Rune will NOT work.`);
        }
        player.playSound(fits ? "random.levelup" : "note.bass");
    }

    // ── 6b. Give a Rune item ─────────────────────────────────────────────────
    static giveRune(player, runeId, level) {
        const grade = RUNE_GRADES.find((g) => g.tier === RUNE_REGISTRY[runeId].tier) ?? RUNE_GRADES[0];
        const stack = createRuneItem(grade);
        applyRuneToItem(stack, runeId, level);
        giveRuneItem(player, stack);
        player.sendMessage(`§a[Rune Creative] Gave you §f${stack.nameTag} §7(${formatRuneName(runeId)} ${LEVEL_LABEL[clampLevel(level)]})§a.`);
        player.playSound("random.orb");
        this.openMain(player);
    }
}
