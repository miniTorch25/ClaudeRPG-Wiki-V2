// chorus_gui.js — Chorus menus.
//
//   ChorusGui.openSetView(player, onBack)  — read-only view of active set effects
//                                            (used by the Status Menu and Ultench)
//   ChorusGui.openMenu(player, onBack)     — Ultimate Enchanter hub:
//                                            Roll / Lock / Remove / View
//
// Rolling: pick a TIER, every unlocked socket of the armor gets a random element of that tier.
// Locked sockets keep their element (and bind the piece to its tier).
//
// Back navigation is done with callbacks so this file never imports the menus
// that open it (avoids circular imports).

import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { ChorusManager } from "./chorus_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { GemManager } from "./gem_manager.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { displayName } from "./rarity_name.js";
import {
    CHORUS_TIERS, CHORUS_ELEMENTS, CHORUS_THRESHOLDS, CHORUS_MAX_SLOTS,
    CHORUS_ROLL_COST, CHORUS_ROLL_SETTINGS, CHORUS_LOCK_COST, CHORUS_REMOVE_COST, getEffect,
    CHORUS_FUSION, CHORUS_FUSION_COST, CHORUS_FUSION_UNLOCK,
} from "../config/chorus_config.js";
import { onChorusFusion } from "./achievement_hooks.js";
import { onMenuOpened } from "./achievement_hooks.js";

const SCREEN = "systems.chorus_gui.js";
const RESONANT_INK = "crpg:resonant_ink";
const STELLAR_CORE = "crpg:stellar_core";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getArmorRefs(player) {
    const refs = [];
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const eq  = player.getComponent(EntityComponentTypes.Equippable);
    if (inv) {
        for (let i = 0; i < inv.size; i++) {
            const slot = inv.getSlot(i);
            if (slot.hasItem() && ChorusManager.isEligibleType(slot.typeId)) refs.push({ kind: "inventory", index: i });
        }
    }
    if (eq) {
        for (const es of [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs, EquipmentSlot.Feet]) {
            const slot = eq.getEquipmentSlot(es);
            if (slot?.hasItem() && ChorusManager.isEligibleType(slot.typeId)) refs.push({ kind: "equipment", equipSlot: es });
        }
    }
    return refs;
}

function resolveSlot(player, ref) {
    if (ref.kind === "inventory") return player.getComponent(EntityComponentTypes.Inventory)?.container?.getSlot(ref.index);
    return player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(ref.equipSlot);
}

function elementText(id) {
    const def = CHORUS_ELEMENTS[id];
    return def ? `${def.color}${def.label}` : "§8Empty";
}

// Element icon for a socket button (empty sockets show a plain gem-less icon).
function elementIcon(id) {
    return CHORUS_ELEMENTS[id] ? `textures/icons/elements/${id}` : "textures/icons/chorus";
}

// Cost of rolling `sockets` sockets of a piece at `tier` (full roll = both sockets).
function rollCost(tier, sockets) {
    const base = CHORUS_ROLL_COST[tier];
    if (sockets >= 2) return base;
    const f = CHORUS_ROLL_SETTINGS.SINGLE_FACTOR;
    return { resonant: Math.ceil(base.resonant * f), stellar: Math.ceil((base.stellar ?? 0) * f) };
}

function lockedText(slot, i) {
    return ChorusManager.isLocked(slot, i) ? " §6[Locked]" : "";
}

function costText(c) {
    const parts = [];
    if (c.resonant > 0)       parts.push(`${c.resonant}× Resonant Ink`);
    if ((c.stellar ?? 0) > 0) parts.push(`${c.stellar}× Stellar Core`);
    return parts.length ? parts.join(" + ") : "Free";
}

function canAfford(player, c) {
    return GemManager.countItem(player, RESONANT_INK) >= c.resonant
        && GemManager.countItem(player, STELLAR_CORE) >= (c.stellar ?? 0);
}

function pay(player, c) {
    for (let i = 0; i < c.resonant; i++) GemManager.consumeItem(player, RESONANT_INK);
    for (let i = 0; i < (c.stellar ?? 0); i++) GemManager.consumeItem(player, STELLAR_CORE);
}

// ─── Fusion helpers ──────────────────────────────────────────────────────────

const FUSION_LIST_LIMIT = 30;

// Why a Fusion tier is closed for this player (null = open).
function fusionLockReason(player, tierId) {
    if (!MasteryManager.isUnlockOpen(player, "chorus", tierId)) {
        return `Chorus Mastery Lv.${MasteryManager.unlockLevel("chorus", tierId)}`;
    }
    const needP = CHORUS_FUSION_UNLOCK[tierId]?.prestige ?? 0;
    if (ProgressionManager.getPrestige(player) < needP) return `Prestige ${needP}`;
    return null;
}

// Every valid Fusion the player can do right now at `tierId`:
// [{ target, refs: [ref] | [refA, refB] }]. Pieces that are the same physical slot are never paired.
function fusionOptions(player, tierId) {
    const refs = getArmorRefs(player);
    const slots = refs.map((r) => resolveSlot(player, r));
    const out = [];
    const wantTier = (id) => CHORUS_ELEMENTS[id]?.tier === tierId;
    for (let i = 0; i < refs.length; i++) {
        const t1 = ChorusManager.fusionTarget([slots[i]]);
        if (t1 && wantTier(t1)) out.push({ target: t1, refs: [refs[i]] });
        for (let j = i + 1; j < refs.length; j++) {
            const t2 = ChorusManager.fusionTarget([slots[i], slots[j]]);
            if (t2 && wantTier(t2)) out.push({ target: t2, refs: [refs[i], refs[j]] });
        }
    }
    return out;
}

function recipeText(id) {
    const r = CHORUS_FUSION[id];
    const el = (e) => elementText(e);
    return r.pieces === 1
        ? `${elementText(id)}§7 = ${el(r.from[0])} §7+ ${el(r.from[1])} §8(one piece: its 2 sockets)`
        : `${elementText(id)}§7 = ${el(r.from[0])} §7+ ${el(r.from[1])} §8(two pieces, both become ${CHORUS_ELEMENTS[id].label})`;
}

// ─── ChorusGui ───────────────────────────────────────────────────────────────

export const ChorusGui = {

    // Read-only: active sets + their 2/4/6/8 effects.
    openSetView(player, onBack = null) {
        onMenuOpened(player, "chorus");
        const { totalSlots, sets } = ChorusManager.getPlayerSets(player);
        const pieces = ChorusManager.getPlayerPieces(player);

        let body = `§f=== §dChorus §f===\n§7Elements on armor: §f${totalSlots} / ${CHORUS_MAX_SLOTS} sockets\n\n§7§lYour armor§r`;
        for (const p of pieces) {
            const name = `${p.name[0].toUpperCase()}${p.name.slice(1)}`;
            if (!p.item) { body += `\n§8${name}: —`; continue; }
            const tier = ChorusManager.getTier(p.item);
            const tierText = tier ? `${CHORUS_TIERS[tier].color}${CHORUS_TIERS[tier].label} ` : "";
            body += `\n§7${name}: §f${displayName(p.item)}\n  ${tierText}§8[ ${p.elements.map(elementText).join("§8 | ")} §8]`;
        }

        if (sets.length === 0) {
            body += "\n\n§8No elements imprinted yet.\n§8Use the Ultimate Enchanter → Chorus to imprint elements.";
        }

        for (const set of sets) {
            const parts = Object.entries(set.parts).map(([id, n]) => `${elementText(id)} §fx${n}`).join("§8 + ");
            body += `\n\n§l${set.color}Type: ${set.name}§r §f(${set.count}/${CHORUS_MAX_SLOTS})`;
            body += set.kind === "hybrid" ? " §8[Hybrid]" : " §8[Single]";
            body += `\n§7Made of: ${parts}`;
            if (set.kind === "hybrid") {
                body += `\n§8Hybrid counts pairs (lower count x2)` +
                        (set.unpaired > 0 ? `\n§e${set.unpaired} unpaired socket(s) not counted` : "");
            }
            for (const t of CHORUS_THRESHOLDS) {
                const eff = getEffect(set.id, t);
                const on = set.count >= t;
                const status = eff.ready ? "" : " §8(Coming Soon)";
                body += `\n${on ? "§a[ON] " : "§8[OFF] "}§7${t}: ${on ? "§f" : "§7"}${eff.desc}${status}`;
            }
            const next = CHORUS_THRESHOLDS.find((t) => set.count < t);
            body += next !== undefined
                ? `\n§7Next effect at §f${next}§7 — need §f${next - set.count}§7 more.`
                : `\n§6All effects unlocked!`;
        }

        if (sets.length > 0) {
            body += "\n\n§8Tip: Effects stack (8 = 2+4+6+8). Using 3+ different elements means each counts on its own.";
        }

        const hybridOn = ChorusManager.isHybridEnabled(player);
        body += `\n\n§7Hybrid mixing: ${hybridOn ? "§aON" : "§cOFF"} §8(${hybridOn
            ? "two different elements of one tier merge into a hybrid set"
            : "every element counts on its own, no hybrid sets"})`;

        const form = new ActionFormData()
            .title("§l§dChorus")
            .body(body)
            .button(hybridOn ? "§aHybrid Mixing: ON\n§8[Tap to turn OFF]" : "§cHybrid Mixing: OFF\n§8[Tap to turn ON]", "textures/icons/gear")
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            if (r.selection === 0) {
                ChorusManager.setHybridEnabled(player, !hybridOn);
                player.sendMessage(`§d[Chorus] §fHybrid mixing is now ${!hybridOn ? "§aON" : "§cOFF"}§f.`);
                return this.openSetView(player, onBack);
            }
            if (onBack) onBack();
        }).catch((e) => console.warn(`[Chorus] Set view error: ${e}`));
    },

    // Ultimate Enchanter hub.
    openMenu(player, onBack = null) {
        if (!ProgressionManager.guard(player, "chorus")) return;
        const form = new ActionFormData()
            .title("§l§dChorus")
            .body(
                "§7Pick a tier and every unlocked socket of an armor piece gets a random element of that tier (2 sockets per piece).\n" +
                "§7Lock the elements you want to keep, then reroll the rest.\n" +
                `§8Matching elements unlock set effects at ${CHORUS_THRESHOLDS.join(" / ")}.`
            )
            .button("§dRoll Chorus\n§8[Pick a tier, get random elements]", "textures/icons/chorus")
            .button("§6Lock Elements\n§8[Keep an element while rerolling]", "textures/icons/lock")
            .button("§cRemove Element\n§8[Clear a socket]",                  "textures/icons/trash_can")
            .button("§6Fusion\n§8[Awaken / Melodious / Genesis]",            "textures/icons/chorus")
            .button("§bView Set Effects\n§8[Your current sets]",             "textures/icons/blue_stats")
            .button("§8< Back",                                               "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: this.openSelectArmor(player, "roll", onBack); break;
                case 1: this.openSelectArmor(player, "lock", onBack); break;
                case 2: this.openSelectArmor(player, "remove", onBack); break;
                case 3: this.openFusionMenu(player, onBack); break;
                case 4: this.openSetView(player, () => this.openMenu(player, onBack)); break;
                case 5: if (onBack) onBack(); break;
            }
        }).catch((e) => console.warn(`[Chorus] Menu error: ${e}`));
    },

    openSelectArmor(player, mode, onBack) {
        const refs = getArmorRefs(player);
        if (refs.length === 0) {
            player.sendMessage("§c[Chorus] No armor found! (Shields have no Chorus sockets.)");
            return this.openMenu(player, onBack);
        }

        const titles = { roll: "§l§dRoll — Armor", lock: "§l§6Lock — Armor", remove: "§l§cRemove — Armor" };
        const form = new ActionFormData().title(titles[mode] ?? "§l§dChorus — Armor");
        for (const ref of refs) {
            const slot = resolveSlot(player, ref);
            const els = ChorusManager.getElements(slot);
            const tier = ChorusManager.getTier(slot);
            const sub = tier
                ? `${CHORUS_TIERS[tier].color}${CHORUS_TIERS[tier].label} §8[ ${elementText(els[0])}${lockedText(slot, 0)}§8, ${elementText(els[1])}${lockedText(slot, 1)} §8]`
                : "§8No elements";
            form.button(`§f${displayName(slot.getItem())}\n${sub}`, getItemIconPath(slot.getItem()));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === refs.length) return this.openMenu(player, onBack);
            const ref = refs[r.selection];
            if ((mode === "roll" || mode === "lock") && ChorusManager.isFused(resolveSlot(player, ref))) {
                player.sendMessage("§c[Chorus] Fused pieces (Awaken or higher) cannot be rolled or locked. You can only Remove their elements.");
                return this.openSelectArmor(player, mode, onBack);
            }
            if (mode === "roll") return this.openSelectTier(player, ref, onBack);
            if (mode === "lock") return this.openLockMenu(player, ref, onBack);
            this.openSelectSocket(player, ref, onBack);
        }).catch((e) => console.warn(`[Chorus] Select armor error: ${e}`));
    },

    // ─── Roll ────────────────────────────────────────────────────────────────

    openSelectTier(player, ref, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§c[Chorus] Item no longer available!");
            return this.openMenu(player, onBack);
        }

        if (ChorusManager.isFused(slot)) {
            player.sendMessage("§c[Chorus] Fused pieces cannot be rolled.");
            return this.openSelectArmor(player, "roll", onBack);
        }
        const els = ChorusManager.getElements(slot);
        const targets = ChorusManager.getRollTargets(slot);
        const forced = ChorusManager.getForcedTier(slot);
        const tiers = Object.entries(CHORUS_TIERS).filter(([id, tr]) => !tr.fusion && (!forced || id === forced));

        const echo = GemManager.countItem(player, RESONANT_INK);

        let body = `§f${displayName(slot.getItem())}\n`;
        els.forEach((id, i) => { body += `§7Socket #${i + 1}: ${elementText(id)}${lockedText(slot, i)}\n`; });
        if (targets.length === 0) {
            body += "\n§cBoth sockets are locked — unlock one to roll.";
        } else {
            body += `\n§7Rolls ${targets.length === 2 ? "both sockets" : `socket #${targets[0] + 1} only`}.`;
            if (forced) body += `\n§7Bound to ${CHORUS_TIERS[forced].color}${CHORUS_TIERS[forced].label}§7 by the locked element.`;
        }
        body += `\n§7Have: §f${echo}× Resonant Ink   ${GemManager.countItem(player, STELLAR_CORE)}× Stellar Core`;

        const form = new ActionFormData().title("§l§dRoll — Tier").body(body);
        const options = targets.length === 0 ? [] : tiers;
        for (const [id, tier] of options) {
            const cost = rollCost(id, targets.length);
            if (!MasteryManager.isUnlockOpen(player, "chorus", id)) {
                form.button(`§8${tier.label} §c[Locked]\n§8Chorus Mastery Lv.${MasteryManager.unlockLevel("chorus", id)}`);
                continue;
            }
            form.button(`${tier.color}${tier.label}\n§8${costText(cost)}`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === options.length) return this.openSelectArmor(player, "roll", onBack);
            this.doRoll(player, ref, options[r.selection][0], onBack);
        }).catch((e) => console.warn(`[Chorus] Select tier error: ${e}`));
    },

    doRoll(player, ref, tierId, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) return this.openMenu(player, onBack);

        if (ChorusManager.isFused(slot)) {
            player.sendMessage("§c[Chorus] Fused pieces cannot be rolled.");
            return this.openSelectArmor(player, "roll", onBack);
        }
        const targets = ChorusManager.getRollTargets(slot);
        const forced = ChorusManager.getForcedTier(slot);
        if (targets.length === 0) {
            player.sendMessage("§c[Chorus] Both sockets are locked.");
            return this.openSelectTier(player, ref, onBack);
        }
        if (forced && forced !== tierId) {
            player.sendMessage("§c[Chorus] A locked element binds this piece to its tier.");
            return this.openSelectTier(player, ref, onBack);
        }
        if (!MasteryManager.isUnlockOpen(player, "chorus", tierId)) {
            player.sendMessage(`§c[Chorus] ${CHORUS_TIERS[tierId].label} needs Chorus Mastery Lv.${MasteryManager.unlockLevel("chorus", tierId)}.`);
            return this.openSelectTier(player, ref, onBack);
        }

        const cost = rollCost(tierId, targets.length);
        if (!canAfford(player, cost)) {
            player.sendMessage(`§c[Chorus] Need §f${costText(cost)}§c.`);
            return this.openSelectTier(player, ref, onBack);
        }

        // Validated above, so a refused roll never costs materials.
        pay(player, cost);
        const results = ChorusManager.roll(slot, tierId);
        if (!results) {
            player.sendMessage("§c[Chorus] The roll failed. Nothing was consumed.");
            return this.openSelectTier(player, ref, onBack);
        }
        ItemRestrictionManager.updateSlotLore(slot, player);
        MasteryManager.addXp(player, "chorus", ((MASTERY.CHORUS_XP[tierId] ?? 0) * targets.length) / 2);

        const text = results.map((x) => `#${x.index + 1} ${elementText(x.elementId)}`).join("§f, ");
        player.sendMessage(`§d[Chorus] §fRolled ${CHORUS_TIERS[tierId].color}${CHORUS_TIERS[tierId].label}§f: ${text}`);
        player.playSound("random.levelup");
        this.openSelectTier(player, ref, onBack);   // ready for a quick reroll
    },

    // ─── Fusion ──────────────────────────────────────────────────────────────

    openFusionMenu(player, onBack) {
        if (!ProgressionManager.guard(player, "chorus")) return;
        const tiers = Object.entries(CHORUS_TIERS).filter(([, tr]) => tr.fusion);
        const have = GemManager.countItem(player, STELLAR_CORE);
        const form = new ActionFormData()
            .title("§l§6Chorus Fusion")
            .body(
                "§7Fuse Transcend elements into a higher element. Fusion is §cpermanent§7: fused pieces cannot be rolled or locked.\n" +
                "§7Awaken: one piece with two matching Transcend elements.\n" +
                "§7Melodious / Genesis: two fused pieces, both become the new element.\n" +
                `§7Have: §f${have}× Stellar Core`
            );
        for (const [id, tr] of tiers) {
            const why = fusionLockReason(player, id);
            if (why) form.button(`§8${tr.label} §c[Locked]\n§8${why}`, `textures/icons/tiers/${id}`);
            else form.button(`${tr.color}${tr.label}\n§8${costText(CHORUS_FUSION_COST[id])}`, `textures/icons/tiers/${id}`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === tiers.length) return this.openMenu(player, onBack);
            const [id] = tiers[r.selection];
            const why = fusionLockReason(player, id);
            if (why) {
                player.sendMessage(`§c[Chorus] ${CHORUS_TIERS[id].label} Fusion needs ${why}.`);
                return this.openFusionMenu(player, onBack);
            }
            this.openFusionList(player, id, onBack);
        }).catch((e) => console.warn(`[Chorus] Fusion menu error: ${e}`));
    },

    openFusionList(player, tierId, onBack) {
        const tr = CHORUS_TIERS[tierId];
        const recipes = Object.keys(CHORUS_FUSION).filter((id) => CHORUS_ELEMENTS[id].tier === tierId);
        const options = fusionOptions(player, tierId).slice(0, FUSION_LIST_LIMIT);

        let body = `${tr.color}${tr.label}§7 recipes:\n` + recipes.map((id) => `§8- ${recipeText(id)}`).join("\n");
        body += `\n\n§7Cost per Fusion: §f${costText(CHORUS_FUSION_COST[tierId])} §8| §7Have: §f${GemManager.countItem(player, STELLAR_CORE)}× Stellar Core`;
        body += options.length === 0 ? "\n\n§cNo armor matches a recipe yet." : `\n\n§7Pick a Fusion:`;

        const form = new ActionFormData().title(`§l${tr.color}${tr.label} Fusion`).body(body);
        for (const opt of options) {
            const names = opt.refs.map((ref) => displayName(resolveSlot(player, ref).getItem())).join(" §8+ §f");
            form.button(`${CHORUS_ELEMENTS[opt.target].color}→ ${CHORUS_ELEMENTS[opt.target].label}\n§f${names}`, elementIcon(opt.target));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === options.length) return this.openFusionMenu(player, onBack);
            this.openFusionConfirm(player, tierId, options[r.selection], onBack);
        }).catch((e) => console.warn(`[Chorus] Fusion list error: ${e}`));
    },

    openFusionConfirm(player, tierId, opt, onBack) {
        const slots = opt.refs.map((ref) => resolveSlot(player, ref));
        if (slots.some((sl) => !sl?.hasItem()) || ChorusManager.fusionTarget(slots) !== opt.target) {
            player.sendMessage("§c[Chorus] Those pieces changed. Pick the Fusion again.");
            return this.openFusionList(player, tierId, onBack);
        }
        const def = CHORUS_ELEMENTS[opt.target];
        const names = slots.map((sl) => `§f${displayName(sl.getItem())}`).join("\n");
        const form = new MessageFormData()
            .title("§l§6Confirm Fusion")
            .body(
                `${names}\n\n§7Result: ${def.color}${def.label}§7 on ${slots.length === 1 ? "both sockets" : "both sockets of both pieces"}.\n` +
                `§7Cost: §f${costText(CHORUS_FUSION_COST[tierId])}\n\n` +
                "§cThis cannot be undone.§7 Locks are cleared and these pieces can no longer be rolled or locked.\n" +
                "§8Removing a socket later leaves it empty; the old elements do not come back."
            )
            .button1("§6Fuse")
            .button2("§8Cancel");
        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection !== 0) return this.openFusionList(player, tierId, onBack);
            this.doFuse(player, tierId, opt, onBack);
        }).catch((e) => console.warn(`[Chorus] Fusion confirm error: ${e}`));
    },

    doFuse(player, tierId, opt, onBack) {
        const why = fusionLockReason(player, tierId);
        if (why) {
            player.sendMessage(`§c[Chorus] ${CHORUS_TIERS[tierId].label} Fusion needs ${why}.`);
            return this.openFusionMenu(player, onBack);
        }
        const slots = opt.refs.map((ref) => resolveSlot(player, ref));
        if (slots.some((sl) => !sl?.hasItem()) || ChorusManager.fusionTarget(slots) !== opt.target) {
            player.sendMessage("§c[Chorus] Those pieces changed. Nothing was consumed.");
            return this.openFusionList(player, tierId, onBack);
        }
        const cost = CHORUS_FUSION_COST[tierId];
        if (!canAfford(player, cost)) {
            player.sendMessage(`§c[Chorus] Need §f${costText(cost)}§c.`);
            return this.openFusionList(player, tierId, onBack);
        }

        // Validated above, so a refused Fusion never costs materials.
        pay(player, cost);
        if (!ChorusManager.fuse(slots, opt.target)) {
            player.sendMessage("§c[Chorus] The Fusion failed.");
            return this.openFusionList(player, tierId, onBack);
        }
        for (const sl of slots) ItemRestrictionManager.updateSlotLore(sl, player);
        MasteryManager.addXp(player, "chorus", MASTERY.CHORUS_XP[tierId] ?? 0);
        onChorusFusion(player, opt.target);

        const def = CHORUS_ELEMENTS[opt.target];
        player.sendMessage(`§d[Chorus] §fFused into ${def.color}${def.label}§f!`);
        player.playSound("random.levelup");
        this.openFusionList(player, tierId, onBack);
    },

    // ─── Lock ────────────────────────────────────────────────────────────────

    openLockMenu(player, ref, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§c[Chorus] Item no longer available!");
            return this.openMenu(player, onBack);
        }
        const els = ChorusManager.getElements(slot);
        if (!els.some(Boolean)) {
            player.sendMessage("§c[Chorus] This piece has no elements to lock. Roll first.");
            return this.openSelectArmor(player, "lock", onBack);
        }
        const tier = ChorusManager.getTier(slot);
        const cost = CHORUS_LOCK_COST[tier];

        const form = new ActionFormData()
            .title("§l§6Lock Elements")
            .body(
                `§f${displayName(slot.getItem())}\n` +
                `§7Lock: §f${costText(cost)} §8| §7Unlock: §fFree\n` +
                `§7Have: §f${GemManager.countItem(player, RESONANT_INK)}× Resonant Ink\n` +
                "§8A locked element is kept when you roll and keeps the piece on its tier."
            );
        for (let i = 0; i < els.length; i++) {
            const locked = ChorusManager.isLocked(slot, i);
            form.button(`§fSocket #${i + 1}: ${elementText(els[i])}\n${!els[i] ? "§8Empty" : locked ? "§6Locked §8[Tap to unlock]" : "§8Unlocked §8[Tap to lock]"}`, elementIcon(els[i]));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === els.length) return this.openSelectArmor(player, "lock", onBack);
            this.toggleLock(player, ref, r.selection, onBack);
        }).catch((e) => console.warn(`[Chorus] Lock menu error: ${e}`));
    },

    toggleLock(player, ref, index, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) return this.openMenu(player, onBack);
        const element = ChorusManager.getElement(slot, index);
        if (!element) {
            player.sendMessage("§c[Chorus] That socket is empty.");
            return this.openLockMenu(player, ref, onBack);
        }

        if (ChorusManager.isLocked(slot, index)) {
            ChorusManager.setLocked(slot, index, false);
            ItemRestrictionManager.updateSlotLore(slot, player);
            player.sendMessage(`§d[Chorus] §fUnlocked ${elementText(element)}§f in socket #${index + 1}.`);
            return this.openLockMenu(player, ref, onBack);
        }

        const cost = CHORUS_LOCK_COST[ChorusManager.getTier(slot)];
        if (!canAfford(player, cost)) {
            player.sendMessage(`§c[Chorus] Need §f${costText(cost)}§c.`);
            return this.openLockMenu(player, ref, onBack);
        }
        pay(player, cost);
        ChorusManager.setLocked(slot, index, true);
        ItemRestrictionManager.updateSlotLore(slot, player);
        MasteryManager.addXp(player, "chorus", (MASTERY.CHORUS_XP[ChorusManager.getTier(slot)] ?? 0) / 2);
        player.sendMessage(`§d[Chorus] §fLocked ${elementText(element)}§f in socket #${index + 1}.`);
        player.playSound("random.anvil_use");
        this.openLockMenu(player, ref, onBack);
    },

    // ─── Remove ──────────────────────────────────────────────────────────────

    openSelectSocket(player, ref, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§c[Chorus] Item no longer available!");
            return this.openMenu(player, onBack);
        }

        const els = ChorusManager.getElements(slot);
        const form = new ActionFormData().title("§l§cRemove — Socket");
        for (let i = 0; i < els.length; i++) {
            form.button(`§fSocket #${i + 1}\n${elementText(els[i])}${lockedText(slot, i)}`, elementIcon(els[i]));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === els.length) return this.openSelectArmor(player, "remove", onBack);
            this.doRemove(player, ref, r.selection, onBack);
        }).catch((e) => console.warn(`[Chorus] Select socket error: ${e}`));
    },

    doRemove(player, ref, index, onBack) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) return this.openMenu(player, onBack);

        const current = ChorusManager.getElement(slot, index);
        if (!current) {
            player.sendMessage("§c[Chorus] That socket is already empty.");
            return this.openSelectSocket(player, ref, onBack);
        }
        if (ChorusManager.isLocked(slot, index)) {
            player.sendMessage("§c[Chorus] That element is locked. Unlock it first.");
            return this.openSelectSocket(player, ref, onBack);
        }
        if (!canAfford(player, CHORUS_REMOVE_COST)) {
            player.sendMessage(`§c[Chorus] Need §f${costText(CHORUS_REMOVE_COST)}§c.`);
            return this.openMenu(player, onBack);
        }

        pay(player, CHORUS_REMOVE_COST);
        ChorusManager.clearElement(slot, index);
        ItemRestrictionManager.updateSlotLore(slot, player);

        player.sendMessage(`§d[Chorus] §fRemoved ${elementText(current)}§f from socket #${index + 1}.`);
        player.playSound("random.break");
        this.openMenu(player, onBack);
    },
};
