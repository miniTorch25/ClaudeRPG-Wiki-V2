// achievement_engine.js -- pure Achievement logic (no Minecraft imports, so it can be unit-tested).
// Player data shape:  { v: 1, c: { counterKey: number }, u: { achievementId: unlockMinute } }
// Counters are "sum" (add) or "max" (keep best). An Achievement completes when counter >= target.

export function createEngine(defs, maxCounters) {
    const total = defs.length;
    const byId = new Map();
    const byCounter = new Map();
    for (const d of defs) {
        const target = d.target === "all" ? total - 1 : d.target;
        const def = { ...d, target };
        byId.set(def.id, def);
        if (!byCounter.has(def.counter)) byCounter.set(def.counter, []);
        byCounter.get(def.counter).push(def);
    }
    for (const list of byCounter.values()) list.sort((a, b) => a.target - b.target);

    const nowMinute = () => Math.floor(Date.now() / 60000);
    const isMax = (key) => maxCounters.has(key);

    const engine = {
        total,
        defs: [...byId.values()],
        byId,
        hasCounter: (key) => byCounter.has(key),

        emptyData() { return { v: 1, c: {}, u: {} }; },

        parse(raw) {
            try {
                const o = typeof raw === "string" ? JSON.parse(raw) : null;
                if (o && typeof o === "object") return { v: 1, c: o.c && typeof o.c === "object" ? o.c : {}, u: o.u && typeof o.u === "object" ? o.u : {} };
            } catch (_) { /* fall through */ }
            return engine.emptyData();
        },

        serialize(data) { return JSON.stringify({ v: data.v ?? 1, c: data.c, u: data.u }); },

        get(data, key) { return Number(data.c[key]) || 0; },
        isUnlocked(data, id) { return data.u[id] !== undefined; },
        unlockedCount(data) { return Object.keys(data.u).filter((id) => byId.has(id)).length; },

        // Checks every Achievement that uses `key`; returns the newly unlocked defs.
        check(data, key) {
            const out = [];
            const list = byCounter.get(key);
            if (!list) return out;
            const value = engine.get(data, key);
            for (const d of list) {
                if (value < d.target) break;
                if (data.u[d.id] === undefined) { data.u[d.id] = nowMinute(); out.push(d); }
            }
            if (out.length && key !== "ach_unlocked") out.push(...engine.syncMeta(data));
            return out;
        },

        // Meta counter: how many Achievements are done. Re-checks meta Achievements until stable.
        syncMeta(data) {
            const out = [];
            for (let guard = 0; guard < 8; guard++) {
                const n = engine.unlockedCount(data);
                if (n === engine.get(data, "ach_unlocked")) break;
                data.c.ach_unlocked = n;
                out.push(...engine.check(data, "ach_unlocked"));
            }
            return out;
        },

        add(data, key, amount = 1) {
            if (!(amount > 0) || !Number.isFinite(amount)) return [];
            if (isMax(key)) return engine.max(data, key, engine.get(data, key) + amount);
            data.c[key] = engine.get(data, key) + amount;
            return engine.check(data, key);
        },

        max(data, key, value) {
            if (!Number.isFinite(value)) return [];
            if (value <= engine.get(data, key)) return [];
            data.c[key] = value;
            return engine.check(data, key);
        },

        // Admin helpers ---------------------------------------------------
        grant(data, id) {
            const d = byId.get(id);
            if (!d || data.u[id] !== undefined) return [];
            data.u[id] = nowMinute();
            if (engine.get(data, d.counter) < d.target) data.c[d.counter] = d.target;
            return [d, ...engine.syncMeta(data)];
        },
        revoke(data, id) {
            const d = byId.get(id);
            if (!d || data.u[id] === undefined) return false;
            delete data.u[id];
            if (engine.get(data, d.counter) >= d.target) data.c[d.counter] = Math.max(0, d.target - 1);
            engine.syncMeta(data);
            return true;
        },
        setProgress(data, key, value) {
            if (!engine.hasCounter(key)) return [];
            data.c[key] = Math.max(0, Number(value) || 0);
            return engine.check(data, key);
        },
        reset(data) { data.c = {}; data.u = {}; },

        progress(data, id) {
            const d = byId.get(id);
            if (!d) return null;
            const done = data.u[id] !== undefined;
            const value = done ? d.target : Math.min(engine.get(data, d.counter), d.target);
            return { value, target: d.target, done, at: done ? data.u[id] * 60000 : 0 };
        },
    };
    return engine;
}
