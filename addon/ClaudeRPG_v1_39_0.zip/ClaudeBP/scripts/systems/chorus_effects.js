// chorus_effects.js — Chorus set effects (Phase 2: Echo singles, Phase 3: Echo hybrids, Phase 4a: Resonance singles, Phase 4b: Resonance hybrids via data kits, Phase 5: Transcend via data kits).
//
// Effects are cumulative: a set at count 6 has its 2, 4 and 6 effects active.
// Every effect asks one question — `has(player, setId, threshold)` — where
// setId is an element id ("fire") or a sorted hybrid key ("earth+fire").
// Phase 3+ adds hybrids/other tiers by adding more `has(...)` checks here.
//
// Hooks (registered once from main.js via ChorusEffects.register()):
//   EventBus "damage:before"  → damage taken reductions, Stone Skin, on-hit procs
//   EventBus "damage:after"   → reactive effects (reflect, Tidal Wave, Gale Burst, Quake)
//   KillManager listener      → Fire 8 explosion
//   Scheduler 2 / 10 / 20     → dash, speed, auras, regeneration, shield recharge
//   handleEntitySpawn()       → Wind 6 arrow boost (called by the EventRouter)
//   DeathManager death-save   → Revive (Awaken+ 8 slots): a fatal hit leaves the player alive

import { system, world } from "@minecraft/server";
import { EventBus } from "../core/event_bus.js";
import { Scheduler } from "../core/scheduler.js";
import { RuntimeState } from "../core/runtime_state.js";
import { KillManager } from "../managers/kill_manager.js";
import { CooldownManager } from "../managers/cooldown_manager.js";
import { HPManager } from "../managers/hp_manager.js";
import { MovementManager } from "../managers/movement_manager.js";
import { fireSuppressedDamage } from "../managers/damage_manager.js";
import { MobHpManager } from "../managers/mob_hp_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { isBoss } from "../config/mob_config.js";
import { ChorusManager } from "./chorus_manager.js";
import { CHORUS_VALUES as V, CHORUS_KITS, CHORUS_THRESHOLDS, CHORUS_CAPS } from "../config/chorus_config.js";
import { AchievementManager } from "./achievement_manager.js";

// Hybrid ids (sorted element keys — see hybridKey in chorus_config.js)
const STEAM = "fire+water", WILDFIRE = "fire+wind", MAGMA = "earth+fire";
const MONSOON = "water+wind", BOG = "earth+water", SAND = "earth+wind";

const isPlayer = (e) => e?.typeId === "minecraft:player";
const TICKS = 20;

const FIRE_CAUSES     = new Set(["fire", "fire_tick", "lava", "in_fire", "magma"]);
const FREEZE_CAUSES   = new Set(["freezing", "freeze"]);   // Script API reports "freezing"
const WATER_CAUSES    = new Set(["drowning", "magic"]);
const PHYSICAL_CAUSES = new Set(["entity_attack", "projectile", "fall", "contact"]);
const ON_HIT_CAUSES   = new Set(["entity_attack", "projectile", "mace_smash"]);
const EXPLOSION_CAUSES = new Set(["entity_explosion", "block_explosion"]);

const BAD_EFFECTS = [
    "poison", "wither", "slowness", "weakness", "nausea", "blindness",
    "hunger", "mining_fatigue", "darkness", "levitation", "fatal_poison",
];

// ─── State / cache ───────────────────────────────────────────────────────────

function state(player) {
    const root = RuntimeState.player(player.id);
    if (!root.chorus) root.chorus = { sets: null, stamp: -999, shields: {}, lastHit: -9999 };
    return root.chorus;
}

// Active sets, cached for a few ticks — combat hooks can fire many times per second.
function activeSets(player) {
    const st = state(player);
    const now = system.currentTick;
    if (!st.sets || now - st.stamp >= 5) {
        const { sets } = ChorusManager.getPlayerSets(player);
        st.sets = Object.fromEntries(sets.map((s) => [s.id, s.count]));
        st.stamp = now;
    }
    return st.sets;
}

function has(player, setId, threshold) {
    return (activeSets(player)[setId] ?? 0) >= threshold;
}

function anyActive(player) {
    return Object.keys(activeSets(player)).length > 0;
}

// Hostile mobs near a point (never players, pets or passive animals).
function nearbyHostiles(entity, radius, exclude = null) {
    try {
        return entity.dimension
            .getEntities({ location: entity.location, maxDistance: radius, families: ["monster"] })
            .filter((e) => e.isValid && e.id !== exclude?.id);
    } catch { return []; }
}

function pushAway(from, target, power, lift) {
    try {
        const dx = target.location.x - from.location.x;
        const dz = target.location.z - from.location.z;
        const len = Math.hypot(dx, dz) || 1;
        target.applyImpulse({ x: (dx / len) * power, y: lift, z: (dz / len) * power });
    } catch { /* target invalid / not pushable */ }
}

// Ignite memory — Fire 8 only explodes enemies that Chorus itself ignited.
function ignitedMap() {
    const g = RuntimeState.global("chorus");
    if (!g.ignited) g.ignited = new Map();
    return g.ignited;
}

function ignite(target, seconds) {
    try {
        target.setOnFire(seconds, true);
        ignitedMap().set(target.id, system.currentTick + V.fire.igniteMemorySeconds * TICKS);
    } catch { /* target invalid */ }
}

// Frozen memory — Frost 8 bonus damage applies to enemies Frost rooted/froze.
function frozenMap() {
    const g = RuntimeState.global("chorus");
    if (!g.frozen) g.frozen = new Map();
    return g.frozen;
}

function markFrozen(target, seconds) {
    try { frozenMap().set(target.id, system.currentTick + seconds * TICKS); } catch { /* invalid */ }
}

function isFrozen(target) {
    const exp = frozenMap().get(target?.id);
    return exp !== undefined && system.currentTick <= exp;
}

function isUndead(entity) {
    try { return entity.matches({ families: ["undead"] }); } catch { return false; }
}

function isNight() {
    try { const t = world.getTimeOfDay(); return t >= 13000 && t <= 23000; } catch { return false; }
}

// Players (including `player`) within radius.
function nearbyPlayers(player, radius) {
    try {
        return player.dimension
            .getEntities({ location: player.location, maxDistance: radius, type: "minecraft:player" })
            .filter((p) => p.isValid && HPManager.getHP(p) > 0);
    } catch { return [player]; }
}

function healPercent(player, percent) {
    HPManager.heal(player, HPManager.getMaxHP(player) * (percent / 100));
}

function hpPercent(player) {
    const max = HPManager.getMaxHP(player);
    return max > 0 ? (HPManager.getHP(player) / max) * 100 : 100;
}


function cleanse(player) {
    for (const id of BAD_EFFECTS) { try { player.removeEffect(id); } catch { /* not active */ } }
}

// ─── Dimension / Time helpers ────────────────────────────────────────────────

const passable = (b) => { try { return !!b && !b.isSolid && !b.isLiquid; } catch { return false; } };
const standable = (b) => { try { return !!b && b.isSolid; } catch { return false; } };

function portalFx(dimension, loc) {
    try { dimension.spawnParticle("minecraft:basic_portal_particle", { x: loc.x, y: loc.y + 1, z: loc.z }); } catch { /* particle missing */ }
}

// Safe short-range teleport along a horizontal direction. Tries the full
// distance first, then shorter hops, and only lands on a free 2-high spot with
// solid ground. Returns true if a landing spot was found.
export function blinkPlayer(player, dir, distance) {
    try {
        const len = Math.hypot(dir.x, dir.z);
        if (len < 0.01) return false;
        const dx = dir.x / len, dz = dir.z / len;
        const from = { ...player.location };
        const dim = player.dimension;
        for (let d = Math.floor(distance); d >= 1; d--) {
            const x = Math.floor(from.x + dx * d), z = Math.floor(from.z + dz * d);
            for (const off of [0, 1, -1, 2, -2]) {
                const y = Math.floor(from.y) + off;
                if (!passable(dim.getBlock({ x, y, z })) || !passable(dim.getBlock({ x, y: y + 1, z })) || !standable(dim.getBlock({ x, y: y - 1, z }))) continue;
                const to = { x: x + 0.5, y, z: z + 0.5 };
                system.run(() => {
                    try {
                        if (!player.isValid) return;
                        portalFx(dim, from);
                        player.teleport(to, { keepVelocity: false });
                        portalFx(dim, to);
                        player.playSound("mob.endermen.portal");
                    } catch { /* player left / chunk unloaded */ }
                });
                AchievementManager.event(player, "blinks");
                return true;
            }
        }
    } catch { /* world not ready */ }
    return false;
}

// Direction pointing away from an attacker (or behind the player if unknown).
export function awayDir(player, attacker) {
    try {
        if (attacker?.isValid) return { x: player.location.x - attacker.location.x, z: player.location.z - attacker.location.z };
        const v = player.getViewDirection();
        return { x: -v.x, z: -v.z };
    } catch { return { x: 0, z: 0 }; }
}

// Time 8 / hybrids — Rewind: recover HP lost over the last few seconds.
function rewindHp(player, r) {
    const hist = state(player).hpHist;
    if (!hist || hist.length === 0) return;
    const past = hist[Math.max(0, hist.length - 1 - r.seconds)];
    const gain = Math.min(past - HPManager.getHP(player), HPManager.getMaxHP(player) * (r.maxPct / 100));
    if (gain > 0) { HPManager.heal(player, gain); AchievementManager.event(player, "rewinds"); }
    try { player.playSound("beacon.deactivate"); } catch { /* sound unavailable */ }
}

// Cuts the remaining cooldown of every active Chorus burst (and Blink).
function reduceCooldowns(player, seconds) {
    if (!(seconds > 0)) return;
    for (const setId of Object.keys(activeSets(player))) CooldownManager.reduce(player, `chorus_k_${setId}`, seconds);
    CooldownManager.reduce(player, "chorus_blink", seconds);
}

function addEffectTo(entity, effect, seconds, amplifier = 0, particles = true) {
    // Speed on a PLAYER is scripted (MovementManager) instead of the vanilla potion effect.
    if (effect === "speed" && isPlayer(entity)) { MovementManager.addSpeed(entity, "chorus", amplifier + 1, seconds); return; }
    try { entity.addEffect(effect, Math.round(seconds * TICKS), { amplifier, showParticles: particles }); } catch { /* invalid */ }
}

// Generic flat-damage shield (Stone Skin, Magma Armor). Absorbs part of the
// incoming hit before HP is touched; recharges in tick20 after a quiet period.
function absorb(victim, ctx, key, max, onBreak) {
    const st = state(victim);
    if (st.shields[key] === undefined) st.shields[key] = max;
    st.lastHit = system.currentTick;
    if (st.shields[key] <= 0) return;
    const incoming = Math.max(0, ctx.baseDamage + ctx.flatBonus);
    const taken = Math.min(st.shields[key], incoming);
    if (taken <= 0) return;
    ctx.addFlat(-taken);
    st.shields[key] -= taken;
    if (st.shields[key] <= 0) onBreak?.(victim);
}

function rechargeShield(player, key, max, seconds, label) {
    const st = state(player);
    if (st.shields[key] === undefined) { st.shields[key] = max; return; }
    if (st.shields[key] < max && system.currentTick - st.lastHit >= seconds * TICKS) {
        st.shields[key] = max;
        player.onScreenDisplay.setActionBar(`${label} §aRecharged`);
    }
}

function blast(victim, radius, { damage = 0, push = 0, lift = 0, pull = 0, igniteSec = 0, effect = null, effects = null, onEach = null, execute = null, hold = 0 }) {
    for (const mob of nearbyHostiles(victim, radius)) {
        onEach?.(mob);
        // Execute (Destiny 8): non-boss mobs below the HP threshold die outright.
        if (execute && isExecutable(mob) && targetHpPercent(mob) < execute.hpBelow) {
            fireSuppressedDamage(mob, victim, Math.ceil(remainingHp(mob)) + 1);
            continue;
        }
        // Hold (Cosmos 8): pinned in place for `hold` seconds.
        if (hold > 0 && isExecutable(mob)) addEffectTo(mob, "slowness", hold, 10, false);
        if (push > 0 || lift > 0) pushAway(victim, mob, push, lift);
        if (pull > 0) pushAway(victim, mob, -pull, 0.1);
        for (const [id, sec, amp] of effects ?? []) addEffectTo(mob, id, sec, amp ?? 0);
        if (igniteSec > 0) ignite(mob, igniteSec);
        if (effect) addEffectTo(mob, effect.id, effect.seconds, effect.amplifier ?? 0, effect.particles ?? true);
        if (damage > 0) fireSuppressedDamage(mob, victim, damage);
    }
}



// Capped damage modifiers — every Chorus effect goes through these so stacking
// (tiers + windows + shields + souls) can never make a hit free or absurd.
function reduce(ctx, pct) {
    const used = ctx.meta.chorusReduction ?? 0;
    const add = Math.max(0, Math.min(pct, CHORUS_CAPS.damageReduction - used));
    if (add <= 0) return;
    ctx.meta.chorusReduction = used + add;
    ctx.addMultiplier(-add);
}

function bonus(ctx, pct) {
    const used = ctx.meta.chorusBonus ?? 0;
    const add = Math.max(0, Math.min(pct, CHORUS_CAPS.damageBonus - used));
    if (add <= 0) return;
    ctx.meta.chorusBonus = used + add;
    ctx.addMultiplier(add);
}

// ─── Data-driven kits (Resonance hybrids) ────────────────────────────────────

const CAUSE_GROUPS = {
    fire: FIRE_CAUSES,
    lightning: new Set(["lightning"]),
    explosion: EXPLOSION_CAUSES,
    freeze: FREEZE_CAUSES,
    fall: new Set(["fall"]),
    physical: PHYSICAL_CAUSES,
    magic: new Set(["magic"]),
    projectile: new Set(["projectile"]),
    drowning: new Set(["drowning"]),
    wither: new Set(["wither"]),
    void: new Set(["void", "out_of_world"]),
};

// Active kit specs for a player: [{ setId, name, spec }] for every reached tier.
function activeSpecs(player) {
    const out = [];
    for (const [setId, count] of Object.entries(activeSets(player))) {
        const kit = CHORUS_KITS[setId];
        if (!kit) continue;
        for (const t of CHORUS_THRESHOLDS) {
            if (count >= t && kit[t]) out.push({ setId, name: kit.name, spec: kit[t] });
        }
    }
    return out;
}

function applyEffects(entity, list) {
    for (const [id, sec, amp] of list ?? []) addEffectTo(entity, id, sec, amp ?? 0);
}

// ─── Awaken+ mechanics: Mark / Hold / Execute / Revive ───────────────────────

// Mark: victimId → { owner, pct, until }. Only the player who applied the mark gets the bonus.
function marksMap() {
    const g = RuntimeState.global("chorus");
    if (!g.marks) g.marks = new Map();
    return g.marks;
}

function applyMark(attacker, victim, mark) {
    try { marksMap().set(victim.id, { owner: attacker.id, pct: mark.pct, until: system.currentTick + mark.seconds * TICKS }); } catch { /* invalid */ }
}

function markBonusPct(attacker, victim) {
    const m = marksMap().get(victim?.id);
    return m && m.owner === attacker.id && system.currentTick < m.until ? m.pct : 0;
}

// Execute and Hold never touch bosses, Core or Enchanted mobs (same anti one-shot rule as the rest of the addon).
function isExecutable(mob) {
    try {
        if (!mob?.isValid || isBoss(mob.typeId)) return false;
        if (EvolutionManager.getTierId(mob) === "core" || EvolutionManager.isEnchanted(mob)) return false;
        return true;
    } catch { return false; }
}

function remainingHp(mob) {
    try {
        const pool = MobHpManager.readPool(mob);
        if (pool) return pool.vhp;
        return mob.getComponent("minecraft:health")?.currentValue ?? 0;
    } catch { return 0; }
}

function targetHpPercent(entity) {
    try {
        const h = entity.getComponent("minecraft:health");
        const max = h?.effectiveMax ?? 0;
        return max > 0 ? (h.currentValue / max) * 100 : 100;
    } catch { return 100; }
}

function dealCond(bonus, attacker, victim) {
    switch (bonus.cond) {
        case "night":  return isNight();
        case "undead": return isUndead(victim);
        case "airborne": return !attacker.isOnGround;
        case "frozen": return isFrozen(victim);
        case "lowTarget": return targetHpPercent(victim) < (bonus.hpBelow ?? 30);
        default: return true;
    }
}

// Souls (Death): kills stack a damage bonus that expires if you stop killing.
function soulCount(player) {
    const st = state(player);
    return st.souls && system.currentTick < st.souls.until ? st.souls.count : 0;
}

// Victim side of damage:before. Returns true if the hit was dodged.
function kitVictimBefore(victim, ctx) {
    const specs = activeSpecs(victim);
    if (specs.length === 0) return false;
    const cause = ctx.cause;
    const now = system.currentTick;
    const st = state(victim);
    const isAttack = cause === "entity_attack" || cause === "projectile";

    // Dodge: chances of every active tier add up, are capped, and are rolled once.
    if (isAttack) {
        let dodge = 0;
        for (const { spec } of specs) dodge += spec.dodge?.chance ?? 0;
        dodge = Math.min(dodge, CHORUS_CAPS.dodge ?? 25);
        if (dodge > 0 && Math.random() * 100 < dodge) {
            ctx.cancel("chorus_dodge");
            AchievementManager.event(victim, "dodges");
            victim.onScreenDisplay.setActionBar("§d[Chorus] §fDodged!");
            let step = 0;
            for (const { spec } of specs) step = Math.max(step, spec.dodge?.blink ?? 0);
            if (step > 0) blinkPlayer(victim, awayDir(victim, ctx.attacker), step);
            return true;
        }
    }
    const windowsApplied = new Set();
    for (const { setId, name, spec } of specs) {
        for (const [groups, pct] of spec.resist ?? []) {
            if (groups.some((g) => CAUSE_GROUPS[g]?.has(cause))) reduce(ctx, pct);
        }
        if (spec.lowHpResist && hpPercent(victim) < spec.lowHpResist.hpBelow) reduce(ctx, spec.lowHpResist.pct);
        const win = st.windows?.[setId];
        if (win && now < win.until && !windowsApplied.has(setId)) {
            windowsApplied.add(setId);   // one window per set, not one per unlocked tier
            reduce(ctx, win.pct);
        }
        if (spec.shield) {
            const sh = spec.shield;
            absorb(victim, ctx, `kit:${setId}`, sh.amount, (p) => {
                blast(p, sh.breakRadius, { effects: sh.breakEffects });
                p.onScreenDisplay.setActionBar(`§d[${name}] §cShield shattered!`);
                p.playSound("random.glass");
            });
        }
    }
    return false;
}

// Attacker side of damage:before — bonuses and on-hit procs.
function kitAttackerBefore(attacker, victim, ctx) {
    const st = state(attacker);
    const now = system.currentTick;
    const windowsApplied = new Set();
    const marked = markBonusPct(attacker, victim);   // Mark (Destiny / Genesis): +pct% from the marker only
    if (marked > 0) bonus(ctx, marked);
    for (const { setId, spec } of activeSpecs(attacker)) {
        if (spec.dealBonus && dealCond(spec.dealBonus, attacker, victim)) bonus(ctx, spec.dealBonus.pct);
        if (spec.souls) {
            const n = soulCount(attacker);
            if (n > 0) bonus(ctx, n * spec.souls.bonus);
        }
        const dw = st.dealWindows?.[setId];
        if (dw && now < dw.until && !windowsApplied.has(setId)) {
            windowsApplied.add(setId);
            bonus(ctx, dw.pct);
        }
        const h = spec.onHit;
        if (h && Math.random() * 100 < h.chance) {
            applyEffects(victim, h.effects);
            if (h.igniteSec) ignite(victim, h.igniteSec);
            if (h.mark) applyMark(attacker, victim, h.mark);
            if (h.chainDamage) {
                for (const other of nearbyHostiles(victim, 4, victim).slice(0, h.chainCount ?? 1)) {
                    fireSuppressedDamage(other, attacker, h.chainDamage);
                }
            }
            if (h.healPct) healPercent(attacker, h.healPct);
            if (h.cdr) reduceCooldowns(attacker, h.cdr);
        }
    }
}

function runBurst(victim, setId, name, b, attacker = null) {
    const cdKey = `chorus_k_${setId}`;
    if (!CooldownManager.isReady(victim, cdKey)) return;
    CooldownManager.start(victim, cdKey, b.cooldown);
    blast(victim, b.radius, {
        damage: b.damage ?? 0, push: b.push ?? 0, lift: b.lift ?? 0, pull: b.pull ?? 0,
        igniteSec: b.igniteSec ?? 0, effects: b.effects, execute: b.execute ?? null, hold: b.hold ?? 0,
    });
    for (const [id, sec, amp] of b.selfBuffs ?? []) addEffectTo(victim, id, sec, amp ?? 0, false);
    if (b.selfWindow) {
        const st = state(victim);
        if (!st.windows) st.windows = {};
        st.windows[setId] = { until: system.currentTick + b.selfWindow.seconds * TICKS, pct: b.selfWindow.pct };
    }
    if (b.dealWindow) {
        const st = state(victim);
        if (!st.dealWindows) st.dealWindows = {};
        st.dealWindows[setId] = { until: system.currentTick + b.dealWindow.seconds * TICKS, pct: b.dealWindow.pct };
    }
    if (b.healPct) healPercent(victim, b.healPct);
    if (b.healNearbyPct) for (const p of nearbyPlayers(victim, b.radius)) healPercent(p, b.healNearbyPct);
    if (b.rewind) rewindHp(victim, b.rewind);
    if (b.cleanse) cleanse(victim);
    if (b.blink) blinkPlayer(victim, awayDir(victim, attacker), b.blink.distance);
    victim.onScreenDisplay.setActionBar(`§d[${name}] §f${b.msg ?? ""}`);
    if (b.sound) victim.playSound(b.sound);
}

// After the hit resolved: thorns + bursts.
function kitVictimAfter(victim, attacker, isHit, isMelee, hasHp) {
    for (const { setId, name, spec } of activeSpecs(victim)) {
        if (isMelee && spec.thorns) {
            fireSuppressedDamage(attacker, victim, spec.thorns.damage);
            applyEffects(attacker, spec.thorns.effects);
        }
        const b = spec.burst;
        if (!b) continue;
        if (b.trigger === "hit" && isHit) runBurst(victim, setId, name, b, attacker);
        else if (b.trigger === "lowHp" && hasHp && hpPercent(victim) <= b.hpBelow) runBurst(victim, setId, name, b, attacker);
    }
}

// ─── damage:before ───────────────────────────────────────────────────────────

function onDamageBefore(ctx) {
    const { attacker, victim } = ctx;
    const cause = ctx.cause;

    // — Revive invulnerability: nothing hurts a player who was just brought back —
    if (isPlayer(victim) && system.currentTick < (state(victim).reviveUntil ?? 0)) {
        ctx.cancel("chorus_revive");
        return;
    }

    // — Victim side —
    if (isPlayer(victim) && anyActive(victim)) {
        const isFire = FIRE_CAUSES.has(cause);
        const isPhysical = PHYSICAL_CAUSES.has(cause);
        const isAttack = cause === "entity_attack" || cause === "projectile";

        // Sandstorm 6 — Dust Veil dodge
        if (isAttack && has(victim, SAND, 6) && Math.random() * 100 < V.sandstorm.dodgeChance) {
            ctx.cancel("chorus_dodge");
            AchievementManager.event(victim, "dodges");
            victim.onScreenDisplay.setActionBar("§e[Dust Veil] §fDodged!");
            return;
        }

        // Data-driven kits (Resonance hybrids): dodge, resist, shields, windows
        if (kitVictimBefore(victim, ctx)) return;

        // Damage-taken reductions (2-slot effects)
        if (cause === "lightning" || EXPLOSION_CAUSES.has(cause)) {
            if (has(victim, "lightning", 2)) reduce(ctx, V.lightning.resist);
        }
        if (EXPLOSION_CAUSES.has(cause) || cause === "projectile") {
            if (has(victim, "metal", 2)) reduce(ctx, V.metal.resist);
        }
        if (FREEZE_CAUSES.has(cause) && has(victim, "frost", 2)) reduce(ctx, V.frost.freezeResist);
        if (cause === "fall" && has(victim, "gale", 2)) reduce(ctx, V.gale.fallResist);
        // Gale 6 — Skybound (airborne)
        if (has(victim, "gale", 6) && !victim.isOnGround) reduce(ctx, V.gale.airResist);
        // Metal 6 — Fortified (low HP)
        if (has(victim, "metal", 6) && hpPercent(victim) < V.metal.fortifiedHpBelow) reduce(ctx, V.metal.fortifiedResist);
        // Metal 8 — Bulwark window
        if (has(victim, "metal", 8) && system.currentTick < (state(victim).bulwarkUntil ?? 0)) {
            reduce(ctx, V.metal.bulwarkResist);
        }
        if (isFire) {
            if (has(victim, "fire", 2))   reduce(ctx, V.fire.fireResist);
            if (has(victim, STEAM, 2))    reduce(ctx, V.steam.resist);
            if (has(victim, WILDFIRE, 2)) reduce(ctx, V.wildfire.fireResist);
            if (has(victim, MAGMA, 2))    reduce(ctx, V.magma.fireResist);
        }
        if (cause === "drowning") {
            if (has(victim, "water", 2)) reduce(ctx, V.water.waterResist);
            if (has(victim, STEAM, 2))   reduce(ctx, V.steam.resist);
            if (has(victim, MONSOON, 2)) reduce(ctx, V.monsoon.drownResist);
        }
        if (cause === "magic") {
            if (has(victim, "water", 2)) reduce(ctx, V.water.waterResist);
            if (has(victim, BOG, 2))     reduce(ctx, V.bog.magicResist);
        }
        if (cause === "fall") {
            if (has(victim, WILDFIRE, 2)) reduce(ctx, V.wildfire.fallResist);
            if (has(victim, MONSOON, 2))  reduce(ctx, V.monsoon.fallResist);
            if (has(victim, SAND, 2))     reduce(ctx, V.sandstorm.fallResist);
        }
        if (isPhysical) {
            if (has(victim, "earth", 2)) reduce(ctx, V.earth.physicalResist);
            if (has(victim, BOG, 2))     reduce(ctx, V.bog.physicalResist);
        }

        // Shields (6-slot effects)
        if (has(victim, "earth", 6)) {
            absorb(victim, ctx, "stone", V.earth.shieldAmount, (p) => {
                p.onScreenDisplay.setActionBar("§6[Stone Skin] §cShattered!");
                p.playSound("dig.stone");
            });
        }
        if (has(victim, MAGMA, 6)) {
            absorb(victim, ctx, "magma", V.magma.shieldAmount, (p) => {
                blast(p, V.magma.shieldBreakRadius, { igniteSec: V.magma.shieldBreakIgniteSeconds });
                p.onScreenDisplay.setActionBar("§6[Magma Armor] §cShattered — scorching nearby enemies!");
                p.playSound("random.fizz");
            });
        }
    }

    // — Attacker side (on-hit procs) —
    if (isPlayer(attacker) && victim && !isPlayer(victim) && ON_HIT_CAUSES.has(cause) && anyActive(attacker)) {
        const roll = (pct) => Math.random() * 100 < pct;

        // Damage-dealt bonuses
        if (has(attacker, "light", 2) && isUndead(victim)) bonus(ctx, V.light.undeadBonus);
        if (has(attacker, "dark", 2) && isNight()) bonus(ctx, V.dark.nightBonus);
        if (has(attacker, "gale", 6) && !attacker.isOnGround) bonus(ctx, V.gale.airBonus);
        if (has(attacker, "frost", 8) && isFrozen(victim)) bonus(ctx, V.frost.frozenBonus);

        // Data-driven kits: damage bonuses and on-hit procs
        kitAttackerBefore(attacker, victim, ctx);

        // Lightning 4 — chain to the nearest other hostile
        if (has(attacker, "lightning", 4) && roll(V.lightning.chainChance)) {
            const others = nearbyHostiles(victim, V.lightning.chainRadius, victim);
            if (others.length > 0) {
                fireSuppressedDamage(others[0], attacker, V.lightning.chainDamage);
                attacker.playSound("ambient.weather.lightning.impact");
            }
        }
        // Lightning 8 — Thunderstrike
        if (has(attacker, "lightning", 8) && roll(V.lightning.boltChance) && CooldownManager.isReady(attacker, "chorus_bolt")) {
            CooldownManager.start(attacker, "chorus_bolt", V.lightning.boltCooldown);
            const targets = new Map(nearbyHostiles(victim, V.lightning.boltRadius).map((m) => [m.id, m]));
            targets.set(victim.id, victim);
            for (const t of targets.values()) fireSuppressedDamage(t, attacker, V.lightning.boltDamage);
            try { victim.dimension.playSound("ambient.weather.lightning.impact", victim.location, { volume: 1 }); } catch { /* ignore */ }
            attacker.onScreenDisplay.setActionBar("§e[Thunderstrike] §fA bolt crashes down!");
        }
        // Frost 4 — root
        if (has(attacker, "frost", 4) && roll(V.frost.rootChance)) {
            addEffectTo(victim, "slowness", V.frost.rootSeconds, V.frost.rootAmplifier);
            markFrozen(victim, V.frost.rootSeconds);
        }
        // Dark 4 — wither
        if (has(attacker, "dark", 4) && roll(V.dark.witherChance)) addEffectTo(victim, "wither", V.dark.witherSeconds);

        if (has(attacker, "fire", 4) && roll(V.fire.igniteChance)) ignite(victim, V.fire.igniteSeconds);
        if (has(attacker, "water", 4) && roll(V.water.slowChance)) {
            addEffectTo(victim, "slowness", V.water.slowSeconds, V.water.slowAmplifier);
        }
        // Steam 4 — blind
        if (has(attacker, STEAM, 4) && roll(V.steam.blindChance)) addEffectTo(victim, "blindness", V.steam.blindSeconds);
        // Wildfire 4 — fire spreads to hostiles near the target
        if (has(attacker, WILDFIRE, 4) && roll(V.wildfire.spreadChance)) {
            ignite(victim, V.wildfire.igniteSeconds);
            for (const mob of nearbyHostiles(victim, V.wildfire.spreadRadius, victim)) ignite(mob, V.wildfire.igniteSeconds);
        }
        // Monsoon 4 — arrows slow
        if (cause === "projectile" && has(attacker, MONSOON, 4) && roll(V.monsoon.projSlowChance)) {
            addEffectTo(victim, "slowness", V.monsoon.slowSeconds, 0);
        }
        // Bog 4 — poison
        if (has(attacker, BOG, 4) && roll(V.bog.poisonChance)) addEffectTo(victim, "poison", V.bog.poisonSeconds);
        // Sandstorm 4 — blind
        if (has(attacker, SAND, 4) && roll(V.sandstorm.blindChance)) addEffectTo(victim, "blindness", V.sandstorm.blindSeconds);
    }
}

// ─── damage:after ────────────────────────────────────────────────────────────

// Runs a "when hit" burst if the set is active and its cooldown is ready.
function whenHit(victim, setId, need, cdKey, cooldown, fn) {
    if (!has(victim, setId, need) || !CooldownManager.isReady(victim, cdKey)) return;
    CooldownManager.start(victim, cdKey, cooldown);
    fn();
}

function onDamageAfter(ctx) {
    const { attacker, victim } = ctx;

    // Kit lifesteal: heal a share of the damage the attacker just dealt
    if (isPlayer(attacker) && victim && !isPlayer(victim) && ON_HIT_CAUSES.has(ctx.cause) && anyActive(attacker)) {
        for (const { spec } of activeSpecs(attacker)) {
            if (spec.lifesteal && (ctx.finalDamage ?? 0) > 0) {
                HPManager.heal(attacker, ctx.finalDamage * (spec.lifesteal.pct / 100));
            }
        }
    }

    if (!isPlayer(victim) || !victim.isValid || !anyActive(victim)) return;

    const isHit = ON_HIT_CAUSES.has(ctx.cause) && attacker && attacker.id !== victim.id;
    const isMelee = isHit && ctx.cause === "entity_attack" && !isPlayer(attacker);
    const lowHp = HPManager.getHP(victim) > 0;

    // Earth 4 — reflect melee damage
    if (isMelee && has(victim, "earth", 4)) {
        const amount = (ctx.finalDamage ?? 0) * (V.earth.reflectPercent / 100);
        if (amount >= 1) fireSuppressedDamage(attacker, victim, amount);
    }
    // Magma 4 — Molten Skin: reflect + ignite
    if (isMelee && has(victim, MAGMA, 4)) {
        const amount = (ctx.finalDamage ?? 0) * (V.magma.reflectPercent / 100);
        if (amount >= 1) fireSuppressedDamage(attacker, victim, amount);
        ignite(attacker, V.magma.reflectIgniteSeconds);
    }

    // Frost 6 — Frost Armor: slow melee attackers
    if (isMelee && has(victim, "frost", 6)) {
        addEffectTo(attacker, "slowness", V.frost.armorSlowSeconds, V.frost.armorSlowAmplifier);
    }
    // Metal 4 — Spikes
    if (isMelee && has(victim, "metal", 4)) fireSuppressedDamage(attacker, victim, V.metal.spikeDamage);

    // Water 8 — Tidal Wave (low HP)
    if (lowHp && hpPercent(victim) <= V.water.tidalHpBelow) {
        whenHit(victim, "water", 8, "chorus_tidal", V.water.tidalCooldown, () => {
            blast(victim, V.water.tidalRadius, { push: V.water.tidalPush, lift: 0.4 });
            cleanse(victim);
            victim.onScreenDisplay.setActionBar("§9[Tidal Wave] §fThe tide pushes back!");
            victim.playSound("random.splash");
        });
    }
    // Steam 8 — Steam Burst (low HP)
    if (lowHp && hpPercent(victim) <= V.steam.burstHpBelow) {
        whenHit(victim, STEAM, 8, "chorus_steam", V.steam.burstCooldown, () => {
            blast(victim, V.steam.burstRadius, {
                damage: V.steam.burstDamage,
                effect: { id: "blindness", seconds: V.steam.burstBlindSeconds },
            });
            victim.onScreenDisplay.setActionBar("§7[Steam Burst] §fScalding steam erupts!");
            victim.playSound("random.fizz");
        });
    }

    // Data-driven kits: thorns + bursts (hit / low HP triggers)
    kitVictimAfter(victim, attacker, isHit, isMelee, lowHp);

    // Dark 8 — Shadow Step (low HP)
    if (lowHp && hpPercent(victim) <= V.dark.stepHpBelow) {
        whenHit(victim, "dark", 8, "chorus_shadow", V.dark.stepCooldown, () => {
            addEffectTo(victim, "invisibility", V.dark.stepSeconds, 0, false);
            addEffectTo(victim, "speed", V.dark.stepSeconds, 1, false);
            healPercent(victim, V.dark.stepHealPercent);
            victim.onScreenDisplay.setActionBar("§8[Shadow Step] §7You vanish into the dark...");
            victim.playSound("mob.endermen.portal");
        });
    }

    if (!isHit) return;

    whenHit(victim, "wind", 8, "chorus_gale", V.wind.burstCooldown, () => {
        blast(victim, V.wind.burstRadius, { push: V.wind.burstPush, lift: V.wind.burstLift, damage: V.wind.burstDamage ?? 0 });
        victim.onScreenDisplay.setActionBar("§f[Gale Burst] §7Enemies blown away!");
        victim.playSound("mace.smash_air");
    });
    whenHit(victim, "earth", 8, "chorus_quake", V.earth.quakeCooldown, () => {
        blast(victim, V.earth.quakeRadius, {
            damage: V.earth.quakeDamage,
            effect: { id: "slowness", seconds: V.earth.quakeSeconds, amplifier: 10, particles: false },
        });
        victim.onScreenDisplay.setActionBar("§6[Quake] §7The ground shakes!");
        victim.playSound("dig.gravel");
    });
    // Wildfire 8 — Firestorm
    whenHit(victim, WILDFIRE, 8, "chorus_firestorm", V.wildfire.stormCooldown, () => {
        blast(victim, V.wildfire.stormRadius, {
            damage: V.wildfire.stormDamage, push: V.wildfire.stormPush, lift: 0.4,
            igniteSec: V.wildfire.stormIgniteSeconds,
        });
        victim.onScreenDisplay.setActionBar("§c[Firestorm] §7Flames rage around you!");
        victim.playSound("mob.ghast.fireball");
    });
    // Magma 8 — Eruption
    whenHit(victim, MAGMA, 8, "chorus_eruption", V.magma.eruptCooldown, () => {
        blast(victim, V.magma.eruptRadius, {
            damage: V.magma.eruptDamage, push: V.magma.eruptPush, lift: V.magma.eruptLift,
            igniteSec: V.magma.eruptIgniteSeconds,
        });
        victim.onScreenDisplay.setActionBar("§6[Eruption] §7Molten rock bursts out!");
        victim.playSound("random.explode");
    });
    // Monsoon 8 — Typhoon
    whenHit(victim, MONSOON, 8, "chorus_typhoon", V.monsoon.typhoonCooldown, () => {
        blast(victim, V.monsoon.typhoonRadius, {
            push: V.monsoon.typhoonPush, lift: 0.4,
            effect: { id: "slowness", seconds: V.monsoon.typhoonSlowSeconds, amplifier: V.monsoon.typhoonSlowAmplifier },
        });
        cleanse(victim);
        victim.onScreenDisplay.setActionBar("§b[Typhoon] §7A storm sweeps enemies away!");
        victim.playSound("random.splash");
    });
    // Bog 8 — Quagmire
    whenHit(victim, BOG, 8, "chorus_quagmire", V.bog.quagCooldown, () => {
        blast(victim, V.bog.quagRadius, {
            damage: V.bog.quagDamage,
            effect: { id: "slowness", seconds: V.bog.quagSlowSeconds, amplifier: V.bog.quagSlowAmplifier },
        });
        HPManager.heal(victim, HPManager.getMaxHP(victim) * (V.bog.quagHealPercent / 100));
        victim.onScreenDisplay.setActionBar("§2[Quagmire] §7The ground turns to mud!");
        victim.playSound("dig.gravel");
    });
    // Frost 8 — Absolute Zero
    whenHit(victim, "frost", 8, "chorus_zero", V.frost.zeroCooldown, () => {
        blast(victim, V.frost.zeroRadius, {
            effect: { id: "slowness", seconds: V.frost.zeroSeconds, amplifier: 10 },
            onEach: (mob) => markFrozen(mob, V.frost.zeroSeconds),
        });
        victim.onScreenDisplay.setActionBar("§b[Absolute Zero] §fEnemies freeze solid!");
        victim.playSound("random.glass");
    });
    // Gale 8 — Cyclone
    whenHit(victim, "gale", 8, "chorus_cyclone", V.gale.cycloneCooldown, () => {
        blast(victim, V.gale.cycloneRadius, { effect: { id: "levitation", seconds: V.gale.levitationSeconds } });
        addEffectTo(victim, "slow_falling", V.gale.slowFallSeconds, 0, false);
        victim.onScreenDisplay.setActionBar("§a[Cyclone] §7Enemies are swept into the sky!");
        victim.playSound("mace.smash_air");
    });
    // Metal 8 — Bulwark (opens the reduction window checked in damage:before)
    whenHit(victim, "metal", 8, "chorus_bulwark", V.metal.bulwarkCooldown, () => {
        state(victim).bulwarkUntil = system.currentTick + V.metal.bulwarkSeconds * TICKS;
        victim.onScreenDisplay.setActionBar("§7[Bulwark] §fIron will hardens your armor!");
        victim.playSound("random.anvil_land");
    });
    // Light 8 — Holy Nova
    whenHit(victim, "light", 8, "chorus_nova", V.light.novaCooldown, () => {
        for (const mob of nearbyHostiles(victim, V.light.novaRadius)) {
            addEffectTo(mob, "blindness", V.light.novaBlindSeconds, 0);
            fireSuppressedDamage(mob, victim, isUndead(mob) ? V.light.novaUndeadDamage : V.light.novaDamage);
        }
        for (const p of nearbyPlayers(victim, V.light.novaRadius)) healPercent(p, V.light.novaHealPercent);
        victim.onScreenDisplay.setActionBar("§6[Holy Nova] §fLight purges the darkness!");
        victim.playSound("random.levelup");
    });
    // Sandstorm 8
    whenHit(victim, SAND, 8, "chorus_sandstorm", V.sandstorm.stormCooldown, () => {
        blast(victim, V.sandstorm.stormRadius, {
            damage: V.sandstorm.stormDamage, push: V.sandstorm.stormPush, lift: V.sandstorm.stormLift,
            effect: { id: "blindness", seconds: V.sandstorm.stormBlindSeconds },
        });
        victim.onScreenDisplay.setActionBar("§e[Sandstorm] §7Sand whips around you!");
        victim.playSound("dig.sand");
    });
}

// ─── Revive (death-save) ─────────────────────────────────────────────────────

// Registered with DeathManager: called when RPG HP hits 0. Returns true when the player was saved.
// Revives of different pieces never stack — they share one cooldown per player (chorus_revive).
function chorusRevive(player) {
    try {
        if (!player?.isValid || !anyActive(player)) return false;
        let best = null;
        for (const { spec } of activeSpecs(player)) {
            if (spec.revive && (!best || spec.revive.hpPct > best.hpPct)) best = spec.revive;
        }
        if (!best || !CooldownManager.isReady(player, "chorus_revive")) return false;

        CooldownManager.start(player, "chorus_revive", best.cooldown);
        HPManager.setHP(player, HPManager.getMaxHP(player) * (best.hpPct / 100));
        HPManager.clearDeathLock(player);
        state(player).reviveUntil = system.currentTick + best.invulnSeconds * TICKS;
        player.sendMessage("§d[Chorus] §fRevive! §7You were brought back from the brink.");
        player.onScreenDisplay.setActionBar("§d✦ Revive ✦");
        player.playSound("random.totem");
        return true;
    } catch { return false; }
}

// ─── Kill hook (Fire 8) ──────────────────────────────────────────────────────

function onKill(killEvent) {
    const killer = killEvent.killer;
    if (!killer || !isPlayer(killer) || killEvent.isPlayerVictim || !anyActive(killer)) return;

    // Lightning 6 — Speed II on kill
    if (has(killer, "lightning", 6)) {
        addEffectTo(killer, "speed", V.lightning.killSpeedSeconds, V.lightning.killSpeedAmplifier, false);
    }
    // Light 4 — Blessing (heal on kill)
    if (has(killer, "light", 4)) healPercent(killer, V.light.killHealPercent);
    // Data-driven kits: souls + kill buffs
    for (const { spec } of activeSpecs(killer)) {
        if (spec.souls) {
            const st = state(killer);
            st.souls = {
                count: Math.min(spec.souls.max, soulCount(killer) + 1),
                until: system.currentTick + spec.souls.seconds * TICKS,
            };
            killer.onScreenDisplay.setActionBar(`§5[Souls] §f${st.souls.count} / ${spec.souls.max}`);
        }
        if (!spec.killBuff) continue;
        for (const [id, sec, amp] of spec.killBuff.effects ?? []) addEffectTo(killer, id, sec, amp ?? 0, false);
        if (spec.killBuff.healPct) healPercent(killer, spec.killBuff.healPct);
        if (spec.killBuff.cdr) reduceCooldowns(killer, spec.killBuff.cdr);
    }

    // Fire 8 — ignited enemies explode on death
    if (!has(killer, "fire", 8)) return;

    const victim = killEvent.victim;
    let id, dimension, location;
    try {
        id = victim.id;
        dimension = victim.dimension;
        location = { ...victim.location };
    } catch { return; }

    const map = ignitedMap();
    const expires = map.get(id);
    if (expires === undefined) return;
    map.delete(id);
    if (system.currentTick > expires) return;

    try {
        for (const mob of dimension.getEntities({ location, maxDistance: V.fire.blastRadius, families: ["monster"] })) {
            if (mob.isValid && mob.id !== id) fireSuppressedDamage(mob, killer, V.fire.blastDamage);
        }
        dimension.spawnParticle("minecraft:large_explosion", location);
        dimension.playSound("random.explode", location, { volume: 0.6 });
    } catch { /* dimension unloaded */ }
}

// ─── Scheduled ticks ─────────────────────────────────────────────────────────

// Every 2 ticks — Wind 4 dash (Sprint + Jump)
function tickDash(player) {
    if (!player.isSprinting || !player.isJumping) return;
    if (!has(player, "wind", 4)) return;
    if (!CooldownManager.isReady(player, "chorus_dash")) return;
    CooldownManager.start(player, "chorus_dash", V.wind.dashCooldown);

    const dir = player.getViewDirection();
    const len = Math.hypot(dir.x, dir.z) || 1;
    const kx = (dir.x / len) * V.wind.dashPower;
    const kz = (dir.z / len) * V.wind.dashPower;
    try {
        player.applyKnockback({ x: kx, z: kz }, V.wind.dashLift);
    } catch {
        try { player.applyKnockback(kx, kz, V.wind.dashPower, V.wind.dashLift); } catch { /* unsupported */ }
    }
    player.playSound("mace.smash_air");
}

// Every 2 ticks — Dimension Blink (Sprint + Jump): short safe teleport forward
function tickBlink(player) {
    if (!player.isSprinting || !player.isJumping || !anyActive(player)) return;
    let distance = 0, cooldown = Infinity;
    for (const { spec } of activeSpecs(player)) {
        if (!spec.blink) continue;
        distance = Math.max(distance, spec.blink.distance);
        cooldown = Math.min(cooldown, spec.blink.cooldown);
    }
    if (distance <= 0 || !CooldownManager.isReady(player, "chorus_blink")) return;
    if (blinkPlayer(player, player.getViewDirection(), distance)) CooldownManager.start(player, "chorus_blink", cooldown);
}

// Every 2 ticks — Gale 4 Double Jump (jump again while airborne)
function tickAirJump(player) {
    const st = state(player);
    const jumping = !!player.isJumping;
    const grounded = !!player.isOnGround;
    if (grounded) { st.airJumped = false; st.airTicks = 0; }
    else st.airTicks = (st.airTicks ?? 0) + 1;

    const pressed = jumping && !st.prevJump;
    st.prevJump = jumping;
    if (grounded || !pressed || st.airJumped || (st.airTicks ?? 0) < 3) return;
    if (!has(player, "gale", 4) || !CooldownManager.isReady(player, "chorus_airjump")) return;

    st.airJumped = true;
    CooldownManager.start(player, "chorus_airjump", V.gale.airJumpCooldown);
    try {
        player.applyKnockback({ x: 0, z: 0 }, V.gale.airJumpPower);
    } catch {
        try { player.applyKnockback(0, 0, 0, V.gale.airJumpPower); } catch { /* unsupported */ }
    }
    player.playSound("mace.smash_air");
}

// Every 10 ticks — buffs that need refreshing
function tick10(player) {
    if (!anyActive(player)) return;
    if (has(player, "wind", 2)) {
        MovementManager.addSpeed(player, "chorus_wind", V.wind.speedAmplifier + 1, 1.5);
    }
    if (has(player, SAND, 2)) {
        MovementManager.addSpeed(player, "chorus_sand", V.sandstorm.speedAmplifier + 1, 1.5);
    }
    if (has(player, "water", 2) && player.isInWater) {
        player.addEffect("dolphins_grace", 30, { amplifier: 0, showParticles: false });
    }
    if (has(player, "gale", 2)) {
        player.addEffect("jump_boost", 30, { amplifier: V.gale.jumpAmplifier, showParticles: false });
    }
    for (const { spec } of activeSpecs(player)) {
        for (const [id, amp] of spec.selfEffects ?? []) {
            if (id === "speed") MovementManager.addSpeed(player, "chorus_kit", (amp ?? 0) + 1, 1.5);   // scripted Speed
            else player.addEffect(id, 30, { amplifier: amp ?? 0, showParticles: false });
        }
    }
    // Wildfire 6 — sprinting ignites hostiles you run past
    if (has(player, WILDFIRE, 6) && player.isSprinting) {
        for (const mob of nearbyHostiles(player, V.wildfire.sprintRadius)) ignite(mob, V.wildfire.sprintIgniteSeconds);
    }
}

// Every 20 ticks — auras, regeneration, shield recharge
function tick20(player) {
    const st = state(player);
    const active = anyActive(player);

    // HP samples for Rewind (one per second, last 16 seconds — Infinity / Genesis rewind 12s)
    if (!st.hpHist) st.hpHist = [];
    st.hpHist.push(HPManager.getHP(player));
    if (st.hpHist.length > 16) st.hpHist.shift();

    if (!active || !has(player, "earth", 6)) delete st.shields.stone;
    if (!active || !has(player, MAGMA, 6)) delete st.shields.magma;
    if (!active) return;
    const alive = HPManager.getHP(player) > 0;

    // Water 6 — regeneration
    if (alive && has(player, "water", 6)) {
        HPManager.heal(player, HPManager.getMaxHP(player) * (V.water.regenPercentPerSec / 100));
    }
    // Monsoon 6 — regeneration while sprinting / swimming
    if (alive && has(player, MONSOON, 6) && (player.isSprinting || player.isInWater)) {
        HPManager.heal(player, HPManager.getMaxHP(player) * (V.monsoon.regenPercentPerSec / 100));
    }

    // Fire 6 — burning aura
    if (has(player, "fire", 6)) {
        for (const mob of nearbyHostiles(player, V.fire.auraRadius)) {
            ignite(mob, V.fire.auraIgniteSeconds);
            fireSuppressedDamage(mob, player, V.fire.auraDamage);
        }
    }
    // Steam 6 — weakness mist
    if (has(player, STEAM, 6)) {
        for (const mob of nearbyHostiles(player, V.steam.auraRadius)) addEffectTo(mob, "weakness", V.steam.weaknessSeconds, 0, false);
    }
    // Bog 6 — mud aura
    if (has(player, BOG, 6)) {
        for (const mob of nearbyHostiles(player, V.bog.auraRadius)) addEffectTo(mob, "slowness", V.bog.auraSlowSeconds, 0, false);
    }

    // Data-driven kits: regen, auras, shield recharge
    const liveShieldKeys = new Set();
    for (const { setId, name, spec } of activeSpecs(player)) {
        if (alive && spec.regen) healPercent(player, spec.regen);
        if (alive && spec.regenWhile && (player.isSprinting || player.isInWater || !player.isOnGround)) {
            healPercent(player, spec.regenWhile.pct);
        }
        const a = spec.aura;
        if (a) {
            for (const mob of nearbyHostiles(player, a.radius)) {
                applyEffects(mob, a.effects);
                if (a.igniteSec) ignite(mob, a.igniteSec);
                if (a.pull) pushAway(player, mob, -a.pull, 0.1);
                if (a.damage) fireSuppressedDamage(mob, player, a.damage);
            }
            if (a.healPct) for (const p of nearbyPlayers(player, a.radius)) healPercent(p, a.healPct);
            if (a.cleanse) cleanse(player);
        }
        if (spec.shield) {
            liveShieldKeys.add(`kit:${setId}`);
            rechargeShield(player, `kit:${setId}`, spec.shield.amount, spec.shield.recharge, `§d[${name}]`);
        }
    }
    for (const key of Object.keys(st.shields)) {
        if (key.startsWith("kit:") && !liveShieldKeys.has(key)) delete st.shields[key];
    }

    // Light 6 — Radiant Aura (self + nearby players)
    if (has(player, "light", 6)) {
        for (const p of nearbyPlayers(player, V.light.auraRadius)) healPercent(p, V.light.auraHealPercent);
    }
    // Dark 6 — Veil (blind nearby hostiles)
    if (has(player, "dark", 6)) {
        for (const mob of nearbyHostiles(player, V.dark.veilRadius)) addEffectTo(mob, "blindness", V.dark.veilBlindSeconds, 0, false);
    }

    // Shield recharge
    if (has(player, "earth", 6)) rechargeShield(player, "stone", V.earth.shieldAmount, V.earth.shieldRechargeSeconds, "§6[Stone Skin]");
    if (has(player, MAGMA, 6))   rechargeShield(player, "magma", V.magma.shieldAmount, V.magma.shieldRechargeSeconds, "§6[Magma Armor]");

    // Prune stale ignite records
    const map = ignitedMap();
    const now = system.currentTick;
    for (const [id, expires] of map) if (now > expires) map.delete(id);
    const fz = frozenMap();
    for (const [id, expires] of fz) if (now > expires) fz.delete(id);
}

// ─── Projectile hook (Wind 6) ────────────────────────────────────────────────

function handleEntitySpawn(event) {
    const entity = event?.entity;
    if (!entity || entity.typeId !== "minecraft:arrow") return;
    system.run(() => {
        try {
            if (!entity.isValid) return;
            const owner = entity.getComponent("minecraft:projectile")?.owner;
            if (!isPlayer(owner) || !has(owner, "wind", 6)) return;
            const v = entity.getVelocity();
            entity.applyImpulse({ x: v.x * V.wind.arrowBoost, y: v.y * V.wind.arrowBoost, z: v.z * V.wind.arrowBoost });
        } catch { /* projectile gone */ }
    });
}

// ─── Registration ────────────────────────────────────────────────────────────

let registered = false;

export const ChorusEffects = {
    register() {
        if (registered) return false;
        registered = true;

        EventBus.on("damage:before", onDamageBefore);
        EventBus.on("damage:after", onDamageAfter);
        EventBus.on("playerLeave", (e) => { if (e?.playerId) RuntimeState.peek(e.playerId) && delete RuntimeState.peek(e.playerId).chorus; });
        EventBus.on("playerSpawn", (e) => { const p = e?.player; if (p) { const st = state(p); st.shields = {}; st.sets = null; st.souls = null; st.windows = {}; st.dealWindows = {}; st.hpHist = []; st.reviveUntil = 0; } });
        KillManager.addListener(onKill);
        // Revive hooks into the death flow (lazy import: death_manager sits above this module).
        import("../managers/death_manager.js").then((m) => m.DeathManager.addDeathSave(chorusRevive)).catch((e) => console.warn(`[Chorus] Revive hook failed: ${e}`));

        Scheduler.every("chorus_dash", 2, () => { for (const p of world.getAllPlayers()) { tickDash(p); tickBlink(p); tickAirJump(p); } });
        Scheduler.every("chorus_tick_10", 10, () => { for (const p of world.getAllPlayers()) tick10(p); });
        Scheduler.every("chorus_tick_20", 20, () => { for (const p of world.getAllPlayers()) tick20(p); });
        return true;
    },

    handleEntitySpawn,

    // For GUI/debug: current cached counts by set id.
    getActiveCounts(player) { return { ...activeSets(player) }; },
};
