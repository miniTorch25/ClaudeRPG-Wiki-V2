// guide_quest.js -- Guide Quest engine: per-player progress, checks the CURRENT step only, notifications, Admin ops.
// Progress = a comma separated list of completed step ids in one dynamic property (GUIDE.PROPERTY) and a list of
// one-time flags (GUIDE.FLAG_PROPERTY). Neither is touched by Prestige / Reset All / Delete All. No rewards.
import { world, system } from "@minecraft/server";
import { GQ_CHAPTERS, GQ_STEPS } from "../config/guide_quest_data.js";
import { GUIDE } from "../config/guide_quest_config.js";
import { MASTERY } from "../config/mastery_config.js";
import { AchievementManager } from "./achievement_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { StatsManager } from "../managers/stats_manager.js";
import { ChorusManager } from "./chorus_manager.js";
import { GemManager } from "./gem_manager.js";
import { SettingsManager } from "./settings_manager.js";
import { ToastManager } from "./toast_manager.js";
import { Scheduler } from "../core/scheduler.js";
import { Logger } from "../core/logger.js";

const STAT_KEYS = ["str", "def", "agi", "psi", "exc", "mag", "wis", "con", "vit"];
const cache = new Map();   // playerId -> { done:Set, flags:Set, dirtyDone, dirtyFlags }

const required = GQ_STEPS.filter((s) => !s.optional);
const stepById = new Map(GQ_STEPS.map((s) => [s.id, s]));
const indexById = new Map(GQ_STEPS.map((s, i) => [s.id, i]));

// ---------------------------------------------------------------- storage
function parseList(raw) { return new Set(typeof raw === "string" && raw ? raw.split(",").filter(Boolean) : []); }

function entry(player) {
    let e = cache.get(player.id);
    if (e) return e;
    let done, flags;
    try { done = player.getDynamicProperty(GUIDE.PROPERTY); } catch (_) { /* fresh */ }
    try { flags = player.getDynamicProperty(GUIDE.FLAG_PROPERTY); } catch (_) { /* fresh */ }
    e = { done: parseList(done), flags: parseList(flags) };
    // ids that no longer exist in the data are dropped
    for (const id of [...e.done]) if (!stepById.has(id)) e.done.delete(id);
    cache.set(player.id, e);
    return e;
}
function saveDone(player, e) { try { player.setDynamicProperty(GUIDE.PROPERTY, [...e.done].join(",")); } catch (error) { Logger.warn(`Guide Quest save failed: ${error}`); } }
function saveFlags(player, e) { try { player.setDynamicProperty(GUIDE.FLAG_PROPERTY, [...e.flags].join(",")); } catch (_) { /* ignore */ } }

// ---------------------------------------------------------------- conditions
function stateValue(player, k) {
    switch (k) {
        case "level_ever": return Math.max(AchievementManager.counter(player, "level_max") || 0, ProgressionManager.getLevel(player) || 0);
        case "prestige":   return ProgressionManager.getPrestige(player) || 0;
        case "world_asc":  return ProgressionManager.getAscension() || 0;
        case "points_spent": {
            if ((ProgressionManager.getPrestige(player) || 0) >= 1) return 1;     // a Prestiged player has obviously spent Points
            const d = StatsManager.getPlayerData(player);
            return STAT_KEYS.reduce((n, key) => n + (Number(d?.[key]) || 0), 0);
        }
        case "mastery_any": {
            let best = 0;
            for (const id of Object.keys(MASTERY.LINES)) best = Math.max(best, MasteryManager.getLevel(player, id) || 0);
            return best;
        }
        case "chorus_set": {
            const { sets } = ChorusManager.getPlayerSets(player);
            return sets.reduce((n, s) => Math.max(n, s.count || 0), 0);
        }
        default: return 0;
    }
}

function met(player, e, c) {
    try {
        switch (c.t) {
            case "state":   return stateValue(player, c.k) >= (c.min ?? 1);
            case "counter": return (AchievementManager.counter(player, c.k) || 0) >= (c.min ?? 1);
            case "flag":    return e.flags.has(c.k);
            case "item": {
                let n = 0;
                for (const id of c.ids) { n += GemManager.countItem(player, id); if (n >= (c.min ?? 1)) return true; }
                return n >= (c.min ?? 1);
            }
            default: return false;
        }
    } catch (_) { return false; }
}

// An item / flag step is also done when a LATER step (not a plain level step, not an item scan) is already met:
// veterans are never asked to "craft X" for something they obviously already used.
function laterProof(player, e, step) {
    for (let i = indexById.get(step.id) + 1; i < GQ_STEPS.length; i++) {
        const c = GQ_STEPS[i].c;
        if (c.t === "item" || (c.t === "state" && c.k === "level_ever")) continue;
        if (met(player, e, c)) return true;
    }
    return false;
}

function stepMet(player, e, step) {
    if (met(player, e, step.c)) return true;
    return (step.c.t === "item" || step.c.t === "flag") && laterProof(player, e, step);
}

// ---------------------------------------------------------------- queries
const isL = (player) => { try { return SettingsManager.get(player, "gq_thai") ? "th" : "en"; } catch (_) { return "en"; } };

function currentStep(e) { return required.find((s) => !e.done.has(s.id)) ?? null; }

function chapterSteps(chId) { return GQ_STEPS.filter((s) => s.ch === chId); }

// ---------------------------------------------------------------- notifications
function notifyOn(player) { try { return GUIDE.ENABLED >= 1 && SettingsManager.get(player, "gq_notify"); } catch (_) { return false; } }

function say(player, header, body, frame, chatLine, sound) {
    if (!notifyOn(player)) return;
    try {
        if (ToastManager.isActive(player)) ToastManager.show(player, { frame, icon: "----", header, body, sound });
        else { player.sendMessage(chatLine); if (sound) player.playSound(sound); }
    } catch (_) { /* player left */ }
}

function announce(player, e, completedSteps, wasQuiet) {
    if (!completedSteps.length) return;
    const lang = isL(player);
    const L = (o) => o[lang] ?? o.en;
    const next = currentStep(e);
    const questDone = !next;
    if (completedSteps.length === 1 && !wasQuiet) {
        const s = completedSteps[0];
        say(player, "Guide Quest - Step Done", `§a${L(s.title)}`, "blue",
            `§a[Guide Quest] §f✔ ${s.id} ${L(s.title)}`, "random.levelup");
        const chDone = required.filter((x) => x.ch === s.ch).every((x) => e.done.has(x.id));
        if (chDone && !questDone) {
            const ch = GQ_CHAPTERS.find((c) => c.id === s.ch);
            say(player, `Guide Quest - Chapter ${s.ch}`, `§6${L(ch.name)} ✔`, "gold",
                `§6[Guide Quest] §fChapter ${s.ch} complete: ${L(ch.name)}`, "random.levelup");
        }
    } else if (completedSteps.length > 1) {
        const txt = lang === "th" ? `ข้ามขั้นที่ทำแล้ว ${completedSteps.length} ขั้น` : `${completedSteps.length} steps already done`;
        say(player, "Guide Quest - Caught up", `§a${txt}`, "blue", `§a[Guide Quest] §f${txt}`, "random.levelup");
    }
    if (questDone) {
        const txt = lang === "th" ? "จบ Guide Quest แล้ว!" : "You finished the Guide Quest!";
        say(player, "Guide Quest Complete", `§d${txt}`, "platinum", `§d[Guide Quest] §f${txt}`, "random.levelup");
    } else if (GUIDE.NOTIFY_NEXT >= 1) {
        say(player, "Guide Quest - Next", `§e${L(next.title)}`, "yellow",
            `§e[Guide Quest] §fNext: ${next.id} ${L(next.title)} §8(Script Tool > Guides & Items)`, null);
    }
}

// ---------------------------------------------------------------- engine
function evaluate(player, { quiet = false } = {}) {
    if (GUIDE.ENABLED < 1 || !player?.isValid) return [];
    const e = entry(player);
    const completed = [];
    for (let guard = 0; guard < GUIDE.MAX_CATCHUP_STEPS; guard++) {
        const cur = currentStep(e);
        if (!cur || !stepMet(player, e, cur)) break;
        e.done.add(cur.id);
        completed.push(cur);
    }
    // side tasks of the chapters reached so far complete whenever their condition is true
    const cur = currentStep(e);
    const lastCh = cur ? cur.ch : GQ_CHAPTERS.length;
    for (const s of GQ_STEPS) {
        if (!s.optional || s.ch > lastCh || e.done.has(s.id)) continue;
        if (met(player, e, s.c)) { e.done.add(s.id); completed.push(s); }
    }
    if (completed.length) {
        saveDone(player, e);
        announce(player, e, completed, quiet);
    }
    return completed;
}

function onJoinWelcome(player) {
    const e = entry(player);
    if (e.flags.has("welcomed")) return;
    e.flags.add("welcomed"); saveFlags(player, e);
    if (GUIDE.WELCOME < 1 || currentStep(e) == null) return;
    const lang = isL(player);
    say(player, "Guide Quest Started", lang === "th" ? "§eดูได้ที่ Script Tool" : "§eOpen: Script Tool", "yellow",
        "§e[Guide Quest] §fA step-by-step guide is waiting: Script Tool > Guides & Items > Guide Quest.", "random.toast");
}

export const GuideQuest = {
    steps: GQ_STEPS,
    chapters: GQ_CHAPTERS,
    requiredCount: required.length,

    register() {
        Scheduler.every("guide_quest", Math.max(5, GUIDE.CHECK_INTERVAL_TICKS), () => {
            if (GUIDE.ENABLED < 1) return;
            for (const player of world.getAllPlayers()) Logger.guard("guide quest check", () => evaluate(player));
        });
    },

    // Hooks (menus / one-time actions)
    onMenu(player, menuId) { this.flag(player, `menu:${menuId}`); },
    flag(player, key) {
        try {
            const e = entry(player);
            if (e.flags.has(key)) return;
            e.flags.add(key); saveFlags(player, e);
        } catch (_) { /* player gone */ }
    },
    onPlayerSpawn(player) {
        system.runTimeout(() => Logger.guard("guide quest welcome", () => {
            if (!player?.isValid) return;
            onJoinWelcome(player);
            evaluate(player);
        }), 100);
    },
    onPlayerLeave(playerId) { cache.delete(playerId); },

    // Queries for the GUI
    lang: isL,
    isDone(player, id) { return entry(player).done.has(id); },
    current(player) { return currentStep(entry(player)); },
    doneCount(player) { const e = entry(player); return required.filter((s) => e.done.has(s.id)).length; },
    chapterProgress(player, chId) {
        const e = entry(player);
        const req = required.filter((s) => s.ch === chId);
        return { done: req.filter((s) => e.done.has(s.id)).length, total: req.length };
    },
    chapterSteps,
    isComplete(player) { return currentStep(entry(player)) == null; },
    check(player) { return evaluate(player); },
};

// ---------------------------------------------------------------- Admin (status:admin quest ...)
const ok = (text) => ({ ok: true, text: `§a[Admin] §f${text}` });
const bad = (text) => ({ ok: false, text: `§c[Admin] ${text}` });

export const GuideQuestAdmin = {
    info(t) {
        const e = entry(t);
        const cur = currentStep(e);
        return ok(`Guide Quest ${t.name}: ${GuideQuest.doneCount(t)}/${required.length} steps (${e.done.size} incl. side tasks). ` +
            (cur ? `Current: ${cur.id} ${cur.title.en}` : "Quest complete."));
    },
    skip(player, t) {
        const e = entry(t);
        const cur = currentStep(e);
        if (!cur) return bad("Quest is already complete.");
        e.done.add(cur.id); saveDone(t, e);
        return ok(`${t.name}: skipped ${cur.id} ${cur.title.en}.`);
    },
    set(player, t, id) {
        if (String(id).toLowerCase() === "start") return this.reset(player, t);
        const target = stepById.get(String(id));
        if (!target) return bad(`Unknown step "${id}". Use ids like 1.1 ... 8.7, or "start".`);
        const e = entry(t);
        const idx = indexById.get(target.id);
        e.done = new Set(GQ_STEPS.filter((s, i) => i < idx).map((s) => s.id));
        saveDone(t, e);
        return ok(`${t.name}: steps before ${target.id} marked done; ${target.id} is now the current step.`);
    },
    complete(player, t) {
        const e = entry(t);
        e.done = new Set(GQ_STEPS.map((s) => s.id)); saveDone(t, e);
        return ok(`${t.name}: Guide Quest marked complete.`);
    },
    reset(player, t) {
        const e = entry(t);
        e.done = new Set(); e.flags = new Set(); saveDone(t, e); saveFlags(t, e);
        return ok(`${t.name}: Guide Quest progress reset.`);
    },
};
