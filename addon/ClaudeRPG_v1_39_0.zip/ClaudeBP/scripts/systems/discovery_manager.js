// discovery_manager.js -- Discovery Log (per-player record of biomes, structures and dimensions found).
//
// Storage : player dynamic property "crpg:disc" = { b: [biomeIds], s: [structureIds], d: [dimIds] }  (never reset by Prestige)
// Biomes  : read with Dimension.getBiome when the API exists (feature-detected; see probe()).
// Structs : no structure API -> signature blocks near the player, scanned with Dimension.getBlocks when it exists.
// XP      : the first find of each entry gives one-time Travel Mastery XP (only if the Travel line is unlocked).
// Creative / Spectator players are not tracked.

import { GameMode, BlockVolume } from "@minecraft/server";
import { DISCOVERY, BIOME_CATALOG, STRUCTURE_CATALOG, DIMENSION_CATALOG } from "../config/exploration_config.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { Logger } from "../core/logger.js";
import { ToastManager } from "./toast_manager.js";
import { SettingsManager } from "./settings_manager.js";

const KEY = "crpg:disc";
const cache = new Map();        // playerId -> { data, dirty }
const runtime = new Map();      // playerId -> { biome, lastScan:{x,y,z,dim}, scanning }
let tickCount = 0;

const stripNs = (id) => String(id ?? "").replace("minecraft:", "");
const dimKey = (dimension) => stripNs(dimension?.id);

function prettify(id) { return stripNs(id).split("_").map((w) => w ? w[0].toUpperCase() + w.slice(1) : w).join(" "); }

const BIOME_NAMES = new Map(Object.values(BIOME_CATALOG).flat());

function entry(player) {
    let e = cache.get(player.id);
    if (!e) {
        let data = { b: [], s: [], d: [] };
        try {
            const raw = player.getDynamicProperty(KEY);
            if (typeof raw === "string" && raw) {
                const p = JSON.parse(raw);
                data = { b: Array.isArray(p.b) ? p.b : [], s: Array.isArray(p.s) ? p.s : [], d: Array.isArray(p.d) ? p.d : [] };
            }
        } catch (_) { /* fresh */ }
        e = { data, dirty: false };
        cache.set(player.id, e);
    }
    return e;
}

function flush(player, e) {
    try { player.setDynamicProperty(KEY, JSON.stringify(e.data)); e.dirty = false; }
    catch (error) { Logger.warn(`Discovery save failed: ${error}`); }
}

function counts(arr) { return Array.isArray(arr) ? arr.length : 0; }

function canTrack(player) {
    if (DISCOVERY.ENABLED < 1 || !player?.isValid) return false;
    try {
        const gm = player.getGameMode();
        return gm !== GameMode.Creative && gm !== GameMode.Spectator;
    } catch (_) { return false; }
}

function announce(player, kind, name, xp) {
    try {
        if (ToastManager.isActive(player)) {
            const icon = kind === "biome" ? "TBIO" : kind === "structure" ? "TSTR" : "TDIM";
            const title = kind === "dimension" ? "New Dimension" : kind === "structure" ? "New Structure" : "New Biome";
            ToastManager.show(player, { frame: "discovery", icon, header: title + (xp > 0 ? ` +${xp} XP` : ""), body: `§f${name}`, sound: "random.levelup", volume: 0.4 });
            return;
        }
        if (SettingsManager.get(player, "disc_chat")) player.sendMessage(`§b[Discovery] §fNew ${kind}: §e${name}` + (xp > 0 ? ` §7(+${xp} Travel XP)` : ""));
        if (SettingsManager.get(player, "disc_actionbar")) player.onScreenDisplay.setActionBar(`§bDiscovered: §e${name}`);
        player.playSound("random.levelup", { volume: 0.4 });
    } catch (_) { /* player left */ }
}

function grantXp(player, amount) {
    if (!(amount > 0)) return 0;
    try { return MasteryManager.addXp(player, "travel", amount) ? amount : 0; } catch (_) { return 0; }
}

export const DiscoveryManager = {
    catalog: { BIOME_CATALOG, STRUCTURE_CATALOG, DIMENSION_CATALOG },

    // ---------- reading ----------
    has(player, kind, id) {
        const e = entry(player);
        return (kind === "biome" ? e.data.b : kind === "structure" ? e.data.s : e.data.d).includes(id);
    },
    list(player, kind) { const e = entry(player); return [...(kind === "biome" ? e.data.b : kind === "structure" ? e.data.s : e.data.d)]; },
    biomeName(id) { return BIOME_NAMES.get(stripNs(id)) ?? prettify(id); },
    biomeIsCatalogued(id) { return BIOME_NAMES.has(stripNs(id)); },

    // [{ id, name, found }] for the checklist screens.
    checklist(player, section) {
        const found = new Set(this.list(player, section === "structures" ? "structure" : section === "dimensions" ? "dimension" : "biome"));
        if (section === "structures") return STRUCTURE_CATALOG.map((s) => ({ id: s.id, name: s.name, found: found.has(s.id), dim: s.dim }));
        if (section === "dimensions") return DIMENSION_CATALOG.map((d) => ({ id: d.id, name: d.name, found: found.has(d.id) }));
        if (section === "other") return [...found].filter((id) => !BIOME_NAMES.has(id)).map((id) => ({ id, name: prettify(id), found: true }));
        return (BIOME_CATALOG[section] ?? []).map(([id, name]) => ({ id, name, found: found.has(id) }));
    },

    totals(player) {
        const e = entry(player);
        const biomeTotal = Object.values(BIOME_CATALOG).reduce((n, l) => n + l.length, 0);
        const biomeFound = e.data.b.filter((id) => BIOME_NAMES.has(id)).length;
        return {
            biomeFound, biomeTotal,
            other: e.data.b.length - biomeFound,
            structureFound: e.data.s.length, structureTotal: STRUCTURE_CATALOG.length,
            dimFound: e.data.d.length, dimTotal: DIMENSION_CATALOG.length,
        };
    },

    // ---------- recording (also used by Admin tools) ----------
    record(player, kind, id, { silent = false } = {}) {
        const e = entry(player);
        const arr = kind === "biome" ? e.data.b : kind === "structure" ? e.data.s : e.data.d;
        if (arr.includes(id)) return false;
        arr.push(id);
        e.dirty = true;
        let name, label, xpBase;
        if (kind === "biome") {
            name = this.biomeName(id); label = "biome";
            xpBase = BIOME_NAMES.has(id) ? DISCOVERY.XP_BIOME : DISCOVERY.XP_OTHER_BIOME;
        } else if (kind === "structure") {
            name = STRUCTURE_CATALOG.find((s) => s.id === id)?.name ?? prettify(id); label = "structure"; xpBase = DISCOVERY.XP_STRUCTURE;
        } else {
            name = DIMENSION_CATALOG.find((d) => d.id === id)?.name ?? prettify(id); label = "dimension";
            xpBase = id === "overworld" ? 0 : DISCOVERY.XP_DIMENSION;     // you start in the Overworld: no XP
        }
        const xp = silent ? 0 : grantXp(player, xpBase);
        flush(player, e);   // finds are rare, so write at once
        if (!silent) announce(player, label, name, xp);
        return true;
    },

    adminClear(player) { cache.set(player.id, { data: { b: [], s: [], d: [] }, dirty: true }); flush(player, cache.get(player.id)); },

    // ---------- API probe (Admin: status:admin disc probe) ----------
    probe(player) {
        const dim = player.dimension;
        let biome = "n/a";
        try { biome = typeof dim.getBiome === "function" ? stripNs(dim.getBiome(player.location)?.id) : "Dimension.getBiome is NOT available"; }
        catch (error) { biome = `getBiome threw: ${error}`; }
        return {
            biomeApi: typeof dim.getBiome === "function",
            blocksApi: typeof dim.getBlocks === "function",
            biome,
        };
    },

    // ---------- scanning ----------
    readBiome(player) {
        const dim = player.dimension;
        if (typeof dim.getBiome !== "function") return null;
        try { return stripNs(dim.getBiome(player.location)?.id) || null; } catch (_) { return null; }
    },

    scanStructures(player, rt) {
        const dim = player.dimension;
        if (typeof dim.getBlocks !== "function") return;
        const here = dimKey(dim), loc = player.location;
        const last = rt.lastScan;
        if (last && last.dim === here && Math.hypot(loc.x - last.x, loc.z - last.z) < DISCOVERY.STRUCTURE_MIN_MOVE && Math.abs(loc.y - last.y) < DISCOVERY.STRUCTURE_MIN_MOVE) return;
        rt.lastScan = { x: loc.x, y: loc.y, z: loc.z, dim: here };

        const pending = STRUCTURE_CATALOG.filter((s) => s.dim === here && !this.has(player, "structure", s.id));
        if (!pending.length) return;
        const r = DISCOVERY.SCAN_RADIUS;
        const from = { x: Math.floor(loc.x) - r, y: Math.floor(loc.y) - DISCOVERY.SCAN_DOWN, z: Math.floor(loc.z) - r };
        const to   = { x: Math.floor(loc.x) + r, y: Math.floor(loc.y) + DISCOVERY.SCAN_UP,   z: Math.floor(loc.z) + r };
        let volume;
        try { volume = new BlockVolume(from, to); } catch (_) { return; }
        for (const s of pending) {
            try {
                const hits = dim.getBlocks(volume, { includeTypes: s.blocks }, false);
                let n = 0;
                if (typeof hits?.getCapacity === "function") n = hits.getCapacity();
                else if (typeof hits?.getBlockLocationIterator === "function") { for (const _ of hits.getBlockLocationIterator()) { if (++n >= s.min) break; } }
                if (n >= s.min) this.record(player, "structure", s.id);
            } catch (_) { /* unloaded chunk or filter refused: try again next scan */ }
        }
    },

    tickPlayer(player, doStructures) {
        if (!canTrack(player)) return;
        const rt = runtime.get(player.id) ?? {};
        runtime.set(player.id, rt);
        const dim = dimKey(player.dimension);
        this.record(player, "dimension", dim);

        const biome = this.readBiome(player);
        if (biome && biome !== rt.biome) {
            rt.biome = biome;
            this.record(player, "biome", biome);
        }
        if (doStructures) this.scanStructures(player, rt);
    },

    // One shared 20-tick job (the biome check runs every BIOME_INTERVAL_TICKS, the scan every STRUCTURE_INTERVAL_TICKS).
    tick(players) {
        tickCount += 20;
        const doBiome = tickCount % Math.max(20, DISCOVERY.BIOME_INTERVAL_TICKS) < 20;
        const doStruct = tickCount % Math.max(20, DISCOVERY.STRUCTURE_INTERVAL_TICKS) < 20;
        if (!doBiome && !doStruct) return;
        for (const p of players) {
            try { this.tickPlayer(p, doStruct); } catch (error) { Logger.warn(`Discovery tick failed: ${error}`); }
        }
    },

    onPlayerLeave(playerId) {
        const e = cache.get(playerId);
        cache.delete(playerId);
        runtime.delete(playerId);
        // entries are written at once on every find, so nothing is lost here
        void e;
    },
};
