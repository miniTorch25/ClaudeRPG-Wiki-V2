// prestige_gui.js -- Prestige menu: overview, Prestige confirm, Perk pick, Perk list.
// Back navigation uses callbacks so this file never imports the menus that open it.

import { ActionFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { PrestigeManager } from "../managers/prestige_manager.js";
import { PRESTIGE, PROGRESSION } from "../config/progression_config.js";
import { CostManager } from "../managers/cost_manager.js";
import { onMenuOpened } from "./achievement_hooks.js";

const SCREEN = "systems.prestige_gui.js";

function pct(n) { return Math.round(n * 100); }

export const PrestigeGui = {

    openMenu(player, onBack = null) {
        onMenuOpened(player, "prestige");
        const prestige = ProgressionManager.getPrestige(player);
        const level    = ProgressionManager.getLevel(player);
        const maxLevel = ProgressionManager.getMaxLevel(player);
        const pending  = ProgressionManager.getPendingPerks(player);
        const atMax    = level >= maxLevel;

        const capNow  = Math.round(ProgressionManager.getStatCapMultiplier(player) * 100);
        const nextMult = 1 + PRESTIGE.LIMIT_BREAK_STEP * ProgressionManager.limitBreakUnits(prestige + 1);
        const capNext = Math.round(nextMult * 100);

        const cost = CostManager.prestigeStatus(player, prestige);
        const costLine = `${cost.ok ? "§a" : "§c"}${cost.need} ${cost.name} §8(you have ${cost.have})`;

        const body =
            `§7Prestige: §f${prestige}\n` +
            `§7Level: §f${level} §8/ ${maxLevel}\n` +
            `§7Stat caps: §f${capNow}% §8→ §a${capNext}% §7after next Prestige\n` +
            `§7Next Max Level: §f${maxLevel + PROGRESSION.MAX_LEVEL_PER_PRESTIGE}\n` +
            `§7Cost: ${costLine}\n\n` +
            (atMax ? "§aYou are at Max Level — you can Prestige." : `§8Reach Level ${maxLevel} to Prestige.`) +
            (pending > 0 ? `\n§6Unspent Perk picks: ${pending}` : "");

        const form = new ActionFormData().title("§l§6PRESTIGE").body(body);
        const actions = [];
        if (pending > 0) { form.button(`§6Choose Perk\n§8[${pending} pick(s) waiting]`, "textures/icons/blue_up_arrow"); actions.push("perk"); }
        form.button(atMax ? "§aPrestige\n§8[Resets Level, Stats, Points]" : "§8Prestige §c[Locked]\n§8Reach Max Level", "textures/icons/prestige"); actions.push("prestige");
        form.button("§bMy Perks\n§8[Owned bonuses]", "textures/icons/blue_stats"); actions.push("list");
        form.button("§8< Back", "textures/icons/back"); actions.push("back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            switch (actions[r.selection]) {
                case "perk": this.openPerkPick(player, onBack); break;
                case "prestige":
                    if (!PrestigeManager.canPrestige(player)) {
                        player.sendMessage(`§c[Prestige] Reach Max Level (Lv.${maxLevel}) first.`);
                        return this.openMenu(player, onBack);
                    }
                    {
                        const st = CostManager.prestigeStatus(player, prestige);
                        if (!st.ok) {
                            player.sendMessage(`§c[Prestige] You need ${st.need} ${st.name} (you have ${st.have}).`);
                            return this.openMenu(player, onBack);
                        }
                    }
                    this.openConfirm(player, onBack);
                    break;
                case "list": this.openPerkList(player, onBack); break;
                case "back": if (onBack) onBack(); break;
            }
        }).catch((e) => console.warn(`[Prestige] Menu error: ${e}`));
    },

    openConfirm(player, onBack) {
        const next = ProgressionManager.getPrestige(player) + 1;
        const cst = CostManager.prestigeStatus(player, next - 1);
        const form = new ActionFormData()
            .title("§l§6Confirm Prestige")
            .body(
                `§fPrestige §e${next}\n\n` +
                "§cResets:§7 Level, XP, Points and ALL stat allocations (back to 0).\n\n" +
                "§aKeeps:§7 unlocked systems (Augment, Chorus, Gem, Rune), items and their sockets/Runes/Gems/Elements, earned Perks.\n\n" +
                `§aGains:§7 Max Level +${PROGRESSION.MAX_LEVEL_PER_PRESTIGE}, higher stat caps, and 1 Perk pick.\n\n` +
                `§eCost:§7 ${cst.need} ${cst.name} §8(consumed)`
            )
            .button("§aPrestige now", "textures/icons/prestige")
            .button("§8Cancel", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === 1) return this.openMenu(player, onBack);
            const result = PrestigeManager.perform(player);
            if (!result.success) {
                player.sendMessage(result.reason === "cost"
                    ? `§c[Prestige] You need ${result.need} ${result.name} (you have ${result.have}).`
                    : "§c[Prestige] You must be at Max Level.");
                return this.openMenu(player, onBack);
            }
            this.openPerkPick(player, onBack);
        }).catch((e) => console.warn(`[Prestige] Confirm error: ${e}`));
    },

    openPerkPick(player, onBack) {
        if (ProgressionManager.getPendingPerks(player) <= 0) return this.openMenu(player, onBack);
        const ids = ProgressionManager.getAvailablePerks(player);
        const form = new ActionFormData()
            .title("§l§6Choose a Perk")
            .body(`§7Pick 1 permanent bonus. Perks may be picked again.\n§8Power shown is what you get now (weakens after Prestige ${PRESTIGE.FULL_UNTIL}).`);
        for (const id of ids) {
            const def = PRESTIGE.PERKS[id];
            const v = ProgressionManager.getNextPerkValue(player, id);
            const owned = ProgressionManager.getPerkCount(player, id);
            form.button(`§e${def.name}\n§8${ProgressionManager.describePerk(id, v)}${owned ? ` (owned x${owned})` : ""}`);
        }
        form.button("§8Later", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === ids.length) return this.openMenu(player, onBack);
            const id = ids[r.selection];
            if (PrestigeManager.choosePerk(player, id)) {
                player.sendMessage(`§6[Prestige] Perk gained: §e${PRESTIGE.PERKS[id].name}`);
                player.playSound("random.levelup");
            }
            this.openMenu(player, onBack);
        }).catch((e) => console.warn(`[Prestige] Perk pick error: ${e}`));
    },

    openPerkList(player, onBack) {
        const lines = [];
        for (const [id, def] of Object.entries(PRESTIGE.PERKS)) {
            const count = ProgressionManager.getPerkCount(player, id);
            if (!count) continue;
            lines.push(`§e${def.name} §8x${count}§7: ${ProgressionManager.describePerk(id, ProgressionManager.getPerkValue(player, id))}`);
        }
        const form = new ActionFormData()
            .title("§l§bMy Perks")
            .body(lines.length ? lines.join("\n") : "§7No Perks yet. Each Prestige grants one pick.")
            .button("§8< Back", "textures/icons/back");
        GuiService.show(player, form, SCREEN).then(() => this.openMenu(player, onBack))
            .catch((e) => console.warn(`[Prestige] Perk list error: ${e}`));
    },
};
