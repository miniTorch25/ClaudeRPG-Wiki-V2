import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { LOOT_BONUS } from "../config/loot_bonus_config.js";

// Reads vanilla Fortune/Looting from the mainhand item and applies them to script-made drops.
export const LootBonus = {

    enchantLevel(entity, enchantId) {
        try {
            const item = entity?.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand);
            return item?.getComponent("minecraft:enchantable")?.getEnchantment(enchantId)?.level ?? 0;
        } catch (_) { return 0; }
    },

    lootingLevel(entity) { return this.enchantLevel(entity, "looting"); },
    fortuneLevel(entity) { return this.enchantLevel(entity, "fortune"); },

    // chance is 0..1. applyKey is an APPLY_* name from LOOT_BONUS (set to 0 to turn Looting off for it).
    scaleChance(chance, lootingLevel, applyKey) {
        if (!(lootingLevel > 0) || !LOOT_BONUS[applyKey]) return chance;
        const scaled = chance * (1 + LOOT_BONUS.LOOTING_CHANCE_PER_LEVEL * lootingLevel);
        return Math.min(scaled, Math.max(chance, LOOT_BONUS.LOOTING_MAX_CHANCE));
    },

    // Random extra items from Looting, added on top of a rolled count.
    extraCount(lootingLevel, applyKey) {
        if (!(lootingLevel > 0) || !LOOT_BONUS[applyKey]) return 0;
        return Math.floor(Math.random() * (lootingLevel * LOOT_BONUS.LOOTING_COUNT_PER_LEVEL + 1));
    },

    // Vanilla ore Fortune: count x max(1, random 0..level+1).
    fortuneMultiplier(fortuneLevel) {
        if (!(fortuneLevel > 0)) return 1;
        return Math.max(1, Math.floor(Math.random() * (fortuneLevel + 2)));
    }
};
