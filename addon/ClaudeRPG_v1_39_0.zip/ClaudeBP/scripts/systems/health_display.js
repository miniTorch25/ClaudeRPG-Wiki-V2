// health_display.js -- wires the HP name tag system into the real world / MobHpManager / mob_config.
import { world, system } from "@minecraft/server";
import { MOB_CONFIG, isBoss } from "../config/mob_config.js";
import { MobHpManager } from "../managers/mob_hp_manager.js";
import { createHealthDisplay } from "./health_display_core.js";

export const HealthDisplay = createHealthDisplay({
    getPool: (entity) => MobHpManager.peekPool(entity),
    isBossType: isBoss,
    bossTypes: Object.keys(MOB_CONFIG).filter(isBoss),
    getEntityById: (id) => { try { return world.getEntity(id); } catch (_) { return undefined; } },
    getTick: () => system.currentTick,
});
