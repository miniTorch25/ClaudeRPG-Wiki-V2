// waypoint_gui.js -- screens for the Waypoint Stone, Waypoint Stone (Blank) and Waypoint Orb.
//
//   Stone : Teleport / Edit (rename, owner + Admin) / Manager (Player, Waystone)
//   Blank : Teleport / Manager (Waystone)
//   Orb   : Teleport / Manager (Waystone) / Edit (Add, Rename, Remove special points)
//   Script Tool > Waypoints : Waystone manager only (sort / remove from anywhere)
//
// ctx = { type: "stone" | "blank" | "orb" | "tool", wp? }  -- remembers which screen to come back to.
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";
import { system, GameMode } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { WAYPOINT } from "../config/exploration_config.js";
import { WaypointManager } from "./waypoint_manager.js";
import { CostManager } from "../managers/cost_manager.js";

const SCREEN = "systems.waypoint_gui.js";
const ICON = "textures/icons/waypoint";
const BACK = "textures/icons/back";
const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

const ok = (player, text) => { try { player.sendMessage(`§b[Waypoint] §f${text}`); } catch (_) {} };
const bad = (player, text) => { try { player.sendMessage(`§c[Waypoint] ${text}`); } catch (_) {} };
const show = (player, form) => GuiService.show(player, form, SCREEN);
const fail = (e) => console.warn(`[Waypoint] ${e}`);
const placeText = (p) => `${WaypointManager.dimLabel(p.dim)} ${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)}`;

const prompting = new Set();   // stone ids that currently have a naming form in progress

export const WaypointGui = {
    // ═══ entry points ═══════════════════════════════════════════════════

    // Right-click on a named Waypoint Stone.
    openStone(player, block) {
        if (!WaypointManager.isEnabled()) return bad(player, "Waypoint Stones are turned off.");
        let wp = WaypointManager.findAt(block.dimension, block.location);
        if (!wp) {   // a stone nobody registered (command / creative): the first player to click claims it
            wp = WaypointManager.register(block.dimension, block.location, player);
            return this.promptName(player, wp.id);
        }
        if (wp.legacyUnnamed) {   // old unnamed stone: remove it
            try { block.setType("minecraft:air"); } catch (_) {}
            WaypointManager.unregister(wp.id);
            return bad(player, "That old, unnamed Waypoint Stone was removed.");
        }
        if (wp.pending) {
            if (wp.owner === player.id) return this.promptName(player, wp.id);
            return bad(player, `${wp.ownerName} has not named this stone yet.`);
        }
        const ctx = { type: "stone", wp };
        if (WaypointManager.isSaved(player, wp.id)) return this.openMain(player, ctx);

        const form = new MessageFormData()
            .title("§l§bSAVE THIS STONE?")
            .body(`§f${wp.name}\n§7Owner: ${wp.ownerName}\n§7${placeText(wp)}\n\n§fSave it to your list so you can travel here from any Waypoint Stone or Orb?\n§7Saved: ${WaypointManager.knownIds(player).length}/${WAYPOINT.SAVED_MAX}`)
            .button1("§aSave").button2("§8Not now");
        show(player, form).then((res) => {
            if (res.canceled) return;
            if (res.selection === 0) {
                const r = WaypointManager.save(player, wp.id);
                if (r === "ok") { ok(player, `Saved "${wp.name}".`); try { player.playSound("random.orb"); } catch (_) {} }
                else if (r === "full") bad(player, `Your list is full (${WAYPOINT.SAVED_MAX}/${WAYPOINT.SAVED_MAX}). Remove a stone in Manager first.`);
                else if (r === "missing") return bad(player, "That stone no longer exists.");
            }
            this.openMain(player, ctx);
        }).catch(fail);
    },

    // Right-click on a Blank stone.
    openBlank(player) {
        if (!WaypointManager.isEnabled()) return bad(player, "Waypoint Stones are turned off.");
        this.openMain(player, { type: "blank" });
    },

    // Using the Waypoint Orb.
    openOrb(player) {
        if (!WaypointManager.isEnabled()) return bad(player, "Waypoint travel is turned off.");
        this.openMain(player, { type: "orb" });
    },

    // Script Tool > Waypoints.
    openManage(player) { this.openWaystone(player, { type: "tool" }); },

    // ═══ naming (forced) ════════════════════════════════════════════════

    // The placer cannot skip this: closing the form opens it again; a busy screen is retried.
    promptName(player, id) {
        if (prompting.has(id)) return;
        prompting.add(id);
        const done = () => prompting.delete(id);
        const attempt = () => {
            const wp = WaypointManager.get(id);
            if (!wp || !wp.pending || !player?.isValid) return done();
            const retry = (ticks) => system.runTimeout(attempt, ticks);
            const form = new ModalFormData()
                .title("§l§bNAME YOUR WAYPOINT")
                .textField(`Every Waypoint Stone needs a name (max ${WAYPOINT.NAME_MAX} characters)`, "e.g. Home base");
            GuiService.show(player, form, SCREEN).then((res) => {
                const still = WaypointManager.get(id);
                if (!still || !still.pending || !player?.isValid) return done();
                if (res.blocked) return retry(20);
                if (res.canceled) {
                    if (res.cancelationReason === "UserBusy") return retry(20);
                    bad(player, "You must name this Waypoint Stone.");
                    return retry(10);
                }
                const named = WaypointManager.finalizeName(player, id, res.formValues?.[0]);
                if (!named) { bad(player, "Please type a name."); return retry(10); }
                done();
                ok(player, `Named "${named.name}" and saved to your list.`);
                try { player.playSound("random.levelup"); } catch (_) {}
            }).catch((e) => { fail(e); retry(40); });
        };
        attempt();
    },

    // Called every few seconds: a placer who left before naming is asked again when they are back.
    checkPending(player) {
        if (GuiService.isOpen(player)) return;
        for (const wp of WaypointManager.pendingOf(player.id)) { this.promptName(player, wp.id); break; }
    },

    // ═══ main menu ══════════════════════════════════════════════════════
    openMain(player, ctx) {
        const wp = ctx.wp ? WaypointManager.get(ctx.wp.id) ?? ctx.wp : null;
        const pearls = CostManager.count(player, WAYPOINT.COST_ITEM);
        const saved = `${WaypointManager.knownIds(player).length}/${WAYPOINT.SAVED_MAX}`;
        const entries = [];
        const form = new ActionFormData();
        let head;
        if (ctx.type === "stone") {
            head = `§f${wp.name}\n§7Owner: ${wp.ownerName}`;
            form.title("§l§bWAYPOINT STONE");
        } else if (ctx.type === "blank") {
            head = "§7Travel only. This stone has no name.";
            form.title("§l§bWAYPOINT STONE §8(Blank)");
        } else {
            head = `§7Special points: ${WaypointManager.specials(player).length}/${WAYPOINT.SPECIAL_MAX}`;
            form.title("§l§dWAYPOINT ORB");
        }
        form.body(`${head}\n§7Saved: §f${saved}§7   ${WAYPOINT.COST_NAME}s: §f${pearls}`);

        form.button("§bTeleport\n§8[Your saved places]", ICON); entries.push(() => this.openTravel(player, ctx));
        if (ctx.type === "stone" && WaypointManager.canManage(player, wp)) {
            form.button("§eEdit\n§8[Rename this stone]", "textures/icons/gear"); entries.push(() => this.openRename(player, ctx));
        }
        form.button("§6Manager\n§8[Sort, remove]", "textures/icons/gear"); entries.push(() => this.openManager(player, ctx));
        if (ctx.type === "orb") {
            form.button("§dEdit\n§8[Special points]", "textures/icons/blue_plus"); entries.push(() => this.openOrbEdit(player, ctx));
        }
        form.button("§8Close", BACK);

        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            entries[res.selection]?.();
        }).catch(fail);
    },

    // ═══ teleport ═══════════════════════════════════════════════════════
    travelRows(player, ctx) {
        const rows = [];
        if (ctx.type === "orb") {
            WaypointManager.specials(player).forEach((p, i) => rows.push({ kind: "special", index: i, name: p.name, where: placeText(p) }));
        }
        for (const w of WaypointManager.known(player)) {
            if (ctx.type === "stone" && ctx.wp && w.id === ctx.wp.id) continue;
            rows.push({ kind: "stone", wp: w, name: w.name });
        }
        return rows;
    },

    openTravel(player, ctx) {
        const creative = player.getGameMode() === GameMode.Creative;
        const rows = this.travelRows(player, ctx);
        const form = new ActionFormData().title("§l§bTELEPORT");
        form.body(rows.length ? "§7Pick a destination." : "§7Nothing saved yet. Right-click a Waypoint Stone to save it.");
        for (const r of rows) {
            if (r.kind === "special") {
                form.button(`§d★ ${r.name}\n§8${r.where} · free`, ICON);
            } else if (r.wp.broken) {
                form.button(`§c${r.name}\n§8Destroyed · cannot travel`, ICON);
            } else {
                const sameDim = player.dimension.id.replace("minecraft:", "") === r.wp.dim;
                const dist = sameDim ? `${Math.round(WaypointManager.horizontalDistance(player, r.wp))}m` : WaypointManager.dimLabel(r.wp.dim);
                const cost = WaypointManager.cost(player, r.wp);
                form.button(`§b${r.name}\n§8${dist} · ${creative ? "free" : plural(cost, WAYPOINT.COST_NAME)}`, ICON);
            }
        }
        form.button("§8Back", BACK);

        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection >= rows.length) return this.back(player, ctx);
            this.confirmTravel(player, ctx, rows[res.selection], creative);
        }).catch(fail);
    },

    confirmTravel(player, ctx, r, creative) {
        if (r.kind === "stone" && r.wp.broken) {
            return bad(player, `"${r.name}" was destroyed, so you cannot travel there. Remove it in Manager when you like.`);
        }
        let body;
        if (r.kind === "special") body = `§fTravel to §d${r.name}§f?\n§7${r.where}\n§7Free. Cooldown ${WAYPOINT.SPECIAL_COOLDOWN_SEC}s.`;
        else {
            const cost = WaypointManager.cost(player, r.wp);
            body = `§fTravel to §b${r.name}§f?\n§7${placeText(r.wp)}\n§7${creative ? "Creative: free." : `Cost: §f${plural(cost, WAYPOINT.COST_NAME)}`}  §7Cooldown ${WAYPOINT.COOLDOWN_SEC}s.`;
        }
        const form = new MessageFormData().title("§l§bTRAVEL").body(body).button1("§aTravel").button2("§8Cancel");
        show(player, form).then((res) => {
            if (res.canceled || res.selection !== 0) return;
            const out = r.kind === "special" ? WaypointManager.travelToSpecial(player, r.index) : WaypointManager.travelToStone(player, r.wp.id);
            if (out.ok) ok(player, out.message); else bad(player, out.message);
        }).catch(fail);
    },

    // ═══ stone: rename ══════════════════════════════════════════════════
    openRename(player, ctx) {
        const wp = WaypointManager.get(ctx.wp?.id);
        if (!wp || !WaypointManager.canManage(player, wp)) return bad(player, "Only the owner (or an Admin) can rename this stone.");
        const form = new ModalFormData().title("§l§eRENAME STONE").textField(`Name (max ${WAYPOINT.NAME_MAX} characters)`, wp.name, { defaultValue: wp.name });
        show(player, form).then((res) => {
            if (res.canceled || !res.formValues) return this.openMain(player, ctx);
            if (!WaypointManager.rename(wp.id, res.formValues[0])) { bad(player, "Please type a name."); return this.openRename(player, ctx); }
            ok(player, `Renamed to "${WaypointManager.get(wp.id).name}". Everyone's list shows the new name.`);
            this.openMain(player, { ...ctx, wp: WaypointManager.get(wp.id) });
        }).catch(fail);
    },

    // ═══ manager ════════════════════════════════════════════════════════
    openManager(player, ctx) {
        const wp = ctx.type === "stone" ? WaypointManager.get(ctx.wp?.id) : null;
        const canPlayers = ctx.type === "stone" && WaypointManager.canManage(player, wp);
        const entries = [];
        const form = new ActionFormData().title("§l§6MANAGER");
        if (canPlayers) {
            form.button("§ePlayer\n§8[Players linked to this stone]", "textures/icons/total_stats"); entries.push(() => this.openPlayers(player, ctx));
        }
        form.button("§bWaystone\n§8[Sort, remove your saved stones]", ICON); entries.push(() => this.openWaystone(player, ctx));
        form.button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection >= entries.length) return this.back(player, ctx);
            entries[res.selection]();
        }).catch(fail);
    },

    // Manager > Player: the owner / Admin removes a player's link to this stone.
    openPlayers(player, ctx) {
        const wp = WaypointManager.get(ctx.wp?.id);
        if (!wp || !WaypointManager.canManage(player, wp)) return bad(player, "Only the owner (or an Admin) can do that.");
        const list = Object.entries(wp.savers).filter(([id]) => id !== player.id);
        const form = new ActionFormData().title("§l§ePLAYERS").body(list.length ? `§7Players who saved §f${wp.name}§7. Pick one to remove.` : "§7Nobody else has saved this stone.");
        for (const [, name] of list) form.button(`§f${name}`, "textures/icons/red_minus");
        form.button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection >= list.length) return this.openManager(player, ctx);
            const [pid, pname] = list[res.selection];
            const confirm = new MessageFormData().title("§l§cREMOVE PLAYER").body(`§fRemove §e${pname} §ffrom §b${wp.name}§f?\n§7The stone leaves their list. They can save it again by right-clicking it.`).button1("§cRemove").button2("§8Cancel");
            show(player, confirm).then((r2) => {
                if (!r2.canceled && r2.selection === 0) {
                    if (WaypointManager.removeSaver(wp.id, pid)) ok(player, `Removed ${pname} from "${wp.name}".`);
                }
                this.openPlayers(player, ctx);
            }).catch(fail);
        }).catch(fail);
    },

    // Manager > Waystone: the player's own saved stones, in priority order.
    openWaystone(player, ctx) {
        const list = WaypointManager.known(player);
        const form = new ActionFormData().title("§l§bWAYSTONES")
            .body(list.length ? `§7${list.length}/${WAYPOINT.SAVED_MAX} saved. The order here is the order in your Teleport list.` : "§7Nothing saved yet.");
        list.forEach((w, i) => form.button(`§f#${i + 1} §b${w.name}\n§8${w.broken ? "§cDestroyed" : placeText(w)}`, ICON));
        form.button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection >= list.length) return ctx.type === "tool" ? undefined : this.openManager(player, ctx);
            this.openWaystoneEntry(player, ctx, list[res.selection].id);
        }).catch(fail);
    },

    openWaystoneEntry(player, ctx, id) {
        const wp = WaypointManager.get(id);
        if (!wp || !WaypointManager.isSaved(player, id)) return this.openWaystone(player, ctx);
        const ids = WaypointManager.knownIds(player);
        const pos = ids.indexOf(wp.id) + 1;
        const form = new ActionFormData().title(`§l§b${wp.name}`).body(`§7Position §f${pos}§7 of ${ids.length}.${wp.broken ? "\n§cThis stone was destroyed." : ""}`)
            .button("§aMove to top", "textures/icons/blue_up_arrow")
            .button("§aMove up", "textures/icons/green_up_arrow")
            .button("§aMove down", "textures/icons/green_down_arrow")
            .button("§cRemove", "textures/icons/trash_can")
            .button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            const s = res.selection;
            if (s === 0 || s === 1 || s === 2) {
                WaypointManager.move(player, id, s === 0 ? "top" : s === 1 ? "up" : "down");
                return this.openWaystoneEntry(player, ctx, id);
            }
            if (s === 3) {
                const confirm = new MessageFormData().title("§l§cREMOVE").body(`§fRemove §b${wp.name} §ffrom your list?\n§7You can save it again by right-clicking the stone.`).button1("§cRemove").button2("§8Cancel");
                return show(player, confirm).then((r2) => {
                    if (!r2.canceled && r2.selection === 0) { WaypointManager.unsave(player, id); ok(player, `Removed "${wp.name}" from your list.`); return this.openWaystone(player, ctx); }
                    this.openWaystoneEntry(player, ctx, id);
                }).catch(fail);
            }
            this.openWaystone(player, ctx);
        }).catch(fail);
    },

    // ═══ orb: special points ════════════════════════════════════════════
    openOrbEdit(player, ctx) {
        const list = WaypointManager.specials(player);
        const full = list.length >= WAYPOINT.SPECIAL_MAX;
        const form = new ActionFormData().title("§l§dSPECIAL POINTS")
            .body(`§7${list.length}/${WAYPOINT.SPECIAL_MAX} saved. They are always first in your Teleport list.\n§7Free to use, ${WAYPOINT.SPECIAL_COOLDOWN_SEC}s cooldown.`)
            .button(full ? "§8Add\n§8[List is full]" : "§aAdd\n§8[Save the spot you stand on]", "textures/icons/green_plus")
            .button("§eRename", "textures/icons/gear")
            .button("§cRemove", "textures/icons/red_minus")
            .button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection === 0) return full ? (bad(player, "Remove a special point first."), this.openOrbEdit(player, ctx)) : this.addSpecial(player, ctx);
            if (res.selection === 1 || res.selection === 2) return this.pickSpecial(player, ctx, res.selection === 1 ? "rename" : "remove");
            this.openMain(player, ctx);
        }).catch(fail);
    },

    addSpecial(player, ctx) {
        const n = WaypointManager.specials(player).length + 1;
        const form = new ModalFormData().title("§l§aADD SPECIAL POINT")
            .textField(`Name (max ${WAYPOINT.NAME_MAX} characters). Saves where you stand now.`, `Point ${n}`, { defaultValue: `Point ${n}` });
        show(player, form).then((res) => {
            if (res.canceled || !res.formValues) return this.openOrbEdit(player, ctx);
            const point = WaypointManager.addSpecial(player, res.formValues[0]);
            if (!point) bad(player, "Remove a special point first."); else { ok(player, `Saved "${point.name}" (${placeText(point)}).`); try { player.playSound("random.orb"); } catch (_) {} }
            this.openOrbEdit(player, ctx);
        }).catch(fail);
    },

    pickSpecial(player, ctx, mode) {
        const list = WaypointManager.specials(player);
        if (!list.length) { bad(player, "No special points saved."); return this.openOrbEdit(player, ctx); }
        const form = new ActionFormData().title(mode === "rename" ? "§l§eRENAME POINT" : "§l§cREMOVE POINT").body("§7Pick a point.");
        for (const p of list) form.button(`§d★ ${p.name}\n§8${placeText(p)}`, ICON);
        form.button("§8Back", BACK);
        show(player, form).then((res) => {
            if (res.canceled || res.blocked) return;
            if (res.selection >= list.length) return this.openOrbEdit(player, ctx);
            const index = res.selection, p = list[index];
            if (mode === "rename") {
                const f2 = new ModalFormData().title("§l§eRENAME POINT").textField(`Name (max ${WAYPOINT.NAME_MAX} characters)`, p.name, { defaultValue: p.name });
                return show(player, f2).then((r2) => {
                    if (!r2.canceled && r2.formValues) { WaypointManager.renameSpecial(player, index, r2.formValues[0]); ok(player, "Point renamed."); }
                    this.openOrbEdit(player, ctx);
                }).catch(fail);
            }
            const confirm = new MessageFormData().title("§l§cREMOVE POINT").body(`§fRemove §d${p.name}§f?\n§7${placeText(p)}`).button1("§cRemove").button2("§8Cancel");
            show(player, confirm).then((r2) => {
                if (!r2.canceled && r2.selection === 0) { WaypointManager.removeSpecial(player, index); ok(player, `Removed "${p.name}".`); }
                this.openOrbEdit(player, ctx);
            }).catch(fail);
        }).catch(fail);
    },

    back(player, ctx) {
        if (ctx.type === "tool") return;
        this.openMain(player, ctx);
    },
};
