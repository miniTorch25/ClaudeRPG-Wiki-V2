// toast_manager.js -- sends toast cards (pop-ups) to players.
//
// Wire format read by the toast UI in ClaudeRP/ui/crpg_toast.json (one chat line, hidden from the normal chat):
//   "_crpg:" + frame(1) + icon(4) + header(28, space padded) + body(rest)
// Frames : 0 grey, 1 blue, 2 yellow (Java style)  3 bronze, 4 silver, 5 gold, 6 platinum, 7 mythic, 8 ascension, 9 discovery
// Icon   : 4-character key of textures/icons/ach/<key>.png ("----" = no icon)
// Header : plain ASCII only (the resource pack cuts it by fixed length), coloured by the frame.
// Body   : may contain colour codes and any characters.
import { world, system } from "@minecraft/server";
import { TOAST } from "../config/toast_config.js";
import { SettingsManager } from "./settings_manager.js";
import { Scheduler } from "../core/scheduler.js";
import { Logger } from "../core/logger.js";

const PREFIX = "_crpg:";
const spacing = () => TOAST.SPACING_TICKS;
const FRAMES = { grey: "0", blue: "1", yellow: "2", bronze: "3", silver: "4", gold: "5", platinum: "6", mythic: "7", ascension: "8", discovery: "9" };
const TIER_FRAMES = [null, "bronze", "silver", "gold", "platinum", "mythic"];   // achievement tier id -> frame

const queues = new Map();     // playerId -> [{ msg, sound, volume }]
const lastSent = new Map();   // playerId -> tick

/** Strip colour codes. */
export function stripCodes(s) { return String(s ?? "").replace(/\u00a7./g, ""); }

/** Fixed-width ASCII header (no colour codes, no multi-byte characters). */
export function fitHeader(s) {
    const clean = stripCodes(s).replace(/'/g, "`").replace(/[^\x20-\x7e]/g, "?").slice(0, TOAST.HEADER_MAX);
    return clean.padEnd(TOAST.HEADER_MAX, " ");
}

/** Single quotes would end a string literal inside the UI expressions: the body gets a typographic apostrophe, the (ASCII-only) header a backtick. */
const safe = (s) => String(s ?? "").replace(/'/g, "\u2019");

/** Cut a body to `max` visible characters (colour codes are kept and not counted). */
export function fitBody(s, max = TOAST.BODY_MAX) {
    const str = safe(s);
    let out = "", visible = 0;
    for (let i = 0; i < str.length; i++) {
        if (str[i] === "\u00a7" && i + 1 < str.length) { out += str[i] + str[i + 1]; i++; continue; }
        if (visible >= max) { out += ".."; return out; }
        out += str[i]; visible++;
    }
    return out;
}

/** Frame character from a name ("gold"), a char ("5") or an achievement tier id (1-5 -> bronze..mythic). */
export function frameChar(frame) {
    if (typeof frame === "number") return FRAMES[TIER_FRAMES[frame] ?? "grey"];
    if (frame in FRAMES) return FRAMES[frame];
    if (/^[0-9]$/.test(String(frame))) return String(frame);
    return FRAMES.grey;
}

export function iconKey(icon) {
    const k = String(icon ?? "").trim();
    return /^[A-Za-z0-9]{4}$/.test(k) ? k : "----";
}

/** Build the wire string (pure; used by tests). */
export function buildMessage({ frame, icon, header, body }) {
    return PREFIX + frameChar(frame) + iconKey(icon) + fitHeader(header) + fitBody(body);
}

function pump() {
    const now = system.currentTick;
    for (const [id, q] of queues) {
        if (!q.length) { queues.delete(id); continue; }
        if (now - (lastSent.get(id) ?? -1e9) < spacing()) continue;
        const player = world.getAllPlayers().find((p) => p.id === id);
        if (!player) { queues.delete(id); continue; }
        sendNow(player, q.shift());
        if (!q.length) queues.delete(id);
    }
}

function sendNow(player, item) {
    lastSent.set(player.id, system.currentTick);
    try {
        player.sendMessage(item.msg);
        if (item.sound) player.playSound(item.sound, { volume: item.volume ?? 1 });
    } catch (_) { /* player left */ }
}

export const ToastManager = {
    register() { Scheduler.every("toast_pump", 4, pump); },

    /** Global switch (Admin) AND the player's own Settings switch. */
    isActive(player) {
        try { return TOAST.ENABLED >= 1 && SettingsManager.get(player, "toast_ui"); } catch (_) { return false; }
    },

    /**
     * opts: { frame, icon, header, body, sound?, volume? }   sound: string | null (null = silent)
     * Returns true when queued / sent.
     */
    show(player, opts) {
        if (!player?.isValid) return false;
        const item = {
            msg: buildMessage(opts),
            sound: opts.sound === undefined ? TOAST.DEFAULT_SOUND : opts.sound,
            volume: opts.volume ?? 1,
        };
        const q = queues.get(player.id);
        const ready = system.currentTick - (lastSent.get(player.id) ?? -1e9) >= spacing();
        if (!q?.length && ready) { sendNow(player, item); return true; }
        const list = q ?? [];
        if (list.length >= TOAST.MAX_QUEUE) return false;
        list.push(item);
        queues.set(player.id, list);
        return true;
    },

    /** False when this player's queue is full (so a paid send can be refused before charging). */
    canAccept(player) { return (queues.get(player.id)?.length ?? 0) < TOAST.MAX_QUEUE; },

    /** Show to every player whose toast switch is on; returns the players that did NOT get one. */
    broadcast(opts) {
        const missed = [];
        for (const p of world.getAllPlayers()) {
            if (this.isActive(p)) this.show(p, opts); else missed.push(p);
        }
        return missed;
    },

    /** Admin helper: one toast per frame style so the UI can be checked in-game. */
    demo(player) {
        const names = Object.keys(FRAMES);
        names.forEach((name, i) => this.show(player, {
            frame: name, icon: i % 2 ? "TASC" : "TDSC", header: `Frame ${i}: ${name}`, body: `\u00a7fToast test ${i + 1}/${names.length}`, sound: i === 0 ? undefined : null,
        }));
        return names.length;
    },

    onPlayerLeave(playerId) { queues.delete(playerId); lastSent.delete(playerId); },
};
