// health_display_core.js -- scan + render logic for the HP name tags. No direct engine imports so it can be
// tested with fakes; health_display.js wires in the real world, MobHpManager and mob_config.
import { HEALTH_DISPLAY as C } from "../config/health_display_config.js";
import { buildHpLine, stripHpLine, defaultName } from "./health_display_name.js";

export function createHealthDisplay(deps) {
    const { getPool, isBossType, bossTypes, getEntityById, getTick } = deps;
    const states = new Map();   // entity id -> { hp, until, kind }  (damage / heal flash)
    const active = new Set();   // entity ids whose name tag we currently own

    function readHp(entity) {
        let health;
        try { health = entity.getComponent("minecraft:health"); } catch (_) { return null; }
        if (!health) return null;
        const real = Number(health.currentValue), realMax = Number(health.effectiveMax);
        if (!(real > 0) || !(realMax > 0)) return null;               // dead or not a living mob
        const pool = getPool(entity);                                   // Ascension virtual HP, or null
        if (pool && pool.vmax > 0) return { cur: Math.max(0, Math.min(pool.vhp, pool.vmax)), max: pool.vmax };
        return { cur: real, max: realMax };
    }

    function render(entity, boss, tick) {
        const hp = readHp(entity);
        if (!hp) return false;
        const id = entity.id;
        const cur = Math.ceil(hp.cur), max = Math.round(hp.max);
        let st = states.get(id);
        if (!st) st = { hp: cur, until: 0, kind: null };
        else if (cur < st.hp) { st.until = tick + C.FLASH_TICKS; st.kind = "damage"; }
        else if (cur > st.hp) { st.until = tick + C.FLASH_TICKS; st.kind = "heal"; }
        st.hp = cur;
        states.set(id, st);

        const current = String(entity.nameTag ?? "");
        let base = stripHpLine(current);
        if (!base && boss) base = defaultName(entity.typeId);
        const line = buildHpLine(cur, max, boss, tick < st.until ? st.kind : null);
        const desired = base ? `${base}\n${line}` : line;
        if (current !== desired) entity.nameTag = desired;
        active.add(id);
        return true;
    }

    function restore(entity) {
        const current = String(entity.nameTag ?? "");
        let base = stripHpLine(current);
        if (base && isBossType(entity.typeId) && base === defaultName(entity.typeId)) base = "";   // name we generated
        if (current !== base) entity.nameTag = base;
    }

    function release(id) {
        try {
            const entity = getEntityById(id);
            if (entity && entity.isValid) restore(entity);
        } catch (_) { /* unloaded or removed */ }
        active.delete(id);
        states.delete(id);
    }

    function collect(players) {
        const found = new Map();   // id -> { entity, boss }
        for (const player of players) {
            let dim, loc;
            try { dim = player.dimension; loc = player.location; } catch (_) { continue; }
            if (C.SHOW_BOSSES) {
                for (const type of bossTypes) {
                    try {
                        for (const e of dim.getEntities({ type, location: loc, maxDistance: C.BOSS_RADIUS })) found.set(e.id, { entity: e, boss: true });
                    } catch (_) { /* skip */ }
                }
            }
            if (C.SHOW_MOBS) {
                try {
                    for (const e of dim.getEntities({ location: loc, maxDistance: C.SCAN_RADIUS, excludeTypes: C.EXCLUDE_TYPES })) {
                        if (found.has(e.id)) continue;
                        const boss = isBossType(e.typeId);
                        if (boss && !C.SHOW_BOSSES) continue;
                        found.set(e.id, { entity: e, boss });
                    }
                } catch (_) { /* skip */ }
            }
        }
        return found;
    }

    function tick(players) {
        if (!C.ENABLED) { restoreAll(); return 0; }
        const now = getTick();
        const seen = new Set();
        let rendered = 0;
        for (const [id, { entity, boss }] of collect(players)) {
            if (rendered >= C.MAX_PER_SCAN) break;
            try {
                if (!entity.isValid) continue;
                if (render(entity, boss, now)) { seen.add(id); rendered++; }
            } catch (_) { /* entity vanished mid-scan */ }
        }
        for (const id of [...active]) if (!seen.has(id)) release(id);   // left range, died, or over the cap
        return rendered;
    }

    function restoreAll() { for (const id of [...active]) release(id); }

    return { tick, restoreAll, _active: active, _states: states };
}
