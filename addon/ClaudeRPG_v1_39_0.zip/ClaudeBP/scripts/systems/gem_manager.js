import { ItemStack, EntityComponentTypes } from "@minecraft/server";
import { GEM_REGISTRY, GEM_DEFS, GEM_CATEGORY_BY_SLOT, getEligibleAbilities, migrateGemSkill, normalizeGemAbility } from "./gem_registry.js";
import { buildGemSkillLoreLines } from "./gem_lore.js";
import { PROGRESSION } from "../config/progression_config.js";
import { MASTERY } from "../config/mastery_config.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { AchievementManager } from "./achievement_manager.js";

// Gem rarity ordered from lowest to highest (index = tier)
export const GEM_TIERS = [
    { id: "common",   label: "Common",   color: "§f", icon: "\uE211", itemId: "crpg:common_gem"   },
    { id: "uncommon", label: "Uncommon", color: "§e", icon: "\uE212", itemId: "crpg:uncommon_gem" },
    { id: "rare",     label: "Rare",     color: "§a", icon: "\uE213", itemId: "crpg:rare_gem"     },
    { id: "unique",   label: "Unique",   color: "§3", icon: "\uE214", itemId: "crpg:unique_gem"   },
    { id: "legend",   label: "Legend",   color: "§9", icon: "\uE215", itemId: "crpg:legend_gem"   },
    { id: "epic",     label: "Epic",     color: "§u", icon: "\uE216", itemId: "crpg:epic_gem"     },
    { id: "mythical", label: "Mythical", color: "§4", icon: "\uE217", itemId: "crpg:myth_gem"     },
];

// All installable gem typeIds → tier id
export const GEM_ITEM_MAP = {
    "crpg:common_gem":   "common",
    "crpg:uncommon_gem": "uncommon",
    "crpg:rare_gem":     "rare",
    "crpg:unique_gem":   "unique",
    "crpg:legend_gem":   "legend",
    "crpg:epic_gem":     "epic",
    "crpg:myth_gem":     "mythical",
};

// Uncarved Gem item ID — source for carving into tiered gems
export const UNCARVED_GEM_ID = "crpg:uncarved_gem";
// Gem Dust item ID — produced by crushing Uncarved Gems with a Hammer
export const GEM_DUST_ID     = "crpg:gem_dust";

// Carve weight table (Mainhand Mechanic: Uncarved Gem + Engraver in Offhand)
// Same distribution as the old Transmute table.
// Also used by Ultench Gem Transmute (random mode) — Phase 3.
export const CARVE_TABLE = [
    { id: "common",   weight: 39 },
    { id: "uncommon", weight: 23 },
    { id: "rare",     weight: 14 },
    { id: "unique",   weight: 5  },
    { id: "legend",   weight: 7  },
    { id: "epic",     weight: 9  },
    { id: "mythical", weight: 3  },
];

// Hammer item IDs that can crush Uncarved Gem → Gem Dust
export const HAMMER_ITEM_IDS = [
    "crpg:reforge_hammer",
    "crpg:diamond_reforge_hammer",
    "crpg:netherite_reforge_hammer",
    "crpg:eternal_hammer",
];

// Socket unlock levels — reduced from [75, 150] to [50, 75] per plan
// Gem gate level, read live so the in-game Config Editor takes effect at once.
export const SOCKET_LEVELS  = [];
Object.defineProperty(SOCKET_LEVELS, 0, { get: () => PROGRESSION.FEATURES.gem.level ?? 0, enumerable: true });
export const ENGRAVE_RATES  = [0.33];
export const SOCKET_COUNT   = SOCKET_LEVELS.length; // Phase 5/#11 — was 2 sockets

// Mag requirement per gem tier (index mirrors GEM_TIERS order)
export const GEM_MAG_REQ = [15, 30, 45, 60, 75, 90, 115];

// Probability of Perfect Carved (yields 2 gems from 1 Uncarved Gem)
const PERFECT_CARVED_CHANCE = 0.01;

// Dynamic property keys on ItemStack
const PROP_SLOT = (i) => `gem_slot${i + 1}`;   // "gem_slot1" | "gem_slot2"
// Dynamic property key for the gem skill enchanted into a slot
// e.g. "gem_skill1" = "swiftness"
const PROP_SKILL = (i) => `gem_skill${i + 1}`;
// Legacy: older versions stored a Gem level here. Gems have no levels now; the value is ignored
// and removed whenever the slot's skill is written or cleared.
const PROP_LEGACY_LEVEL = (i) => `gem_level${i + 1}`;

// Possible slot states
// "locked"   — not yet engraved
// "empty"    — engraved, no gem installed
// <tier id>  — gem installed

// Skills available per tier (for Lore display on unenchanted gems)
// Also used by Ultench Gem Enchanting (Phase 3) — import GEM_TIER_SKILLS there.
export const GEM_TIER_SKILLS = Object.fromEntries(
    Object.entries(GEM_REGISTRY).map(([tier, def]) => [tier, def.skills])
);

export class GemManager {

    // ─── State accessors ──────────────────────────────────────────────────────

    static getSlotState(slot, index) {
        return slot.getDynamicProperty(PROP_SLOT(index)) ?? "locked";
    }

    static setSlotState(slot, index, state) {
        slot.setDynamicProperty(PROP_SLOT(index), state);
    }

    static getSlotStates(slot) {
        return Array.from({ length: SOCKET_COUNT }, (_, i) => this.getSlotState(slot, i));
    }

    // Gem skill enchanted into the slot (null = unenchanted)
    static getSlotSkill(slot, index) {
        return slot.getDynamicProperty(PROP_SKILL(index)) ?? null;
    }

    static setSlotSkill(slot, index, skillName) {
        slot.setDynamicProperty(PROP_LEGACY_LEVEL(index), undefined);
        slot.setDynamicProperty(PROP_SKILL(index), skillName ?? "");
    }

    static clearSlotSkill(slot, index) {
        slot.setDynamicProperty(PROP_LEGACY_LEVEL(index), undefined);
        slot.setDynamicProperty(PROP_SKILL(index), "");
    }

    // ─── Armor categories / ability rolling ───────────────────────────────────

    // "H" | "C" | "L" | "B" for a Helm / Chest / Legs / Boots item type, else null.
    static getArmorCategory(typeId) {
        const req = ITEM_REQUIREMENTS[typeId];
        return req?.type === "armor" ? (GEM_CATEGORY_BY_SLOT[req.slot] ?? null) : null;
    }

    // Display names of the abilities a gem of `tierId` can roll on this armor type.
    static getEligibleSkills(tierId, armorTypeId) {
        return getEligibleAbilities(tierId, this.getArmorCategory(armorTypeId)).map((k) => GEM_DEFS[k].name);
    }

    // Picks a random ability for this tier + armor type. `exclude` (a current skill name) is skipped when
    // another choice exists, so a re-roll never wastes materials on the same result. Returns a name or null.
    static rollSkill(tierId, armorTypeId, exclude = null, random = Math.random) {
        let pool = this.getEligibleSkills(tierId, armorTypeId);
        if (exclude && pool.length > 1) pool = pool.filter((n) => normalizeGemAbility(n) !== normalizeGemAbility(exclude));
        if (pool.length === 0) return null;
        return pool[Math.min(pool.length - 1, Math.floor(random() * pool.length))];
    }

    // Returns the ability key stored in a socket after making sure it is valid for this tier + armor category.
    // Gems from older versions are migrated here, once: a same-named ability that fits stays (with its new
    // values); anything else is re-rolled for free inside its tier + category. Returns null when the socket has
    // no ability. (Writing is rare: after one migration the stored name is valid and this is a cheap check.)
    static ensureSlotSkill(slot, index, tierId, cat) {
        const stored = this.getSlotSkill(slot, index);
        if (!stored) return null;
        const res = migrateGemSkill(tierId, stored, cat);
        if (res.changed) {
            if (!res.name) { this.clearSlotSkill(slot, index); return null; }
            this.setSlotSkill(slot, index, res.name);
        }
        return res.name ? normalizeGemAbility(res.name) : null;
    }

    // ─── Engrave ─────────────────────────────────────────────────────────────

    static engrave(player, armorSlot, socketIndex) {
        if (!ProgressionManager.canUse(player, "gem")) return { success: false, broke: false, reason: "level" };

        const state = this.getSlotState(armorSlot, socketIndex);
        if (state !== "locked") return { success: false, broke: false, reason: "not_locked" };

        const engraverResult = this.consumeEngraverDurability(player);
        if (!engraverResult.found) return { success: false, broke: false, reason: "no_engraver" };

        const success = Math.random() < this.getEngraveRate(player, socketIndex);
        MasteryManager.addXp(player, "gem", MASTERY.GEM_XP_ENGRAVE);
        if (success) this.setSlotState(armorSlot, socketIndex, "empty");

        return { success, broke: engraverResult.broke };
    }

    // Base Engrave rate + Gemwright perk (percentage points), capped at 100%.
    static getEngraveRate(player, socketIndex = 0) {
        const bonus = player ? ProgressionManager.getPerkValue(player, "gem_chance") / 100 : 0;
        return Math.min(1, (ENGRAVE_RATES[socketIndex] ?? 0) + bonus);
    }

    static consumeEngraverDurability(player) {
        const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (!inventory) return { found: false, broke: false };

        // Eternal Engraver passive: if carried anywhere in inventory, every Engraver-related
        // durability cost is completely free — it substitutes for a normal Engraver too.
        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (slot.hasItem() && slot.typeId === "crpg:eternal_engraver") {
                return { found: true, broke: false };
            }
        }

        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (!slot.hasItem() || slot.typeId !== "crpg:engraver") continue;
            try {
                const item = slot.getItem();
                const dur  = item.getComponent("minecraft:durability");
                if (!dur) return { found: true, broke: false };
                dur.damage = Math.min(dur.maxDurability, dur.damage + 1);
                if (dur.damage >= dur.maxDurability) {
                    slot.setItem(undefined);
                    return { found: true, broke: true };
                }
                slot.setItem(item);
                return { found: true, broke: false };
            } catch {
                return { found: true, broke: false };
            }
        }
        return { found: false, broke: false };
    }

    // ─── Install ──────────────────────────────────────────────────────────────

    // Returns tier id installed, or null on failure
    static installGem(player, armorSlot, socketIndex, gemTypeId) {
        // Gems are armor-only (never tools/weapons/shears), whatever the caller passes in.
        if (ITEM_REQUIREMENTS[armorSlot?.typeId]?.type !== "armor") return null;
        const state = this.getSlotState(armorSlot, socketIndex);
        if (state !== "empty") return null;

        const tierId = GEM_ITEM_MAP[gemTypeId];
        if (!tierId) return null;

        // Mag requirement check
        const mag     = player.getDynamicProperty("stat_mag") ?? 0;
        const tierIdx = GEM_TIERS.findIndex((t) => t.id === tierId);
        const magReq  = GEM_MAG_REQ[tierIdx] ?? 0;
        if (mag < magReq) return null;   // caller should show "Need Mag +X" message

        if (!this.consumeItem(player, gemTypeId)) return null;

        this.setSlotState(armorSlot, socketIndex, tierId);
        this.clearSlotSkill(armorSlot, socketIndex);
        return tierId;
    }

    // ─── Remove ───────────────────────────────────────────────────────────────

    static removeGem(player, armorSlot, socketIndex) {
        const state = this.getSlotState(armorSlot, socketIndex);
        const tier  = GEM_TIERS.find((t) => t.id === state);
        if (!tier) return null;

        this.setSlotState(armorSlot, socketIndex, "empty");
        this.clearSlotSkill(armorSlot, socketIndex);
        return new ItemStack(tier.itemId, 1);
    }

    // ─── Carve (Mainhand Mechanic) ─────────────────────────────────────────────
    // Called from event_router.js itemUse handler when:
    //   Mainhand = crpg:uncarved_gem, Offhand = engraver → carve into gem
    //   Mainhand = crpg:uncarved_gem, Offhand = hammer   → crush into gem dust

    // Carve one Uncarved Gem → random Gem (+ 1% chance Perfect Carved = 2 gems)
    // Returns { tierId, count } or null if player has no Uncarved Gem in mainhand
    static carveUncarvedGem(player) {
        const equip   = player.getComponent(EntityComponentTypes.Equippable);
        if (!equip) return null;
        const mainSlot = equip.getEquipmentSlot("Mainhand");
        if (!mainSlot?.hasItem() || mainSlot.typeId !== UNCARVED_GEM_ID) return null;

        // Consume 1 Uncarved Gem from mainhand
        const item = mainSlot.getItem();
        if (item.amount > 1) {
            item.amount -= 1;
            mainSlot.setItem(item);
        } else {
            mainSlot.setItem(undefined);
        }

        const tierId  = this.randomCarve(player);
        const isPerfect = Math.random() < PERFECT_CARVED_CHANCE;
        const count   = isPerfect ? 2 : 1;
        this.addCarveXp(player, tierId, count);
        AchievementManager.add(player, "gems_carved", count);
        AchievementManager.markSeen(player, "gemtier", tierId, "gem_tiers_carved");
        return { tierId, count, isPerfect };
    }

    // Crush one Uncarved Gem → Gem Dust (1-10 per gem)
    // Returns count of Gem Dust produced, or 0 if no Uncarved Gem in mainhand
    static crushUncarvedGem(player) {
        const equip   = player.getComponent(EntityComponentTypes.Equippable);
        if (!equip) return 0;
        const mainSlot = equip.getEquipmentSlot("Mainhand");
        if (!mainSlot?.hasItem() || mainSlot.typeId !== UNCARVED_GEM_ID) return 0;

        const item = mainSlot.getItem();
        if (item.amount > 1) {
            item.amount -= 1;
            mainSlot.setItem(item);
        } else {
            mainSlot.setItem(undefined);
        }

        const dust = Math.floor(Math.random() * 10) + 1;   // 1–10
        AchievementManager.add(player, "gem_dust_collected", dust);
        return dust;
    }

    // ─── ×16 Carved (Shift + Right Click) ──────────────────────────────────────
    // Batch versions — consume up to `max` Uncarved Gems from Mainhand in one
    // click instead of just 1. Bounded by both `max` and the stack's amount.

    // Returns { consumed, results, perfectCount, totalGems } or null if none held
    static carveUncarvedGemBatch(player, max = 16) {
        const equip   = player.getComponent(EntityComponentTypes.Equippable);
        if (!equip) return null;
        const mainSlot = equip.getEquipmentSlot("Mainhand");
        if (!mainSlot?.hasItem() || mainSlot.typeId !== UNCARVED_GEM_ID) return null;

        const item  = mainSlot.getItem();
        const count = Math.min(max, item.amount);
        if (count <= 0) return null;

        if (item.amount > count) {
            item.amount -= count;
            mainSlot.setItem(item);
        } else {
            mainSlot.setItem(undefined);
        }

        const results = {};   // tierId -> gem count produced
        let perfectCount = 0;
        let totalGems    = 0;
        for (let i = 0; i < count; i++) {
            const tierId    = this.randomCarve(player);
            const isPerfect = Math.random() < PERFECT_CARVED_CHANCE;
            const gemCount  = isPerfect ? 2 : 1;
            results[tierId] = (results[tierId] ?? 0) + gemCount;
            if (isPerfect) perfectCount++;
            totalGems += gemCount;
            this.addCarveXp(player, tierId, gemCount);
        }
        AchievementManager.add(player, "gems_carved", totalGems);
        for (const tierId of Object.keys(results)) AchievementManager.markSeen(player, "gemtier", tierId, "gem_tiers_carved");
        return { consumed: count, results, perfectCount, totalGems };
    }

    // Returns { consumed, dustCount } or null if no Uncarved Gem in mainhand
    static crushUncarvedGemBatch(player, max = 16) {
        const equip   = player.getComponent(EntityComponentTypes.Equippable);
        if (!equip) return null;
        const mainSlot = equip.getEquipmentSlot("Mainhand");
        if (!mainSlot?.hasItem() || mainSlot.typeId !== UNCARVED_GEM_ID) return null;

        const item  = mainSlot.getItem();
        const count = Math.min(max, item.amount);
        if (count <= 0) return null;

        if (item.amount > count) {
            item.amount -= count;
            mainSlot.setItem(item);
        } else {
            mainSlot.setItem(undefined);
        }

        let dustCount = 0;
        for (let i = 0; i < count; i++) dustCount += Math.floor(Math.random() * 10) + 1;   // 1–10 each
        AchievementManager.add(player, "gem_dust_collected", dustCount);
        return { consumed: count, dustCount };
    }

    // ─── Carve helper ─────────────────────────────────────────────────────────

    // Gem Mastery XP for carved gems. Common gems stop paying once Uncommon is unlocked.
    static addCarveXp(player, tierId, gemCount) {
        try {
            if (tierId === "common" && MasteryManager.isGemTierOpen(player, "uncommon")) return;
            const xp = MASTERY.GEM_XP_CARVE?.[tierId] ?? 0;
            if (xp > 0) MasteryManager.addXp(player, "gem", xp * gemCount);
        } catch (_) {}
    }

    // Gem tiers the player has not unlocked (Gem Mastery) are left out and the weights re-normalised.
    static randomCarve(player = null) {
        const table = player ? CARVE_TABLE.filter((e) => MasteryManager.isGemTierOpen(player, e.id)) : CARVE_TABLE;
        const pool = table.length ? table : CARVE_TABLE.slice(0, 1);
        const total = pool.reduce((a, e) => a + e.weight, 0);
        const roll = Math.random() * total;
        let cumulative = 0;
        for (const entry of pool) {
            cumulative += entry.weight;
            if (roll < cumulative) return entry.id;
        }
        return pool[0].id;
    }

    // ─── Inventory helpers ────────────────────────────────────────────────────

    static consumeItem(player, typeId) {
        const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (!inventory) return false;
        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (!slot.hasItem() || slot.typeId !== typeId) continue;
            const item = slot.getItem();
            if (item.amount > 1) { item.amount -= 1; slot.setItem(item); }
            else slot.setItem(undefined);
            return true;
        }
        return false;
    }

    static countItem(player, typeId) {
        const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (!inventory) return 0;
        let count = 0;
        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (slot.hasItem() && slot.typeId === typeId) count += slot.getItem().amount;
        }
        return count;
    }

    // ─── Lore helpers ─────────────────────────────────────────────────────────

    static getTierDef(tierId) {
        return GEM_TIERS.find((t) => t.id === tierId) ?? null;
    }

    static getRarityLabel(tierId) {
        if (!tierId || tierId === "locked" || tierId === "empty") return "§8N/A";
        const tier = this.getTierDef(tierId);
        return tier ? `${tier.color}${tier.label}` : "§8N/A";
    }

    // Builds the Gem socket lore block for armor (shown in item lore).
    // Shows skill name + Rarity if enchanted; item name + Rarity if not.
    static buildGemLoreLines(armorSlot, playerLevel, player = null) {
        const lines = ["§r§7Gems:"];
        for (let i = 0; i < SOCKET_COUNT; i++) {
            const state    = this.getSlotState(armorSlot, i);
            const required = SOCKET_LEVELS[i];
            let socketLabel, rarityLabel;

            if (state === "locked") {
                const levelLocked = player ? !ProgressionManager.canUse(player, "gem") : false;
                socketLabel = levelLocked
                    ? `§r§8Requires ${ProgressionManager.requirementText("gem")}.`
                    : "§r§7\uE20B Locked Socket";
                rarityLabel = "§r§8- Rarity: §8N/A";
            } else if (state === "empty") {
                socketLabel = "§r§7\uE210 Empty Socket";
                rarityLabel = "§r§8- Rarity: §8N/A";
            } else {
                const tier  = this.getTierDef(state);
                const skill = this.getSlotSkill(armorSlot, i);

                if (skill) {
                    // Enchanted: show skill name (with rarity icon) as header
                    socketLabel = `§r${tier?.color ?? "§f"}${tier?.icon ?? ""} ${skill}`;
                    rarityLabel = `§r§8- Rarity: ${this.getRarityLabel(state)}`;
                } else {
                    // Unenchanted: show gem name + Rarity only
                    socketLabel = tier
                        ? `§r${tier.color}${tier.icon} ${tier.label} Gem`
                        : "§r§7Unknown Gem";
                    rarityLabel = `§r§8- Rarity: ${this.getRarityLabel(state)}`;
                }
            }
            lines.push(socketLabel, rarityLabel);

            // Detailed skill lore (description + cost/cooldown/stacks), same
            // idea as buildRuneLoreLines on weapons (Phase 6)
            if (state !== "locked" && state !== "empty") {
                const skill = this.getSlotSkill(armorSlot, i);
                if (skill) lines.push(...buildGemSkillLoreLines(skill, player));
            }
        }
        return lines;
    }

    // Builds standalone gem item lore (shown on the gem item itself in inventory).
    // Unenchanted: list possible skills for this tier.
    // Enchanted:   show skill name + buff value.
    static buildGemItemLore(tierId, skillName, buffText) {
        const tier   = this.getTierDef(tierId);
        const color  = tier?.color ?? "§f";
        const lines  = [];

        if (!skillName) {
            // Unenchanted gem: show possible skills
            const skills = GEM_TIER_SKILLS[tierId] ?? [];
            lines.push("§r§7Enchantment options:");
            lines.push(`§r§f${skills.join(", ")}`);
        } else {
            // Enchanted gem
            lines.push(`§r§7Enchant: ${color}${tier?.icon ?? ""} ${skillName}`);
            if (buffText) lines.push(`§r§8${buffText}`);
        }
        return lines;
    }

    static hasInstalledGem(armorSlot) {
        return Array.from({ length: SOCKET_COUNT }, (_, i) => i).some((i) => {
            const s = this.getSlotState(armorSlot, i);
            return s !== "locked" && s !== "empty";
        });
    }

    static getGemEquipLevel(armorSlot) {
        for (let i = 0; i < SOCKET_COUNT; i++) {
            const s = this.getSlotState(armorSlot, i);
            if (s !== "locked" && s !== "empty") return SOCKET_LEVELS[0]; // Gem gate level
        }
        return 0;
    }
}
