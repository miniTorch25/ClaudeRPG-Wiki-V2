// settings_gui.js -- Script Tool > Settings: one screen with a toggle per personal switch.
import { ModalFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { SettingsManager } from "./settings_manager.js";

const SCREEN = "systems.settings_gui.js";

export const SettingsGui = {
    open(player) {
        const defs = SettingsManager.defs;
        const form = new ModalFormData().title("§l§bSETTINGS");
        for (const d of defs) form.toggle(`${d.label}\n§8${d.desc}`, { defaultValue: SettingsManager.get(player, d.id) });
        GuiService.show(player, form, SCREEN).then((res) => {
            if (res.canceled || !res.formValues) return;
            let changed = 0;
            defs.forEach((d, i) => {
                const v = !!res.formValues[i];
                if (v !== SettingsManager.get(player, d.id)) { SettingsManager.set(player, d.id, v); changed++; }
            });
            player.sendMessage(changed ? `§b[Settings] §fSaved (${changed} changed).` : "§b[Settings] §7No changes.");
        }).catch((e) => console.warn(`[Settings] ${e}`));
    },
};
