// knowledge_book.js -- Knowledge Book (EN / TH), organised by category.
// Language -> Category -> Topic. Every number about Progression, Mastery, Ascension and
// Mob Evolution is read from the config files, so the book stays correct when they change.

import { GuiService } from "../gui/gui_service.js";
import { ActionFormData } from "@minecraft/server-ui";
import { RedeemManager } from "./redeem.js";
import { CONFIG } from "../config/config.js";
import { PROGRESSION, PRESTIGE, ASCENSION, MOB_SCALING, ACTION_COSTS } from "../config/progression_config.js";
import { SYNERGY, ELEMENT_HIT, ELEMENT_GUARD } from "../config/synergy_config.js";
import { MASTERY } from "../config/mastery_config.js";
import { EVOLUTION, AWAKEN_ABILITIES, NIGHTMARE, ENCHANTED } from "../config/evolution_config.js";
import { SPECIAL, SPECIAL_ABILITIES as SA, SPECIAL_BOSSES } from "../config/special_config.js";
import { STAT_CAPS, DEFAULT_STAT_CAP } from "../managers/stats_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { ENGRAVE_RATES, GEM_TIERS } from "./gem_manager.js";
import { GEM_REGISTRY, GEM_DEFS, GEM_CATEGORY_NAME } from "./gem_registry.js";
import { buildGemSkillLoreLines } from "./gem_lore.js";
import { describeEffects } from "../rune/rune_lore.js";
import { RUNE_POOL_LABELS } from "../rune/rune_registry.js";
import { RUNE_REGISTRY } from "../rune/rune_registry.js";
import { GEM_CAPS } from "../config/gem_ability_config.js";
import {
    CHORUS_CAPS, CHORUS_SLOTS_PER_ITEM, CHORUS_THRESHOLDS, CHORUS_MAX_SLOTS,
    CHORUS_TIERS, CHORUS_ELEMENTS, CHORUS_HYBRIDS, CHORUS_ROLL_COST, CHORUS_LOCK_COST,
    CHORUS_FUSION, CHORUS_FUSION_COST, CHORUS_FUSION_UNLOCK,
} from "../config/chorus_config.js";
import { onMenuOpened } from "./achievement_hooks.js";
import { GuideQuestGui } from "./guide_quest_gui.js";
import { ACH_DEFS } from "../config/achievement_data.js";
import { AchievementManager } from "./achievement_manager.js";
import { WAYPOINT, DISCOVERY, BIOME_CATALOG, STRUCTURE_CATALOG } from "../config/exploration_config.js";
import { STASH } from "../config/qol_config.js";
import { RUNE_ANVIL_COSTS, RUNE_GRADES } from "../config/rune_item_config.js";
import { HEALTH_DISPLAY } from "../config/health_display_config.js";
import { DAMAGE_INDICATOR } from "../config/damage_indicator_config.js";
import { TOAST, TOAST_COST_NAME } from "../config/toast_config.js";

const BACK_ICON = "textures/icons/back";
const KB_ICON = "textures/icons/kb/kb_";   // kb_cat_<category id>.png / kb_<page id>.png
const SCREEN = "systems.knowledge_book.js";
const PCT = "\uE21F";

const t = (lang, en, th) => (lang === "th" ? th : en);
const L = (...lines) => lines.join("\n");
const pc = (v) => Math.round(v * 100);
const pc2 = (v) => +(v * 100).toFixed(2);   // keeps small chances readable (0.25)
const r1 = (v) => Math.round(v * 100) / 100;

const UI = {
    en: {
        mainTitle: "§lKnowledge Book",
        mainBody: "§7Everything about ClaudeRPG, sorted by topic. Pick a category:",
        back: "§8< Back",
        topics: (n) => `§8${n} topics`,
    },
    th: {
        mainTitle: "§lหนังสือความรู้",
        mainBody: "§7รวมทุกเรื่องของ ClaudeRPG แยกตามหมวด เลือกหมวดที่ต้องการ:",
        back: "§8< ย้อนกลับ",
        topics: (n) => `§8${n} หัวข้อ`,
    },
};

const LEGACY_ENCY = {
 "melee": {
  "en": {
   "title": "§lEncyclopedia — Melee Runes",
   "body": "§cMelee Runes§r §8(Sword / Axe only)\n\n§fRelentless §8T1 TRIGGER §7— First 3 hits deal +15\uE21F dmg per hit.\n§fSeverance §8T2 TRIGGER §7— Execute targets below 15\uE21F HP (cap 50 HP).\n§fShockwave §8T3 TRIGGER §7— AoE burst when below 30\uE21F HP. (12s CD)\n§fRuination §8T3 TRIGGER §7— Hit 1: +60\uE21F, Hits 2-3: +20\uE21F + execute.\n§fExecutioner §8T4 TRIGGER §7— +100\uE21F dmg vs targets below 25\uE21F HP. (8s CD)\n§fIron Will §8T4 PASSIVE §7— Reduce damage by 10\uE21F when below 50\uE21F HP.\n§fStormcall §8T4 ACTIVE §7— Lightning AoE 10r, 8 targets. (125 Mana, 15s CD)\n§fWarden's Echo §8T4 ACTIVE §7— Knockback AoE 8r +10 dmg. (100 Mana, 10s CD)\n§fBerserker §8T5 STATE §7— Speed scales with missing HP (up to +4 amp).\n§fPhantom Strike §8T5 TRIGGER §7— Every 5 hits: teleport behind + +15 bonus dmg.\n§fBloodshed §8T5 PASSIVE §7— +1 flat atk per 100 kills (max +25).\n§fWrath of Giants §8T6 PASSIVE §7— Kills in 30s -> flat dmg (max +40).\n§fSoulbound Fury §8T7 STATE §7— 50 souls -> AoE burst + 8 heal. (30s CD)\n§fCrimson Surge §8T7 TRIGGER §7— 20\uE21F lifesteal per hit. (15 Mana/hit)\n§fDoom's Edge §8T7 TRIGGER §7— Kill stack -> mega burst in 60s window. (45s CD)"
  },
  "th": {
   "title": "§lสารานุกรม — Melee Runes",
   "body": "§cMelee Runes§r §8(ดาบ / ขวาน)\n\n§fRelentless §8T1 TRIGGER §7— 3 ฮิตแรกดาเมจ +15\uE21F ต่อครั้ง\n§fSeverance §8T2 TRIGGER §7— สังหารเป้าหมายที่ HP ต่ำกว่า 15\uE21F (แคป 50 HP)\n§fShockwave §8T3 TRIGGER §7— ระเบิด AoE เมื่อ HP ต่ำกว่า 30\uE21F (CD 12 วิ)\n§fRuination §8T3 TRIGGER §7— ฮิต 1: +60\uE21F, ฮิต 2-3: +20\uE21F + execute\n§fExecutioner §8T4 TRIGGER §7— +100\uE21F ดาเมจต่อเป้าที่ HP ต่ำกว่า 25\uE21F (CD 8 วิ)\n§fIron Will §8T4 PASSIVE §7— ลดดาเมจที่รับ 10\uE21F เมื่อ HP ต่ำกว่า 50\uE21F\n§fStormcall §8T4 ACTIVE §7— ฟ้าผ่า AoE 10r สูงสุด 8 เป้า (125 Mana, CD 15 วิ)\n§fWarden's Echo §8T4 ACTIVE §7— ดันศัตรู AoE 8r +10 ดาเมจ (100 Mana, CD 10 วิ)\n§fBerserker §8T5 STATE §7— ความเร็วเพิ่มตาม HP ที่หาย (สูงสุด +4 amp)\n§fPhantom Strike §8T5 TRIGGER §7— ทุก 5 ฮิต: วาร์ปหลังเป้า + +15 ดาเมจ\n§fBloodshed §8T5 PASSIVE §7— +1 atk ทุก 100 kills (สูงสุด +25)\n§fWrath of Giants §8T6 PASSIVE §7— kills ใน 30 วิ -> ดาเมจเพิ่ม (สูงสุด +40)\n§fSoulbound Fury §8T7 STATE §7— 50 souls -> AoE + ฟื้นฟู 8 HP (CD 30 วิ)\n§fCrimson Surge §8T7 TRIGGER §7— ดูดเลือด 20\uE21F ต่อฮิต (15 Mana/ครั้ง)\n§fDoom's Edge §8T7 TRIGGER §7— สะสม kills -> ระเบิดในหน้าต่าง 60 วิ (CD 45 วิ)"
  }
 },
 "ranged": {
  "en": {
   "title": "§lEncyclopedia — Ranged Runes",
   "body": "§bRanged Runes§r §8(Bow / Crossbow only)\n\n§fDeadeye §8T2 PASSIVE §7— +1 dmg per 5 blocks distance (max +20).\n§fPiercing Shot §8T3 TRIGGER §7— Projectile pierces 2 targets. (3s CD)\n§fShattershot §8T3 TRIGGER §7— AoE 3r on impact (50\uE21F dmg). (5s CD)\n§fGambit §8T3 TRIGGER §7— 60\uE21F normal, 14.5\uE21F +50\uE21F bonus, 0.5\uE21F execute, 25\uE21F self-hit.\n§fMultishot §8T4 TRIGGER §7— Fire 3 arrows simultaneously. (4s CD)\n§fExplosive Arrow §8T4 TRIGGER §7— AoE 3r on hit (60\uE21F dmg). (3s CD)\n§fOvercharge §8T4 STATE §7— Accumulate +1 dmg per 60s idle (max +50).\n§fPredator §8T5 PASSIVE §7— +1 dmg per 5 blocks distance (max +30).\n§fPhantom Volley §8T5 TRIGGER §7— 15\uE21F chance to fire 2nd arrow free. (2s CD)\n§fSkyfall §8T5 TRIGGER §7— Arrow teleports above the nearest enemy and drops on it (never misses). (6s CD)\n§fHailstorm §8T6 ACTIVE §7— 10-arrow barrage in 8r. (80 Mana, 20s CD)\n§fVoidshot §8T7 TRIGGER §7— Ignore 30\uE21F target armor. (5s CD)\n§fEclipse §8T7 STATE §7— 20 kills -> instant AoE 12r. (60s CD)\n§fCataclysm §8T7 ACTIVE §7— Explosion 15r, 40 dmg. (150 Mana, 45s CD)"
  },
  "th": {
   "title": "§lสารานุกรม — Ranged Runes",
   "body": "§bRanged Runes§r §8(ธนู / หน้าไม้)\n\n§fDeadeye §8T2 PASSIVE §7— +1 ดาเมจต่อ 5 บล็อก (สูงสุด +20)\n§fPiercing Shot §8T3 TRIGGER §7— ลูกศรทะลุ 2 เป้า (CD 3 วิ)\n§fShattershot §8T3 TRIGGER §7— AoE 3r เมื่อกระทบ (50\uE21F ดาเมจ, CD 5 วิ)\n§fGambit §8T3 TRIGGER §7— 60\uE21F ปกติ, 14.5\uE21F +50\uE21F bonus, 0.5\uE21F สังหาร, 25\uE21F ตีตัวเอง\n§fMultishot §8T4 TRIGGER §7— ยิง 3 ลูกพร้อมกัน (CD 4 วิ)\n§fExplosive Arrow §8T4 TRIGGER §7— AoE 3r เมื่อโดน (60\uE21F ดาเมจ, CD 3 วิ)\n§fOvercharge §8T4 STATE §7— สะสม +1 ดาเมจต่อ 60 วิที่ไม่ยิง (สูงสุด +50)\n§fPredator §8T5 PASSIVE §7— +1 ดาเมจต่อ 5 บล็อก (สูงสุด +30)\n§fPhantom Volley §8T5 TRIGGER §7— 15\uE21F โอกาสยิงลูกที่ 2 ฟรี (CD 2 วิ)\n§fSkyfall §8T5 TRIGGER §7— ลูกศรวาร์ปไปเหนือหัวศัตรูที่ใกล้ที่สุดแล้วตกใส่ (โดนแน่นอน) (CD 6 วิ)\n§fHailstorm §8T6 ACTIVE §7— ยิง 10 ลูกพร้อมกันในรัศมี 8r (80 Mana, CD 20 วิ)\n§fVoidshot §8T7 TRIGGER §7— เพิกเฉยเกราะ 30\uE21F (CD 5 วิ)\n§fEclipse §8T7 STATE §7— 20 kills -> AoE ทันที 12r (CD 60 วิ)\n§fCataclysm §8T7 ACTIVE §7— ระเบิด 15r, 40 ดาเมจ (150 Mana, CD 45 วิ)"
  }
 },
 "allweapon": {
  "en": {
   "title": "§lEncyclopedia — All-Weapon Runes",
   "body": "§eAll-Weapon Runes§r §8(Melee + Ranged + Tool)\n\n§fOpening Strike §8T1 §7+50\uE21F first hit per target.\n§fLifedrain §8T2 §710\uE21F lifesteal. (20 Mana, 2s CD)\n§fVenom §8T2 §7Poison + Wither on hit.\n§fWindfall §8T2 §7Kill: 50\uE21F x1, 13\uE21F x2, 2\uE21F x3 drops.\n§fColossus Bane §8T3 §7+50 flat vs giant mobs.\n§fTempest §8T3 §735\uE21F lightning strike on hit. (2s CD)\n§fScholar's Mark §8T3 §7x2 ClaudeRPG XP from kills.\n§fMana Surge §8T3 §7+30\uE21F dmg when mana full.\n§fResilience §8T3 §7-10\uE21F cooldown on all runes.\n§fFrenzy §8T4 §720 kills -> Speed+Strength 15s.\n§fSoul Reaper §8T4 §7100 souls -> buff + heal.\n§fFortune's Favor §8T4 §75\uE21F chance bonus drop on kill.\n§fVital Strike §8T4 §7Every 10 hits: x2 crit.\n§fMana Siphon §8T5 §7+5 Mana per hit. (1s CD)\n§fUndying §8T5 §7Survive first death per respawn at 1 HP.\n§fResonance §8T6 §7+5\uE21F gem ability effectiveness.\n§fAscendant §8T7 §7+1 flat dmg per 10 levels (max +20)."
  },
  "th": {
   "title": "§lสารานุกรม — All-Weapon Runes",
   "body": "§eAll-Weapon Runes§r §8(ทุกอาวุธและเครื่องมือ)\n\n§fOpening Strike §8T1 §7+50\uE21F ดาเมจฮิตแรกต่อเป้า\n§fLifedrain §8T2 §7ดูดเลือด 10\uE21F (20 Mana, CD 2 วิ)\n§fVenom §8T2 §7ติดพิษ + Wither เมื่อโจมตี\n§fWindfall §8T2 §7kill: 50\uE21F x1, 13\uE21F x2, 2\uE21F x3 ดรอป\n§fColossus Bane §8T3 §7+50 ดาเมจต่อมอนสเตอร์ยักษ์\n§fTempest §8T3 §735\uE21F โอกาสฟ้าผ่าเมื่อโจมตี (CD 2 วิ)\n§fScholar's Mark §8T3 §7x2 ClaudeRPG XP จาก kills\n§fMana Surge §8T3 §7+30\uE21F ดาเมจเมื่อ Mana เต็ม\n§fResilience §8T3 §7-10\uE21F cooldown ทุก Rune\n§fFrenzy §8T4 §720 kills -> Speed+Strength 15 วิ\n§fSoul Reaper §8T4 §7100 souls -> buff + ฟื้นฟู HP\n§fFortune's Favor §8T4 §75\uE21F โอกาสดรอปของโบนัสเมื่อ kill\n§fVital Strike §8T4 §7ทุก 10 ฮิต: crit x2\n§fMana Siphon §8T5 §7+5 Mana ต่อฮิต (CD 1 วิ)\n§fUndying §8T5 §7รอดตายครั้งแรกต่อ respawn ที่ 1 HP\n§fResonance §8T6 §7+5\uE21F ประสิทธิภาพ Gem ability ทุกตัว\n§fAscendant §8T7 §7+1 ดาเมจทุก 10 เลเวล (สูงสุด +20)"
  }
 },
 "tool": {
  "en": {
   "title": "§lEncyclopedia — Tool Runes",
   "body": "§2Tool Runes§r §8(Pickaxe / Axe / Shovel / Hoe)\n\n§fLucky Strike §8T1 TRIGGER §7— 5\uE21F chance x2 ore drop.\n§fSmelter's Touch §8T2 TRIGGER §7— Auto-smelt ores on break.\n§fEarthsplitter §8T3 PASSIVE §7— +24 vein break limit.\n§fGreed §8T4 TRIGGER §7— Bonus material drops per block.\n§fMagnetize §8T5 PASSIVE §7— Pull item drops within 6r.\n§fFortune's Harvest §8T6 TRIGGER §7— 40\uE21F chance x2-4 drops.\n§fVoid Siphon §8T7 TRIGGER §7— Every 100 blocks: +50 Mana."
  },
  "th": {
   "title": "§lสารานุกรม — Tool Runes",
   "body": "§2Tool Runes§r §8(พิกแอกซ์ / ขวาน / จอบ / พลั่ว)\n\n§fLucky Strike §8T1 §75\uE21F โอกาสดรอปแร่ x2\n§fSmelter's Touch §8T2 §7หลอมแร่อัตโนมัติเมื่อขุด\n§fEarthsplitter §8T3 §7เพิ่มลิมิต Vein +24 บล็อก\n§fGreed §8T4 §7ดรอปวัสดุโบนัสต่อบล็อกที่ขุด\n§fMagnetize §8T5 §7ดูดไอเทมดรอปในรัศมี 6 บล็อก\n§fFortune's Harvest §8T6 §740\uE21F โอกาสดรอป x2-4\n§fVoid Siphon §8T7 §7ทุก 100 บล็อก: ฟื้นฟู +50 Mana"
  }
 },
 "gems": {
  "en": {
   "title": "§lEncyclopedia — Gems & Enchants",
   "body": "§5Gems & Enchants§r §8(installed in the Armor socket)\n\n§fCommon\n§fSwiftness §7— +30\uE21F movement speed.\n§fVitality §7— +20 flat Max HP.\n§fFeatherfall §7— Negates all fall damage.\n§fKeen Eyes §7— Permanent Night Vision.\n\n§eUncommon\n§fBulwark §7— +5 flat armor.\n§fIntuition §7— +12\uE21F evasion (dodge chance).\n§fTenacity §7— -20\uE21F damage taken while below 50\uE21F HP.\n§fVigor §7— +1 HP regen per second.\n\n§aRare\n§fAssassination §7— +50\uE21F damage on sneak attacks.\n§fFortress §7— -40\uE21F damage taken and +3 HP/s while standing still and sneaking.\n§fReservoir §7— +50 max Mana.\n§fAdrenaline §7— +20\uE21F melee damage while below 30\uE21F HP.\n\n§3Unique\n§fReflection §7— 20\uE21F chance (40\uE21F with a shield) to reflect melee damage back at the attacker.\n§fCinderveil §7— Fire aura: damages nearby enemies, grants you Fire Resistance.\n§fGlacial Presence §7— Ice aura: slows nearby enemies; heals you in Powder Snow.\n§fSecond Wind §7— Once every 60s, auto-heals 15 HP when you drop below 20\uE21F HP.\n\n§9Legend\n§fImmunity §7— Trigger to clear all negative effects. (30s cooldown)\n§fVoid Escape §7— Auto-teleports you to spawn if you fall below Y -64.\n§fGuardian Shield §7— Charges a shield stack every 60s (max 3); each stack blocks or softens one hit.\n§fBulletproof §7— -25\uE21F damage taken from projectiles.\n\n§uEpic\n§fFrostflare §7— Fire + ice aura; heals you near fire/Powder Snow, damages & slows nearby enemies.\n§fFlight §7— Toggleable flight; costs 50 Mana per second while airborne.\n§fVampirism §7— Heal 15\uE21F of melee damage dealt as HP.\n§fStatic Field §7— Deals 3 damage to all enemies within 4 blocks every 2s.\n\n§4Mythical\n§fUndying §7— Once per 120s, cheats death: full heal when HP drops critically low.\n§fDomain §7— While sneaking, damages, slows and knocks back nearby hostile mobs (bosses exempt).\n§fBerserker §7— +25\uE21F damage dealt and -30\uE21F damage taken while below 25\uE21F HP.\n§fColossus §7— +30 flat Max HP and -10\uE21F damage taken, always active.\n\n%%GEMREQ%%\n§7Mag requirement: Common +15 ... Mythical +115"
  },
  "th": {
   "title": "§lสารานุกรม — Gems & Enchants",
   "body": "§5Gems & Enchants§r §8(ติดตั้งในช่องเดียวของเกราะ)\n\n§fCommon\n§fSwiftness §7— ความเร็วเคลื่อนที่ +30\uE21F\n§fVitality §7— พลังชีวิตสูงสุด +20 (ค่าคงที่)\n§fFeatherfall §7— ไม่โดนดาเมจจากการตกที่สูงเลย\n§fKeen Eyes §7— มองเห็นในที่มืดตลอดเวลา\n\n§eUncommon\n§fBulwark §7— เกราะเพิ่ม +5 (ค่าคงที่)\n§fIntuition §7— โอกาสหลบ (Evasion) +12\uE21F\n§fTenacity §7— ลดดาเมจที่รับ 20\uE21F เมื่อ HP ต่ำกว่า 50\uE21F\n§fVigor §7— ฟื้นฟู HP เพิ่ม +1 ต่อวินาที\n\n§aRare\n§fAssassination §7— ดาเมจ +50\uE21F เมื่อโจมตีขณะย่อ\n§fFortress §7— ลดดาเมจที่รับ 40\uE21F และฟื้นฟู +3 HP/วิ เมื่อย่อและยืนนิ่ง\n§fReservoir §7— Mana สูงสุด +50\n§fAdrenaline §7— ดาเมจระยะประชิด +20\uE21F เมื่อ HP ต่ำกว่า 30\uE21F\n\n§3Unique\n§fReflection §7— 20\uE21F โอกาส (40\uE21F ถ้าถือโล่) สะท้อนดาเมจกลับผู้โจมตี\n§fCinderveil §7— ออร่าไฟ: ทำดาเมจศัตรูใกล้เคียง และให้ Fire Resistance แก่ตัวเอง\n§fGlacial Presence §7— ออร่าน้ำแข็ง: ทำให้ศัตรูใกล้เคียงช้าลง และฟื้นฟู HP เมื่อยืนใน Powder Snow\n§fSecond Wind §7— ทุก 60 วิ ถ้า HP ต่ำกว่า 20\uE21F จะฟื้นฟู HP อัตโนมัติ 15 หน่วย\n\n§9Legend\n§fImmunity §7— กดใช้เพื่อล้างสถานะติดลบทั้งหมด (คูลดาวน์ 30 วิ)\n§fVoid Escape §7— วาร์ปกลับจุดเกิดอัตโนมัติเมื่อตกต่ำกว่า Y -64\n§fGuardian Shield §7— สะสมชาร์จโล่ทุก 60 วิ (สูงสุด 3) แต่ละชาร์จกันหรือลดดาเมจ 1 ครั้ง\n§fBulletproof §7— ลดดาเมจจากกระสุน/ธนู 25\uE21F\n\n§uEpic\n§fFrostflare §7— ออร่าไฟ+น้ำแข็งรวมกัน ฟื้นฟู HP เมื่ออยู่ใกล้ไฟ/Powder Snow ทำดาเมจและหน่วงศัตรูใกล้เคียง\n§fFlight §7— บินได้ (เปิด/ปิดได้) ใช้ Mana 50 ต่อวินาทีขณะบิน\n§fVampirism §7— ดูดเลือด 15\uE21F ของดาเมจระยะประชิดที่ตี กลับมาเป็น HP\n§fStatic Field §7— ทำดาเมจ 3 หน่วยแก่ศัตรูทุกตัวในระยะ 4 บล็อก ทุก 2 วิ\n\n§4Mythical\n§fUndying §7— ทุก 120 วิ รอดตายอัตโนมัติ 1 ครั้ง: ฟื้นฟู HP เต็มเมื่อ HP ต่ำวิกฤต\n§fDomain §7— ขณะย่อ ทำดาเมจ หน่วง และผลักมอนสเตอร์ศัตรูใกล้เคียง (ยกเว้นบอส)\n§fBerserker §7— ดาเมจ +25\uE21F และลดดาเมจที่รับ 30\uE21F เมื่อ HP ต่ำกว่า 25\uE21F\n§fColossus §7— พลังชีวิตสูงสุด +30 และลดดาเมจที่รับ 10\uE21F ตลอดเวลา\n\n%%GEMREQ%%\n§7Mag ที่ต้องการ: Common +15 ... Mythical +115"
  }
 }
};
const LEGACY_STATIC = {
 "restrictions": {
  "en": {
   "title": "§lItem Restrictions",
   "body": "§fWeapons, tools, and armor may have minimum stat Requirements shown in their Lore.\n\n§fIf you don't meet them:\n§f- §cMelee / Ranged §fwon't deal damage\n§f- §6Tools §fcan't break blocks\n§f- §aArmor §fautomatically unequips\n\n§fEnchanting an item increases its §uPsi §frequirement."
  },
  "th": {
   "title": "§lข้อจำกัดของไอเทม",
   "body": "§fอาวุธ เครื่องมือ และเกราะอาจต้องการค่าสถานะขั้นต่ำ ดู §7Requirements §fใน Lore\n\n§fถ้าค่าไม่พอ:\n§f- §cอาวุธ Melee/Ranged §fไม่สร้างดาเมจ\n§f- §6Tool §fทำลายบล็อกไม่ได้\n§f- §aเกราะ §fถูกถอดออกอัตโนมัติ\n\n§fการตีเอนชานต์จะเพิ่มค่า §uPsi §fที่ต้องใช้"
  }
 },
 "combat": {
  "en": {
   "title": "§lCombat Mechanics",
   "body": "§fEvasion §7(Armor): §fchance to fully dodge a hit. Boosted by §bIntuition §fGem.\n\n§fArmor §7(Armor): §freduces damage; partly healed back. Boosted by §aBulwark §fGem.\n\n§fChain Attack §7(Melee): §fhits nearby enemies for a \uE21F of your damage.\n\n§fStunt §7(Ranged): §fchance to briefly freeze a target.\n\n§fScavenging §7(Ranged): §fchance to double item drops on a kill.\n\n§fGem Abilities add further combat effects — see the §5Gem System §fpage."
  },
  "th": {
   "title": "§lกลไกการต่อสู้",
   "body": "§fEvasion §7(เกราะ): §fโอกาสหลบการโจมตีได้เต็มๆ — เพิ่มด้วยอัญมณี §bIntuition\n\n§fArmor §7(เกราะ): §fลดดาเมจ — เพิ่มด้วยอัญมณี §aBulwark\n\n§fChain Attack §7(Melee): §fโจมตีศัตรูใกล้เคียงเพิ่มด้วย \uE21F ของดาเมจที่ตี\n\n§fStunt §7(Ranged): §fโอกาสสตันเป้าหมาย\n\n§fScavenging §7(Ranged): §fโอกาสดรอปของเพิ่มสองเท่าตอนฆ่า\n\n§fอัญมณีเพิ่มเอฟเฟคการต่อสู้อีกมาก — ดูหน้า §5ระบบอัญมณี"
  }
 },
 "mining": {
  "en": {
   "title": "§lMining Mechanics",
   "body": "§fMining configured ores grants bonus XP.\n\n§fVein §7(Tool Augment): §fbreaks connected ore blocks for free.\n§f  • Vein drops come from vanilla loot tables, so §eFortune§f and §eSilk Touch§f work as normal. Each block costs 1 durability.\n§f  • §eShears§f can Vein leaves (Augment: Vein only, no Runes, no Gems).\n§f  • §eEarthsplitter §fRune adds §f+24 Vein blocks §f(global cap: 48).\n\n§fLuck §7(Pickaxe Augment): §fchance for a bonus ore drop (Fortune applies; Silk Touch gives the ore block).\n\n§fLooting §7(vanilla): §fraises addon drop chances, e.g. Fortune's Favor and evolved-mob Gem / Core / Essence drops.\n\n§fInsufficient §6Exc §fprevents a tool from breaking blocks entirely."
  },
  "th": {
   "title": "§lกลไกการขุด",
   "body": "§fการขุดแร่ที่กำหนดไว้จะได้ XP โบนัส\n\n§fVein §7(Tool Augment): §fทำลายบล็อกแร่ชนิดเดียวกันที่ต่อกันให้ฟรี\n§f  • ของดรอปจาก Vein มาจาก loot table ของเกม จึงใช้ §eFortune§f และ §eSilk Touch§f ได้ตามปกติ และเสียความทนทาน 1 ต่อบล็อก\n§f  • §eกรรไกร§f ใช้ Vein กับใบไม้ได้ (Augment ได้เฉพาะ Vein ใส่ Rune/Gem ไม่ได้)\n§f  • §eEarthsplitter §fRune เพิ่ม §f+24 บล็อก Vein §f(แคป: 48)\n\n§fLuck §7(พิกแอกซ์): §fโอกาสได้ดรอปแร่โบนัส (Fortune มีผล, Silk Touch ได้บล็อกแร่)\n\n§fLooting §7(vanilla): §fเพิ่มโอกาสดรอปของแอดออน เช่น Fortune's Favor และ Gem / Core / Essence จากม็อบวิวัฒนาการ\n\n§fถ้า §6Exc §fไม่พอ เครื่องมือจะทำลายบล็อกไม่ได้เลย"
  }
 },
 "augment": {
  "en": {
   "title": "§lAugment System",
   "body": "§fEquipment can roll random §9Augment §fstats. Each item type has its own stat pool:\n\n§fMelee: §7Atk Dmg, Chain Attack, Chain Chance, Chain Damage, Move Speed\n§fRanged: §7Atk Dmg, Stunt, Move Speed, Scavenging\n§fTool: §7Atk Dmg, Vein §8(Pickaxes also roll Luck; Shears roll Vein only)\n§fArmor: §7Move Speed, Armor, Health, Evasion, Mana, Mana Regen\n\n§fOpen §9Augment Stats §f(from your Stats Book) to see totals and toggle stats on or off."
  },
  "th": {
   "title": "§lระบบ Augment",
   "body": "§fอุปกรณ์จะสุ่มค่า §9Augment §fได้ แต่ละประเภทมีค่าของตัวเอง:\n\n§fMelee: §7Atk Dmg, Chain Attack, Chain Chance, Chain Damage, Move Speed\n§fRanged: §7Atk Dmg, Stunt, Move Speed, Scavenging\n§fTool: §7Atk Dmg, Vein §8(พิกแอกซ์ได้ Luck เพิ่ม, กรรไกรได้ Vein อย่างเดียว)\n§fArmor: §7Move Speed, Armor, Health, Evasion, Mana, Mana Regen\n\n§fเปิดเมนู §9Augment Stats §f(จาก Stats Book) เพื่อดูค่ารวมและเปิด-ปิดค่าแต่ละตัวได้"
  }
 },
 "reforge": {
  "en": {
   "title": "§lReforge & Anvil",
   "body": "§fSneak + right-click any Anvil, or right-click while holding a §6Reforge Hammer §fto open the Reforge menu.\n\n§9Reroll §f— randomise all unlocked stats (Hammer durability + 1 Augment Crystal)\n§dMax §f— set one stat to its maximum (Hammer durability + 1 Augment Core)\n§eLock / Unlock §f— protect a stat from Reroll (Lock: durability + 2 Crystals; Unlock: durability only)\n§cRemove §f— clear all stats for free\n\n§fHigh rolls are intentionally rare.\n\n§bGem Fusion §f(same menu) §f— combine 5 Gems of one tier into 1 Gem of the next tier up, or just 2 Gems + 1 Augment Core. Costs Hammer durability. §dFuse All §f(Standard) fuses every Gem in your inventory as high as possible until nothing is left or the Hammer breaks.\n\n§6Perfect Salvage §f— on the Salvage confirm screen, spend 1 Augment Core to get 100% of the materials back."
  },
  "th": {
   "title": "§lการ Reforge และทั่ง",
   "body": "§fกด Shift + คลิกขวาที่ทั่ง หรือถือ §6Reforge Hammer §fแล้วคลิกขวาที่ทั่ง เพื่อเปิดเมนู Reforge\n\n§9Reroll §f— สุ่มค่า Augment ใหม่ทุกตัวที่ไม่ได้ล็อก (ความทนทาน Hammer + Augment Crystal 1 อัน)\n§dMax §f— ตั้งค่า Augment 1 ค่าเป็นสูงสุด (ความทนทาน + Augment Core 1 อัน)\n§eLock / Unlock §f— ล็อกค่าไม่ให้ถูก Reroll (Lock: ความทนทาน + Crystal 2 อัน, Unlock: ความทนทานอย่างเดียว)\n§cRemove §f— ล้างค่า Augment ทั้งหมด ฟรี\n\n§fการได้ค่าสูงๆ ถูกออกแบบให้หายากโดยตั้งใจ\n\n§bGem Fusion §f(เมนูเดียวกัน) §f— รวมอัญมณี 5 เม็ดเทียร์เดียวกัน หรือใช้แค่ 2 เม็ด + Augment Core 1 อัน เป็นอัญมณีเทียร์ถัดไป 1 เม็ด ใช้ความทนทาน Hammer §dFuse All §f(แบบ Standard) รวมอัญมณีทั้งหมดในช่องเก็บของให้สูงที่สุดเท่าที่ทำได้ จนไม่เหลือให้รวมหรือ Hammer พัง\n\n§6Perfect Salvage §f— หน้ายืนยัน Salvage ใช้ Augment Core 1 อัน เพื่อได้วัสดุคืน 100%"
  }
 },
 "mana": {
  "en": {
   "title": "§lMana",
   "body": "§fMax Mana = §f50 + (§bMag §f× 10) §f+ Augment bonuses + §3Reservoir §fGem bonus.\n\n§fMana regenerates 1/s base, +1 per §fWis§f, + Augment and Gem regen bonuses.\n\n§fMana is consumed by active §eRune §fabilities (Stormcall, Warden's Echo, Lifedrain, etc.) and by the §bFlight §fGem ability (50/s while airborne).\n\n§fIf Mana hits 0 while flying, §bFlight §fis disabled automatically."
  },
  "th": {
   "title": "§lมานา",
   "body": "§fMana สูงสุด = §f50 + (§bMag §f× 10) §f+ โบนัสจาก Augment + โบนัสอัญมณี §3Reservoir\n\n§fMana ฟื้นฟู 1/วินาที บวก 1 ต่อ §fWis §fและโบนัสจาก Augment และ Gem\n\n§fMana จะถูกใช้โดย §eRune §fที่ Active ได้ (Stormcall, Warden's Echo, Lifedrain ฯลฯ) และอัญมณี §bFlight §f(50/วินาที ขณะบิน)\n\n§fถ้า Mana หมดขณะบิน §bFlight §fจะถูกปิดอัตโนมัติ"
  }
 }
};
const featReq = (id) => ProgressionManager.requirementText(id);
const legacy = (id, lang, extra = "") => {
    const p = LEGACY_STATIC[id][lang];
    return { title: p.title, body: extra ? `${p.body}\n\n${extra}` : p.body };
};
const capOf = (stat) => STAT_CAPS[stat] ?? DEFAULT_STAT_CAP;

// ─── Dynamic encyclopedia (Gems / Runes): built from the registries + config + lore, so it never goes stale ───
const stripLore = (l) => l.replace(/^\xa7r(\xa78|\xa77)?/, "");
const isNoise = (l) => !l || l.startsWith("Chorus Synergy") || l.startsWith("Stacks across");

function gemEncy(lang, tierIds, title) {
    const rows = [];
    for (const tid of tierIds) {
        const tier = GEM_TIERS.find((x) => x.id === tid);
        rows.push(`${tier?.color ?? "§f"}${tier?.label ?? tid}`);
        for (const key of GEM_REGISTRY[tid].abilities) {
            const def = GEM_DEFS[key];
            const cats = def.cats.length === 4 ? t(lang, "All armor", "เกราะทุกชิ้น") : [...def.cats].map((c) => GEM_CATEGORY_NAME[c]).join(" / ");
            const desc = buildGemSkillLoreLines(def.name, null).map(stripLore).filter((l) => !isNoise(l)).join(" ");
            rows.push(`§f${def.name} §8[${cats}]`, `§7  ${desc}`);
        }
        rows.push("");
    }
    return { title, body: L(t(lang, "§dGem Abilities§r §8(no levels; Gem Potency boosts the power numbers)", "§dGem Ability§r §8(ไม่มีเลเวล Gem Potency เพิ่มค่าพลัง)"), "", ...rows).trimEnd() };
}

function runeEncy(lang, pools, title) {
    const rows = [];
    for (const pool of pools) {
        const ids = Object.keys(RUNE_REGISTRY)
            .filter((id) => RUNE_REGISTRY[id].category === pool)
            .sort((a, b) => RUNE_REGISTRY[a].tier - RUNE_REGISTRY[b].tier);
        if (!ids.length) continue;
        rows.push(`§e${RUNE_POOL_LABELS[pool] ?? pool}`);
        for (const id of ids) {
            const m = RUNE_REGISTRY[id];
            const d = describeEffects(id, 4, 0, ["pickaxe", "axe", "shovel", "hoe", "all_tool"].includes(pool));
            rows.push(`§f${m.name} §8T${m.tier}`);
            if (d.good.length) rows.push(`§a  ${d.good.join(", ")}`);
            if (d.bad.length) rows.push(`§c  ${d.bad.join(", ")}`);
        }
        rows.push("");
    }
    return { title, body: L(t(lang, "§8Values shown at Lv 4 (base). Levels run Lv 1-8; drawbacks shrink as Lv rises.", "§8ค่าที่แสดงคือ Lv 4 (ฐาน) เลเวลมี Lv 1-8 ข้อเสียจะลดลงเมื่อ Lv สูงขึ้น"), "", ...rows).trimEnd() };
}

const PAGES = {

    // ═══ Getting Started ═══════════════════════════════════════════════════

    basics: (lang) => ({
        title: t(lang, "§lBasics", "§lพื้นฐาน"),
        body: t(lang,
            L("§fUse your §bStats Book §fto open the Status Menu at any time.", "",
              "§fFrom it you can spend Points on stats, open §6Prestige§f, §bMastery §fand §4Ascension§f, view your Chorus set, check Augment totals, or reset.", "",
              "§fThe HUD on the §eleft of your screen §fshows your Name, Level, XP and Mana.", "",
              "§fGain XP from killing mobs, mining ore, eating food and fishing. XP stops at your Max Level — keep playing to earn §bMastery §fXP and prepare to §6Prestige§f."),
            L("§fใช้ §bStats Book §fเพื่อเปิด Status Menu ได้ตลอดเวลา", "",
              "§fจากเมนูนี้คุณเพิ่มค่าสถานะด้วย Point, เปิด §6Prestige§f, §bMastery §fและ §4Ascension§f, ดูชุด Chorus, ดูโบนัส Augment หรือรีเซ็ตได้", "",
              "§fHUD §eด้านซ้ายของหน้าจอ §fแสดงชื่อ, เลเวล, XP และ Mana", "",
              "§fได้ XP จากการฆ่ามอน ขุดแร่ กินอาหาร และตกปลา เมื่อถึงเลเวลสูงสุด XP จะหยุดเพิ่ม ให้เก็บ XP §bMastery §fและเตรียม §6Prestige §fต่อ")),
    }),

    stats: (lang) => ({
        title: t(lang, "§lStats & Leveling", "§lค่าสถานะและเลเวล"),
        body: t(lang,
            L("§fYou have 9 stats: §cStr§f, §aDef§f, §bAgi§f, §uPsi§f, §6Exc§f, §wMag§f, §fWis§f, §4Con §fand §4Vit§f.", "",
              `§fEach Level gives §e${CONFIG.POINTS_PER_LEVEL} Points§f. Spend them one at a time, or all at once with §bCustom Allocation§f.`, "",
              `§fMost stats cap at §e${DEFAULT_STAT_CAP}§f. Exceptions: Mag §e${capOf("mag")}§f, Wis §e${capOf("wis")}§f, Con §e${capOf("con")}§f, Vit §e${capOf("vit")}§f. §6Prestige §fraises every cap.`, "",
              "§fMany items need minimum stats — check the item's Lore. Enchanting raises the §uPsi §frequirement."),
            L("§fมีค่าสถานะ 9 ตัว: §cStr§f, §aDef§f, §bAgi§f, §uPsi§f, §6Exc§f, §wMag§f, §fWis§f, §4Con §fและ §4Vit", "",
              `§fทุกเลเวลได้ §e${CONFIG.POINTS_PER_LEVEL} Point§f ใช้ทีละอัน หรือหลายอันพร้อมกันด้วย §bCustom Allocation`, "",
              `§fค่าสถานะส่วนใหญ่มีเพดาน §e${DEFAULT_STAT_CAP}§f ยกเว้น Mag §e${capOf("mag")}§f, Wis §e${capOf("wis")}§f, Con §e${capOf("con")}§f, Vit §e${capOf("vit")}§f และ §6Prestige §fจะเพิ่มเพดานทุกตัว`, "",
              "§fไอเทมหลายชิ้นต้องการค่าสถานะขั้นต่ำ ดู Lore ของไอเทม การตีเอนชานต์จะเพิ่มค่า §uPsi §fที่ต้องใช้")),
    }),

    health: (lang) => ({
        title: t(lang, "§lHealth", "§lพลังชีวิต"),
        body: t(lang,
            L(`§fMax HP = §c${CONFIG.HP_BASE} §f+ §4Con §fx ${CONFIG.HP_PER_CON} + Augment §7Health §fx ${CONFIG.HP_AUGMENT_MULT} + Gem and Perk bonuses.`, "",
              `§fHP regenerates §c${CONFIG.HP_REGEN_PER_SEC}/s §fplus §4Vit §fx ${CONFIG.HP_REGEN_PER_VIT}/s, plus Gem and Perk regen.`, "",
              "§fPrestige resets Con and Vit to 0, so Max HP falls back to the base — rebuild it as you level again."),
            L(`§fHP สูงสุด = §c${CONFIG.HP_BASE} §f+ §4Con §fx ${CONFIG.HP_PER_CON} + Augment §7Health §fx ${CONFIG.HP_AUGMENT_MULT} + โบนัสจาก Gem และ Perk`, "",
              `§fHP ฟื้นฟู §c${CONFIG.HP_REGEN_PER_SEC}/วินาที §fบวก §4Vit §fx ${CONFIG.HP_REGEN_PER_VIT}/วินาที และโบนัสฟื้นฟูจาก Gem / Perk`, "",
              "§fเมื่อ Prestige ค่า Con และ Vit จะกลับเป็น 0 HP สูงสุดจึงลดลงเท่าค่าพื้นฐาน ต้องสร้างใหม่ตอนเลเวลอัพ")),
    }),

    mana: (lang) => legacy("mana", lang, t(lang,
        "§fThe §3Deep Well §fPerk adds more Max Mana.",
        "§fPerk §3Deep Well §fเพิ่ม Mana สูงสุดได้อีก")),

    restrictions: (lang) => legacy("restrictions", lang),

    guidequest: (lang) => ({
        title: t(lang, "§lGuide Quest", "§lไกด์เควส"),
        body: t(lang,
            L("§fA step-by-step quest that teaches the game in the order you unlock it. It checks itself while you play, so just do what the current step says. §eThere are no rewards§f: it is a guide only.", "",
              "§bChapters", "",
              "§f1 Basics · 2 Prestige · 3 Augment (Prestige 1) · 4 Chorus (Prestige 2) · 5 Mastery & Ascension · 6 Gem (Prestige 4, Ascension 2) · 7 Rune (Prestige 6, Ascension 3) · 8 Advanced Chorus (Resonance, Transcend, Fusion). 42 steps plus 2 side tasks; the quest ends when step 8.7 (Genesis set) is done.", "",
              "§bGood to know", "",
              "§f• Steps you already did are skipped automatically, so existing players catch up in seconds.",
              "§f• Side tasks (◇) never block the quest and complete by themselves when you do them.",
              "§f• Some steps need the whole world to reach an Ascension level; anyone with enough Prestige can raise it.",
              "§f• Enchanted mobs drop Augment Crystals, and 1 Crystal + Diamond + Lapis crafts 2 Crystals.", "",
              "§7Open it from Script Tool > Guides & Items, or Status Menu > Progression. Settings can turn its pop-ups off or switch it to Thai."),
            L("§fเควสที่สอนเกมทีละขั้นตามลำดับที่คุณปลดล็อก ตรวจเองระหว่างเล่น ทำตามขั้นปัจจุบันได้เลย §eไม่มีรางวัล§f เป็นไกด์อย่างเดียว", "",
              "§bรายการบท", "",
              "§f1 พื้นฐาน · 2 Prestige · 3 Augment (Prestige 1) · 4 Chorus (Prestige 2) · 5 Mastery และ Ascension · 6 Gem (Prestige 4, Ascension 2) · 7 Rune (Prestige 6, Ascension 3) · 8 Chorus ขั้นสูง (Resonance, Transcend, Fusion) รวม 42 ขั้นและเควสเสริม 2 อัน เควสจบเมื่อทำขั้น 8.7 (ชุด Genesis) สำเร็จ", "",
              "§bควรรู้", "",
              "§f• ขั้นที่เคยทำแล้วจะข้ามให้อัตโนมัติ ผู้เล่นเดิมจึงตามทันในไม่กี่วินาที",
              "§f• เควสเสริม (◇) ไม่บล็อกเควสหลัก และสำเร็จเองเมื่อคุณทำ",
              "§f• บางขั้นต้องให้ทั้งโลกถึงระดับ Ascension ที่กำหนด ผู้เล่นที่มี Prestige พอเป็นคนยกให้ได้",
              "§f• มอน Enchanted ดรอป Augment Crystal และคราฟต์ Crystal 1 + Diamond + Lapis ได้ Crystal 2 อัน", "",
              "§7เปิดได้จาก Script Tool > Guides & Items หรือ Status Menu > Progression ใน Settings ปิดป๊อปอัปหรือสลับเป็นภาษาไทยได้")),
        actions: [{
            label: t(lang, "§a▶ Open Guide Quest", "§a▶ เปิด Guide Quest"),
            icon: "textures/icons/progression",
            run: (player) => GuideQuestGui.openMain(player),
        }],
    }),

    redeem: (lang) => ({
        title: t(lang, "§lRedeem Codes", "§lการกรอกโค้ด"),
        body: t(lang,
            L("§fUse the button below or the §6Script Tool §fto enter a code and claim items.", "",
              "§fIf your inventory is full when you redeem, items drop at your feet — they are never silently lost.", "",
              "§fSome codes can only be used a limited number of times per player. Check §bList Redeemed Codes §fto see your progress."),
            L("§fกดปุ่มด้านล่างหรือใช้ §6Script Tool §fเพื่อกรอกโค้ดรับไอเทม", "",
              "§fถ้า Inventory เต็มตอน Redeem ไอเทมจะดรอปที่เท้า ไม่มีไอเทมหายเงียบๆ", "",
              "§fบางโค้ดกรอกได้จำกัดครั้งต่อผู้เล่น เช็คจำนวนที่ใช้ไปแล้วที่ §bList Redeemed Codes")),
        actions: [{
            label: t(lang, "§e🎁 Enter Redeem Code", "§e🎁 กรอกโค้ด Redeem"),
            icon: "textures/icons/blue_plus",
            run: (player) => RedeemManager.openRedeemMenu(player),
        }],
    }),

    // ═══ Progression ═══════════════════════════════════════════════════════

    roadmap: (lang) => {
        const F = PROGRESSION.FEATURES;
        return {
            title: t(lang, "§lProgression Roadmap", "§lแผนที่ความก้าวหน้า"),
            body: t(lang,
                L(`§fReach Max Level (Lv.${PROGRESSION.BASE_MAX_LEVEL}) → §6Prestige §f→ higher caps, new unlocks. Repeat.`, "",
                  `§9Augment §8— §fLv.${F.augment.level}`,
                  `§dChorus §8— §fLv.${F.chorus.level}`,
                  `§5Gem §8— §f${featReq("gem")}`,
                  `§bRune §8— §f${featReq("rune")}`,
                  `§bMastery §8— §fPrestige ${MASTERY.UNLOCK_PRESTIGE}`,
                  `§4Ascension §8— §fPrestige ${ASCENSION.REQUIRED_PRESTIGE[1]}`, "",
                  "§fLevel unlocks are permanent — a Prestige never locks them again."),
                L(`§fถึงเลเวลสูงสุด (Lv.${PROGRESSION.BASE_MAX_LEVEL}) → §6Prestige §f→ เพดานสูงขึ้น ปลดล็อกของใหม่ แล้ววนซ้ำ`, "",
                  `§9Augment §8— §fLv.${F.augment.level}`,
                  `§dChorus §8— §fLv.${F.chorus.level}`,
                  `§5Gem §8— §f${featReq("gem")}`,
                  `§bRune §8— §f${featReq("rune")}`,
                  `§bMastery §8— §fPrestige ${MASTERY.UNLOCK_PRESTIGE}`,
                  `§4Ascension §8— §fPrestige ${ASCENSION.REQUIRED_PRESTIGE[1]}`, "",
                  "§fของที่ปลดด้วยเลเวลถาวร Prestige จะไม่ล็อกกลับ")),
        };
    },

    prestige: (lang) => {
        const step = pc(PRESTIGE.LIMIT_BREAK_STEP);
        return {
            title: t(lang, "§lPrestige", "§lPrestige"),
            body: t(lang,
                L(`§fAt §eMax Level §f(Lv.${PROGRESSION.BASE_MAX_LEVEL}, +${PROGRESSION.MAX_LEVEL_PER_PRESTIGE} per Prestige) open §6Prestige §fin the Status Menu.`, "",
                  "§cResets: §fLevel, XP, Points and every stat.",
                  "§aKeeps: §funlocked systems, your items (sockets, Runes, Gems, Elements), Perks and Mastery.",
                  `§aGains: §fMax Level +${PROGRESSION.MAX_LEVEL_PER_PRESTIGE}, every stat cap +${step}${PCT} of its base, and §e1 Perk §fpick.`, "",
                  `§eCost: §f${ACTION_COSTS.PRESTIGE.BASE} §6${ACTION_COSTS.PRESTIGE.NAME}§f (+${ACTION_COSTS.PRESTIGE.PER} per Prestige, max ${ACTION_COSTS.PRESTIGE.CAP}), consumed. Craft: 2 Resonant Ink + Diamond Block + Gold Block.`, "",
                  `§fThere is no Prestige limit, but from Prestige ${PRESTIGE.FULL_UNTIL + 1} each step is weaker (x${PRESTIGE.DECAY} per Prestige, never below x${PRESTIGE.MIN_FACTOR}).`),
                L(`§fเมื่อถึง §eเลเวลสูงสุด §f(Lv.${PROGRESSION.BASE_MAX_LEVEL}, +${PROGRESSION.MAX_LEVEL_PER_PRESTIGE} ต่อ Prestige) เปิด §6Prestige §fใน Status Menu`, "",
                  "§cรีเซ็ต: §fเลเวล, XP, Point และค่าสถานะทั้งหมด",
                  "§aคงไว้: §fระบบที่ปลดแล้ว ไอเทมของคุณ (ช่อง Socket, Rune, Gem, Element) Perk และ Mastery",
                  `§aได้รับ: §fเลเวลสูงสุด +${PROGRESSION.MAX_LEVEL_PER_PRESTIGE}, เพดานค่าสถานะทุกตัว +${step}${PCT} ของค่าฐาน และเลือก §ePerk 1 อย่าง`, "",
                  `§eค่าใช้จ่าย: §f${ACTION_COSTS.PRESTIGE.BASE} §6${ACTION_COSTS.PRESTIGE.NAME}§f (+${ACTION_COSTS.PRESTIGE.PER} ต่อ Prestige สูงสุด ${ACTION_COSTS.PRESTIGE.CAP}) ถูกใช้หมดไป คราฟต์: Resonant Ink 2 + Diamond Block + Gold Block`, "",
                  `§fไม่จำกัดจำนวน Prestige แต่ตั้งแต่ Prestige ${PRESTIGE.FULL_UNTIL + 1} แต่ละขั้นจะอ่อนลง (x${PRESTIGE.DECAY} ต่อ Prestige ต่ำสุด x${PRESTIGE.MIN_FACTOR})`)),
        };
    },

    achievements: (lang) => {
        const per = (id) => ACH_DEFS.filter((d) => d.cat === id).length;
        const hidden = ACH_DEFS.filter((d) => d.hidden).length;
        return {
            title: t(lang, "\u00a7lAchievements", "\u00a7l\u0e23\u0e30\u0e1a\u0e1a\u0e04\u0e27\u0e32\u0e21\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08 (Achievement)"),
            body: t(lang,
                L(`\u00a7fThere are \u00a7e${ACH_DEFS.length} Achievements \u00a7fin 3 categories: \u00a7cCombat \u00a7f(${per("combat")}), \u00a7aWork & Support \u00a7f(${per("work")}) and \u00a7dMisc & Silly \u00a7f(${per("misc")}).`,
                  "\u00a77No rewards and no effect on gameplay, only bragging rights.", "",
                  "\u00a7eOpen: \u00a7fthe \u00a7eAchievements \u00a7fbutton in the main menu, or the Script Tool.",
                  "\u00a7eTiers: \u00a76Bronze \u00a77Silver \u00a7eGold \u00a7bPlatinum \u00a7dMythic\u00a7f. A coloured icon means done, a grey icon means not yet.", "",
                  `\u00a7e${hidden} Hidden Achievements \u00a7fshow as \u00a78???\u00a7f until you complete them.`,
                  "\u00a7aSaved per player. \u00a7fPrestige, Reset All and Delete All never reset them.",
                  "\u00a7cCreative and Spectator mode do not count.",
                  "\u00a7fLevel, Prestige, Ascension, Mastery and Chorus set Achievements are filled in from your current progress, so players who started earlier get them back."),
                L(`\u00a7f\u0e21\u0e35\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14 \u00a7e${ACH_DEFS.length} \u0e23\u0e32\u0e22\u0e01\u0e32\u0e23 \u00a7f\u0e41\u0e1a\u0e48\u0e07\u0e40\u0e1b\u0e47\u0e19 3 \u0e2b\u0e21\u0e27\u0e14: \u00a7c\u0e15\u0e48\u0e2d\u0e2a\u0e39\u0e49 \u00a7f(${per("combat")}), \u00a7a\u0e17\u0e33\u0e07\u0e32\u0e19\u0e41\u0e25\u0e30\u0e2a\u0e19\u0e31\u0e1a\u0e2a\u0e19\u0e38\u0e19 \u00a7f(${per("work")}) \u0e41\u0e25\u0e30 \u00a7d\u0e08\u0e34\u0e1b\u0e32\u0e16\u0e30 \u00a7f(${per("misc")})`,
                  "\u00a77\u0e44\u0e21\u0e48\u0e21\u0e35\u0e23\u0e32\u0e07\u0e27\u0e31\u0e25\u0e41\u0e25\u0e30\u0e44\u0e21\u0e48\u0e01\u0e23\u0e30\u0e17\u0e1a\u0e01\u0e32\u0e23\u0e40\u0e25\u0e48\u0e19 \u0e40\u0e1b\u0e47\u0e19\u0e41\u0e04\u0e48\u0e04\u0e27\u0e32\u0e21\u0e20\u0e39\u0e21\u0e34\u0e43\u0e08", "",
                  "\u00a7e\u0e40\u0e1b\u0e34\u0e14\u0e44\u0e14\u0e49: \u00a7f\u0e1b\u0e38\u0e48\u0e21 \u00a7eAchievements \u00a7f\u0e43\u0e19\u0e40\u0e21\u0e19\u0e39\u0e2b\u0e25\u0e31\u0e01 \u0e2b\u0e23\u0e37\u0e2d Script Tool",
                  "\u00a7e\u0e23\u0e30\u0e14\u0e31\u0e1a: \u00a76\u0e1a\u0e23\u0e2d\u0e19\u0e0b\u0e4c \u00a77\u0e40\u0e07\u0e34\u0e19 \u00a7e\u0e17\u0e2d\u0e07 \u00a7b\u0e41\u0e1e\u0e25\u0e15\u0e15\u0e34\u0e19\u0e31\u0e21 \u00a7d\u0e15\u0e33\u0e19\u0e32\u0e19 \u00a7f\u0e44\u0e2d\u0e04\u0e2d\u0e19\u0e21\u0e35\u0e2a\u0e35 = \u0e17\u0e33\u0e41\u0e25\u0e49\u0e27 \u0e44\u0e2d\u0e04\u0e2d\u0e19\u0e2a\u0e35\u0e40\u0e17\u0e32 = \u0e22\u0e31\u0e07\u0e44\u0e21\u0e48\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08", "",
                  `\u00a7e${hidden} \u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e0b\u0e48\u0e2d\u0e19 \u00a7f\u0e08\u0e30\u0e41\u0e2a\u0e14\u0e07\u0e40\u0e1b\u0e47\u0e19 \u00a78???\u00a7f \u0e08\u0e19\u0e01\u0e27\u0e48\u0e32\u0e08\u0e30\u0e17\u0e33\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08`,
                  "\u00a7a\u0e1a\u0e31\u0e19\u0e17\u0e36\u0e01\u0e41\u0e22\u0e01\u0e15\u0e32\u0e21\u0e1c\u0e39\u0e49\u0e40\u0e25\u0e48\u0e19 \u00a7fPrestige, Reset All \u0e41\u0e25\u0e30 Delete All \u0e44\u0e21\u0e48\u0e17\u0e33\u0e43\u0e2b\u0e49\u0e04\u0e27\u0e32\u0e21\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08\u0e16\u0e39\u0e01\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15",
                  "\u00a7c\u0e42\u0e2b\u0e21\u0e14 Creative \u0e41\u0e25\u0e30 Spectator \u0e44\u0e21\u0e48\u0e19\u0e31\u0e1a",
                  "\u00a7f\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e17\u0e35\u0e48\u0e2d\u0e34\u0e07\u0e08\u0e32\u0e01\u0e2a\u0e16\u0e32\u0e19\u0e30\u0e1b\u0e31\u0e08\u0e08\u0e38\u0e1a\u0e31\u0e19 (\u0e40\u0e25\u0e40\u0e27\u0e25, Prestige, Ascension, Mastery, \u0e0a\u0e38\u0e14 Chorus) \u0e08\u0e30\u0e44\u0e14\u0e49\u0e04\u0e37\u0e19\u0e08\u0e32\u0e01\u0e04\u0e27\u0e32\u0e21\u0e04\u0e37\u0e1a\u0e2b\u0e19\u0e49\u0e32\u0e1b\u0e31\u0e08\u0e08\u0e38\u0e1a\u0e31\u0e19 \u0e1c\u0e39\u0e49\u0e40\u0e25\u0e48\u0e19\u0e40\u0e01\u0e48\u0e32\u0e08\u0e36\u0e07\u0e44\u0e21\u0e48\u0e40\u0e2a\u0e35\u0e22\u0e02\u0e2d\u0e07"),
            ),
        };
    },

    perks: (lang) => {
        const rows = Object.values(PRESTIGE.PERKS).map((p) =>
            `§e${p.name} §8(P${p.minPrestige}+) §7— ${p.desc.replace("{v}", String(p.base))}`);
        return {
            title: t(lang, "§lPrestige Perks", "§lPerk จาก Prestige"),
            body: t(lang,
                L("§fEvery Prestige lets you pick §e1 Perk§f. You can pick the same Perk again.", "", ...rows, "",
                  `§8A Perk's power is fixed when you pick it, so picks after Prestige ${PRESTIGE.FULL_UNTIL} are weaker.`),
                L("§fทุกครั้งที่ Prestige เลือก §ePerk 1 อย่าง§f เลือกซ้ำได้", "", ...rows, "",
                  `§8พลังของ Perk ถูกล็อกตอนที่เลือก การเลือกหลัง Prestige ${PRESTIGE.FULL_UNTIL} จึงอ่อนลง`)),
        };
    },

    mastery: (lang) => {
        const sg = (v) => `${v >= 0 ? "+" : ""}${Math.round(v * 100) / 100}`;
        const fx = (e) => e.kind === "fixed" ? `${e.name} ${sg(e.per)}${e.unit}/Lv` : `${e.name} ${sg(e.max)}${e.unit}`;
        const rows = [];
        for (const def of Object.values(MASTERY.LINES)) {
            rows.push(`${def.icon}${def.name} §8(Lv.${def.maxLevel})`);
            const base = Object.values(def.effects ?? {}).map(fx).join(", ");
            if (base) rows.push(`  §7${base}`);
            for (const p of Object.values(def.paths ?? {})) rows.push(`  §f${p.name}: §7${Object.values(p.effects).map(fx).join(", ")}`);
            if (def.unlocks?.length) rows.push(`  §a${def.unlocks.map((u) => `${u.name} Lv.${u.level}`).join(", ")}`);
        }
        return {
            title: t(lang, "§lMastery", "§lMastery"),
            body: t(lang,
                L(`§fPermanent skill lines, unlocked at §6Prestige ${MASTERY.UNLOCK_PRESTIGE}§f. Prestige never resets them, and they earn XP even at Max Level.`,
                  "§fEvery level gives a random share of each bonus; the full amount (shown below) is reached at the line's max level.",
                  "§fSome lines have Paths: pick ONE (free to change, once per minute). You can also switch any single bonus on or off — XP is still earned while it is off.", "",
                  ...rows, "",
                  "§8Open §bMastery §8in the Status Menu to see your progress, or Total Statistics for your totals."),
                L(`§fสายทักษะถาวร ปลดล็อกที่ §6Prestige ${MASTERY.UNLOCK_PRESTIGE}§f Prestige ไม่รีเซ็ต และได้ XP แม้ถึงเลเวลสูงสุด`,
                  "§fทุกเลเวลจะได้โบนัสแบบสุ่มเป็นส่วนหนึ่ง และจะได้ค่าเต็ม (ตามด้านล่าง) เมื่อถึงเลเวลสูงสุดของสายนั้น",
                  "§fบางสายมี Path ให้เลือกได้เพียงหนึ่ง (เปลี่ยนฟรี ทุก 1 นาที) และปิด/เปิดโบนัสทีละอย่างได้ โดยยังได้ XP ต่อ", "",
                  ...rows, "",
                  "§8ดูความคืบหน้าที่ §bMastery §8ใน Status Menu และค่ารวมที่ Total Statistics")),
        };
    },

    ascension: (lang) => {
        const R = ASCENSION.REQUIRED_PRESTIGE;
        const hp = ASCENSION.MOB_HP, dm = ASCENSION.MOB_DAMAGE, bh = ASCENSION.BOSS_HP;
        return {
            title: t(lang, "§lAscension", "§lAscension"),
            body: t(lang,
                L("§fAscension is the §4world's difficulty§f. One player presses it and §eeveryone §fshoulders it. It never goes down.", "",
                  `§fNeeds Prestige: Ascension 1 = P${R[1]}, 2 = P${R[2]}, 3 and up = P${R.DEFAULT}.`, "",
                  `§eCost: §f${ACTION_COSTS.ASCENSION.BASE} §c${ACTION_COSTS.ASCENSION.NAME}§f (+${ACTION_COSTS.ASCENSION.PER} per Ascension, max ${ACTION_COSTS.ASCENSION.CAP}), consumed. Craft: 2 Resonant Ink + Nether Star + Netherite Ingot.`, "",
                  `§fEach Ascension: Mob HP +${pc(hp.PER_ASC)}${PCT} (max x${hp.CAP}), Mob damage +${pc(dm.PER_ASC)}${PCT} (max x${dm.CAP}), Boss HP +${pc(bh.PER_ASC)}${PCT} (max x${bh.CAP}).`, "",
                  `§fAlso opens: ${Object.entries(ASCENSION.UNLOCK_NOTES).map(([a, n]) => `§7Asc ${a}: ${n}`).join(" ")}`, "",
                  "§8Everyone hears who raised it."),
                L("§fAscension คือ §4ความยากของโลก§f ผู้เล่นคนหนึ่งกด และ §eทุกคน §fรับผลร่วมกัน ลดลงไม่ได้", "",
                  `§fต้องมี Prestige: Ascension 1 = P${R[1]}, 2 = P${R[2]}, 3 ขึ้นไป = P${R.DEFAULT}`, "",
                  `§eค่าใช้จ่าย: §f${ACTION_COSTS.ASCENSION.BASE} §c${ACTION_COSTS.ASCENSION.NAME}§f (+${ACTION_COSTS.ASCENSION.PER} ต่อ Ascension สูงสุด ${ACTION_COSTS.ASCENSION.CAP}) ถูกใช้หมดไป คราฟต์: Resonant Ink 2 + Nether Star + Netherite Ingot`, "",
                  `§fทุก Ascension: HP มอน +${pc(hp.PER_ASC)}${PCT} (สูงสุด x${hp.CAP}) ดาเมจมอน +${pc(dm.PER_ASC)}${PCT} (สูงสุด x${dm.CAP}) HP บอส +${pc(bh.PER_ASC)}${PCT} (สูงสุด x${bh.CAP})`, "",
                  `§fปลดล็อกเพิ่ม: Asc 2: บอสดรอป Uncarved Gem และระบบ Gem (ต้องมี P2), Asc 3: ระบบ Rune (ต้องมี P3), Asc 4: มอน Geode ดรอป Uncarved Gem`, "",
                  "§8ทุกคนจะรู้ว่าใครเป็นคนกด")),
        };
    },

    // ═══ Equipment ═════════════════════════════════════════════════════════

    ultench: (lang) => ({
        title: t(lang, "§lUltimate Enchanter", "§lUltimate Enchanter"),
        body: t(lang,
            L("§fThe §bUltimate Enchanter §fopens for everyone. Each function has its own requirement:", "",
              `§bRune §8— §f${featReq("rune")}`,
              `§5Gem §8— §f${featReq("gem")}`,
              `§dChorus §8— §f${featReq("chorus")}`,
              "§bVanilla Enchant §8— §fno requirement §7(uses Enchant Essence)", "",
              "§fLocked functions show what is still missing. Materials: Rune and Chorus use only Resonant Ink; Gem uses only Gem Dust."),
            L("§fบล็อก §bUltimate Enchanter §fเปิดใช้ได้ทุกคน แต่แต่ละฟังก์ชันมีเงื่อนไขของตัวเอง:", "",
              `§bRune §8— §f${featReq("rune")}`,
              `§5Gem §8— §f${featReq("gem")}`,
              `§dChorus §8— §f${featReq("chorus")}`,
              "§bVanilla Enchant §8— §fไม่มีเงื่อนไข §7(ใช้ Enchant Essence)", "",
              "§fฟังก์ชันที่ล็อกจะบอกว่ายังขาดอะไร วัตถุดิบ: Rune และ Chorus ใช้ Resonant Ink อย่างเดียว, Gem ใช้ Gem Dust อย่างเดียว")),
    }),

    augment: (lang) => legacy("augment", lang, t(lang,
        `§9Augment §funlocks at §e${featReq("augment")}§f.`,
        `§9Augment §fปลดล็อกที่ §e${featReq("augment")}§f`)),

    reforge: (lang) => legacy("reforge", lang, t(lang,
        `§8Augment needs ${featReq("augment")}; Gem Fusion needs the Gem requirement (${featReq("gem")}).`,
        `§8Augment ต้อง ${featReq("augment")} ส่วน Gem Fusion ต้องผ่านเงื่อนไขของ Gem (${featReq("gem")})`)),

    gem: (lang) => ({
        title: t(lang, "§lGem System", "§lระบบอัญมณี"),
        body: t(lang,
            L("§fGems are installed in the single armor socket to grant passive abilities.", "",
              `§fUnlock: §e${featReq("gem")}§f. Engraving the socket succeeds §e${pc(ENGRAVE_RATES[0])}${PCT}§f of the time (raised by the §3Gemwright §fPerk). §5Gem Mastery §funlocks higher Gem tiers raises Uncarved Gem drops, and adds Gem Potency (up to +20%) to the power numbers of every socketed skill; cooldowns and caps never change.`, "",
              "§fTiers: §fCommon, §eUncommon, §aRare, §3Unique, §9Legend, §6Epic, §4Mythical", "",
              "§fEach tier has 12 abilities (84 in total). Abilities are tied to an armor category (Helm / Chest / Legs / Boots), so Gem Enchanting rolls a random ability that the armor piece can carry. Abilities have no levels: Gem Mastery adds Gem Potency instead.", "",
              `§fTiers 1-3 stack across armor pieces. All Gem sources together are capped: -${GEM_CAPS.dmgReduction}${PCT} damage taken, ${GEM_CAPS.dodge}${PCT} Dodge, +${GEM_CAPS.meleeBonus}${PCT} melee damage, +${GEM_CAPS.speed}${PCT} speed. Tiers 4-7 belong to one category each. Full list in the §dEncyclopedia§f.`, "",
              "§fThe Ultimate Enchanter engraves, installs and removes Gems, and can Transmute them.",
              "§fGem Fusion §7(Reforge menu)§f: combine 5 Gems of one tier (or 2 Gems + 1 Augment Core) into 1 Gem one tier higher."),
            L("§fติดตั้งอัญมณีในช่องเดียวของเกราะเพื่อรับความสามารถแบบพาสซีฟ", "",
              `§fเงื่อนไข: §e${featReq("gem")}§f การเจาะช่องสำเร็จ §e${pc(ENGRAVE_RATES[0])}${PCT}§f (เพิ่มได้ด้วย Perk §3Gemwright§f) ส่วน §5Gem Mastery §fปลดล็อก Gem tier สูงขึ้น เพิ่มการดรอป Uncarved Gem และเพิ่ม Gem Potency (สูงสุด +20%) ให้ค่าพลังของสกิล Gem ทุกช่อง ส่วนคูลดาวน์และเพดานไม่เปลี่ยน`, "",
              "§fระดับ: §fCommon, §eUncommon, §aRare, §3Unique, §9Legend, §6Epic, §4Mythical", "",
              "§fแต่ละระดับมี 12 Ability (รวม 84) ผูกกับหมวดเกราะ (Helm / Chest / Legs / Boots) การ Enchant จึงสุ่ม Ability ที่ชิ้นนั้นใส่ได้ ไม่มีเลเวลอีกแล้ว Gem Mastery เพิ่ม Gem Potency แทน", "",
              `§fระดับ 1-3 ซ้อนทับข้ามชิ้นได้ แต่มีเพดานรวม: ลดดาเมจ ${GEM_CAPS.dmgReduction}${PCT}, Dodge ${GEM_CAPS.dodge}${PCT}, ดาเมจประชิด +${GEM_CAPS.meleeBonus}${PCT}, ความเร็ว +${GEM_CAPS.speed}${PCT} ส่วนระดับ 4-7 ผูกหมวดเดียว ดูรายการทั้งหมดที่ §dสารานุกรม§f`, "",
              "§fUltimate Enchanter ใช้เจาะช่อง/สวม/ถอด Gem และ Transmute ได้",
              "§fGem Fusion §7(เมนู Reforge)§f: รวม Gem 5 เม็ดเทียร์เดียวกัน (หรือ 2 เม็ด + Augment Core 1 อัน) เป็น Gem เทียร์สูงขึ้น 1 ขั้น")),
    }),

    rune: (lang) => ({
        title: t(lang, "§lRune System", "§lระบบ Rune"),
        body: t(lang,
            L("§fRunes are installed on weapons and tools to add powerful triggered effects.", "",
              "§bRune items", "",
              "§fCraft an §eUncarved Rune §f(Legend Gem + Amethyst Shard), hold it with an Engraver in your offhand and use it (Shift = x16). You get a Rune item of a random grade: " + RUNE_GRADES.map((g) => `${g.color}${g.label}§f`).join(" < ") + ". Grade = Tier (Gamma T1 ... Omega T7) and the rune inside is random.", "",
              "§bAnvil > Rune", "",
              `§dRecarved §f(${RUNE_ANVIL_COSTS.recarved} Resonant Ink): re-roll the grade and the rune.`,
              `§bReroll §f(${RUNE_ANVIL_COSTS.rerollPerTier} Ink x tier): new effect, same grade.`,
              `§9Selective reroll §f(${RUNE_ANVIL_COSTS.selectPerTier} Ink x tier): new effect of a Type you choose.`,
              "§aInsert §f: install a Rune item into the weapon or tool in your mainhand (one rune per item).",
              "§cRemove §f: take the rune back out as a Rune item. Its Lv is kept.", "",
              `§fUnlock: §e${featReq("rune")}§f. Boosted by the §dRunebound §fPerk. §dRune Mastery §funlocks higher Rune tiers, adds Rune Level (up to +4, max Lv 8) and shortens cooldowns. The bonus follows whoever holds the item, so the same weapon or armor shows a higher level for a player with more Mastery.`, "",
              "§fCategories:",
"§fThere are 116 Runes. Each has a good side and a drawback; the drawback shrinks as the Rune levels up (gone at Lv 7). 7 Curses (one per grade) have a penalty only and never gain levels from Mastery or Synergy. Runes are split by type: Sword, Bow, Spear, Trident, Mace, All-Weapon, Pickaxe, Axe, Shovel, Hoe and All-Tool.",
"§c  Melee §8— §7swords, axes, spears   §b  Ranged §8— §7bows, crossbows",
"§e  All Weapons §8— §7any weapon or tool   §2  Tool §8— §7pickaxe, axe, shovel, hoe",
"§fRune levels run Lv 1-8. Full list in the §dEncyclopedia§f.", "",
              "§fActive Runes (Stormcall, Warden's Echo): §fSneak + Use item to trigger.",
"§fRunes found on old weapons are converted automatically: a replaced rune becomes its successor, and one the weapon can no longer hold is removed for free."),
            L("§fติดตั้ง Rune บนอาวุธและเครื่องมือเพื่อเพิ่มความสามารถพิเศษที่ทริกเกอร์ได้", "",
              "§bไอเทมรูน", "",
              "§fคราฟต์ §eUncarved Rune §f(Legend Gem + Amethyst Shard) ถือคู่กับ Engraver ที่มือรองแล้วใช้ (Shift = x16) จะได้ไอเทมรูนเกรดสุ่ม: " + RUNE_GRADES.map((g) => `${g.color}${g.label}§f`).join(" < ") + " เกรด = Tier (Gamma T1 ... Omega T7) และรูนข้างในสุ่ม", "",
              "§bAnvil > Rune", "",
              `§dRecarved §f(${RUNE_ANVIL_COSTS.recarved} Resonant Ink): สุ่มเกรดและรูนใหม่`,
              `§bReroll §f(${RUNE_ANVIL_COSTS.rerollPerTier} Ink x tier): สุ่มเอฟเฟกต์ใหม่ เกรดเดิม`,
              `§9Selective reroll §f(${RUNE_ANVIL_COSTS.selectPerTier} Ink x tier): สุ่มเอฟเฟกต์ใหม่ตามประเภทที่เลือก`,
              "§aInsert §f: ติดตั้งไอเทมรูนลงอาวุธหรือเครื่องมือที่ถือในมือหลัก (1 ชิ้นต่อ 1 รูน)",
              "§cRemove §f: ถอดรูนออกมาเป็นไอเทมรูน เก็บ Lv เดิมไว้", "",
              `§fเงื่อนไข: §e${featReq("rune")}§f เสริมได้ด้วย Perk §dRunebound§f ส่วน §dRune Mastery §fปลดล็อก Rune tier สูงขึ้น เพิ่มเลเวลรูน (สูงสุด +4 ไม่เกิน Lv 8) และลด Cooldown โบนัสผูกกับผู้ถือไอเทม อาวุธหรือเกราะชิ้นเดียวกันจึงแสดงเลเวลสูงขึ้นสำหรับผู้เล่นที่ Mastery สูงกว่า`, "",
              "§fประเภท:",
"§fมี Rune ทั้งหมด 116 ตัว แต่ละตัวมีด้านดีและข้อเสีย ข้อเสียจะลดลงเมื่อเลเวลสูงขึ้น (หายไปที่ Lv 7) คำสาป 7 ตัว (1 ตัวต่อ 1 เกรด) มีแต่โทษและไม่ได้เลเวลจาก Mastery/Synergy แบ่งประเภท: ดาบ ธนู หอก ตรีศูล กระบอง ทุกอาวุธ พิกแอ็กซ์ ขวาน พลั่ว จอบ และทุกเครื่องมือ",
"§c  Melee §8— §7ดาบ ขวาน หอก   §b  Ranged §8— §7ธนู หน้าไม้",
"§e  ทุกอาวุธ §8— §7อาวุธหรือเครื่องมือใดก็ได้   §2  Tool §8— §7พลั่ว ขวาน พลั่วดิน จอบ",
"§fเลเวล Rune ตั้งแต่ Lv 1-8 ดูรายการทั้งหมดที่ §dสารานุกรม§f", "",
              "§fActive Rune (Stormcall, Warden's Echo): §fกด Sneak + ใช้ไอเทมเพื่อ activate",
"§fRune บนอาวุธเก่าจะถูกแปลงอัตโนมัติ: ตัวที่ถูกแทนที่จะกลายเป็นตัวใหม่ ส่วนตัวที่อาวุธใส่ไม่ได้อีกจะถูกถอดออกฟรี")),
    }),

    chorus: (lang) => {
        const cost = (c) => [c.resonant ? `${c.resonant} Resonant Ink` : "", c.stellar ? `${c.stellar} Stellar Core` : ""].filter(Boolean).join(" + ") || "Free";
        const tierRows = Object.entries(CHORUS_TIERS).filter(([, tr]) => !tr.fusion).map(([id, tr]) =>
            `${tr.color}${tr.label} §8— §f${cost(CHORUS_ROLL_COST[id])} §8(${t(lang, "lock", "ล็อก")}: ${cost(CHORUS_LOCK_COST[id])})`);
        return {
            title: t(lang, "§lChorus", "§lChorus"),
            body: t(lang,
                L(`§fChorus turns armor into an elemental build. Unlocks at §e${featReq("chorus")}§f.`, "",
                  `§fEach armor piece has §e${CHORUS_SLOTS_PER_ITEM} element sockets §f(${CHORUS_MAX_SLOTS} for a full set; the shield has none).`,
                  `§fMatching elements unlock set effects at §e${CHORUS_THRESHOLDS.join(" / ")} §fsockets, and they stack.`, "",
                  "§dRoll §f— pick a tier (§aEcho§f, §bResonance§f, §dTranscend§f). Every unlocked socket gets a random element of that tier; duplicates are possible.",
                  "§6Lock §f— keep an element while you reroll the other socket. A locked element also binds the piece to its tier. Unlocking is free.", "",
                  ...tierRows, "§8(cost to roll both sockets; rolling one costs half)", "",
                  "§fTwo different elements of one tier form a §ehybrid set §f(e.g. Fire + Water = Steam). You can turn §eHybrid Mixing §foff in Status Menu > Chorus.", "",
                  `§dSynergy §f-- Runes grow stronger when your armor carries a matching element: §e${Object.entries(SYNERGY.LEVEL_BONUS).map(([n, l]) => `${n}+ sockets = +${l} Level`).join(", ")}§f (max Lv 8; Transcend +${SYNERGY.TRANSCEND_EXTRA_LEVEL}, Genesis armor +${SYNERGY.GENESIS_EXTRA_LEVEL}). From §e${SYNERGY.RIDER_MIN_SLOTS} sockets §fthe strongest matching element also adds a bonus effect: your Rune / offensive Gem hits can burn, slow, wither or heal, and defensive Gems react when enemies hit you. Fused elements count as their parents (Awaken = 2, Melodious = 4, Genesis = all 8). The matching elements are listed on every Gem and Rune tooltip.`, "",
                  `§8Chorus bonuses are capped: ${CHORUS_CAPS.damageReduction}${PCT} damage reduction, ${CHORUS_CAPS.damageBonus}${PCT} damage bonus.`),
                L(`§fChorus เปลี่ยนเกราะให้เป็นบิลด์ธาตุ ปลดล็อกที่ §e${featReq("chorus")}`, "",
                  `§fเกราะแต่ละชิ้นมี §eช่องธาตุ ${CHORUS_SLOTS_PER_ITEM} ช่อง §f(ครบชุดมี ${CHORUS_MAX_SLOTS} ช่อง โล่ไม่มีช่อง)`,
                  `§fธาตุที่ตรงกันปลดเอฟเฟกต์ชุดที่ §e${CHORUS_THRESHOLDS.join(" / ")} §fช่อง และสะสมต่อกัน`, "",
                  "§dสุ่ม (Roll) §f— เลือกระดับ (§aEcho§f, §bResonance§f, §dTranscend§f) ทุกช่องที่ไม่ล็อกจะได้ธาตุสุ่มในระดับนั้น ได้ธาตุซ้ำได้",
                  "§6ล็อก (Lock) §f— เก็บธาตุที่ชอบไว้แล้วสุ่มช่องที่เหลือ ธาตุที่ล็อกจะผูกเกราะไว้กับระดับนั้นด้วย การปลดล็อกฟรี", "",
                  ...tierRows, "§8(ราคาสุ่มทั้ง 2 ช่อง สุ่มช่องเดียวจ่ายครึ่งหนึ่ง)", "",
                  "§fธาตุ 2 ชนิดในระดับเดียวกันรวมเป็น §eชุดผสม §f(เช่น Fire + Water = Steam) ปิดการผสมได้ที่ Status Menu > Chorus §eHybrid Mixing", "",
                  `§dSynergy §f-- Rune แข็งแกร่งขึ้นเมื่อเกราะมีธาตุตรงกัน §e${Object.entries(SYNERGY.LEVEL_BONUS).map(([n, l]) => `${n}+ ช่อง = +${l} Level`).join(", ")}§f (สูงสุด Lv 8; Transcend +${SYNERGY.TRANSCEND_EXTRA_LEVEL}, เกราะ Genesis +${SYNERGY.GENESIS_EXTRA_LEVEL}) ตั้งแต่ §e${SYNERGY.RIDER_MIN_SLOTS} ช่อง §fธาตุที่ตรงมากที่สุดจะเพิ่มเอฟเฟกต์ เช่น เผา ชะลอ สาปแช่ง หรือฟื้น HP เมื่อโจมตีด้วย Rune / Gem สายโจมตี และ Gem สายป้องกันจะตอบโต้เมื่อศัตรูโจมตีคุณ ธาตุที่ผสมแล้วนับเป็นธาตุแม่ (Awaken = 2, Melodious = 4, Genesis = ครบ 8) ธาตุที่ตรงกันแสดงในทุก Tooltip ของ Gem และ Rune`, "",
                  `§8โบนัส Chorus มีเพดาน: ลดดาเมจ ${CHORUS_CAPS.damageReduction}${PCT} เพิ่มดาเมจ ${CHORUS_CAPS.damageBonus}${PCT}`)),
        };
    },

    mixing: (lang) => {
        const el = (id) => `${CHORUS_ELEMENTS[id].color}${CHORUS_ELEMENTS[id].label}`;
        const rows = [];
        for (const [key, tier] of Object.entries(CHORUS_TIERS).filter(([, x]) => !x.fusion)) {
            const list = Object.values(CHORUS_HYBRIDS).filter((h) => CHORUS_ELEMENTS[h.elements[0]].tier === key);
            rows.push(`${tier.color}${tier.label} §8(${list.length})`);
            for (const h of list) rows.push(`§f  ${el(h.elements[0])} §f+ ${el(h.elements[1])} §f= §e${h.name}`);
            rows.push("");
        }
        return {
            title: t(lang, "§lElement Mixing", "§lการผสมธาตุ"),
            body: t(lang,
                L("§fWear armor with §eexactly 2 different elements §fof the §esame tier §fand they merge into a §dhybrid set§f.", "",
                  "§6Rules", "§f- Cross-tier mixes and 3+ different elements do not merge; each element counts on its own.",
                  "§f- Hybrid sockets = §e2 x the smaller count §fof the two elements (e.g. 3 Fire + 2 Water = 4). Extra unpaired sockets do not count.",
                  "§f- Turn mixing off in Status Menu > Chorus > §eHybrid Mixing§f.", "",
                  ...rows).trimEnd(),
                L("§fสวมเกราะที่มี §eธาตุต่างกันพอดี 2 ชนิด §fในระดับ §eเดียวกัน §fแล้วจะรวมเป็น §dชุดผสม", "",
                  "§6กติกา", "§f- ต่างระดับ หรือมีธาตุต่างกัน 3 ชนิดขึ้นไป จะไม่รวมกัน แต่ละธาตุนับแยก",
                  "§f- จำนวนช่องของชุดผสม = §e2 x จำนวนที่น้อยกว่า §fของสองธาตุ (เช่น Fire 3 + Water 2 = 4) ช่องที่เหลือไม่คู่ไม่นับ",
                  "§f- ปิดการผสมได้ที่ Status Menu > Chorus > §eHybrid Mixing", "",
                  ...rows).trimEnd()),
        };
    },

    fusion: (lang) => {
        const el = (id) => `${CHORUS_ELEMENTS[id].color}${CHORUS_ELEMENTS[id].label}`;
        const unlockLv = (tid) => MASTERY.LINES.chorus.unlocks.find((u) => u.id === tid)?.level ?? "?";
        const cost = (c) => [c.resonant ? `${c.resonant} Resonant Ink` : "", c.stellar ? `${c.stellar} Stellar Core` : ""].filter(Boolean).join(" + ") || "Free";
        const tierBlock = (tid, enHow, thHow) => {
            const tr = CHORUS_TIERS[tid];
            const recipes = Object.entries(CHORUS_FUSION).filter(([id]) => CHORUS_ELEMENTS[id].tier === tid)
                .map(([id, r]) => `§f  ${el(id)} §f= ${r.from.map(el).join(" §f+ ")}`);
            return [`${tr.color}${tr.label}`, t(lang, enHow, thHow),
                `§8  ${t(lang, "Needs", "ต้องมี")} Chorus Mastery Lv.${unlockLv(tid)}, Prestige ${CHORUS_FUSION_UNLOCK[tid].prestige}  §8|  ${t(lang, "Cost", "ราคา")} ${cost(CHORUS_FUSION_COST[tid])}`,
                ...recipes, ""];
        };
        return {
            title: t(lang, "§lChorus Fusion", "§lChorus Fusion"),
            body: L(t(lang,
                    "§fFuse Transcend elements into rarer ones: Chorus > §6Fusion§f. A Fusion is §cpermanent§f: fused pieces can no longer be rolled or locked (you can still Remove a socket, but the old elements do not come back).",
                    "§fรวมธาตุ Transcend ให้เป็นธาตุที่หายากขึ้น: Chorus > §6Fusion§f การ Fusion §cถาวร§f: ชิ้นที่ Fuse แล้วจะ Roll หรือ Lock ไม่ได้อีก (ยัง Remove ช่องได้ แต่ธาตุเดิมไม่คืนมา)"), "",
                ...tierBlock("awaken",
                    "§f  One armor piece whose two sockets hold the matching Transcend pair. Both sockets become the new element.",
                    "§f  เกราะ 1 ชิ้นที่ 2 ช่องเป็นคู่ธาตุ Transcend ที่ตรงสูตร ทั้งสองช่องจะกลายเป็นธาตุใหม่"),
                ...tierBlock("melodious",
                    "§f  Two Awaken pieces (each with both sockets the same element). Both pieces become the new element.",
                    "§f  เกราะ Awaken 2 ชิ้น (แต่ละชิ้นเป็นธาตุเดียวกันทั้ง 2 ช่อง) ทั้งสองชิ้นจะกลายเป็นธาตุใหม่"),
                ...tierBlock("genesis",
                    "§f  One Destiny piece + one Infinity piece. Both become Genesis.",
                    "§f  เกราะ Destiny 1 ชิ้น + Infinity 1 ชิ้น ทั้งสองจะกลายเป็น Genesis"),
                t(lang,
                    "§8Awaken and above never form hybrid sets. Revive: a fatal hit leaves you alive once per cooldown (cooldowns do not stack between pieces).",
                    "§8ตั้งแต่ Awaken ขึ้นไปไม่มีชุดผสม Revive: โดนตีถึงตายจะรอดได้ 1 ครั้งต่อ Cooldown (ไม่ซ้อนกันระหว่างชิ้น)")).trimEnd(),
        };
    },

    scripttool: (lang) => ({
        title: t(lang, "§lScript Tool", "§lScript Tool"),
        body: t(lang,
            L("§fThe §6Script Tool §fopens every menu from one place, so you never type commands.", "",
              "§fRight-click it to open: Status Menu, Chorus, Gem / Ultimate Enchant, Reforge, Redeem, Knowledge Book, or get a Stats Book.", "",
              "§7Creative mode adds Rune Creative. Players with the Admin tag also get the Admin Panel, Roll Additional Augment and Reset Redeem Usage."),
            L("§fScript Tool เปิดทุกเมนูได้จากที่เดียว ไม่ต้องพิมพ์คำสั่ง", "",
              "§fคลิกขวาเพื่อเปิด: Status Menu, Chorus, Gem / Ultimate Enchant, Reforge, Redeem, Knowledge Book หรือรับ Stats Book", "",
              "§7โหมด Creative มีปุ่ม Rune Creative เพิ่ม ผู้ที่มีแท็ก Admin จะมี Admin Panel, Roll Additional Augment และ Reset Redeem Usage เพิ่ม")),
    }),

    // ═══ Combat & Enemies ══════════════════════════════════════════════════

    combat: (lang) => legacy("combat", lang, t(lang,
        "§fThe Nightmare event and Mob Evolution add new threats — see the pages below.",
        "§fอีเวนต์ Nightmare และ Mob Evolution เพิ่มภัยคุกคามใหม่ ดูหน้าถัดไป")),

    scaling: (lang) => {
        const hp = ASCENSION.MOB_HP, dm = ASCENSION.MOB_DAMAGE, bh = ASCENSION.BOSS_HP;
        const a = ProgressionManager.getAscension();
        return {
            title: t(lang, "§lEnemy Scaling", "§lความแรงของศัตรู"),
            body: t(lang,
                L(`§fWorld Ascension now: §c${a}`, "",
                  `§fHostile mobs get §cx${r1(ProgressionManager.getMobHpMult())} §fHP and deal §cx${r1(ProgressionManager.getMobDamageMult())} §fdamage. Bosses get §cx${r1(ProgressionManager.getBossHpMult())} §fHP.`,
                  `§8Formula: HP 1 + ${hp.PER_ASC} per Ascension (max x${hp.CAP}), damage 1 + ${dm.PER_ASC} (max x${dm.CAP}), Boss HP 1 + ${bh.PER_ASC} (max x${bh.CAP}).`, "",
                  `§fPlayers deal §ax${r1(ProgressionManager.getPlayerDamageMult())} §fdamage to hostile mobs; Bosses hit §cx${r1(ProgressionManager.getBossDamageMult())} §fharder. Evolved mobs gain up to §cx${EVOLUTION.ASC_DAMAGE.CAP} §fextra damage with Ascension. Combined enemy damage never exceeds §cx${MOB_SCALING.TOTAL_DAMAGE_CAP}§f.`, "",
                  `§fXP bonus: §a+${ProgressionManager.getAscensionXpBonus()}% §ffrom Ascension (+${ASCENSION.XP_BONUS.PER_ASC}% each, max ${ASCENSION.XP_BONUS.CAP}%) and §6+${PRESTIGE.XP_BONUS_PER}% §fper Prestige (max ${PRESTIGE.XP_BONUS_CAP}%).`, "",
                  `§fWhile Ascension is above 0, one enemy hit can never take more than §e${pc(MOB_SCALING.MAX_HIT_FRACTION)}${PCT} §fof your Max HP.`, "",
                  "§fMob HP is tracked as a hidden pool; the health bar shrinks in proportion as you hurt it.", "",
                  `§fBosses drop §eUncarved Gems §fonly from Ascension ${MOB_SCALING.BOSS_GEM_MIN_ASCENSION}.`),
                L(`§fAscension ของโลกตอนนี้: §c${a}`, "",
                  `§fมอนศัตรูมี HP §cx${r1(ProgressionManager.getMobHpMult())} §fและดาเมจ §cx${r1(ProgressionManager.getMobDamageMult())} §fบอสมี HP §cx${r1(ProgressionManager.getBossHpMult())}`,
                  `§8สูตร: HP 1 + ${hp.PER_ASC} ต่อ Ascension (สูงสุด x${hp.CAP}) ดาเมจ 1 + ${dm.PER_ASC} (สูงสุด x${dm.CAP}) HP บอส 1 + ${bh.PER_ASC} (สูงสุด x${bh.CAP})`, "",
                  `§fผู้เล่นทำดาเมจต่อมอนสเตอร์ §ax${r1(ProgressionManager.getPlayerDamageMult())}§f บอสทำดาเมจเพิ่ม §cx${r1(ProgressionManager.getBossDamageMult())}§f มอนที่วิวัฒนาการได้ดาเมจเพิ่มตาม Ascension สูงสุด §cx${EVOLUTION.ASC_DAMAGE.CAP}§f และดาเมจรวมของศัตรูไม่เกิน §cx${MOB_SCALING.TOTAL_DAMAGE_CAP}§f`, "",
                  `§fโบนัส XP: §a+${ProgressionManager.getAscensionXpBonus()}%§f จาก Ascension (+${ASCENSION.XP_BONUS.PER_ASC}% ต่อระดับ สูงสุด ${ASCENSION.XP_BONUS.CAP}%) และ §6+${PRESTIGE.XP_BONUS_PER}%§f ต่อ Prestige (สูงสุด ${PRESTIGE.XP_BONUS_CAP}%)`, "",
                  `§fตอน Ascension มากกว่า 0 การโจมตีหนึ่งครั้งของมอนจะไม่ทำเกิน §e${pc(MOB_SCALING.MAX_HIT_FRACTION)}${PCT} §fของ Max HP คุณ`, "",
                  "§fHP มอนเก็บเป็นพูลซ่อน หลอดเลือดจะลดตามสัดส่วนเมื่อโดนตี", "",
                  `§fบอสดรอป §eUncarved Gem §fตั้งแต่ Ascension ${MOB_SCALING.BOSS_GEM_MIN_ASCENSION} เท่านั้น`)),
        };
    },

    evolution: (lang) => {
        const tiers = Object.values(EVOLUTION.TIERS).map((x) =>
            `${x.color}${x.name} §8(${x.event ? "event, " : ""}Asc ${x.unlockAsc})`).join("§7, ");
        return {
            title: t(lang, "§lMob Evolution", "§lMob Evolution"),
            body: t(lang,
                L("§fFrom Ascension 1, new hostile mobs may §eevolve §finto a themed variant. Each tier is a theme, not a power ladder.", "",
                  `§fChance per spawn: ${pc(EVOLUTION.CHANCE_BASE)}${PCT} + ${pc(EVOLUTION.CHANCE_PER_ASC)}${PCT} per Ascension (max ${pc(EVOLUTION.CHANCE_MAX)}${PCT}). Evolved mobs show a particle trail.`,
                  `§fBosses never evolve, allies called by Elite / Awakened mobs never evolve, and at most ${EVOLUTION.AREA_CAP} evolved mobs live near each other.`, "",
                  `§fTiers: ${tiers}`, "",
                  `§tEnchanted §fis a modifier that can appear even at Ascension 0 (${pc2(ENCHANTED.CHANCE_BASE)}${PCT} + ${pc2(ENCHANTED.CHANCE_PER_ASC)}${PCT} per Ascension) and stacks with any tier except Core.`,
                  "§mStellar Core §f(right-click a mob) forces an evolution. Bosses are immune.", "",
                  "§fDetails for every tier: §dEncyclopedia §7> Enemy Bestiary."),
                L("§fตั้งแต่ Ascension 1 มอนศัตรูที่เกิดใหม่อาจ §eวิวัฒน์ §fเป็นแบบธีมเฉพาะ แต่ละ Tier คือธีม ไม่ใช่บันไดพลัง", "",
                  `§fโอกาสตอนเกิด: ${pc(EVOLUTION.CHANCE_BASE)}${PCT} + ${pc(EVOLUTION.CHANCE_PER_ASC)}${PCT} ต่อ Ascension (สูงสุด ${pc(EVOLUTION.CHANCE_MAX)}${PCT}) มอนวิวัฒน์จะมีอนุภาคบอก`,
                  `§fบอสไม่วิวัฒน์ มอนที่ Elite / Awakened เรียกมาไม่วิวัฒน์ และมอนวิวัฒน์อยู่รวมกันได้ไม่เกิน ${EVOLUTION.AREA_CAP} ตัวในพื้นที่`, "",
                  `§fTier: ${tiers}`, "",
                  `§tEnchanted §fเป็นตัวเสริมที่เกิดได้แม้ Ascension 0 (${pc2(ENCHANTED.CHANCE_BASE)}${PCT} + ${pc2(ENCHANTED.CHANCE_PER_ASC)}${PCT} ต่อ Ascension) ติดคู่กับ Tier ใดก็ได้ยกเว้น Core`,
                  "§mStellar Core §f(คลิกขวาที่มอน) บังคับวิวัฒน์ได้ ยกเว้นบอส", "",
                  "§fรายละเอียดทุก Tier ดูที่ §dสารานุกรม §7> ทำเนียบศัตรู")),
        };
    },

    nightmare: (lang) => {
        const lv = [...NIGHTMARE.LEVELS].reverse();
        const rows = lv.map((l) => `§f${l.days}+ ${t(lang, "days", "วัน")} §8— §c${pc(l.chance)}${PCT} §7${t(lang, "per check", "ต่อรอบ")}, ${l.wave[0]}-${l.wave[1]} ${t(lang, "mobs", "ตัว")}${l.close ? t(lang, " §4(right next to you, even indoors)", " §4(โผล่ข้างตัวคุณ แม้อยู่ในบ้าน)") : ""}`);
        return {
            title: t(lang, "§lNightmare Event", "§lอีเวนต์ Nightmare"),
            body: t(lang,
                L(`§fFrom Ascension ${NIGHTMARE.MIN_ASCENSION}, staying awake is dangerous. The game counts the §eworld days since you last slept§f.`, "",
                  "§fAt night in the Overworld, Nightmare mobs may appear around you:", ...rows, "",
                  `§fThey are tougher, earn big XP and can blind you. At most ${NIGHTMARE.MAX_ALIVE_NEAR} stay near you.`, "",
                  "§aSleeping in a bed resets the counter."),
                L(`§fตั้งแต่ Ascension ${NIGHTMARE.MIN_ASCENSION} การไม่นอนเป็นอันตราย เกมนับ §eจำนวนวันในโลกตั้งแต่คุณนอนครั้งล่าสุด`, "",
                  "§fตอนกลางคืนใน Overworld มอน Nightmare อาจโผล่รอบตัวคุณ:", ...rows, "",
                  `§fแข็งแกร่งกว่า ให้ XP สูง และทำให้ตาบอดได้ อยู่ใกล้คุณได้ไม่เกิน ${NIGHTMARE.MAX_ALIVE_NEAR} ตัว`, "",
                  "§aนอนบนเตียงเพื่อรีเซ็ตตัวนับ")),
        };
    },

    // ═══ Gathering & Resources ═════════════════════════════════════════════

    mining: (lang) => legacy("mining", lang),

    explore: (lang) => {
        const biomes = Object.values(BIOME_CATALOG).reduce((n, l) => n + l.length, 0);
        const pearl = WAYPOINT.COST_NAME;
        return {
            title: t(lang, "§lExploration", "§lการสำรวจ"),
            body: t(lang,
                L("§bWaypoint Stone §f(craft: 4 Stone Bricks, 4 Ender Pearls, 1 Compass)", "",
                  "§fPlace it and you must §ename it §fright away (the form cannot be skipped). The name and position are then saved to your list. Right-click a stone someone else placed and you are asked whether to §asave §fit.", "",
                  "§fRight-click a stone: §bTeleport §f(your saved places), §eEdit §f(rename, owner / Admin) and §6Manager §f(Player: remove players linked to the stone; Waystone: sort and remove your saved stones). Renaming changes the name in everyone's list.", "",
                  `§eCost: §f${pearl}s only, 1 per ${WAYPOINT.BLOCKS_PER_PEARL} blocks (min ${WAYPOINT.MIN_COST}, max ${WAYPOINT.MAX_COST}). Another dimension always costs ${WAYPOINT.MAX_COST}. Cooldown ${WAYPOINT.COOLDOWN_SEC}s. You arrive on top of the stone.`,
                  `§eLimits: §f${WAYPOINT.PER_PLAYER_MAX} stones per player, ${WAYPOINT.SAVED_MAX} saved places each, ${WAYPOINT.MIN_SPACING} blocks apart. Only the owner (or an Admin) can break a stone, and explosions cannot. A destroyed stone stays in lists until removed but you cannot travel there.`,
                  "§7Script Tool > Waypoints opens the Waystone manager from anywhere.", "",
                  "§bWaypoint Stone (Blank) §f(craft: 4 Stone Bricks, 1 Ender Pearl)", "",
                  "§fNo name, no owner. Right-click to teleport to your saved places (Teleport and Manager > Waystone). Anyone can break it.", "",
                  "§dWaypoint Orb §f(craft: 4 Netherite Ingots, 2 Echo Shards, 1 Ender Eye, 1 Nether Star, 1 Myth Gem)", "",
                  `§fUse it anywhere: Teleport, Manager > Waystone, and Edit. Edit lets you §aAdd §fup to ${WAYPOINT.SPECIAL_MAX} special points on the spot you stand, §eRename §fand §cRemove §fthem. Special points are always at the top of the list, cost nothing, and have a ${WAYPOINT.SPECIAL_COOLDOWN_SEC}s cooldown.`, "",
                  "§bDiscovery Log", "",
                  `§fThe Log remembers the §e${biomes} biomes§f, §e${STRUCTURE_CATALOG.length} structures §fand the 3 dimensions you find. Open it from the Script Tool.`,
                  `§eFirst-find reward: §fone-time Travel Mastery XP (biome ${DISCOVERY.XP_BIOME}, structure ${DISCOVERY.XP_STRUCTURE}, Nether / End ${DISCOVERY.XP_DIMENSION}). The Travel line unlocks at Prestige ${MASTERY.UNLOCK_PRESTIGE}; finds made before that are saved but give no XP.`,
                  "§7Structures are spotted by signature blocks close to you, so look around inside them. Creative and Spectator are not tracked."),
                L("§bWaypoint Stone §f(คราฟต์: Stone Bricks 4, Ender Pearl 4, Compass 1)", "",
                  "§fวางแล้วต้อง §eตั้งชื่อ §fทันที (ข้ามไม่ได้) จากนั้นชื่อและตำแหน่งจะถูกเซฟลงรายการของคุณ ถ้าคลิกขวาหินที่คนอื่นวาง จะมีถามว่าจะ §aเซฟ §fหรือไม่", "",
                  "§fคลิกขวาที่หิน: §bTeleport §f(ที่ที่เซฟไว้), §eEdit §f(เปลี่ยนชื่อ เจ้าของ / Admin) และ §6Manager §f(Player: ลบผู้เล่นที่ผูกกับหินนี้, Waystone: จัดลำดับและลบหินที่เซฟไว้) การเปลี่ยนชื่อมีผลกับรายการของทุกคน", "",
                  `§eค่าใช้จ่าย: §fใช้ ${pearl} อย่างเดียว 1 ต่อ ${WAYPOINT.BLOCKS_PER_PEARL} บล็อก (ต่ำสุด ${WAYPOINT.MIN_COST} สูงสุด ${WAYPOINT.MAX_COST}) ข้ามมิติคิด ${WAYPOINT.MAX_COST} เสมอ คูลดาวน์ ${WAYPOINT.COOLDOWN_SEC} วินาที จะไปโผล่ด้านบนของหิน`,
                  `§eข้อจำกัด: §fคนละ ${WAYPOINT.PER_PLAYER_MAX} ก้อน เซฟได้คนละ ${WAYPOINT.SAVED_MAX} ที่ ห่างกันอย่างน้อย ${WAYPOINT.MIN_SPACING} บล็อก ทุบได้เฉพาะเจ้าของ (หรือ Admin) และระเบิดทำลายไม่ได้ หินที่ถูกทำลายจะค้างในรายการจนกว่าจะลบเอง แต่เทเลพอร์ตไปไม่ได้`,
                  "§7Script Tool > Waypoints เปิดตัวจัดการ Waystone ได้จากทุกที่", "",
                  "§bWaypoint Stone (Blank) §f(คราฟต์: Stone Bricks 4, Ender Pearl 1)", "",
                  "§fไม่มีชื่อ ไม่มีเจ้าของ คลิกขวาเพื่อเทเลพอร์ตไปยังที่ที่เซฟไว้ (Teleport และ Manager > Waystone) ใครก็ทุบได้", "",
                  "§dWaypoint Orb §f(คราฟต์: Netherite Ingot 4, Echo Shard 2, Ender Eye 1, Nether Star 1, Myth Gem 1)", "",
                  `§fใช้ได้ทุกที่: Teleport, Manager > Waystone และ Edit ใน Edit สามารถ §aAdd §fจุดพิเศษตรงที่ยืนได้สูงสุด ${WAYPOINT.SPECIAL_MAX} จุด §eRename §fและ §cRemove §fจุดพิเศษอยู่บนสุดของรายการเสมอ ไม่เสียค่าใช้จ่าย คูลดาวน์ ${WAYPOINT.SPECIAL_COOLDOWN_SEC} วินาที`, "",
                  "§bDiscovery Log", "",
                  `§fสมุดบันทึกจำ §e${biomes} ไบโอม§f, §e${STRUCTURE_CATALOG.length} โครงสร้าง §fและ 3 มิติที่คุณเคยเจอ เปิดได้จาก Script Tool`,
                  `§eรางวัลเจอครั้งแรก: §fได้ Travel Mastery XP ครั้งเดียว (ไบโอม ${DISCOVERY.XP_BIOME}, โครงสร้าง ${DISCOVERY.XP_STRUCTURE}, Nether / End ${DISCOVERY.XP_DIMENSION}) สาย Travel ปลดล็อกที่ Prestige ${MASTERY.UNLOCK_PRESTIGE} สิ่งที่เจอก่อนหน้านั้นยังถูกบันทึกแต่ไม่ได้ XP`,
                  "§7โครงสร้างตรวจจากบล็อกเฉพาะตัวที่อยู่ใกล้คุณ จึงควรเดินดูรอบๆ ข้างในโครงสร้าง ไม่นับโหมด Creative และ Spectator")),
        };
    },

    toast: (lang) => ({
        title: t(lang, "§lToast Pop-ups", "§lToast ป๊อปอัป"),
        body: t(lang,
            L("§fSmall cards at the top right of the screen. They appear for an §eAchievement§f (frame colour = tier: Bronze, Silver, Gold, Platinum, Mythic), a new §bDiscovery §f(biome, structure, dimension) and an §cAscension §fraised by anyone.", "",
              "§7Turn them off in Settings > Toast pop-ups to get the classic chat / action bar lines instead.", "",
              "§bToast Composer §f(Script Tool)", "",
              `§fSend your own card. To §eyourself it is free§f. To another player it costs §e${TOAST.SEND_COST} ${TOAST_COST_NAME}s§f; if you do not have enough, nothing is sent and nothing is taken. Wait ${TOAST.SEND_COOLDOWN_SEC}s between paid sends.`,
              "§fPick a frame, an icon (or type a 4-character icon key), a header and a body. Use §ePreview only §fto see it on yourself first.", "",
              "§bRules", "",
              "§fHeader: English letters and numbers only, max 28. Body: any language, about 22 characters fit. Colours: §e&a &b &c &d &e &f §fand §e&l §ffor bold.", "",
              "§bCommand", "",
              "§e/scriptevent toast:send @s | gold | CB01 | Hello | &eWelcome", "",
              "§7Format: target | frame | icon | header | body | sound. Command blocks and Admins can also use @a, @p, @r. /scriptevent toast:help shows the list."),
            L("§fการ์ดเล็กๆ มุมขวาบนของหน้าจอ แสดงเมื่อปลดล็อก §eAchievement §f(สีกรอบตามระดับ: Bronze, Silver, Gold, Platinum, Mythic), เจอ §bDiscovery §fใหม่ (ไบโอม, สิ่งปลูกสร้าง, มิติ) และเมื่อมีคนยก §cAscension §fของโลก", "",
              "§7ปิดได้ที่ Settings > Toast pop-ups แล้วจะกลับไปใช้ข้อความในแชท / Action Bar แบบเดิม", "",
              "§bToast Composer §f(Script Tool)", "",
              `§fส่งการ์ดของตัวเอง ส่งให้ §eตัวเองฟรี§f ส่งให้ผู้เล่นคนอื่นใช้ §e${TOAST.SEND_COST} ${TOAST_COST_NAME}§f ถ้ามีไม่พอจะไม่ส่งและไม่หักของ รอ ${TOAST.SEND_COOLDOWN_SEC} วินาทีระหว่างการส่งแบบเสียค่าใช้จ่าย`,
              "§fเลือกกรอบ ไอคอน (หรือพิมพ์รหัสไอคอน 4 ตัวอักษร) หัวข้อ และเนื้อหา ใช้ §ePreview only §fเพื่อดูตัวอย่างบนหน้าจอตัวเองก่อน", "",
              "§bกติกา", "",
              "§fหัวข้อ: อังกฤษและตัวเลขเท่านั้น สูงสุด 28 ตัว เนื้อหา: ใช้ได้ทุกภาษา แสดงได้ประมาณ 22 ตัวอักษร สี: §e&a &b &c &d &e &f §fและ §e&l §fสำหรับตัวหนา", "",
              "§bคำสั่ง", "",
              "§e/scriptevent toast:send @s | gold | CB01 | Hello | &eWelcome", "",
              "§7รูปแบบ: เป้าหมาย | กรอบ | ไอคอน | หัวข้อ | เนื้อหา | เสียง Command Block และ Admin ใช้ @a, @p, @r ได้ด้วย พิมพ์ /scriptevent toast:help เพื่อดูรายการ")),
    }),

    items: (lang) => ({
        title: t(lang, "§lItem Categories", "§lหมวดหมู่ไอเทม"),
        body: t(lang,
            L("§fEvery item belongs to one of §e4 groups§f:", "",
              "§cWeapon §7- Sword, Bow, Spear, Trident, Mace, Magic",
              "§eTool §7- Pickaxe, Axe, Shovel, Hoe, Shears",
              "§9Armor §7- Helmet, Chestplate, Leggings, Boots, Shield",
              "§aConsumable §7- Food, Drink, Ammo, Gem, Rune", "",
              "§bWhere it shows", "",
              "§fMenus that list your items (Reforge, Salvage, Vanilla Enchant) now print the group and kind under the name, like §7Weapon · Sword§f.", "",
              "§bRunes", "",
              "§fOnly §cWeapons §fand §eTools §fcan hold a Rune. §eShears§f, Armor (shield included) and Consumables cannot. Armor uses Gems instead.", "",
              "§7Items you already own keep working; nothing is lost or converted."),
            L("§fไอเทมทุกชิ้นอยู่ใน §e4 หมวดใหญ่§f:", "",
              "§cอาวุธ §7- ดาบ, ธนู, หอก, ตรีศูล, กระบอง, เวท",
              "§eเครื่องมือ §7- พิกแอ็กซ์, ขวาน, พลั่ว, จอบ, กรรไกร",
              "§9เกราะ §7- หมวก, เกราะ, กางเกง, รองเท้า, โล่",
              "§aไอเทมใช้งาน §7- อาหาร, เครื่องดื่ม, กระสุน, มณี, รูน", "",
              "§bแสดงที่ไหน", "",
              "§fเมนูที่แสดงรายการไอเทม (Reforge, Salvage, Vanilla Enchant) จะแสดงหมวดและชนิดใต้ชื่อ เช่น §7อาวุธ · ดาบ§f", "",
              "§bรูน", "",
              "§fมีเพียง §cอาวุธ §fและ §eเครื่องมือ §fที่ติดรูนได้ ส่วน §eกรรไกร§f เกราะ (รวมโล่) และไอเทมใช้งานติดรูนไม่ได้ เกราะใช้มณีแทน", "",
              "§7ไอเทมเดิมที่มีอยู่ใช้ได้ตามปกติ ไม่มีอะไรหายหรือถูกแปลง")),
    }),

    qol: (lang) => ({
        title: t(lang, "§lQuality of Life", "§lความสะดวกสบาย"),
        body: t(lang,
            L("§bQuick Stash §f(Script Tool)", "",
              `§fOne tap moves items from your inventory into chests / barrels within §e${STASH.RADIUS} blocks§f, but only item types the container §ealready holds§f.`,
              "§7Never moved: the held item, armor, and any item with lore (runes, gems, augments, reforged gear). The hotbar is skipped unless you turn it on in Settings.", "",
              "§bSettings §f(Script Tool)", "",
              "§fPersonal on/off switches: Toast pop-ups, achievement and discovery notices (chat / action bar), Quick Stash hotbar and Chorus Aura. Your choices are saved per player and survive Prestige and resets. A server-wide §eoff§f from the Admin always wins.", "",
              "§bRe-Crops Rune §f(Hoe)", "",
              "§fA Hoe with the §eRe-Crops §fRune plants a fully grown crop again (wheat, carrots, potatoes, beetroot, nether wart), using a seed from the drops (or your inventory). Works with Vein. Not in Creative.", "",
              "§bChorus Aura", "",
              "§fParticles around you that match your strongest Chorus set. Purely cosmetic; higher tiers shine more. Other players see it too.", "",
              "§bHealth Display", "",
              `§fMobs within §e${HEALTH_DISPLAY.SCAN_RADIUS} blocks §f(bosses §e${HEALTH_DISPLAY.BOSS_RADIUS}§f) show their HP as numbers under their name, like §cHP §f12.5K§7/§f25K§f, shown when you aim at the mob (like any name tag). Evolved and Ascension mobs show their real, scaled HP. The current HP turns §4red §fwhen hit and §agreen §fwhen healed. Players are not shown.`,
              "§7Admin can switch it on or off for the whole world (Config Editor).", "",
              "§bDamage Numbers", "",
              `§fEvery hit you land on a mob or boss pops up the damage as a floating number near it for 2 seconds: §fwhite §ffor a normal hit and §6orange §ffor a critical hit. It shows the damage that was really dealt, after all bonuses. Up to §e${DAMAGE_INDICATOR.MAX_PER_PLAYER} §fnumbers per player at once; hits on mobs farther than §e${DAMAGE_INDICATOR.VIEW_RADIUS} blocks §fshow nothing. Hits on the same mob within §e${(DAMAGE_INDICATOR.MERGE_TICKS / 20).toFixed(1)} §fsecond merge into one number. Other players see the numbers too.`,
              "§7Bonus damage from some Runes is not shown. Admin can switch it on or off (Config Editor)."),
            L("§bQuick Stash §f(Script Tool)", "",
              `§fแตะครั้งเดียวย้ายของจากช่องเก็บของไปยังหีบ / บาร์เรลในระยะ §e${STASH.RADIUS} บล็อก §fโดยย้ายเฉพาะชนิดไอเทมที่ภาชนะนั้น §eมีอยู่แล้ว`,
              "§7จะไม่ย้าย: ไอเทมที่ถืออยู่, เกราะ และไอเทมที่มี lore (รูน, เจม, ออกเมนต์, ของที่ Reforge) ช่อง Hotbar ถูกข้ามเว้นแต่เปิดใน Settings", "",
              "§bSettings §f(Script Tool)", "",
              "§fสวิตช์เปิด/ปิดส่วนตัว: Toast ป๊อปอัป, แจ้งเตือน Achievement และ Discovery (แชท / Action Bar), Hotbar ของ Quick Stash และ Chorus Aura บันทึกต่อผู้เล่นและไม่หายเมื่อ Prestige หรือรีเซ็ต ถ้า Admin ปิดทั้งเซิร์ฟเวอร์ จะถือตามนั้นเสมอ", "",
              "§bRune Re-Crops §f(จอบ)", "",
              "§fจอบที่ติด Rune §eRe-Crops §fจะปลูกพืชที่โตเต็มที่ซ้ำให้ (ข้าวสาลี, แครอท, มันฝรั่ง, บีทรูท, เนเธอร์วอร์ต) โดยใช้เมล็ดจากของที่ดรอป (หรือจากกระเป๋า) ใช้ร่วมกับ Vein ได้ ไม่ทำงานในโหมด Creative", "",
              "§bChorus Aura", "",
              "§fอนุภาครอบตัวตามเซ็ต Chorus ที่แข็งที่สุดของคุณ เป็นความสวยงามอย่างเดียว ยิ่งระดับสูงยิ่งเด่น ผู้เล่นอื่นเห็นด้วย", "",
              "§bHealth Display", "",
              `§fมอนในระยะ §e${HEALTH_DISPLAY.SCAN_RADIUS} บล็อก §f(บอส §e${HEALTH_DISPLAY.BOSS_RADIUS}§f) แสดง HP เป็นตัวเลขใต้ชื่อ เช่น §cHP §f12.5K§7/§f25K§f จะขึ้นเมื่อเล็งไปที่มอน (เหมือนชื่อจาก Name Tag ทั่วไป) มอน Evolve และ Ascension แสดง HP จริงหลังคูณแล้ว ค่า HP ปัจจุบันเป็น §4สีแดง §fเมื่อโดนตี และ §aสีเขียว §fเมื่อฟื้น ไม่แสดงผู้เล่น`,
              "§7Admin เปิด/ปิดได้ทั้งโลก (Config Editor)", "",
              "§bDamage Numbers", "",
              `§fทุกครั้งที่คุณโจมตีมอนหรือบอส จะมีตัวเลขความเสียหายลอยขึ้นใกล้ตัวมอน 2 วินาที: §fสีขาว §fเมื่อตีปกติ และ §6สีส้ม §fเมื่อเป็นคริติคอล แสดงความเสียหายที่หักจริงหลังบวกโบนัสทั้งหมดแล้ว พร้อมกันได้สูงสุด §e${DAMAGE_INDICATOR.MAX_PER_PLAYER} §fตัวต่อผู้เล่น ถ้ามอนอยู่ไกลเกิน §e${DAMAGE_INDICATOR.VIEW_RADIUS} บล็อก §fจะไม่แสดง ตีมอนตัวเดิมซ้ำภายใน §e${(DAMAGE_INDICATOR.MERGE_TICKS / 20).toFixed(1)} §fวินาที ตัวเลขจะรวมเป็นตัวเดียว ผู้เล่นอื่นเห็นตัวเลขด้วย`,
              "§7ดาเมจโบนัสจากรูนบางชนิดไม่แสดงตัวเลข Admin เปิด/ปิดได้ (Config Editor)")),
    }),

    resources: (lang) => ({
        title: t(lang, "§lResource Guide", "§lคู่มือหาวัตถุดิบ"),
        body: t(lang,
            L("§fKey materials and where to get them:", "",
              `§eUncarved Gem §f— Wither, Warden and Ender Dragon (Ascension ${MOB_SCALING.BOSS_GEM_MIN_ASCENSION}+), Geode mobs (Ascension ${EVOLUTION.TIERS.geode.unlockAsc}+) and rarely Awakened mobs. Craft: §f9x Gem Dust §f-> 1.`, "",
              "§eGem Dust §f— crush an Uncarved Gem with a Reforge Hammer §7(Mainhand: Gem, Offhand: Hammer)§f.", "",
              "§eResonant Ink §f— Brewing Stand: §7Dragon's Breath + Echo Shard§f.", "",
              "§eGenesis Ink §f— Brewing Stand: §7Resonant Ink + Uncarved Gem Block §8(9x Uncarved Gem -> 1 Block)§f. §8Only used to brew Transcendent Ink.", "",
              "§eReforge Hammer §f— craft: §7Iron Block + Dark Oak Log§f.", "",
              "§eEngraver §f— craft: §7Amethyst Shard + Netherite Ingot + Amethyst Block§f.", "",
              "§eStellar Upgrade §f— craft: §7Netherite Upgrade Template + Uncommon Gems + Gold Blocks §8(duplication is intentionally expensive)§f.", "",
              "§eEternal Engraver / Ultimate Picker / Insight Lens §f— Smithing Table (or crafting): §7Stellar Upgrade + the right Gem tier§f.", "",
              "§eUltimate Enchanter §f— craft: §74 Uncarved Gems + Stone Bricks + Crafting Table + Enchanting Table§f."),
            L("§fวัตถุดิบสำคัญและวิธีหา:", "",
              `§eUncarved Gem §f— ดรอปจาก Wither, Warden, Ender Dragon (ตั้งแต่ Ascension ${MOB_SCALING.BOSS_GEM_MIN_ASCENSION}) มอน Geode (Ascension ${EVOLUTION.TIERS.geode.unlockAsc}+) และมอน Awakened (หายาก) หรือคราฟต์ §f9x Gem Dust §f-> 1`, "",
              "§eGem Dust §f— บด Uncarved Gem ด้วย Reforge Hammer §7(มือหลัก: Gem, มือรอง: ค้อน)§f", "",
              "§eResonant Ink §f— แท่นปรุงยา: §7Dragon's Breath + Echo Shard§f", "",
              "§eGenesis Ink §f— แท่นปรุงยา: §7Resonant Ink + Uncarved Gem Block §8(Uncarved Gem 9 เม็ด -> 1 บล็อก)§f §8ใช้ปรุง Transcendent Ink เท่านั้น", "",
              "§eReforge Hammer §f— คราฟต์: §7Iron Block + Dark Oak Log§f", "",
              "§eEngraver §f— คราฟต์: §7Amethyst Shard + Netherite Ingot + Amethyst Block§f", "",
              "§eStellar Upgrade §f— คราฟต์: §7Netherite Upgrade Template + Uncommon Gems + Gold Blocks §8(การทำซ้ำแพงโดยตั้งใจ)§f", "",
              "§eEternal Engraver / Ultimate Picker / Insight Lens §f— Smithing Table (หรือคราฟต์): §7Stellar Upgrade + Gem ระดับที่ถูกต้อง§f", "",
              "§eUltimate Enchanter §f— คราฟต์: §7Uncarved Gem 4 เม็ด + Stone Bricks + Crafting Table + Enchanting Table§f")),
    }),

    // ═══ Encyclopedia ══════════════════════════════════════════════════════

    e_melee:     (lang) => runeEncy(lang, ["sword", "spear", "mace"], t(lang, "§lEncyclopedia — Sword, Spear & Mace Runes", "§lสารานุกรม — Rune ดาบ หอก กระบอง")),
    e_ranged:    (lang) => runeEncy(lang, ["bow", "trident"], t(lang, "§lEncyclopedia — Bow & Trident Runes", "§lสารานุกรม — Rune ธนู ตรีศูล")),
    e_allweapon: (lang) => runeEncy(lang, ["all_weapon"], t(lang, "§lEncyclopedia — All-Weapon Runes", "§lสารานุกรม — Rune ทุกอาวุธ")),
    e_tool:      (lang) => runeEncy(lang, ["pickaxe", "axe", "shovel", "hoe", "all_tool", "curse"], t(lang, "§lEncyclopedia — Tool & Curse Runes", "§lสารานุกรม — Rune เครื่องมือ และคำสาป")),

    e_gems:  (lang) => gemEncy(lang, ["common", "uncommon", "rare"], t(lang, "§lEncyclopedia — Gems (Tier 1-3)", "§lสารานุกรม — Gem (ระดับ 1-3)")),
    e_gems2: (lang) => gemEncy(lang, ["unique", "legend", "epic", "mythical"], t(lang, "§lEncyclopedia — Gems (Tier 4-7)", "§lสารานุกรม — Gem (ระดับ 4-7)")),

    e_chorus: (lang) => {
        const rows = [];
        for (const [key, tier] of Object.entries(CHORUS_TIERS)) {
            const els = Object.values(CHORUS_ELEMENTS).filter((e) => e.tier === key).map((e) => `${e.color}${e.label}`).join("§7, ");
            if (tier.fusion) {   // Awaken and above: no hybrids, show the Fusion recipes instead
                rows.push(`${tier.color}${tier.label}`, `§7  ${els}`,
                    ...Object.entries(CHORUS_FUSION).filter(([id]) => CHORUS_ELEMENTS[id].tier === key)
                        .map(([id, r]) => `§8  ${CHORUS_ELEMENTS[id].label} = ${r.from.map((f) => CHORUS_ELEMENTS[f].label).join(" + ")}`), "");
                continue;
            }
            const hybrids = Object.values(CHORUS_HYBRIDS).filter((h) => CHORUS_ELEMENTS[h.elements[0]].tier === key).map((h) => h.name).join(", ");
            rows.push(`${tier.color}${tier.label}`, `§7  ${els}`, `§8  ${t(lang, "Hybrids", "ชุดผสม")}: ${hybrids}`, "");
        }
        return {
            title: t(lang, "§lEncyclopedia — Chorus Elements", "§lสารานุกรม — ธาตุ Chorus"),
            body: L(t(lang, "§dChorus Elements§r §8(armor sockets)", "§dธาตุ Chorus§r §8(ช่องบนเกราะ)"), "", ...rows).trimEnd(),
        };
    },

    e_synergy: (lang) => {
        const fx = (r) => {
            if (!r) return "-";
            const out = [];
            if (r.bonusPct) out.push(`+${r.bonusPct}% dmg`);
            if (r.burn || r.burnAttacker) out.push(`burn ${r.burn ?? r.burnAttacker}s`);
            const st = r.target ?? r.attacker;
            if (st) out.push(`${st[0]} ${Math.round(st[1] / 20 * 10) / 10}s`);
            if (r.self) out.push(`self ${r.self[0]} ${Math.round(r.self[1] / 20 * 10) / 10}s`);
            if (r.healPct) out.push(`heal ${r.healPct}%`);
            return out.join(", ") + (r.chance ? ` (${r.chance}%)` : "");
        };
        const rows = [];
        for (const [id, e] of Object.entries(CHORUS_ELEMENTS).filter(([, x]) => !CHORUS_TIERS[x.tier].fusion)) {
            rows.push(`${e.color}${e.label}`, `§7  ${t(lang, "Hit", "\u0e42\u0e08\u0e21\u0e15\u0e35")}: §f${fx(ELEMENT_HIT[id])}`, `§7  ${t(lang, "Guard", "\u0e1b\u0e49\u0e2d\u0e07\u0e01\u0e31\u0e19")}: §f${fx(ELEMENT_GUARD[id])}`, "");
        }
        return {
            title: t(lang, "§lEncyclopedia -- Chorus Synergy", "§l\u0e2a\u0e32\u0e23\u0e32\u0e19\u0e38\u0e01\u0e23\u0e21 -- Chorus Synergy"),
            body: L(t(lang, `§8Bonus effect from ${SYNERGY.RIDER_MIN_SLOTS}+ matching sockets (more at 6 / 8). Hit = offensive Gem / Rune hits, Guard = defensive Gems when you are hit.`, `§8\u0e42\u0e1a\u0e19\u0e31\u0e2a\u0e40\u0e21\u0e37\u0e48\u0e2d\u0e18\u0e32\u0e15\u0e38\u0e15\u0e23\u0e07\u0e01\u0e31\u0e19 ${SYNERGY.RIDER_MIN_SLOTS}+ \u0e0a\u0e48\u0e2d\u0e07 (\u0e41\u0e23\u0e07\u0e02\u0e36\u0e49\u0e19\u0e17\u0e35\u0e48 6 / 8)`), "", ...rows).trimEnd(),
        };
    },

    e_bestiary: (lang) => {
        const T = EVOLUTION.TIERS, A = AWAKEN_ABILITIES;
        const st = (x) => `§8HP x${x.hp} / ${t(lang, "Dmg", "ดาเมจ")} x${x.damage} / XP x${x.xp}`;
        const rows = [
            `${T.tough.color}${T.tough.name} §8(Asc ${T.tough.unlockAsc})`, st(T.tough),
            t(lang, "§7  Sturdier, hits harder, more XP.", "§7  ทนขึ้น ตีแรงขึ้น ให้ XP มากขึ้น"), "",
            `${T.elite.color}${T.elite.name} §8(Asc ${T.elite.unlockAsc})`, st(T.elite),
            t(lang,
                `§7  Fast below ${pc(T.elite.enrageBelow)}${PCT} HP; calls ${T.elite.callCount} allies below ${pc(T.elite.callBelow)}${PCT} (zombie, skeleton, pillager families).`,
                `§7  วิ่งเร็วเมื่อ HP ต่ำกว่า ${pc(T.elite.enrageBelow)}${PCT} เรียกพวก ${T.elite.callCount} ตัวเมื่อต่ำกว่า ${pc(T.elite.callBelow)}${PCT} (สายซอมบี้ สเกเลตัน พิลเลเจอร์)`), "",
            `${T.sculk.color}${T.sculk.name} §8(Asc ${T.sculk.unlockAsc})`, st(T.sculk),
            t(lang,
                `§7  Senses you through walls (${T.sculk.senseRange} blocks; ${T.sculk.senseRangeNoisy} if you sprint, jump, or it is night / underground). +${pc(T.sculk.hotDamageBonus)}${PCT} damage and faster while you are noisy. Always drops ${T.sculk.shardMin}-${T.sculk.shardMax} Echo Shards. Sculk Potion (1 Echo Shard + 2 Soul Soil + 2 Glass Bottle = 2 potions): hit a monster while holding it to turn it Sculk at any Ascension (such mobs drop no Shards).`,
                `§7  รับรู้คุณทะลุกำแพง (${T.sculk.senseRange} บล็อก; ${T.sculk.senseRangeNoisy} ถ้าคุณวิ่ง กระโดด หรือเป็นกลางคืน/ใต้ดิน) ตีแรงขึ้น +${pc(T.sculk.hotDamageBonus)}${PCT} และวิ่งเร็วขึ้นเมื่อคุณส่งเสียง ดรอป Echo Shard ${T.sculk.shardMin}-${T.sculk.shardMax} ชิ้นแน่นอน Sculk Potion (Echo Shard 1 + Soul Soil 2 + Glass Bottle 2 ได้ 2 ขวด) ถือตีมอนเพื่อเปลี่ยนเป็น Sculk ได้ทุกระดับ Ascension (มอนแบบนี้ไม่ดรอป Shard)`), "",
            `${T.geode.color}${T.geode.name} §8(Asc ${T.geode.unlockAsc})`, st(T.geode),
            t(lang, `§7  ${pc(T.geode.gemChance)}${PCT} to drop an Uncarved Gem when you kill it.`, `§7  ${pc(T.geode.gemChance)}${PCT} ดรอป Uncarved Gem เมื่อคุณฆ่า`), "",
            `${T.inferno.color}${T.inferno.name} §8(Asc ${T.inferno.unlockAsc})`, st(T.inferno),
            t(lang,
                `§7  ${pc(T.inferno.burnChance)}${PCT} to set you ablaze. In the Nether its stat bonus is x${T.inferno.netherPower}; elsewhere it only has the flames.`,
                `§7  ${pc(T.inferno.burnChance)}${PCT} ทำให้คุณติดไฟ ใน Nether โบนัสสเตตัส x${T.inferno.netherPower} ที่อื่นมีแค่ไฟ`), "",
            `${T.nightmare.color}${T.nightmare.name} §8(Asc ${T.nightmare.unlockAsc}, event)`, st(T.nightmare),
            t(lang, `§7  Only from the Nightmare event. ${pc(T.nightmare.blindChance)}${PCT} to blind you on hit.`, `§7  มาจากอีเวนต์ Nightmare เท่านั้น ${pc(T.nightmare.blindChance)}${PCT} ทำให้ตาบอดเมื่อโดนตี`), "",
            `${T.core.color}${T.core.name} §8(Asc ${T.core.unlockAsc})`, st(T.core),
            t(lang,
                `§7  Stationary, but still attacks. One hit never removes more than ${pc(T.core.hitCapFraction)}${PCT} of its HP, so it can't be one-shot. ${pc(T.core.dropChance)}${PCT} to drop ONE Augment Core or Stellar Core.`,
                `§7  ขยับไม่ได้แต่ยังโจมตี ตีครั้งเดียวไม่เกิน ${pc(T.core.hitCapFraction)}${PCT} ของ HP จึงฆ่าทีเดียวไม่ได้ ${pc(T.core.dropChance)}${PCT} ดรอป Augment Core หรือ Stellar Core อย่างใดอย่างหนึ่ง 1 ชิ้น`), "",
            `${ENCHANTED.color}${ENCHANTED.name} §8(modifier)`, `§8XP x${ENCHANTED.xp}`,
            t(lang,
                `§7  Any tier except Core. A shield blocks one whole hit, then returns after ${ENCHANTED.shieldIntervalMs / 1000}s. Always drops ${ENCHANTED.essenceMin}-${ENCHANTED.essenceMax} Enchant Essence and ${ENCHANTED.crystalMin}-${ENCHANTED.crystalMax} Augment Crystal.`,
                `§7  ติดได้ทุก Tier ยกเว้น Core เกราะกันดาเมจได้ 1 ครั้งเต็มๆ แล้วกลับมาใน ${ENCHANTED.shieldIntervalMs / 1000} วินาที ดรอป Enchant Essence ${ENCHANTED.essenceMin}-${ENCHANTED.essenceMax} ชิ้น และ Augment Crystal ${ENCHANTED.crystalMin}-${ENCHANTED.crystalMax} ชิ้นแน่นอน`), "",
            `${T.awaken.color}${T.awaken.name} §8(Asc ${T.awaken.unlockAsc})`, st(T.awaken),
            t(lang,
                "§7  Zombie family: dash, berserk at low HP, rallies allies. Skeleton family: fires extra arrows. Spider family: webs your feet, leaps.",
                "§7  สายซอมบี้: พุ่งเข้าใส่ คลั่งตอน HP ต่ำ เรียกพวก สายสเกเลตัน: ยิงธนูเสริม สายแมงมุม: วางใยใต้เท้า กระโดดพุ่ง"),
            t(lang, "§7  Other mobs (Creeper, Enderman, Witch, Blaze...) and bosses: see Special Mobs & Bosses.", "§7  มอนอื่น (Creeper, Enderman, Witch, Blaze...) และบอส: ดูหัวข้อมอนพิเศษและบอส"),
            t(lang,
                `§7  Random mutation: ${Object.values(T.awaken.mutations).map((m) => m.name).join(", ")}. Rare drops: Uncarved Gem, Gem Dust.`,
                `§7  มี Mutation สุ่ม: ${Object.values(T.awaken.mutations).map((m) => m.name).join(", ")} ดรอปหายาก: Uncarved Gem, Gem Dust`),
        ];
        return {
            title: t(lang, "§lEncyclopedia — Enemy Bestiary", "§lสารานุกรม — ทำเนียบศัตรู"),
            body: L(t(lang, "§cEvolved Mobs§r §8(multipliers vs the Ascension-scaled mob)", "§cมอนวิวัฒน์§r §8(ตัวคูณเทียบมอนที่ปรับตาม Ascension)"), "", ...rows),
        };
    },

    e_special: (lang) => {
        const sec = (ms) => Math.round(ms / 1000);
        const A = SA, R = SPECIAL.RAGE;
        const mobRows = [
            t(lang, "§dCreeper", "§dCreeper"),
            t(lang, `§7  Pounce lunge every ${sec(A.creeper.pounce.cooldownMs)}s. If a player kills it, a small blast (no block damage) follows after ${r1(A.creeper.deathBlast.delayTicks / 20)}s.`,
                    `§7  พุ่งเข้าใส่ทุก ${sec(A.creeper.pounce.cooldownMs)} วิ ถ้าผู้เล่นฆ่า จะมีระเบิดเล็ก (ไม่ทำลายบล็อก) ตามมาหลัง ${r1(A.creeper.deathBlast.delayTicks / 20)} วิ`),
            t(lang, "§dEnderman", "§dEnderman"),
            t(lang, `§7  Blink: when you look at it from ${A.enderman.blink.minDist}-${A.enderman.blink.maxDist} blocks it teleports right behind you (every ${sec(A.enderman.blink.cooldownMs)}s, safe spots only).`,
                    `§7  Blink: เมื่อคุณมองมันจากระยะ ${A.enderman.blink.minDist}-${A.enderman.blink.maxDist} บล็อก มันจะวาร์ปไปด้านหลังคุณ (ทุก ${sec(A.enderman.blink.cooldownMs)} วิ เฉพาะจุดที่ปลอดภัย)`),
            t(lang, "§dWitch", "§dWitch"),
            t(lang, `§7  Hex: Slowness + Weakness within ${A.witch.hex.maxDist} blocks (every ${sec(A.witch.hex.cooldownMs)}s). Heals ${pc(A.witch.heal.fraction)}${PCT} once below ${pc(A.witch.heal.below)}${PCT} HP.`,
                    `§7  Hex: Slowness + Weakness ในระยะ ${A.witch.hex.maxDist} บล็อก (ทุก ${sec(A.witch.hex.cooldownMs)} วิ) ฟื้น ${pc(A.witch.heal.fraction)}${PCT} หนึ่งครั้งเมื่อ HP ต่ำกว่า ${pc(A.witch.heal.below)}${PCT}`),
            t(lang, "§dBlaze", "§dBlaze"),
            t(lang, `§7  Fire volley: ${A.blaze.volley.count} fireballs fanned at you every ${sec(A.blaze.volley.cooldownMs)}s.`,
                    `§7  ยิงไฟรัว ${A.blaze.volley.count} ลูกเป็นแนวพัดใส่คุณทุก ${sec(A.blaze.volley.cooldownMs)} วิ`),
            t(lang, "§dPillager", "§dPillager"),
            t(lang, `§7  Fires 2 extra arrows every ${sec(A.pillager.volley.cooldownMs)}s.`, `§7  ยิงธนูเพิ่ม 2 ดอกทุก ${sec(A.pillager.volley.cooldownMs)} วิ`),
            t(lang, "§dVindicator / Piglin Brute", "§dVindicator / Piglin Brute"),
            t(lang, `§7  Rage below ${pc(R.below)}${PCT} HP: faster and +${pc(R.damageBonus)}${PCT} damage.`, `§7  Rage เมื่อ HP ต่ำกว่า ${pc(R.below)}${PCT}: เร็วขึ้นและดาเมจ +${pc(R.damageBonus)}${PCT}`),
            t(lang, "§dEvoker", "§dEvoker"),
            t(lang, `§7  Fang line: ${A.evoker.fangs.count} fangs erupt toward you every ${sec(A.evoker.fangs.cooldownMs)}s.`, `§7  Fang line: เขี้ยว ${A.evoker.fangs.count} อันพุ่งขึ้นเป็นแนวเข้าหาคุณทุก ${sec(A.evoker.fangs.cooldownMs)} วิ`),
            t(lang, "§dGuardian", "§dGuardian"),
            t(lang, `§7  Tidal pull: drags you toward it every ${sec(A.guardian.pull.cooldownMs)}s.`, `§7  Tidal pull: ดึงคุณเข้าหามันทุก ${sec(A.guardian.pull.cooldownMs)} วิ`),
            t(lang, "§dBreeze", "§dBreeze"),
            t(lang, `§7  Gust: blasts you away when closer than ${A.breeze.gust.maxDist} blocks (every ${sec(A.breeze.gust.cooldownMs)}s).`, `§7  Gust: เป่าคุณกระเด็นเมื่ออยู่ใกล้กว่า ${A.breeze.gust.maxDist} บล็อก (ทุก ${sec(A.breeze.gust.cooldownMs)} วิ)`),
        ];
        const bossRows = [];
        for (const boss of Object.values(SPECIAL_BOSSES)) {
            bossRows.push(`§6${boss.name}`);
            for (const ph of boss.phases) {
                const bits = [];
                if (ph.aura) bits.push(t(lang, `aura ${ph.aura.radius} blocks (${ph.aura.effects.map((e) => e.id).join(" + ")})`, `ออร่า ${ph.aura.radius} บล็อก (${ph.aura.effects.map((e) => e.id).join(" + ")})`));
                if (ph.tremor) bits.push(t(lang, `tremor ${ph.tremor.radius} blocks (push, hurt, Darkness)`, `แผ่นดินไหว ${ph.tremor.radius} บล็อก (ผลัก ทำดาเมจ Darkness)`));
                if (ph.summon) bits.push(t(lang, `summons ${ph.summon.count}x ${ph.summon.type.replace("minecraft:", "")}`, `เรียก ${ph.summon.type.replace("minecraft:", "")} ${ph.summon.count} ตัว`));
                if (ph.enrage) bits.push(t(lang, `enrage (faster, +${pc(ph.enrage.damageBonus)}${PCT} damage)`, `คลั่ง (เร็วขึ้น ดาเมจ +${pc(ph.enrage.damageBonus)}${PCT})`));
                bossRows.push(t(lang,
                    `§7  Below ${pc(ph.below)}${PCT} HP, Asc ${ph.unlockAsc}+: ${bits.join(", ")}`,
                    `§7  HP ต่ำกว่า ${pc(ph.below)}${PCT}, Asc ${ph.unlockAsc}+: ${bits.join(", ")}`));
            }
        }
        return {
            title: t(lang, "§lEncyclopedia — Special Mobs & Bosses", "§lสารานุกรม — มอนพิเศษและบอส"),
            body: L(
                t(lang, "§cAwakened special mobs§r §8(Awakened tier, Asc 7+; on top of the mutation)", "§cมอนพิเศษระดับ Awakened§r §8(Tier Awakened, Asc 7+ เพิ่มจาก Mutation)"), "", ...mobRows, "",
                t(lang, "§cBosses§r §8(abilities unlock per phase as the world Ascends)", "§cบอส§r §8(สกิลปลดล็อกทีละเฟสตาม Ascension ของโลก)"), "", ...bossRows, "",
                t(lang,
                    `§8Evolved mobs are named after their tier. Evolved mobs and boss minions farther than ${SPECIAL.CLEANUP.DISTANCE} blocks from every player are removed. At most ${SPECIAL.MINION_CAP} minions stay near a boss. Ability damage still obeys the ${pc(MOB_SCALING.MAX_HIT_FRACTION)}${PCT} max-hit cap.`,
                    `§8มอนวิวัฒน์ใช้ชื่อตาม Tier มอนวิวัฒน์และลูกสมุนบอสที่ห่างผู้เล่นทุกคนเกิน ${SPECIAL.CLEANUP.DISTANCE} บล็อกจะถูกลบ ลูกสมุนอยู่ใกล้บอสได้ไม่เกิน ${SPECIAL.MINION_CAP} ตัว ดาเมจจากสกิลยังติดเพดาน ${pc(MOB_SCALING.MAX_HIT_FRACTION)}${PCT} ของ Max HP`)),
        };
    },
};

const CATEGORIES = [
    { id: "start",  color: "§f", title: { en: "Getting Started",        th: "เริ่มต้นใช้งาน" },
      pages: ["basics", "guidequest", "stats", "health", "mana", "restrictions", "redeem", "scripttool", "toast"] },
    { id: "prog",   color: "§6", title: { en: "Progression",            th: "ความก้าวหน้า" },
      pages: ["roadmap", "prestige", "perks", "mastery", "ascension", "achievements"] },
    { id: "equip",  color: "§9", title: { en: "Equipment & Enchanting", th: "อุปกรณ์และการเสริมพลัง" },
      pages: ["items", "ultench", "augment", "reforge", "chorus", "mixing", "fusion", "gem", "rune"] },
    { id: "combat", color: "§4", title: { en: "Combat & Enemies",       th: "การต่อสู้และศัตรู" },
      pages: ["combat", "scaling", "evolution", "nightmare"] },
    { id: "gather", color: "§2", title: { en: "Gathering & Resources",  th: "การหาทรัพยากร" },
      pages: ["mining", "resources", "explore", "qol"] },
    { id: "enc",    color: "§d", title: { en: "Encyclopedia",           th: "สารานุกรม" },
      pages: ["e_chorus", "e_synergy", "e_bestiary", "e_special", "e_gems", "e_gems2", "e_melee", "e_ranged", "e_allweapon", "e_tool"] },
];

function buildPage(pageId, lang) {
    try {
        return PAGES[pageId](lang);
    } catch (error) {
        console.warn(`[Knowledge Book] Failed to build page "${pageId}": ${error}`);
        return { title: "§lKnowledge Book", body: t(lang, "§cThis page could not be loaded.", "§cไม่สามารถโหลดหน้านี้ได้") };
    }
}

function topicLabel(page) {
    return "§f" + page.title.replace("§l", "").replace(/^(Encyclopedia|สารานุกรม) — /, "");
}

function showPage(player, lang, catId, pageId) {
    AchievementManager.markSeen(player, "kb", pageId, "kb_topics");
    const ui = UI[lang];
    const page = buildPage(pageId, lang);
    const form = new ActionFormData().title(page.title).body(page.body);

    const actions = page.actions ?? [];
    for (const action of actions) form.button(action.label, action.icon ?? "");
    form.button(ui.back, BACK_ICON);

    GuiService.show(player, form, SCREEN).then((response) => {
        if (response.canceled) return;
        if (response.selection < actions.length) actions[response.selection].run(player);
        else KnowledgeManager.openCategory(player, lang, catId);
    }).catch((error) => {
        console.warn(`[Knowledge Book] Failed to open page "${pageId}": ${error}`);
    });
}

export class KnowledgeManager {
    static openMainMenu(player) {
        onMenuOpened(player, "knowledge"); AchievementManager.event(player, "kb_opened");
        const form = new ActionFormData()
            .title("§lLanguage / ภาษา")
            .body("Choose your language.\nเลือกภาษาของคุณ")
            .button("§fEnglish")
            .button("§fภาษาไทย");

        GuiService.show(player, form, SCREEN).then((response) => {
            if (response.canceled) return;
            this.openTopicMenu(player, response.selection === 1 ? "th" : "en");
        }).catch((error) => {
            console.warn(`[Knowledge Book] Failed to open language menu: ${error}`);
        });
    }

    // Category list
    static openTopicMenu(player, lang) {
        const ui = UI[lang];
        const form = new ActionFormData().title(ui.mainTitle).body(ui.mainBody);
        for (const cat of CATEGORIES) {
            form.button(`${cat.color}§l${cat.title[lang]}\n${ui.topics(cat.pages.length)}`, `${KB_ICON}cat_${cat.id}`);
        }

        GuiService.show(player, form, SCREEN).then((response) => {
            if (response.canceled) return;
            const cat = CATEGORIES[response.selection];
            if (cat) this.openCategory(player, lang, cat.id);
        }).catch((error) => {
            console.warn(`[Knowledge Book] Failed to open topic menu: ${error}`);
        });
    }

    // Topic list of one category
    static openCategory(player, lang, catId) {
        const ui = UI[lang];
        const cat = CATEGORIES.find((c) => c.id === catId);
        if (!cat) return this.openTopicMenu(player, lang);

        const form = new ActionFormData().title(`${cat.color}§l${cat.title[lang]}`).body("§7" + t(lang, "Pick a topic:", "เลือกหัวข้อ:"));
        for (const pageId of cat.pages) form.button(topicLabel(buildPage(pageId, lang)), `${KB_ICON}${pageId}`);
        form.button(ui.back, BACK_ICON);

        GuiService.show(player, form, SCREEN).then((response) => {
            if (response.canceled) return;
            if (response.selection >= cat.pages.length) return this.openTopicMenu(player, lang);
            showPage(player, lang, cat.id, cat.pages[response.selection]);
        }).catch((error) => {
            console.warn(`[Knowledge Book] Failed to open category "${catId}": ${error}`);
        });
    }
}
