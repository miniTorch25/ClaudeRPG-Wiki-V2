// achievement_hooks.js -- connects the existing combat / augment / gem / rune systems to the Achievement counters.
// Phase B3 (Combat category). Everything here only READS game events; it never changes gameplay.
// Pieces that already emit events (damage:after, damage:resolved, kills) are listened to here;
// the few systems without events call the small on* helpers from this file.
import { GuideQuest } from "./guide_quest.js";
import { world, system, EquipmentSlot, EntityComponentTypes } from "@minecraft/server";
import { AchievementManager as AM } from "./achievement_manager.js";
import { EventBus } from "../core/event_bus.js";
import { Scheduler } from "../core/scheduler.js";
import { Logger } from "../core/logger.js";
import { HPManager } from "../managers/hp_manager.js";
import { MobHpManager } from "../managers/mob_hp_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { AugmentManager } from "./augment.js";
import { GemManager } from "./gem_manager.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { AUGMENT_CRYSTAL_COST } from "../config/salvage_config.js";
import { RUNE_PROP_KEY, getRuneKind, getRuneMeta } from "../rune/rune_registry.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { HOE_VEIN_BLOCKS } from "../vein/hoe.js";
import { PRESTIGE_KEYS } from "../config/progression_config.js";
import { ChorusManager } from "./chorus_manager.js";
import { CHORUS_ELEMENTS } from "../config/chorus_config.js";
import { normalizeDamageCause } from "../managers/damage_manager.js";
import { stripRarityPrefix, prettyItemName } from "./rarity_name.js";

const isPlayer = (e) => e?.typeId === "minecraft:player";
const GEM_TIER_ORDER = ["common", "uncommon", "rare", "unique", "legend", "epic", "mythical"];
const FIRE_CAUSES = new Set(["fire", "fire_tick", "in_fire"]);
const MAXED_FLAG = "crpg:ach_maxed";          // set on an item once all its Augment stats were seen at max
const streaks = new Map();                    // playerId -> hits in a row without taking damage
const curseRun = new Map();                   // playerId -> Curse Runes etched in a row
const lowHp = new Set();                      // playerIds that dropped below 10% HP (for Second Wind)
const ARMOR_SLOTS = [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs, EquipmentSlot.Feet];

const lastKillTick = new Map();               // playerId -> tick of the last kill (peaceful time)
const lastAttackTick = new Map();             // playerId -> tick of the last hit dealt
const overkill = new Set();                   // chickens that took a 100+ hit
let registered = false;

// --- Combat: hits dealt (CB) and damage taken (DT) ---------------------------------------
function onDamageAfter(ctx) {
    const a = ctx?.attacker, v = ctx?.victim;
    if (!isPlayer(a) || !v || isPlayer(v)) return;
    const dmg = Number(ctx.finalDamage);
    if (!(dmg > 0)) return;
    const projectile = !!ctx.source?.damagingProjectile;
    const melee = !projectile && (ctx.cause === "entity_attack" || ctx.cause === "mace_smash");
    if (MobHpManager.isScalable(v)) AM.event(a, "hostile_hit");
    if (melee) AM.event(a, "melee_hits");
    if (projectile) {
        AM.event(a, "ranged_hits");
        try {
            const l1 = a.location, l2 = v.location;
            AM.max(a, "max_range_hit", Math.floor(Math.hypot(l1.x - l2.x, l1.y - l2.y, l1.z - l2.z)));
        } catch (_) { /* target gone */ }
    }
    AM.max(a, "max_hit", Math.floor(dmg));
    if (v.typeId === "minecraft:chicken" && dmg >= 100) overkill.add(v.id);
    lastAttackTick.set(a.id, system.currentTick);
    AM.add(a, "total_damage", Math.round(dmg));
    const n = (streaks.get(a.id) ?? 0) + 1;
    streaks.set(a.id, n);
    AM.max(a, "hit_streak", n);
}

function onDamageResolved({ context, target, result } = {}) {
    if (!isPlayer(target) || !(result?.applied > 0)) return;
    streaks.set(target.id, 0);
    const applied = result.applied;
    AM.event(target, "dmg_taken_events");
    AM.add(target, "dmg_taken", applied);
    if (!result.killed) {
        AM.max(target, "max_hit_taken", applied);
        if (result.hp === 1) AM.event(target, "one_hp_survive");
        try {
            if (result.hp / HPManager.getMaxHP(target) < 0.1) { AM.event(target, "low_hp"); lowHp.add(target.id); }
        } catch (_) { /* HP unavailable */ }
    }
    const cause = context?.cause;
    if (cause === "fall") AM.add(target, "fall_dmg", applied);
    else if (FIRE_CAUSES.has(cause)) AM.add(target, "fire_dmg", applied);
    if (context?.attacker?.typeId === "minecraft:creeper") AM.event(target, "creeper_blasts_taken");
    if (cause === "lightning") AM.event(target, "lightning_struck");
    if (cause === "anvil") AM.event(target, "anvil_hit");
    if (context?.attacker?.typeId === "minecraft:enderman") {
        try { if (target.getEntitiesFromViewDirection({ maxDistance: 24 }).some((h) => h.entity?.id === context.attacker.id)) AM.event(target, "enderman_eye"); } catch (_) {}
    }
}

// --- Kills (MS) ------------------------------------------------------------------------------
// Must run BEFORE EvolutionManager.onKill (that one clears the tier cache), so main.js registers it first.
export function onKill(kill) {
    const killer = kill?.killer, victim = kill?.victim;
    if (!isPlayer(killer) || !victim || isPlayer(victim)) return;
    const hostile = MobHpManager.isScalable(victim);
    const tierId = EvolutionManager.getTierId(victim);
    if (killer.isSneaking) AM.event(killer, "sneak_kills");
    if (hostile) {
        AM.event(killer, "kills_hostile");
        try { if (victim.dimension.id === "minecraft:nether") AM.event(killer, "kills_nether"); } catch (_) {}
        if (kill.isUndead) AM.event(killer, "kills_undead");
        if (victim.typeId === "minecraft:creeper") AM.event(killer, "kills_creeper");
        if (victim.typeId === "minecraft:enderman") AM.event(killer, "kills_enderman");
    }
    if (tierId) {
        AM.event(killer, "kills_evolved");
        if (tierId === "elite") AM.event(killer, "kills_elite");
        if (tierId === "core") AM.event(killer, "kills_core");
        if (tierId === "nightmare") AM.event(killer, "kills_nightmare");
    }
    // Misc (B5)
    lastKillTick.set(killer.id, system.currentTick);
    const naked = isNaked(killer);
    if (naked) AM.event(killer, "naked_kills");
    if (naked && kill.isBoss) AM.event(killer, "naked_boss");
    try { if (killer.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand)?.typeId === "minecraft:stick") AM.event(killer, "stick_kills"); } catch (_) {}
    if (victim.typeId === "minecraft:chicken") {
        AM.event(killer, "chicken_kills");
        if (overkill.delete(victim.id)) AM.event(killer, "overkill_chicken");
    }
    if (victim.typeId === "minecraft:slime") AM.event(killer, "slime_kills");
    if (kill.isBoss) {
        AM.event(killer, "boss_kills");
        AM.markSeen(killer, "boss", victim.typeId, "bosses_distinct");
        if (ProgressionManager.getAscension() >= 5) AM.event(killer, "boss_kills_asc5");
    }
}

// --- Augment (AU): called from reforge.js ---------------------------------------------------
function allAugmentStatsMaxed(slot, type) {
    const defs = Object.values(AugmentManager.getDefsForType(type, slot.typeId) ?? {});
    return defs.length > 0 && defs.every((d) => (slot.getDynamicProperty(d.key) ?? 0) >= d.max);
}
function checkMaxed(player, slot, type) {
    try {
        if (slot.getDynamicProperty(MAXED_FLAG) === true || !allAugmentStatsMaxed(slot, type)) return;
        slot.setDynamicProperty(MAXED_FLAG, true);
        AM.event(player, "aug_maxed");
        checkAugmentFullSet(player);
    } catch (_) { /* item changed */ }
}
function checkAugmentFullSet(player) {
    try {
        const eq = player.getComponent(EntityComponentTypes.Equippable);
        const main = eq?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!main?.hasItem() || !["melee", "ranged"].includes(ITEM_REQUIREMENTS[main.typeId]?.type)) return;
        if (main.getDynamicProperty(MAXED_FLAG) !== true) return;
        for (const s of ARMOR_SLOTS) {
            const slot = eq.getEquipmentSlot(s);
            if (!slot?.hasItem() || slot.getDynamicProperty(MAXED_FLAG) !== true) return;
        }
        AM.max(player, "aug_full_set", 1);
    } catch (_) { /* equipment unavailable */ }
}

export function onAugmentReroll(player, slot, type, hadStats, crystals) {
    AM.event(player, "aug_rerolls");
    AM.event(player, "items_reforged");
    AM.event(player, "aug_crystal_use");
    AM.add(player, "aug_crystals_spent", crystals);
    if (!hadStats) AM.event(player, "aug_installs");
    try {
        const perfect = Object.entries(AugmentManager.getDefsForType(type, slot.typeId) ?? {}).some(([name, d]) =>
            d.max > d.min && (slot.getDynamicProperty(d.key) ?? 0) >= d.max && !AugmentManager.isLocked(slot, type, name));
        if (perfect) AM.event(player, "aug_perfect_roll");
    } catch (_) { /* ignore */ }
    checkMaxed(player, slot, type);
}
export function onAugmentMax(player, slot, type) {
    AM.event(player, "items_reforged");
    AM.event(player, "aug_core_use");
    checkMaxed(player, slot, type);
}
export function onAugmentLock(player) {
    AM.event(player, "items_reforged");
    AM.event(player, "aug_locks");
    AM.event(player, "aug_crystal_use");
    AM.add(player, "aug_crystals_spent", AUGMENT_CRYSTAL_COST.lock);
}

// --- Gem (GM): called from ultench_gui.js / reforge.js ----------------------------------------
export function onUltenchUse(player) { AM.event(player, "ultench_uses"); }
export function onGemEnchant(player, tierId) {
    onUltenchUse(player);
    AM.event(player, "gem_enchants");
    if (tierId === "mythical") AM.event(player, "gem_t7");
}
export function onGemFusion(player, count = 1) { AM.add(player, "gem_fusions", count); }

// Armor Gem abilities worn right now: all four pieces carry an enchanted gem; same / tier checks.
function checkGemSets(player) {
    try {
        const eq = player.getComponent(EntityComponentTypes.Equippable);
        const parts = [];
        for (const s of ARMOR_SLOTS) {
            const slot = eq?.getEquipmentSlot(s);
            if (!slot?.hasItem() || ITEM_REQUIREMENTS[slot.typeId]?.type !== "armor") return;
            const tier = GEM_TIER_ORDER.indexOf(GemManager.getSlotState(slot, 0));
            const skill = GemManager.getSlotSkill(slot, 0);
            if (tier < 0 || !skill) return;
            parts.push({ tier, skill });
        }
        AM.max(player, "gem_full_set", 1);
        if (parts.every((p) => p.tier <= 2 && p.skill === parts[0].skill)) AM.max(player, "gem_stacked", 1);
        if (parts.every((p) => p.tier >= 4)) AM.max(player, "gem_t5_set", 1);
    } catch (_) { /* equipment unavailable */ }
}

// --- Rune (RN) --------------------------------------------------------------------------------
export function onRuneEtched(player, runeId, inkSpent = 0) {
    onUltenchUse(player);
    if (inkSpent > 0) AM.add(player, "ink_spent", inkSpent);
    AM.event(player, "runes_etched");
    const kind = getRuneKind(runeId);
    if (kind !== "curse") AM.event(player, "rune_neutral");   // every non-curse rune has a good and a bad side
    if (kind === "curse") {
        AM.event(player, "rune_curse");
        const run = (curseRun.get(player.id) ?? 0) + 1;
        curseRun.set(player.id, run);
        AM.max(player, "curse_streak", run);
        AM.markSeen(player, "curse_cat", runeId, "curse_categories");   // distinct Curse Runes owned
    } else curseRun.set(player.id, 0);
    const tier = getRuneMeta(runeId)?.tier;
    if (tier) AM.markSeen(player, "runetier", tier, "rune_tiers_obtained");
}
// A Rune whose effect fires on hit / kill / block gets its chance to trigger (counted at the dispatcher).
export function onRuneDispatch(player, runeId) {
    const arch = getRuneMeta(runeId)?.arch;
    if (arch === "TRIGGER" || arch === "ACTIVE") AM.event(player, "rune_procs");
}
// Melee weapon + ranged weapon + tool, each carrying a Rune, anywhere in the inventory / equipment.
function checkRuneArsenal(player) {
    try {
        const types = new Set();
        const scan = (item) => {
            if (item && typeof item.getDynamicProperty(RUNE_PROP_KEY) === "string") {
                const t = ITEM_REQUIREMENTS[item.typeId]?.type;
                if (t === "melee" || t === "ranged" || t === "tool") types.add(t);
            }
        };
        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        for (let i = 0; i < (inv?.size ?? 0); i++) scan(inv.getItem(i));
        scan(player.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand));
        if (types.size === 3) AM.max(player, "rune_full_arsenal", 1);
    } catch (_) { /* inventory unavailable */ }
}


// =====================================================================================================
// Phase B4 -- Work & Support (Mining, Woodcutting, Farming, Fishing, Travel, Mastery, Progression,
// Chorus, Crafting)
// =====================================================================================================
const ORE_COUNTERS = [
    ["ore_coal", /^minecraft:(deepslate_)?coal_ore$/],
    ["ore_iron", /^minecraft:(deepslate_)?iron_ore$/],
    ["ore_gold", /^minecraft:(deepslate_|nether_)?gold_ore$/],
    ["ore_emerald", /^minecraft:(deepslate_)?emerald_ore$/],
    ["ore_diamond", /^minecraft:(deepslate_)?diamond_ore$/],
    ["ore_debris", /^minecraft:ancient_debris$/],
];
const LOG_RE = /_(log|wood|stem)$/;
const NETHER_STEM_RE = /^minecraft:(stripped_)?(crimson|warped)_stem$/;
const LEAVES_RE = /_leaves$/;
const SEED_BLOCKS = new Set(["minecraft:wheat", "minecraft:beetroot", "minecraft:pumpkin_stem", "minecraft:melon_stem", "minecraft:carrots",
    "minecraft:potatoes", "minecraft:nether_wart", "minecraft:torchflower_crop", "minecraft:pitcher_crop", "minecraft:cocoa"]);
const MOUNTS = new Set(["minecraft:horse", "minecraft:donkey", "minecraft:mule", "minecraft:skeleton_horse", "minecraft:zombie_horse",
    "minecraft:pig", "minecraft:strider", "minecraft:camel"]);
const BOATS = new Set(["minecraft:boat", "minecraft:chest_boat"]);

// n blocks of `typeId` were broken by the player. ripe=false means an unripe crop (not a harvest).
export function onBlocksBroken(player, typeId, n = 1, { ripe = true } = {}) {
    if (!(n > 0) || !typeId) return;
    AM.add(player, "blocks_mined", n);
    for (const [key, re] of ORE_COUNTERS) if (re.test(typeId)) { AM.add(player, key, n); break; }
    if (LOG_RE.test(typeId)) {
        AM.add(player, "logs_chopped", n);
        if (NETHER_STEM_RE.test(typeId)) AM.add(player, "nether_stems", n);
    } else if (LEAVES_RE.test(typeId)) {
        AM.add(player, "leaves_broken", n);
    }
    const crop = HOE_VEIN_BLOCKS[typeId];
    if (crop && ripe && !LEAVES_RE.test(typeId)) {
        if (crop.growthState) AM.add(player, "crops_harvested", n);
        else AM.add(player, "gourds_harvested", n);
    }
}
// From the normal break event (needs the block state to know whether a crop was ripe).
export function onBlockBroken(player, permutation) {
    const typeId = permutation?.type?.id;
    if (!typeId) return;
    const crop = HOE_VEIN_BLOCKS[typeId];
    let ripe = true;
    if (crop?.growthState) {
        try { ripe = Number(permutation.getState(crop.growthState)) >= crop.maxGrowth; } catch (_) { ripe = false; }
    }
    onBlocksBroken(player, typeId, 1, { ripe });
}
// One Vein activation finished: `destroyed` extra blocks + the block the player broke themselves.
export function onVeinFinished(player, typeId, destroyed) {
    onBlocksBroken(player, typeId, destroyed);            // Vein breaks fire no break events
    const chain = destroyed + 1;
    AM.max(player, LOG_RE.test(typeId) ? "vein_logs_max" : "vein_blocks_max", chain);
}
export function onFortuneHarvest(player) { AM.event(player, "fortune_harvest"); }

// Fishing: category is fish | junk | treasure (from the Fishing XP table).
export function onFishCaught(player, itemTypeId, category) {
    if (category === "fish") {
        AM.event(player, "fish_caught");
        try { const t = world.getTimeOfDay(); if (t >= 13000 && t <= 23000) AM.event(player, "fish_night"); } catch (_) {}
        if (itemTypeId === "minecraft:pufferfish") AM.event(player, "fish_puffer");
    } else if (category === "treasure") AM.event(player, "fish_treasure");
    else if (category === "junk") AM.event(player, "fish_junk");
}

// Chorus
export function onChorusFusion(player, targetId) {
    const tier = CHORUS_ELEMENTS[targetId]?.tier;
    if (tier === "awaken") AM.event(player, "chorus_awaken");
    if (tier === "melodious") AM.event(player, "chorus_melodious");
}
function chorusState(player) {
    const out = {};
    try {
        const pieces = ChorusManager.getPlayerPieces(player);
        for (const piece of pieces) for (const el of piece.elements ?? []) {
            const tier = el && CHORUS_ELEMENTS[el]?.tier;
            if (tier === "echo") out.chorus_echo = 1;
            else if (tier === "resonance") out.chorus_resonance = 1;
            else if (tier === "transcend") out.chorus_transcend = 1;
        }
        const { sets } = ChorusManager.getPlayerSets(player);
        if (sets.some((x) => x.count >= 8)) out.chorus_8slot = 1;
        if (sets.some((x) => x.kind === "hybrid" && x.count >= 2)) out.chorus_hybrid = 1;
        if (sets.some((x) => x.id === "genesis" && x.count >= 8)) out.chorus_genesis_set = 1;
    } catch (_) { /* equipment unavailable */ }
    return out;
}

// Current-state counters. These also give existing players their old progress (backfill).
function progressionState(player) {
    const out = {};
    try {
        const level = ProgressionManager.getLevel(player);
        out.level_max = level;
        if (level >= ProgressionManager.getMaxLevel(player)) out.level_maxed = 1;
        const prestige = ProgressionManager.getPrestige(player);
        out.prestige_max = prestige;
        if (prestige >= 1) out.mastery_unlocked = 1;
        out.asc_max = ProgressionManager.getAscension();
        const raw = player.getDynamicProperty(PRESTIGE_KEYS.PERKS);
        if (typeof raw === "string" && raw.length) out.perks_picked = raw.split(",").filter(Boolean).length;
    } catch (_) { /* not ready */ }
    return out;
}
function masteryState(player) {
    const out = {};
    try {
        let lv5 = 0, maxed = 0, path = 0;
        for (const [id, def] of Object.entries(MASTERY.LINES)) {
            const lv = MasteryManager.getLevel(player, id);
            if (lv >= 5) lv5++;
            if (lv >= def.maxLevel) { maxed++; out[`mastery_max_${id}`] = 1; }
            if (def.paths && MasteryManager.getPath(player, id)) path = 1;
        }
        out.lines_lv5 = lv5;
        out.lines_maxed = maxed;
        if (path) out.path_chosen = 1;
    } catch (_) { /* not ready */ }
    return out;
}

// Travel: distance per second, split by how the player moved.
const travel = new Map();     // playerId -> { x, z, dim, carry: {key: fractional blocks} }
function accrue(player, st, key, d) {
    const total = (st.carry[key] ?? 0) + d;
    const whole = Math.floor(total);
    st.carry[key] = total - whole;
    if (whole > 0) AM.add(player, key, whole);
}
function travelTick(player) {
    const loc = player.location, dim = player.dimension.id;
    let st = travel.get(player.id);
    if (!st) { st = { x: loc.x, z: loc.z, dim, carry: {} }; travel.set(player.id, st); }
    if (st.dim !== dim) {
        AM.markSeen(player, "dim", dim, "dims_visited");
        st.x = loc.x; st.z = loc.z; st.dim = dim; return;
    }
    if (dim === "minecraft:nether" || dim === "minecraft:the_end") AM.markSeen(player, "dim", dim, "dims_visited");
    if (dim === "minecraft:overworld" && loc.y <= -60) AM.max(player, "bedrock_reached", 1);   // no need to move
    const d = Math.hypot(loc.x - st.x, loc.z - st.z);
    st.x = loc.x; st.z = loc.z;
    if (d < 0.3 || d > (player.isGliding ? 120 : MASTERY.TRAVEL_MAX_STEP)) return;       // standing still or teleported
    const ridden = player.getComponent("minecraft:riding")?.entityRidingOn?.typeId;
    if (player.isGliding) accrue(player, st, "dist_elytra", d);
    else if (ridden && BOATS.has(ridden)) accrue(player, st, "dist_boat", d);
    else if (ridden && MOUNTS.has(ridden)) accrue(player, st, "dist_mount", d);
    else if (!ridden) {
        accrue(player, st, "dist_foot", d);
        if (player.isSprinting) accrue(player, st, "dist_sprint", d);
    }
    if (dim === "minecraft:nether") accrue(player, st, "dist_nether", d);
    if (dim === "minecraft:overworld") {
        try {
            const sp = world.getDefaultSpawnLocation();
            AM.max(player, "max_spawn_dist", Math.floor(Math.hypot(loc.x - sp.x, loc.z - sp.z)));
        } catch (_) { /* no spawn */ }
    }
}

// Farming / woodcutting actions without a game event of their own.
const nearestPlayer = (entity, maxDist) => {
    let best = null, bestD = maxDist;
    for (const p of world.getAllPlayers()) {
        if (p.dimension.id !== entity.dimension.id) continue;
        const d = Math.hypot(p.location.x - entity.location.x, p.location.y - entity.location.y, p.location.z - entity.location.z);
        if (d < bestD) { best = p; bestD = d; }
    }
    return best;
};
function subscribeWorkEvents() {
    world.afterEvents.playerPlaceBlock.subscribe((e) => Logger.guard("achievement place", () => {
        const id = e.block?.typeId;
        if (!id) return;
        if (id.endsWith("_sapling") || id === "minecraft:mangrove_propagule" || id === "minecraft:cherry_sapling") AM.event(e.player, "saplings_planted");
        else if (SEED_BLOCKS.has(id)) AM.event(e.player, "seeds_planted");
    }));
    world.afterEvents.playerInteractWithBlock.subscribe((e) => Logger.guard("achievement interact", () => {
        if (e.itemStack?.typeId === "minecraft:bone_meal") AM.event(e.player, "bonemeal_used");
    }));
    world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
        try {
            const held = e.itemStack?.typeId;
            const id = e.block?.typeId;
            if ((id !== "minecraft:beehive" && id !== "minecraft:bee_nest") || (held !== "minecraft:glass_bottle" && held !== "minecraft:shears")) return;
            if (e.block.permutation.getState("honey_level") !== 5) return;
            const player = e.player;
            system.run(() => AM.event(player, "honey_collected"));     // honey_level 5 + bottle/shears = collected
        } catch (_) { /* ignore */ }
    });
    world.beforeEvents.playerInteractWithEntity.subscribe((e) => {
        try {
            if (e.target?.typeId !== "minecraft:sheep" || e.itemStack?.typeId !== "minecraft:shears") return;
            if (e.target.getComponent("minecraft:is_sheared") || e.target.getComponent("minecraft:is_baby")) return;
            const player = e.player;
            system.run(() => AM.event(player, "sheep_sheared"));
        } catch (_) { /* ignore */ }
    });
    world.afterEvents.entitySpawn.subscribe((e) => Logger.guard("achievement breed", () => {
        if (String(e.cause) !== "Born" || !e.entity?.isValid) return;
        const p = nearestPlayer(e.entity, 12);
        if (p) AM.event(p, "animals_bred");
    }));
}

export function registerWorkAchievementHooks() {
    AM.registerStateProvider(progressionState);
    AM.registerStateProvider(masteryState);
    AM.registerStateProvider(chorusState);
    Scheduler.every("ach_travel", 20, () => {
        for (const player of world.getAllPlayers()) Logger.guard("achievement travel", () => travelTick(player));
    });
    EventBus.on("playerLeave", (e) => { if (e?.playerId) travel.delete(e.playerId); });
    subscribeWorkEvents();
}


// =====================================================================================================
// Phase B5 -- Misc & Silly: menus, deaths, activity, odd behavior
// =====================================================================================================
const ARMOR_MATERIAL = /^minecraft:(leather|chainmail|iron|golden|diamond|netherite|turtle)_/;
const BED_RE = /(^|_)bed$/;
const ANVILS = new Set(["minecraft:anvil", "minecraft:chipped_anvil", "minecraft:damaged_anvil"]);
const fast = new Map();       // playerId -> per-player motion state for the 2-tick job
const deathCtx = new Map();   // playerId -> { context, rune, tick } captured when the RPG death starts
const anvilWatch = new Map(); // playerId -> { until, known:Set } (rename detection window after using an anvil)
const sec = new Map();        // playerId -> per-second state (playtime, core mobs, far trips)

function equippedItems(player) {
    const eq = player.getComponent(EntityComponentTypes.Equippable);
    return ARMOR_SLOTS.map((s) => { try { const sl = eq?.getEquipmentSlot(s); return sl?.hasItem() ? sl.getItem() : undefined; } catch (_) { return undefined; } });
}
function isNaked(player) { try { return equippedItems(player).every((i) => !i); } catch (_) { return false; } }
function mainhandRune(player) {
    try { return player.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand)?.getDynamicProperty(RUNE_PROP_KEY) ?? null; } catch (_) { return null; }
}
function customNames(player) {
    const out = new Map();
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    for (let i = 0; i < (inv?.size ?? 0); i++) {
        const it = inv.getItem(i);
        if (!it?.nameTag) continue;
        const base = stripRarityPrefix(it.nameTag);
        if (!base || base === prettyItemName(it.typeId)) continue;
        const key = `${it.typeId}|${base}`;
        out.set(key, (out.get(key) ?? 0) + 1);
    }
    return out;
}

// --- Deaths ---------------------------------------------------------------------------------------
function onPlayerDied(player, damageSource) {
    const saved = deathCtx.get(player.id);
    deathCtx.delete(player.id);
    const recent = saved && system.currentTick - saved.tick < 60;
    const ctx = recent ? saved.context : null;
    const cause = ctx?.cause ?? normalizeDamageCause(damageSource?.cause);
    const attacker = ctx?.attacker ?? damageSource?.damagingEntity;
    const rune = recent ? saved.rune : null;
    AM.event(player, "deaths");
    if (cause === "fall") {
        AM.event(player, "death_fall");
        const st = fast.get(player.id);
        if (st && st.peakY - player.location.y >= 100) AM.event(player, "death_fall_big");
    }
    if (cause === "lava") AM.event(player, "death_lava");
    if (cause === "drowning") AM.event(player, "death_drown");
    if (cause === "starve" || cause === "starvation") AM.event(player, "death_starve");
    if (FIRE_CAUSES.has(cause)) AM.event(player, "death_fire");
    if (cause === "void") AM.event(player, "death_void");
    if (attacker?.typeId === "minecraft:creeper") AM.event(player, "death_creeper");
    if (attacker && EvolutionManager.getTierId(attacker) === "elite") AM.event(player, "death_elite");
    if (cause === "projectile" && attacker?.id === player.id && rune === "returning_doom") AM.event(player, "death_returning_doom");
    if (rune && getRuneKind(rune) === "curse") AM.event(player, "death_curse_rune");
    if (rune === "glass_cannon") AM.event(player, "death_glass_cannon");
    streaks.set(player.id, 0);
}

// --- 2-tick motion job: jumps, nonstop sprint, standing still, sleeping, falls ------------------------
function fastTick(player) {
    let st = fast.get(player.id);
    const loc = player.location;
    if (!st) { st = { jumping: false, sprint: 0, idle: 0, x: loc.x, y: loc.y, z: loc.z, sleeping: false, peakY: loc.y, pig: false }; fast.set(player.id, st); }
    const jumping = !!player.isJumping;
    if (jumping && !st.jumping) AM.event(player, "jumps");
    st.jumping = jumping;
    if (player.isSprinting) { st.sprint += 2; if (st.sprint % 20 === 0) AM.max(player, "sprint_nonstop_sec", st.sprint / 20); }
    else st.sprint = 0;
    const moved = Math.abs(loc.x - st.x) + Math.abs(loc.y - st.y) + Math.abs(loc.z - st.z);
    st.x = loc.x; st.y = loc.y; st.z = loc.z;
    const sleeping = !!player.isSleeping;
    if (sleeping && !st.sleeping) AM.event(player, "sleeps");
    st.sleeping = sleeping;
    if (moved < 0.01 && !sleeping) { st.idle += 2; if (st.idle % 20 === 0) AM.max(player, "idle_max_sec", st.idle / 20); }
    else st.idle = 0;
    // fall tracking (peak height while airborne) for "fall 100+ blocks" and the pig fall
    if (player.isOnGround || player.isInWater || player.isFlying || player.isGliding) {
        if (st.pig && st.peakY - loc.y >= 20 && player.isOnGround) AM.event(player, "pig_fall");
        st.peakY = loc.y; st.pig = false;
    } else {
        if (loc.y > st.peakY) st.peakY = loc.y;
        if (player.getComponent("minecraft:riding")?.entityRidingOn?.typeId === "minecraft:pig") st.pig = true;
    }
}

// --- 1-second job: playtime, peaceful time, Core mob, sculk, far trips, raid omen -------------------------
function secTick(player) {
    let st = sec.get(player.id);
    if (!st) { st = { carry: {}, coreSec: 0, farTrip: false, omen: false }; sec.set(player.id, st); lastKillTick.set(player.id, lastKillTick.get(player.id) ?? system.currentTick); }
    accrue(player, st, "playtime_min", 1 / 60);
    AM.max(player, "peaceful_min", Math.floor((system.currentTick - (lastKillTick.get(player.id) ?? system.currentTick)) / 1200));
    // standing next to a Core mob without attacking
    try {
        if (system.currentTick - (lastAttackTick.get(player.id) ?? -9999) < 20) st.coreSec = 0;
        else {
            const near = player.dimension.getEntities({ location: player.location, maxDistance: 6, excludeTypes: ["minecraft:player", "minecraft:item"] });
            if (near.some((e) => EvolutionManager.getTierId(e) === "core")) { st.coreSec++; AM.max(player, "core_stand_sec", st.coreSec); }
            else st.coreSec = 0;
        }
    } catch (_) { st.coreSec = 0; }
    // sneaking over sculk (Deep Dark): real horizontal distance walked since the last second
    try {
        const dx = player.location.x - (st.sx ?? player.location.x), dz = player.location.z - (st.sz ?? player.location.z);
        st.sx = player.location.x; st.sz = player.location.z;
        const d = Math.hypot(dx, dz);
        if (player.isSneaking && d > 0.05 && d < 4) {
            const below = player.dimension.getBlock({ x: Math.floor(player.location.x), y: Math.floor(player.location.y) - 1, z: Math.floor(player.location.z) });
            if (below?.typeId === "minecraft:sculk") accrue(player, st, "sculk_sneak_blocks", d);
        }
    } catch (_) {}
    // back to spawn after a long trip
    try {
        if (player.dimension.id === "minecraft:overworld") {
            const sp = world.getDefaultSpawnLocation();
            const dist = Math.hypot(player.location.x - sp.x, player.location.z - sp.z);
            if (dist >= 5000) st.farTrip = true;
            else if (st.farTrip && dist < 30) { st.farTrip = false; AM.event(player, "spawn_return"); }
        }
    } catch (_) {}
    // raid: the Raid Omen effect shows up when a raid is about to start
    try {
        const omen = !!player.getEffect("raid_omen");
        if (omen && !st.omen) AM.event(player, "raids");
        st.omen = omen;
    } catch (_) {}
    // rename detection after using an anvil
    const w = anvilWatch.get(player.id);
    if (w) {
        if (system.currentTick > w.until) anvilWatch.delete(player.id);
        else {
            const now = customNames(player);
            for (const [key, n] of now) if ((w.known.get(key) ?? 0) < n) { AM.event(player, "renames"); anvilWatch.delete(player.id); break; }
        }
    }
}

// --- 5-second state: full inventory, four different armor materials ----------------------------------------
function miscState(player) {
    try {
        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (inv && inv.size >= 36 && inv.emptySlotsCount === 0) AM.max(player, "inv_full", 1);
    } catch (_) {}
    try {
        const mats = equippedItems(player).map((i) => i?.typeId.match(ARMOR_MATERIAL)?.[1]);
        if (mats.every(Boolean) && new Set(mats).size === 4) AM.max(player, "fashion", 1);
    } catch (_) {}
}

// Menus / Knowledge Book / Reset: tiny helpers called from the GUI files.
export function onMenuOpened(player, menuId) { AM.markSeen(player, "menu", menuId, "menus_distinct"); GuideQuest.onMenu(player, menuId); }

function subscribeMiscEvents() {
    EventBus.on("player:rpgDeath", ({ player, context } = {}) => {
        if (player?.id) deathCtx.set(player.id, { context, rune: mainhandRune(player), tick: system.currentTick });
    });
    world.afterEvents.entityDie.subscribe((e) => Logger.guard("achievement death", () => {
        if (isPlayer(e.deadEntity)) onPlayerDied(e.deadEntity, e.damageSource);
    }));
    world.afterEvents.itemCompleteUse.subscribe((e) => Logger.guard("achievement eat", () => {
        const id = e.itemStack?.typeId, p = e.source;
        if (!isPlayer(p)) return;
        if (id === "minecraft:rotten_flesh") AM.event(p, "rotten_eaten");
        else if (id === "minecraft:pufferfish") AM.event(p, "puffer_eaten");
        else if (id === "minecraft:chorus_fruit") AM.event(p, "chorus_fruit_eaten");
    }));
    world.afterEvents.itemUse.subscribe((e) => Logger.guard("achievement use", () => {
        if (e.itemStack?.typeId === "minecraft:firework_rocket" && isPlayer(e.source)) AM.event(e.source, "fireworks");
    }));
    world.afterEvents.itemStartUse.subscribe((e) => Logger.guard("achievement spyglass", () => {
        if (e.itemStack?.typeId === "minecraft:spyglass" && isPlayer(e.source)) AM.event(e.source, "spyglass_uses");
    }));
    world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
        try {
            const id = e.block?.typeId, player = e.player;
            if (id === "minecraft:cake") system.run(() => AM.event(player, "cake_eaten"));
            else if (BED_RE.test(id) && player.dimension.id !== "minecraft:overworld") system.run(() => AM.event(player, "bed_explode"));
            else if (ANVILS.has(id)) system.run(() => {
                try { anvilWatch.set(player.id, { until: system.currentTick + 2400, known: customNames(player) }); } catch (_) {}
            });
        } catch (_) { /* ignore */ }
    });
    world.beforeEvents.playerInteractWithEntity.subscribe((e) => {
        try {
            const t = e.target?.typeId, held = e.itemStack?.typeId, player = e.player;
            const baby = !!e.target.getComponent("minecraft:is_baby");
            if (t === "minecraft:cow" && held === "minecraft:bucket" && !baby) system.run(() => AM.event(player, "milk"));
            else if (held === "minecraft:lead" && e.target.getComponent("minecraft:leashable") && !e.target.getComponent("minecraft:leashable").isLeashed && t !== "minecraft:player") system.run(() => AM.event(player, "leashes"));
            else if (t === "minecraft:villager_v2" || t === "minecraft:villager") {
                const now = system.currentTick, last = tradeCooldown.get(player.id) ?? -999;
                if (!baby && now - last > 60) { tradeCooldown.set(player.id, now); system.run(() => AM.event(player, "trades")); }
            }
        } catch (_) { /* ignore */ }
    });
    // Dropped items: an item entity appearing at head height right next to a player.
    world.afterEvents.entitySpawn.subscribe((e) => Logger.guard("achievement drop", () => {
        const ent = e.entity;
        if (!ent?.isValid || ent.typeId !== "minecraft:item" || String(e.cause) !== "Spawned") return;
        for (const p of world.getAllPlayers()) {
            if (p.dimension.id !== ent.dimension.id) continue;
            const dy = ent.location.y - p.location.y;
            if (dy < 0.9 || dy > 1.8 || Math.hypot(ent.location.x - p.location.x, ent.location.z - p.location.z) > 1.2) continue;
            const stack = ent.getComponent("minecraft:item")?.itemStack;
            AM.add(p, "items_dropped", stack?.amount ?? 1);
            return;
        }
    }));
}
const tradeCooldown = new Map();

export function registerMiscAchievementHooks() {
    AM.registerStateProvider((player) => ({ joined: 1 }));
    Scheduler.every("ach_fast", 2, () => { for (const p of world.getAllPlayers()) Logger.guard("achievement fast", () => fastTick(p)); });
    Scheduler.every("ach_second", 20, () => { for (const p of world.getAllPlayers()) Logger.guard("achievement second", () => secTick(p)); });
    Scheduler.every("ach_misc_state", 100, () => { for (const p of world.getAllPlayers()) miscState(p); });
    EventBus.on("playerLeave", (e) => { const id = e?.playerId; if (id) { fast.delete(id); sec.delete(id); deathCtx.delete(id); anvilWatch.delete(id); lastKillTick.delete(id); lastAttackTick.delete(id); tradeCooldown.delete(id); curseRun.delete(id); } });
    subscribeMiscEvents();
}

// --- Registration ---------------------------------------------------------------------------------
export function registerCombatAchievementHooks() {
    if (registered) return false;
    registered = true;
    EventBus.on("damage:after", onDamageAfter);
    EventBus.on("damage:resolved", onDamageResolved);
    EventBus.on("playerLeave", (e) => { if (e?.playerId) { streaks.delete(e.playerId); lowHp.delete(e.playerId); } });
    // Second Wind: back to full HP after dropping under 10%.
    Scheduler.every("ach_second_wind", 20, () => {
        if (!lowHp.size) return;
        for (const player of world.getAllPlayers()) {
            if (!lowHp.has(player.id)) continue;
            try {
                const hp = HPManager.getHP(player);
                if (hp <= 0) lowHp.delete(player.id);
                else if (hp >= HPManager.getMaxHP(player)) { lowHp.delete(player.id); AM.event(player, "second_wind"); }
            } catch (_) { lowHp.delete(player.id); }
        }
    });
    // State checks (what is worn / carried right now): every 5 seconds.
    Scheduler.every("ach_state_checks", 100, () => {
        for (const player of world.getAllPlayers()) {
            checkGemSets(player);
            checkRuneArsenal(player);
            checkAugmentFullSet(player);
        }
    });
    return true;
}
