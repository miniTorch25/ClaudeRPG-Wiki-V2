// ClaudeRPG GemState — runtime-only Gem ability state.
// Persistent Gem configuration remains on ItemStack dynamic properties.
import { RuntimeState } from "../core/runtime_state.js";

function state(playerId) {
    const root = RuntimeState.player(playerId);
    if (!root.gem) root.gem = {};
    if (!(root.gem.guardianStacks >= 0)) root.gem.guardianStacks = 0;
    if (!(root.gem.guardianNextCharge >= 0)) root.gem.guardianNextCharge = 0;
    return root.gem;
}

export const GemState = {
    get(playerId) { return state(playerId); },
    getGuardianStacks(playerId) { return state(playerId).guardianStacks; },
    setGuardianStacks(playerId, value) { state(playerId).guardianStacks = Math.max(0, value); },
    getGuardianNextCharge(playerId) { return state(playerId).guardianNextCharge; },
    setGuardianNextCharge(playerId, value) { state(playerId).guardianNextCharge = value; },
    clearPlayer(playerId) {
        const root = RuntimeState.peek(playerId);
        if (root) root.gem = {};
    },
};
