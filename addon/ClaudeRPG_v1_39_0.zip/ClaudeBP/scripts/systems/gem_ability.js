// gem_ability.js — Gem Ability Dispatcher
//
// Maps gem tier IDs installed on armor slots to their ability handlers.
// Called from main.js interval and event hooks.
//
// Usage:
//   GemAbility.hasAbility(player, "vitality")      → bool
//   GemAbility.count(player, "vitality")           → how many armor pieces carry it (tiers 1-3 stack)
//   GemAbility.getAbilities(player)                → Set<string>
//   GemAbility.tickPassive(player)                 → called every 10 ticks
//   GemAbility.onHurtBefore(event)                 → called in entityHurt.before
//   GemAbility.onHurtAfter(event)                  → called in entityHurt.after
//   GemAbility.onDie(event)                        → called when player might die

import { system, world, EntityComponentTypes, EquipmentSlot, ItemStack, GameMode } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { GemManager, SOCKET_COUNT } from "./gem_manager.js";
import { ManaManager } from "../managers/mana_manager.js";
import { CooldownManager } from "../managers/cooldown_manager.js";
import { HudManager } from "../managers/hud_manager.js";
import { HPManager } from "../managers/hp_manager.js";
import { StatsManager } from "../managers/stats_manager.js";
import { RUNE_PROP_KEY } from "../rune/rune_registry.js";
import { RUNE_CONFIG, useRuneLevelOf } from "../config/rune_config.js";
import { GemState } from "./gem_state.js";
import { GEM_CATEGORY_BY_SLOT } from "./gem_registry.js";
import { getScaledGemConfig, GEM_CAPS } from "../config/gem_ability_config.js";
import { MovementManager } from "../managers/movement_manager.js";
import { KillManager } from "../managers/kill_manager.js";
import { fireSuppressedDamage } from "../managers/damage_manager.js";
import { Scheduler } from "../core/scheduler.js";
import { isBoss } from "../config/mob_config.js";
import { blinkPlayer, awayDir } from "./chorus_effects.js";
import { Synergy } from "./synergy.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { AchievementManager } from "./achievement_manager.js";

// Effects Immunity cleanses (script equivalent of `/effect @s <id> 0 255` for each).
// Edit this list to add/remove effects.
const NEGATIVE_EFFECTS = new Set([
    "slowness", "mining_fatigue", "nausea", "blindness", "hunger", "weakness",
    "poison", "fatal_poison", "wither", "levitation", "darkness",
    "bad_omen", "raid_omen", "trial_omen", "infested", "oozing", "weaving", "wind_charged"
]);

// Armor slots that can hold gems
const ARMOR_SLOTS = [
    EquipmentSlot.Head,
    EquipmentSlot.Chest,
    EquipmentSlot.Legs,
    EquipmentSlot.Feet,
];

// Runtime state is centralized in RuntimeState through GemState.

// --- Helpers ---

function getEquipment(player) {
    return player.getComponent(EntityComponentTypes.Equippable);
}

// Reads the mainhand-equipped rune ID directly (no import from rune_manager.js,
// to avoid a circular dependency — same pattern used in cooldown_manager.js).
function getMainhandRuneId(player) {
    const slot = getEquipment(player)?.getEquipmentSlot(EquipmentSlot.Mainhand);
    if (!slot?.hasItem()) return null;
    return slot.getItem().getDynamicProperty(RUNE_PROP_KEY) ?? null;
}

function getHealth(entity) {
    return entity.getComponent(EntityComponentTypes.Health);
}

// Bug fix — "player.isFlying = true/false" throws ("TypeError: not a function")
// because Player.isFlying is a read-only property in @minecraft/server 2.6.0
// (Bedrock 1.26.51); it has a getter but no setter. The only supported way to
// grant/revoke flight from script is the /ability command.
function setFlying(player, enabled) {
    try {
        player.runCommand(`ability @s mayfly ${enabled}`);
        player.runCommand(`ability @s flying ${enabled}`);
    } catch (_) {}
}

// Gem Flight bookkeeping. The gem only ever touches a player's abilities while
// it is the one that granted flight ("granted"). Creative/Spectator flight is
// native to the game mode: the gem must never grant, drain or revoke it, or
// the player loses their own flight (mayfly false) after a single flight.
const flightGranted = new Set();

function hasNativeFlight(player) {
    try {
        const mode = player.getGameMode();
        return mode === GameMode.creative || mode === GameMode.spectator;
    } catch (_) { return false; }
}

// Gem config for this player: gc(player).tenacity.dmgReduction, etc.
// Gems have no levels; the player's Gem Potency (Gem Mastery) boosts the power numbers.
// Cached per player per tick (getAbilities walks every armor socket).
const _abilityCache = new Map();   // playerId -> { tick, set }
const _potencyCache = new Map();   // playerId -> { tick, pct }
function gc(player) {
    const tick = system.currentTick;
    let entry = _potencyCache.get(player.id);
    if (!entry || entry.tick !== tick) {
        entry = { tick, pct: MasteryManager.getGemPotency(player) + GemAbility.getResonancePotency(player) };
        _potencyCache.set(player.id, entry);
    }
    return new Proxy({}, {
        get: (_, skill) => getScaledGemConfig(String(skill), entry.pct),
    });
}

// --- Core API ---

const FIRE_CAUSES  = new Set(["fire", "fire_tick", "lava", "in_fire", "magma"]);
const MAGIC_CAUSES = new Set(["magic", "wither", "poison"]);

// Ability keys grouped by the stat they feed (every ability here is a plain passive; value x stack count).
const STAT_ABILITIES = {
    maxHp:     ["vitality", "hearty", "fortitude", "titan_heart", "colossus"],        // field maxHpBonus
    regen:     ["recovery", "vigor", "titan_heart"],                                  // field regenBonus
    maxMana:   ["focus", "arcane_reservoir", "arcane_surge", "archmages_crown", "ascended_mind"],   // maxMana
    manaRegen: ["mana_trickle", "clear_mind", "arcane_reservoir", "arcane_surge", "archmages_crown", "ascended_mind"],   // manaRegen
    speed:     ["swiftness", "swift_strides", "wind_walker", "godspeed"],             // speedPct
    dodge:     ["intuition", "reflexes", "evasion"],                                  // dodge
};

const exhaustionLast = new Map();   // playerId -> last seen exhaustion (Marathon)

// Per-player runtime state for the tier 4-7 abilities that need memory between events.
//   warpath {n,last}  rampage {n,until}  momentum {since,stoppedAt}  quicksilver {until}  hits Map(targetId -> n)
//   prevJump/airJumped/airTicks (Skystep)  frostTick
const _st = new Map();
function st(player) {
    let s = _st.get(player.id);
    if (!s) { s = { warpath: { n: 0, last: 0 }, rampage: { n: 0, until: 0 }, momentum: { since: 0, stoppedAt: 0 }, quicksilver: 0, hits: new Map() }; _st.set(player.id, s); }
    return s;
}
const TICKS = 20;
const NEGATIVE_BLIND = ["blindness", "darkness", "nausea"];

export class GemAbility {

    // Map<abilityKey, count> of the abilities active on this player: how many equipped armor pieces carry
    // each one. Tiers 1-3 stack (count 1-4); tiers 4-7 are bound to one category so count is 0 or 1.
    // Cached per player per tick (walked on every hit and every passive tick).
    static getCounts(player) {
        return this._entry(player).counts;
    }

    // Shared read-only Set of active ability keys (cached for this tick) -- never mutate it.
    static getAbilities(player) {
        return this._entry(player).set;
    }

    static count(player, abilityKey) {
        return this._entry(player).counts.get(abilityKey) ?? 0;
    }

    static hasAbility(player, abilityKey) {
        return this.count(player, abilityKey) > 0;
    }

    static _entry(player) {
        const tick = system.currentTick;
        const hit = _abilityCache.get(player.id);
        if (hit && hit.tick === tick) return hit;
        const counts = this._computeCounts(player);
        const entry = { tick, counts, set: new Set(counts.keys()) };
        _abilityCache.set(player.id, entry);
        return entry;
    }

    static _computeCounts(player) {
        const counts = new Map();
        const equipment = getEquipment(player);
        if (!equipment) return counts;

        for (const slotId of ARMOR_SLOTS) {
            const slot = equipment.getEquipmentSlot(slotId);
            if (!slot?.hasItem()) continue;

            const req = ITEM_REQUIREMENTS[slot.typeId];
            if (!req || req.type !== "armor") continue;
            const cat = GEM_CATEGORY_BY_SLOT[req.slot] ?? null;

            for (let i = 0; i < SOCKET_COUNT; i++) {
                const tierId = GemManager.getSlotState(slot, i);
                if (!GemManager.getTierDef(tierId)) continue;   // "locked" / "empty" -- no gem installed

                // Older Gems are migrated here, once, the first time they are worn (see GemManager.ensureSlotSkill).
                const key = GemManager.ensureSlotSkill(slot, i, tierId, cat);
                if (!key) continue;                              // a gem with no ability yet grants nothing
                counts.set(key, (counts.get(key) ?? 0) + 1);
            }
        }
        return counts;
    }

    // Σ count × config[field] over the abilities of one stat group.
    static _sum(player, group, field) {
        let total = 0;
        const counts = this.getCounts(player);
        if (counts.size === 0) return 0;
        const cfg = gc(player);
        for (const key of STAT_ABILITIES[group]) {
            const n = counts.get(key);
            if (n) total += n * (cfg[key]?.[field] ?? 0);
        }
        return total;
    }

    static register() {
        if (this._registered) return false;
        this._registered = true;
        KillManager.addListener((e) => this.onKill(e));
        // Every 2 ticks: Skystep (Double Jump) and Frost Walker need finer timing than the 10-tick passive loop.
        Scheduler.every("gem_fast", 2, () => {
            for (const p of world.getAllPlayers()) { try { this.tickFast(p); } catch (_) { /* player left */ } }
        });
        return true;
    }

    // ---------------------------------------------------------------
    // Step 2.2 — Passive abilities (called every 10 ticks per player)
    // ---------------------------------------------------------------
    static tickPassive(player) {
        const ab = this.getAbilities(player);
        if (ab.size === 0) {
            this._tickGuardianOff(player);
            exhaustionLast.delete(player.id);
            return;
        }
        const cfg = gc(player);

        // Swiftness / Swift Strides / ...: movement speed is applied by AugmentManager.applyPassiveStats (getGemSpeedBonus).
        // Vitality / Hearty / ...: Max HP is script-based (getGemHpBonus, read by HPManager.recalcMaxHP).
        // Damage reduction, dodge, attack bonuses: computed live at hit time (see the getGem... helpers below).

        // Keen Eyes: permanent Night Vision (utility only, so a vanilla effect is fine)
        if (ab.has("keen_eyes")) {
            player.addEffect("night_vision", 60, { amplifier: 0, showParticles: false });
        }

        // Aqua Lung: breathe underwater indefinitely and see clearly while submerged
        if (ab.has("aqua_lung")) {
            player.addEffect("water_breathing", 60, { amplifier: 0, showParticles: false });
            if (player.isInWater) player.addEffect("night_vision", 60, { amplifier: 0, showParticles: false });
        }

        // Marathon: sprinting costs less hunger (exhaustion gained while sprinting is reduced)
        this._tickMarathon(player, ab, cfg);

        // Clairvoyance / Third Eye: Night Vision and hostile mobs around you glow
        if (ab.has("clairvoyance") || ab.has("third_eye")) {
            player.addEffect("night_vision", 60, { amplifier: 0, showParticles: false });
            const radius = Math.max(ab.has("clairvoyance") ? cfg.clairvoyance.radius : 0, ab.has("third_eye") ? cfg.third_eye.radius : 0);
            this._glowHostiles(player, radius);
        }

        // Third Eye: immune to Blindness / Darkness / Nausea.  Soulward: immune to Wither.  Godspeed: immune to Slowness.
        if (ab.has("third_eye")) for (const id of NEGATIVE_BLIND) this._strip(player, id);
        if (ab.has("soulward")) this._strip(player, "wither");
        if (ab.has("godspeed")) this._strip(player, "slowness");

        // Momentum Strike: build damage while sprinting (read by getGemAttackBonusPercent)
        if (ab.has("momentum_strike")) {
            const m = st(player).momentum, now = system.currentTick;
            if (player.isSprinting) { if (!m.since) m.since = now; m.stoppedAt = 0; }
            else if (m.since && !m.stoppedAt) m.stoppedAt = now;
        }

        // Sanctuary: sneaking and standing still heals (the damage reduction part is live in the combat pipeline)
        if (ab.has("sanctuary") && player.isSneaking && !this._isMoving(player)) {
            HPManager.heal(player, this.count(player, "sanctuary") * cfg.sanctuary.healPerSec * 0.5);   // tickPassive runs every 0.5s
        }

        // Guardian Shield: charge one stack per interval
        if (ab.has("guardian_shield")) {
            const g = cfg.guardian_shield;
            const stacks  = GemState.getGuardianStacks(player.id);
            const nextChg = GemState.getGuardianNextCharge(player.id);
            if (stacks < g.maxStacks && Date.now() >= nextChg) {
                const newStacks = stacks + 1;
                GemState.setGuardianStacks(player.id, newStacks);
                GemState.setGuardianNextCharge(player.id, Date.now() + g.chargeSec * 1000);
                player.onScreenDisplay.setActionBar(
                    `§b[Guardian Shield] Shield charged! §f${newStacks}/${g.maxStacks}`
                );
                HudManager.markDirty(player);
            }
        } else {
            this._tickGuardianOff(player);
        }

        // Void Escape: teleport to spawn if below void
        if (ab.has("void_escape") && player.location.y < cfg.void_escape.voidY) {
            const spawn = player.spawnPoint
                ? { x: player.spawnPoint.x, y: player.spawnPoint.y, z: player.spawnPoint.z }
                : { x: 0, y: 64, z: 0 };
            player.teleport(spawn, { dimension: player.spawnPoint?.dimension ?? player.dimension });
            player.onScreenDisplay.setActionBar("§b[Void Escape] Teleported to spawn!");
        }

        // Flight: mana drain while flying (enable/disable is handled by
        // tickFlightCheck, run every 20 ticks based on armor equip state)
        if (ab.has("flight") && player.isFlying && !hasNativeFlight(player)) {
            if (!ManaManager.consume(player, cfg.flight.manaPerSec / 20)) {
                // Out of mana — disable flight
                setFlying(player, false);
                player.onScreenDisplay.setActionBar("§c[Flight] Out of mana!");
            }
        }

        // Domain: push hostile entities away while sneaking
        if (ab.has("domain") && player.isSneaking) {
            this._applyDomain(player);
        }

        // Aura ticks (run every 10 ticks, no separate interval needed)
        if (ab.has("frostflare")) {
            this._applyAura(player, "frostflare");
        } else {
            if (ab.has("cinderveil"))        this._applyAura(player, "cinderveil");
            if (ab.has("glacial_presence"))  this._applyAura(player, "glacial_presence");
        }

        // Second Wind: auto-heal burst when dropping below its HP threshold
        this._checkSecondWind(player);

        // Static Field: periodic AoE damage pulse to nearby enemies
        if (ab.has("static_field")) {
            this._applyStaticField(player);
        }
    }

    // Removes a negative effect if present (script immunity).
    static _strip(player, effectId) {
        try { if (player.getEffect(effectId)) player.removeEffect(effectId); } catch (_) { /* unavailable */ }
    }

    // Makes hostile mobs within `radius` glow for a moment (refreshed by the 10-tick passive loop).
    static _glowHostiles(player, radius) {
        try {
            for (const e of player.dimension.getEntities({ location: player.location, maxDistance: radius, families: ["monster"] })) {
                try { e.addEffect("glowing", 30, { amplifier: 0, showParticles: false }); } catch (_) { /* skip */ }
            }
        } catch (_) { /* query failed */ }
    }

    // Every 2 ticks: Skystep (Double Jump) and Frost Walker.
    static tickFast(player) {
        const ab = this.getAbilities(player);
        const s = st(player);

        if (ab.has("skystep")) {
            const jumping = !!player.isJumping, grounded = !!player.isOnGround;
            if (grounded) { s.airJumped = false; s.airTicks = 0; } else s.airTicks = (s.airTicks ?? 0) + 1;
            const pressed = jumping && !s.prevJump;
            s.prevJump = jumping;
            if (!grounded && pressed && !s.airJumped && (s.airTicks ?? 0) >= 3 && !player.isFlying) {
                s.airJumped = true;
                try { player.applyKnockback({ x: 0, z: 0 }, 0.55); }
                catch { try { player.applyKnockback(0, 0, 0, 0.55); } catch (_) { /* unsupported */ } }
                try { player.playSound("mace.smash_air"); } catch (_) {}
            }
        } else { s.prevJump = false; s.airJumped = false; }

        // Frost Walker: water under your feet freezes (frosted ice melts back on its own)
        if (ab.has("frost_walker") && !player.isFlying && (player.isOnGround || player.isInWater || player.isSwimming)) {
            try {
                const dim = player.dimension, bx = Math.floor(player.location.x), by = Math.floor(player.location.y) - 1, bz = Math.floor(player.location.z);
                for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
                    const b = dim.getBlock({ x: bx + dx, y: by, z: bz + dz });
                    const above = dim.getBlock({ x: bx + dx, y: by + 1, z: bz + dz });
                    if (b?.typeId === "minecraft:water" && (above?.isAir || above?.typeId === "minecraft:air")) b.setType("minecraft:frosted_ice");
                }
            } catch (_) { /* chunk not loaded */ }
        }
    }

    static _tickGuardianOff(player) {
        GemState.setGuardianStacks(player.id, 0);
        GemState.setGuardianNextCharge(player.id, 0);
    }

    static _isMoving(player) {
        const vel = player.getVelocity();
        return Math.abs(vel.x) > 0.01 || Math.abs(vel.z) > 0.01;
    }

    // Marathon: of the exhaustion the game adds while the player sprints, give back `hungerReduction`%.
    static _tickMarathon(player, ab, cfg) {
        if (!ab.has("marathon")) { exhaustionLast.delete(player.id); return; }
        try {
            const ex = player.getComponent("minecraft:player.exhaustion");
            if (!ex) return;
            const cur = ex.currentValue;
            const last = exhaustionLast.get(player.id);
            let next = cur;
            if (player.isSprinting && last !== undefined && cur > last) {
                const pct = Math.min(100, this.count(player, "marathon") * cfg.marathon.hungerReduction);
                next = Math.max(last, cur - (cur - last) * (pct / 100));
                ex.setCurrentValue(next);
            }
            exhaustionLast.set(player.id, next);
        } catch (_) { /* component unavailable */ }
    }

    // ---------------------------------------------------------------
    // Step 2.3/2.4 — entityHurt.before handlers
    // ---------------------------------------------------------------
    static onHurtBefore(event) {
        const victim = event.hurtEntity;
        if (victim?.typeId !== "minecraft:player") return;
        const ab = this.getAbilities(victim);
        if (ab.size === 0) return;
        const cfg = gc(victim);
        const rawCause = String(event.damageSource?.cause ?? "");
        const hitter = event.damageSource?.damagingEntity;

        // Immunities: Frost Walker (freezing), Soulward (Wither)
        if (ab.has("frost_walker") && (rawCause === "freezing" || rawCause === "freeze")) { event.cancel = true; return; }
        if (ab.has("soulward") && rawCause === "wither") { event.cancel = true; return; }

        // Premonition: every N seconds the first attack that lands is dodged automatically
        if (ab.has("premonition") && hitter && hitter.id !== victim.id && CooldownManager.isReady(victim, "premonition")) {
            CooldownManager.start(victim, "premonition", cfg.premonition.intervalSec);
            event.cancel = true;
            victim.onScreenDisplay.setActionBar("§d[Premonition] Attack foreseen — dodged!");
            this.onDodge(victim);
            return;
        }

        // Phase Step: chance to dodge and blink away from the attacker
        if (ab.has("phase_step") && hitter && hitter.id !== victim.id && CooldownManager.isReady(victim, "phase_step")
            && Math.random() * 100 < cfg.phase_step.chance) {
            CooldownManager.start(victim, "phase_step", cfg.phase_step.cooldownSec);
            event.cancel = true;
            blinkPlayer(victim, awayDir(victim, hitter), cfg.phase_step.distance);
            victim.onScreenDisplay.setActionBar("§d[Phase Step] Slipped away!");
            this.onDodge(victim);
            return;
        }

        // Spell Mirror: chance to send a Magic attack back at whoever cast it
        if (ab.has("spell_mirror") && rawCause === "magic" && hitter && hitter.isValid && hitter.id !== victim.id
            && Math.random() * 100 < cfg.spell_mirror.chance) {
            const dmg = event.damage;
            event.cancel = true;
            system.run(() => { try { fireSuppressedDamage(hitter, victim, Math.ceil(dmg)); } catch (_) {} });
            victim.onScreenDisplay.setActionBar("§b[Spell Mirror] Reflected!");
            return;
        }

        // Guardian Shield: absorb damage stacks
        if (ab.has("guardian_shield")) {
            const g = cfg.guardian_shield;
            const stacks = GemState.getGuardianStacks(victim.id);
            if (stacks > 0 && event.damage <= g.absorb) {
                event.cancel = true;
                const newStacks = stacks - 1;
                GemState.setGuardianStacks(victim.id, newStacks);
                GemState.setGuardianNextCharge(victim.id, Date.now() + g.chargeSec * 1000);
                victim.onScreenDisplay.setActionBar(
                    `§b[Guardian Shield] Absorbed! §f${newStacks}/${g.maxStacks} remaining`
                );
                HudManager.markDirty(victim);
                return;
            } else if (stacks > 0) {
                // Damage exceeds absorb — consume one stack and reduce damage
                const newStacks = stacks - 1;
                GemState.setGuardianStacks(victim.id, newStacks);
                GemState.setGuardianNextCharge(victim.id, Date.now() + g.chargeSec * 1000);
                event.damage = Math.max(1, event.damage - g.absorb);
                victim.onScreenDisplay.setActionBar(
                    `§b[Guardian Shield] Partially absorbed! §f${newStacks}/${g.maxStacks}`
                );
                HudManager.markDirty(victim);
            }
        }

        // Reflection: chance (higher with a shield in the offhand) to reflect damage
        if (ab.has("reflection") && !event.cancel) {
            const equipment  = getEquipment(victim);
            const offhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Offhand);
            const hasShield  = offhandSlot?.hasItem() &&
                               offhandSlot.getItem().typeId === "minecraft:shield";
            const chance     = hasShield ? cfg.reflection.shieldChance : cfg.reflection.chance;

            if (Math.random() * 100 < chance) {
                const attacker = event.damageSource?.damagingEntity;
                const dmg      = event.damage;
                event.cancel   = true;
                if (attacker && attacker.isValid) {
                    system.run(() => {
                        try {
                            attacker.runCommand(`damage @s ${Math.ceil(dmg)} entity_attack`);
                        } catch (_) {}
                    });
                    victim.onScreenDisplay.setActionBar("§b[Reflection] Reflected!");
                }
            }
        }
    }

    // ---------------------------------------------------------------
    // Step 2.5 — entityHurt.after handlers
    // ---------------------------------------------------------------
    static onHurtAfter(event) {
        const victim = event.hurtEntity;
        if (victim?.typeId !== "minecraft:player") return;
        const ab = this.getAbilities(victim);
        if (ab.size === 0) return;

        // Quicksilver: being hit grants a short speed burst (read by getGemSpeedBonus)
        if (ab.has("quicksilver")) {
            st(victim).quicksilver = system.currentTick + gc(victim).quicksilver.seconds * TICKS;
        }

        // Thorns: melee attackers take damage back (stacks per piece)
        if (ab.has("thorns") && event.damageSource?.cause === "entityAttack" && !event.damageSource?.damagingProjectile) {
            const attacker = event.damageSource?.damagingEntity;
            const dmg = this.count(victim, "thorns") * gc(victim).thorns.damage;
            if (attacker?.isValid && attacker.id !== victim.id && dmg > 0) fireSuppressedDamage(attacker, victim, dmg);
        }

        // Undying: when HP drops below 5, instant heal + mana = 0
        if (ab.has("undying")) {
            const hp = getHealth(victim);
            if (hp && hp.currentValue < 5 && hp.currentValue > 0) {
                if (CooldownManager.isReady(victim, "undying")) {
                    CooldownManager.start(victim, "undying", gc(victim).undying.cooldownSec);
                    ManaManager.setMana(victim, 0);
                    system.run(() => {
                        if (victim.isValid) {
                            HPManager.setHP(victim, HPManager.getMaxHP(victim));
                            victim.onScreenDisplay.setActionBar("§c[Undying] Cheated death!");
                            HudManager.markDirty(victim);
                        }
                    });
                }
            }
        }
    }

    // Kill hook (registered by register()): Killer's Rush.
    static onKill(killEvent) {
        const killer = killEvent?.killer;
        if (!killer?.isValid || killEvent.isPlayerVictim) return;
        const cfg = gc(killer);
        if (this.hasAbility(killer, "killers_rush")) {
            const c = cfg.killers_rush;
            MovementManager.addSpeed(killer, "gem_killers_rush", (c.speedAmplifier ?? 1) + 1, c.speedSeconds);
        }
        if (this.hasAbility(killer, "rampage")) {
            const r = st(killer).rampage, c = cfg.rampage, now = system.currentTick;
            r.n = (now < r.until ? r.n : 0) + 1;
            if (r.n > c.maxStacks) r.n = c.maxStacks;
            r.until = now + c.seconds * TICKS;       // every kill refreshes the timer for all stacks
            killer.onScreenDisplay.setActionBar(`§c[Rampage] §f${r.n}/${c.maxStacks} §7(+${r.n * c.perKill}%)`);
        }
        if (this.hasAbility(killer, "reapers_due")) {
            HPManager.heal(killer, HPManager.getMaxHP(killer) * (cfg.reapers_due.healPct / 100));
        }
    }

    // ---------------------------------------------------------------
    // Stat helpers — read by other systems. Everything below is "value x stack count", then the global caps.
    // ---------------------------------------------------------------

    // Dodge % from Gems (cap GEM_CAPS.dodge, separate from the Chorus cap). Called by AugmentManager.applyEvasion.
    static getGemEvasionBonus(player) {
        return Math.min(GEM_CAPS.dodge, this._sum(player, "dodge", "dodge"));
    }

    // Bulwark was removed in v5; kept so older callers keep working.
    static getGemArmorBonus() {
        return 0;
    }

    // Flat max Mana (ManaManager.getMaxMana) and Mana regen/s (ManaManager.getRegenPerSecond). Uncapped.
    static getGemManaBonus(player) {
        return this._sum(player, "maxMana", "maxMana");
    }

    static getGemManaRegenBonus(player) {
        return this._sum(player, "manaRegen", "manaRegen");
    }

    // Movement speed % (cap GEM_CAPS.speed). Called by AugmentManager.applyPassiveStats.
    static getGemSpeedBonus(player) {
        let pct = this._sum(player, "speed", "speedPct");
        if (this.hasAbility(player, "quicksilver") && system.currentTick < (st(player).quicksilver ?? 0)) {
            pct += gc(player).quicksilver.speedPct;
        }
        return Math.min(GEM_CAPS.speed, pct);
    }

    // Flat Max HP (HPManager.recalcMaxHP) and HP regen/s (HPManager.getRegenPerSecond). Uncapped.
    static getGemHpBonus(player) {
        return this._sum(player, "maxHp", "maxHpBonus");
    }

    static getGemRegenBonus(player) {
        return this._sum(player, "regen", "regenBonus");
    }

    // ---------------------------------------------------------------
    // Total % damage reduction from Gems — computed live at hit time (CombatPipeline), capped at
    // GEM_CAPS.dmgReduction. `cause` is the normalized damage cause.
    // ---------------------------------------------------------------
    static getGemDamageReductionPercent(player, cause = null) {
        const counts = this.getCounts(player);
        if (counts.size === 0) return 0;
        const cfg = gc(player);
        const n = (k) => counts.get(k) ?? 0;
        const hp = getHealth(player);
        const hpBelow = (pct) => !!hp && hp.currentValue < hp.effectiveMax * (pct / 100);
        const isProjectile = cause === "projectile";
        const isMagic = MAGIC_CAUSES.has(cause);
        const isFire = FIRE_CAUSES.has(cause);

        let r = 0;
        r += n("toughness") * cfg.toughness.dmgReduction;
        r += n("resolve") * cfg.resolve.dmgReduction;
        r += n("colossus") * cfg.colossus.dmgReduction;
        if (n("tenacity") && hpBelow(cfg.tenacity.hpThresholdPct)) r += n("tenacity") * cfg.tenacity.dmgReduction;
        if (n("berserker") && hpBelow(cfg.berserker.hpThresholdPct)) r += cfg.berserker.dmgReduction;
        if (n("sanctuary") && player.isSneaking && !this._isMoving(player)) r += n("sanctuary") * cfg.sanctuary.dmgReduction;

        if (isProjectile) {
            r += n("padded_plate") * cfg.padded_plate.projReduction;
            r += n("plate_wall") * cfg.plate_wall.projReduction;
            r += n("bulletproof") * cfg.bulletproof.dmgReduction;
        }
        if (cause === "entity_attack") r += n("stoneskin") * cfg.stoneskin.meleeReduction;
        if (isMagic) {
            r += n("spell_ward") * cfg.spell_ward.magicReduction;
            r += n("soulward") * cfg.soulward.magicReduction;
        }
        if (isMagic || isFire) r += n("spellbreaker") * cfg.spellbreaker.magicFireReduction;
        if (cause === "fall") r += n("soft_landing") * cfg.soft_landing.fallReduction;

        return Math.min(GEM_CAPS.dmgReduction, r);
    }

    // True when a fall of `baseDamage` (vanilla damage, about height - 3) should do no damage at all:
    // Cat's Grace (safe up to 10 blocks), Wind Walker (15). Earthbound / Earthshaker / Skystep come with tier 4-7.
    static shouldNegateFall(player, baseDamage) {
        const counts = this.getCounts(player);
        if (counts.size === 0) return false;
        const cfg = gc(player);
        let safe = 0;
        if (counts.has("cats_grace")) safe = Math.max(safe, cfg.cats_grace.safeFallBlocks);
        if (counts.has("wind_walker")) safe = Math.max(safe, cfg.wind_walker.safeFallBlocks);
        if (counts.has("earthbound")) return true;
        return safe > 0 && baseDamage + 3 <= safe;
    }

    // ---------------------------------------------------------------
    // Total % damage dealt bonus. Melee-specific sources are capped at GEM_CAPS.meleeBonus; "general" sources
    // (Rampage, Third Eye) apply to every hit on top of that.
    // `info`: { ranged: true } for arrows/tridents, otherwise melee; { victim } enables target-based bonuses.
    // Called by CombatPipeline.
    // ---------------------------------------------------------------
    static getGemAttackBonusPercent(player, info = {}) {
        const counts = this.getCounts(player);
        if (counts.size === 0) return 0;
        const cfg = gc(player);
        const n = (k) => counts.get(k) ?? 0;
        const now = system.currentTick;

        // General sources
        let general = 0;
        if (n("third_eye")) general += cfg.third_eye.extraDamagePct;
        if (n("rampage")) { const r = st(player).rampage; if (now < r.until) general += r.n * cfg.rampage.perKill; }

        if (info.ranged) {
            return general + n("marksman") * cfg.marksman.rangedBonus
                 + n("eagle_eye") * cfg.eagle_eye.rangedBonus
                 + n("dragons_gaze") * cfg.dragons_gaze.rangedBonus;
        }

        const hp = getHealth(player);
        const hpBelow = (pct) => !!hp && hp.currentValue < hp.effectiveMax * (pct / 100);
        let b = n("brawler") * cfg.brawler.meleeBonus + n("brute_force") * cfg.brute_force.meleeBonus
              + n("overpower") * cfg.overpower.meleeBonus + n("warlords_might") * cfg.warlords_might.meleeBonus;
        if (n("adrenaline") && hpBelow(cfg.adrenaline.hpThresholdPct)) b += n("adrenaline") * cfg.adrenaline.meleeBonus;
        if (n("berserker") && hpBelow(cfg.berserker.hpThresholdPct)) b += cfg.berserker.dmgBonus;

        // Warpath: consecutive hits within the window stack
        if (n("warpath")) {
            const w = st(player).warpath;
            if (now - w.last <= cfg.warpath.windowSec * TICKS) b += w.n * cfg.warpath.perStack;
        }
        // Momentum Strike: +perSec per second of sprinting, kept for lingerSec after you stop
        if (n("momentum_strike")) {
            const m = st(player).momentum, c = cfg.momentum_strike;
            if (m.since && (!m.stoppedAt || now - m.stoppedAt <= c.lingerSec * TICKS)) {
                const end = m.stoppedAt || now;
                b += Math.min(c.maxBonus, Math.floor((end - m.since) / TICKS) * c.perSec);
            } else if (m.since) { m.since = 0; m.stoppedAt = 0; }
        }
        // Executioner's Gait: bonus against targets that are already low
        if (n("executioners_gait") && info.victim) {
            const vh = info.victim.getComponent?.(EntityComponentTypes.Health);
            if (vh && vh.effectiveMax > 0 && vh.currentValue < vh.effectiveMax * (cfg.executioners_gait.hpThresholdPct / 100)) {
                b += cfg.executioners_gait.dmgBonus;
            }
        }
        return general + Math.min(GEM_CAPS.meleeBonus, b);
    }

    // % of the target's armor ignored by this attacker's hit (Overpower: melee, Dragon's Gaze: ranged).
    static getArmorPenetration(player, info = {}) {
        const cfg = gc(player);
        if (info.ranged) return this.hasAbility(player, "dragons_gaze") ? cfg.dragons_gaze.armorPenPct : 0;
        return this.hasAbility(player, "overpower") ? cfg.overpower.armorPenPct : 0;
    }

    // Unyielding: fraction of Max HP one hit may take at most (null = no limit).
    static getMaxHitFraction(player) {
        return this.hasAbility(player, "unyielding") ? gc(player).unyielding.maxHitPct / 100 : null;
    }

    // Mind Over Matter: returns a function(damage) -> damage absorbed by Mana (1:1), or null without the ability.
    static makeManaAbsorb(player) {
        if (!this.hasAbility(player, "mind_over_matter")) return null;
        const pct = gc(player).mind_over_matter.absorbPct / 100;
        return (damage) => {
            try {
                const { mana } = ManaManager.getMana(player);
                const pay = Math.min(damage * pct, mana);
                if (pay <= 0) return 0;
                ManaManager.setMana(player, mana - pay);
                return pay;
            } catch (_) { return 0; }
        };
    }

    // Ascended Mind: % off the Mana cost of every skill. Lucid Mind: % off Rune / Gem cooldowns.
    static getGemManaCostReduction(player) {
        return this.hasAbility(player, "ascended_mind") ? gc(player).ascended_mind.manaCostReduction : 0;
    }

    static getGemCooldownReduction(player) {
        return this.hasAbility(player, "lucid_mind") ? gc(player).lucid_mind.cooldownReduction : 0;
    }

    // Called after a successful dodge (Evasion grants a speed burst).
    static onDodge(player) {
        AchievementManager.event(player, "dodges");
        if (!this.hasAbility(player, "evasion")) return;
        const c = gc(player).evasion;
        MovementManager.addSpeed(player, "gem_evasion", (c.speedAmplifier ?? 1) + 1, c.speedSeconds);
    }

    // Fall landing: returns true when the fall should do no damage. Earthshaker also releases its shockwave.
    static onFall(player, baseDamage) {
        if (this.hasAbility(player, "earthshaker")) {
            const c = gc(player).earthshaker;
            if (baseDamage + 3 >= c.minHeight) {
                this._shockwave(player, player.location, c.radius, c.damage);
                return true;
            }
        }
        return this.shouldNegateFall(player, baseDamage);
    }

    // Called by the pipeline after a player's hit landed. `info`: { victim, melee, damage }.
    static afterHit(attacker, info) {
        const counts = this.getCounts(attacker);
        if (counts.size === 0 || !info.melee) return;
        const cfg = gc(attacker), s = st(attacker), now = system.currentTick;

        if (counts.has("warpath")) {
            const w = s.warpath;
            w.n = (now - w.last <= cfg.warpath.windowSec * TICKS ? w.n : 0) + 1;
            if (w.n > cfg.warpath.maxStacks) w.n = cfg.warpath.maxStacks;
            w.last = now;
        }

        const victim = info.victim;
        if (counts.has("warlords_might") && victim?.isValid) {
            const c = cfg.warlords_might;
            const hits = (s.hits.get(victim.id) ?? 0) + 1;
            if (hits >= c.stunEvery) {
                s.hits.delete(victim.id);
                if (!isBoss(victim.typeId)) {
                    try { victim.addEffect("slowness", c.stunSec * TICKS, { amplifier: 10, showParticles: false }); } catch (_) {}
                    try { victim.addEffect("weakness", c.stunSec * TICKS, { amplifier: 4, showParticles: false }); } catch (_) {}
                }
                attacker.onScreenDisplay.setActionBar("§6[Warlord's Might] Stunned!");
            } else s.hits.set(victim.id, hits);
            if (s.hits.size > 40) s.hits.clear();   // never grow without bound
        }

        if (counts.has("thunder_stride") && attacker.isSprinting && CooldownManager.isReady(attacker, "thunder_stride")) {
            const c = cfg.thunder_stride;
            CooldownManager.start(attacker, "thunder_stride", c.cooldownSec);
            this._shockwave(attacker, attacker.location, c.radius, c.damage);
        }
    }

    // Damages every non-player entity around `center` (Earthshaker, Thunder Stride).
    static _shockwave(player, center, radius, damage) {
        try {
            for (const e of player.dimension.getEntities({ location: center, maxDistance: radius, excludeTypes: ["minecraft:player", "minecraft:item"] })) {
                if (e.id === player.id) continue;
                try { fireSuppressedDamage(e, player, damage); } catch (_) { /* skip */ }
            }
            player.dimension.spawnParticle?.("minecraft:large_explosion", center);
            player.playSound("random.explode", { volume: 0.5 });
        } catch (_) { /* dimension unavailable */ }
    }

    // Sneak twice (event_router): Immunity (cleanse) and Voidstep (blink forward).
    static onDoubleSneak(player) {
        this.triggerImmunity(player);
        this._triggerVoidstep(player);
    }

    static _triggerVoidstep(player) {
        if (!this.hasAbility(player, "voidstep") || !CooldownManager.isReady(player, "voidstep")) return false;
        const c = gc(player).voidstep;
        const v = player.getViewDirection();
        if (blinkPlayer(player, { x: v.x, z: v.z }, c.distance)) {
            CooldownManager.start(player, "voidstep", c.cooldownSec);
            return true;
        }
        player.onScreenDisplay.setActionBar("§c[Voidstep] No room to step!");
        return false;
    }

    // ---------------------------------------------------------------
    // Helper: Vampirism lifesteal — called from CombatPipeline right after a
    // player attacker's hit is finalized, with the real final damage dealt.
    // ---------------------------------------------------------------
    static applyLifesteal(attacker, damageDealt, melee = true) {
        if (damageDealt <= 0 || !melee) return;
        const cfg = gc(attacker);
        let pct = 0;
        if (this.hasAbility(attacker, "vampirism")) pct += cfg.vampirism.lifestealPct;
        if (this.hasAbility(attacker, "bloodthirst")) pct += cfg.bloodthirst.lifestealPct;
        const heal = damageDealt * (pct / 100);
        if (heal > 0) HPManager.heal(attacker, heal);
    }

    // ---------------------------------------------------------------
    // Internal: Second Wind — once per cooldown, auto-heal when HP drops
    // below its threshold
    // ---------------------------------------------------------------
    static _checkSecondWind(player) {
        if (!this.hasAbility(player, "second_wind")) return;
        const hp = getHealth(player);
        if (!hp || hp.currentValue <= 0) return;

        const cfg = gc(player).second_wind;
        if (hp.currentValue >= hp.effectiveMax * (cfg.hpThresholdPct / 100)) return;
        if (!CooldownManager.isReady(player, "second_wind")) return;

        CooldownManager.start(player, "second_wind", cfg.cooldownSec);
        HPManager.heal(player, cfg.healAmount);
        player.onScreenDisplay.setActionBar(`§b[Second Wind] Healed §f${cfg.healAmount} HP§b!`);
        HudManager.markDirty(player);
    }

    // ---------------------------------------------------------------
    // Internal: Static Field — periodic AoE damage pulse to nearby enemies
    // ---------------------------------------------------------------
    static _applyStaticField(player) {
        const cfg = gc(player).static_field;
        if (!CooldownManager.isReady(player, "static_field_pulse")) return;
        CooldownManager.start(player, "static_field_pulse", cfg.intervalSec);

        const nearby = player.dimension.getEntities({
            location: player.location,
            maxDistance: cfg.radius,
            excludeTypes: ["minecraft:player", "minecraft:item"],
        });
        for (const entity of nearby) {
            try { entity.runCommand(`damage @s ${cfg.damage} entity_attack`); } catch (_) {}
        }
    }

    // ---------------------------------------------------------------
    // Helper: damage multiplier % from Assassination while sneaking (+ Resonance rune).
    // Called by DamageManager pipeline.
    // ---------------------------------------------------------------
    static getAssassinationMultiplier(player) {
        const n = this.count(player, "assassination");
        return (n > 0 && player.isSneaking) ? Math.round(n * gc(player).assassination.sneakBonus) : 0;
    }

    // Resonance rune: every active Gem ability makes ALL Gem abilities stronger by gemEffectivenessBonus
    // (default 5%) -- added to Gem Potency, so it raises the same power numbers (see GEM_POTENCY_KEYS).
    // Returns whole percent points of Potency.
    static getResonancePotency(player) {
        if (getMainhandRuneId(player) !== "resonance") return 0;
        useRuneLevelOf(player);
        const bonus = RUNE_CONFIG.resonance?.gemEffectivenessBonus ?? 0;
        return Math.round(bonus * 100 * this.getAbilities(player).size);
    }

    // ---------------------------------------------------------------
    // Internal: Aura tick (Cinderveil / Glacial Presence / Frostflare)
    // ---------------------------------------------------------------
    static _applyAura(player, type) {
        const isFire  = type === "cinderveil"  || type === "frostflare";
        const isIce   = type === "glacial_presence" || type === "frostflare";
        const duration = type === "frostflare" ? 24 : 12; // seconds

        const nearby = player.dimension.getEntities({
            location: player.location,
            maxDistance: gc(player)[type]?.radius ?? 3,
            excludeTypes: ["minecraft:player", "minecraft:item"],
        });

        for (const entity of nearby) {
            // Immune: targets sharing the same aura type
            if (type !== "frostflare" && this.hasAbility(entity, type)) continue;

            if (isIce || type === "cinderveil") {
                entity.addEffect("slowness", duration * 20, { amplifier: 1, showParticles: false });
            }
            if (type === "cinderveil") { try { entity.setOnFire(3, true); } catch (_) {} }
        }

        // Fire Resistance for self
        if (isFire) {
            player.addEffect("fire_resistance", 30, { amplifier: 0, showParticles: false });
        }

        // Ice heal: standing in Powder Snow
        if (isIce) {
            try {
                const blockBelow = player.dimension.getBlock({
                    x: Math.floor(player.location.x),
                    y: Math.floor(player.location.y) - 1,
                    z: Math.floor(player.location.z),
                });
                if (blockBelow?.typeId === "minecraft:powder_snow") {
                    HPManager.heal(player, 1);
                }
            } catch (_) {}
        }

        // Fire heal: standing on fire or lava (Frostflare only)
        if (type === "frostflare") {
            try {
                const blockAt = player.dimension.getBlock({
                    x: Math.floor(player.location.x),
                    y: Math.floor(player.location.y),
                    z: Math.floor(player.location.z),
                });
                const onFire = blockAt?.typeId === "minecraft:fire"
                    || blockAt?.typeId === "minecraft:soul_fire"
                    || blockAt?.typeId === "minecraft:lava";
                if (onFire) {
                    HPManager.heal(player, 1);
                }
            } catch (_) {}
        }

        // Damage ticks are handled separately every 4 seconds — tracked via cooldown
        const dmgKey      = `aura_dmg_${type}`;
        const dmgInterval = isIce ? 4 : 1; // Ice: 4s, Fire: 1s
        const dmgAmount   = isIce ? (type === "frostflare" ? 6 : 5) : (type === "frostflare" ? 2 : 1);

        if (CooldownManager.isReady(player, dmgKey)) {
            CooldownManager.start(player, dmgKey, dmgInterval);
            for (const entity of nearby) {
                if (type !== "frostflare" && this.hasAbility(entity, type)) continue;
                try {
                    entity.runCommand(`damage @s ${dmgAmount} entity_attack`);
                } catch (_) {}
            }
        }
    }

    // ---------------------------------------------------------------
    // Internal: Domain — push hostile mobs away while sneaking
    // ---------------------------------------------------------------
    static _applyDomain(player) {
        if (!CooldownManager.isReady(player, "domain")) return;
        const c = gc(player).domain;
        const EXEMPT = new Set([
            "minecraft:ender_dragon",
            "minecraft:wither",
            "minecraft:warden",
            "minecraft:iron_golem",
            "minecraft:ravager",
        ]);

        const nearby = player.dimension.getEntities({
            location: player.location,
            maxDistance: c.radius,
            excludeTypes: ["minecraft:player", "minecraft:item"],
        });
        let hit = 0;
        for (const entity of nearby) {
            if (EXEMPT.has(entity.typeId)) continue;
            hit++;
            try { entity.runCommand(`damage @s ${c.damage} entity_attack`); } catch (_) {}

            // Push entity away from player
            try {
                const dx = entity.location.x - player.location.x;
                const dz = entity.location.z - player.location.z;
                const len = Math.sqrt(dx * dx + dz * dz) || 1;
                entity.applyImpulse({ x: (dx / len) * 2, y: 0.4, z: (dz / len) * 2 });
            } catch (_) {}
        }
        if (hit > 0) {
            CooldownManager.start(player, "domain", c.cooldownSec);   // only a Domain that hit something goes on cooldown
            player.onScreenDisplay.setActionBar("§5[Domain] Repelled!");
        }
    }

    // Called by Immunity trigger (sneak double-tap or scriptevent)
    static triggerImmunity(player) {
        if (!this.hasAbility(player, "immunity")) return false;
        if (!CooldownManager.isReady(player, "immunity")) {
            const left = CooldownManager.getRemainingSeconds(player, "immunity");
            player.onScreenDisplay.setActionBar(`§c[Immunity] Cooldown: ${left}s`);
            return false;
        }
        CooldownManager.start(player, "immunity", 30);
        system.run(() => {
            try {
                for (const e of player.getEffects()) {   // remove ONLY negative effects (buffs are kept)
                    const id = String(e.typeId).replace("minecraft:", "");
                    if (NEGATIVE_EFFECTS.has(id)) { try { player.removeEffect(e.typeId); } catch (_) {} }
                }
                player.onScreenDisplay.setActionBar("§a[Immunity] Negative effects cleansed!");
            } catch (_) {}
        });
        return true;
    }

    // Called every 20 ticks (Phase 5/#12) — Flight now turns on the instant
    // the player has the ability (i.e. wears armor with a Flight Gem) and
    // turns off the instant they no longer do, instead of a Shift-spam toggle.
    static tickFlightCheck(player) {
        // Creative/Spectator: flight belongs to the game mode. If the gem ever
        // touched this player's abilities (e.g. they switched mode while a gem
        // grant was active), hand native flight back, then leave them alone.
        if (hasNativeFlight(player)) {
            if (flightGranted.delete(player.id)) {
                try { player.runCommand("ability @s mayfly true"); } catch (_) {}
            }
            return;
        }

        const hasFlight = this.hasAbility(player, "flight");

        if (hasFlight) {
            if (!flightGranted.has(player.id)) {
                flightGranted.add(player.id);
                setFlying(player, true);
                player.onScreenDisplay.setActionBar(`§b[Flight] Enabled — costs §f${gc(player).flight.manaPerSec} Mana/s`);
            } else if (!player.isFlying) {
                setFlying(player, true);
            }
            return;
        }

        // Flight gem no longer equipped: revoke what the gem granted, even if
        // the player is standing on the ground (otherwise mayfly stays true
        // and they can still take off once more).
        if (flightGranted.delete(player.id)) {
            setFlying(player, false);
            player.onScreenDisplay.setActionBar("§7[Flight] Disabled");
        }
    }

    static onPlayerLeave(playerId) {
        Synergy.onPlayerLeave(playerId);
        _abilityCache.delete(playerId);
        _potencyCache.delete(playerId);
        exhaustionLast.delete(playerId);
        _st.delete(playerId);
        flightGranted.delete(playerId);
    }
}
