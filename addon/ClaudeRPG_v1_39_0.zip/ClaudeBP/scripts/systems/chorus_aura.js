// chorus_aura.js -- Chorus Aura: cosmetic particles around a player wearing Chorus armor. Display only, no stats.
// Shows the player's strongest set (hybrid sets alternate between their two elements). Particles are spawned in the
// world, so other players see them too. Personal switch: Settings > Chorus Aura. Global switch: CHORUS_AURA.ENABLED.
import { system } from "@minecraft/server";
import { CHORUS_AURA } from "../config/qol_config.js";
import { CHORUS_ELEMENTS } from "../config/chorus_config.js";
import { ChorusManager } from "./chorus_manager.js";
import { SettingsManager } from "./settings_manager.js";

const cache = new Map();     // playerId -> { until: tick, elements: [ids], bonus: n }
let angle = 0;

function resolveAura(player) {
    const { sets } = ChorusManager.getPlayerSets(player);
    const top = sets.find((s) => s.count >= CHORUS_AURA.MIN_SLOTS);
    if (!top) return { elements: [], bonus: 0 };
    const elements = (top.elements ?? []).filter((id) => CHORUS_ELEMENTS[id]);
    const tier = CHORUS_ELEMENTS[elements[0]]?.tier;
    return { elements, bonus: CHORUS_AURA.TIER_BONUS[tier] ?? 0 };
}

function visible(player) {
    if (!player?.isValid) return false;
    try { if (player.getEffect("invisibility")) return false; } catch (_) {}
    try { if (player.getGameMode() === "Spectator") return false; } catch (_) {}
    return true;
}

export const ChorusAura = {
    // One pulse for one player.
    pulse(player) {
        if (!visible(player) || !SettingsManager.get(player, "chorus_aura")) return;
        let c = cache.get(player.id);
        if (!c || c.until <= system.currentTick) {
            c = { ...resolveAura(player), until: system.currentTick + Math.max(10, CHORUS_AURA.REFRESH_TICKS) };
            cache.set(player.id, c);
        }
        if (!c.elements.length) return;
        const n = Math.max(1, CHORUS_AURA.PER_TICK + c.bonus);
        const r = CHORUS_AURA.RADIUS, base = player.location, dim = player.dimension;
        for (let i = 0; i < n; i++) {
            const a = angle + (i * 2 * Math.PI) / n;
            const id = c.elements[i % c.elements.length];
            const particle = CHORUS_AURA.PARTICLES[id] ?? CHORUS_AURA.FALLBACK;
            try { dim.spawnParticle(particle, { x: base.x + Math.cos(a) * r, y: base.y + 0.2 + ((i % 3) * 0.6), z: base.z + Math.sin(a) * r }); } catch (_) { /* unknown id or unloaded chunk */ }
        }
    },

    // Shared job (every 10 ticks).
    tick(players) {
        if (CHORUS_AURA.ENABLED < 1) return;
        angle = (angle + 0.9) % (Math.PI * 2);
        for (const p of players) { try { this.pulse(p); } catch (_) {} }
    },

    onPlayerLeave(playerId) { cache.delete(playerId); },
};
