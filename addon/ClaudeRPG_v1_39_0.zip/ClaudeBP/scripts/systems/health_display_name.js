// health_display_name.js -- pure helpers for the HP name tag (no Minecraft API, safe to import anywhere).
// A rendered name is "<base name>\n<HP line>" or just "<HP line>" for mobs without a name.
import { HEALTH_DISPLAY as C } from "../config/health_display_config.js";

const CODE = "(?:§.)*";
const NUM = "[\\d.,]+[KMB]?";
const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

let cachedLabel = null;
let cachedRegex = null;
function lineRegex() {
    const label = String(C.LABEL ?? "");
    if (cachedRegex && cachedLabel === label) return cachedRegex;
    const head = label ? `${esc(label)} ` : "";
    cachedRegex = new RegExp(`^${CODE}${head}${CODE}${NUM}${CODE}\\/${CODE}${NUM}${CODE}$`);
    cachedLabel = label;
    return cachedRegex;
}

// 950 -> "950", 12500 -> "12.5K", 1234567 -> "1.2M"
export function formatHp(value) {
    let v = Number(value);
    if (!Number.isFinite(v) || v < 0) v = 0;
    v = Math.round(v);
    const from = Math.max(1000, Number(C.COMPACT_FROM) || 10000);
    if (v < from) return String(v);
    for (const [size, tag] of [[1e9, "B"], [1e6, "M"], [1e3, "K"]]) {
        if (v >= size) {
            const x = Math.floor((v / size) * 10) / 10;
            return (Number.isInteger(x) ? String(x) : x.toFixed(1)) + tag;
        }
    }
    return String(v);
}

// flash: "damage" | "heal" | null
export function buildHpLine(cur, max, boss = false, flash = null) {
    const curColor = flash === "damage" ? C.COLOR_DAMAGE : flash === "heal" ? C.COLOR_HEAL : C.COLOR_NUM;
    const bold = boss ? "§l" : "";
    const label = C.LABEL ? `${boss ? C.BOSS_PREFIX : C.COLOR_LABEL}${C.LABEL} ` : "";
    return `${label}${curColor}${bold}${formatHp(cur)}${C.COLOR_SEP}${bold}/${C.COLOR_NUM}${bold}${formatHp(max)}§r`;
}

export function isHpLine(line) { return lineRegex().test(String(line ?? "")); }

// "Elite Zombie\nHP 12/20" -> "Elite Zombie"; "HP 12/20" -> ""; anything else is returned unchanged.
export function stripHpLine(name) {
    const text = String(name ?? "");
    const lines = text.split("\n");
    if (lines.length && isHpLine(lines[lines.length - 1])) return lines.slice(0, -1).join("\n");
    return text;
}

// True when the whole name is only our HP line (the mob has no real name yet).
export function isHpOnlyName(name) {
    const text = String(name ?? "");
    return text.length > 0 && !text.includes("\n") && isHpLine(text);
}

// "minecraft:ender_dragon" -> "Ender Dragon"
export function defaultName(typeId) {
    return String(typeId ?? "entity").split(":").pop().replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
