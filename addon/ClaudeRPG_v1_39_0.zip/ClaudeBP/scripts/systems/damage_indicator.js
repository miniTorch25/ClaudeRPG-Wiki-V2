// damage_indicator.js -- wires the floating damage numbers into the real scheduler.
import { system } from "@minecraft/server";
import { createDamageIndicator } from "./damage_indicator_core.js";

export const DamageIndicator = createDamageIndicator({
    defer: (fn) => system.run(fn),
    getTick: () => system.currentTick,
});
