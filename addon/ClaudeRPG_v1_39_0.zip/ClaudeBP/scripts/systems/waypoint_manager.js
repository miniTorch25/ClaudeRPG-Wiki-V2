// waypoint_manager.js -- Waypoint Stone / Blank / Orb data + logic (no GUI).
//
// Stones (named)   : one world dynamic property per stone  "crpg:wps_<id>"
//                    { id, name, owner, ownerName, dim, x, y, z, v:2, pending?, broken?, legacyUnnamed?, savers:{ playerId: playerName } }
//                    pending  = placed but not named yet (unusable until the owner names it)
//                    broken   = the block was destroyed: the entry stays in saved lists, travel is refused
//                    savers   = players who saved this stone (source of truth; lets the owner remove a player at any time)
// Player list      : player dynamic property "crpg:wp_known" [stone ids]  (ORDER = priority, max WAYPOINT.SAVED_MAX)
// Orb points       : player dynamic property "crpg:wp_special" [{ name, dim, x, y, z }]  (max WAYPOINT.SPECIAL_MAX, listed first)
// Blank stones     : not stored anywhere (no name, no owner); they only open the travel menu.
// Teleport target  : the top of the stone (first free 2-block space above it).
// Old data         : "crpg:wp_world" (one big property) is converted on first load; old unnamed stones are destroyed when possible.

import { world, system, ItemStack, GameMode } from "@minecraft/server";
import { WAYPOINT } from "../config/exploration_config.js";
import { CostManager } from "../managers/cost_manager.js";
import { AdminManager } from "../managers/admin_manager.js";
import { Logger } from "../core/logger.js";

const LEGACY_KEY = "crpg:wp_world";
const ENTRY_PREFIX = "crpg:wps_";
const NEXT_KEY = "crpg:wp_next";
const KNOWN_KEY = "crpg:wp_known";
const VER_KEY = "crpg:wp_ver";
const SPECIAL_KEY = "crpg:wp_special";

let reg = null;                          // { next, list } loaded lazily
const lastStoneTp = new Map();           // playerId -> tick
const lastSpecialTp = new Map();         // playerId -> tick

// ---------- registry ----------
function persist(id) {
    try {
        const e = reg?.list[id];
        world.setDynamicProperty(ENTRY_PREFIX + id, e ? JSON.stringify(e) : undefined);
    } catch (error) { Logger.warn(`Waypoint save failed: ${error}`); }
}

function migrateLegacy(raw) {
    const parsed = JSON.parse(raw);
    reg.next = Math.max(reg.next, parsed.next | 0, 1);
    for (const w of Object.values(parsed.list ?? {})) {
        if (!w || w.id === undefined || reg.list[String(w.id)]) continue;
        const id = String(w.id);
        const e = {
            id, name: String(w.name ?? ""), owner: w.owner ?? null, ownerName: w.ownerName ?? "World",
            dim: w.dim, x: w.x | 0, y: w.y | 0, z: w.z | 0, v: 2, savers: {},
        };
        if (e.name === `Waypoint ${id}` || !e.name) e.legacyUnnamed = true;   // never named by its owner: to be destroyed
        reg.list[id] = e;
        persist(id);
    }
    world.setDynamicProperty(NEXT_KEY, reg.next);
    world.setDynamicProperty(LEGACY_KEY, undefined);
}

function load() {
    if (reg) return reg;
    reg = { next: 1, list: {} };
    try {
        const next = world.getDynamicProperty(NEXT_KEY);
        if (typeof next === "number") reg.next = Math.max(1, next | 0);
        for (const key of world.getDynamicPropertyIds()) {
            if (!key.startsWith(ENTRY_PREFIX)) continue;
            try {
                const e = JSON.parse(world.getDynamicProperty(key));
                if (e && e.id !== undefined) { e.savers = e.savers ?? {}; reg.list[String(e.id)] = e; }
            } catch (_) { /* skip a corrupt entry */ }
        }
        const legacy = world.getDynamicProperty(LEGACY_KEY);
        if (typeof legacy === "string" && legacy) migrateLegacy(legacy);
    } catch (error) { Logger.warn(`Waypoint registry unreadable, starting empty: ${error}`); }
    return reg;
}

function cleanName(name, fallback) {
    const n = String(name ?? "").replace(/[\u00a7\r\n\t]/g, "").trim().slice(0, WAYPOINT.NAME_MAX);
    return n || fallback;
}

const dimKey = (dimension) => String(dimension?.id ?? dimension ?? "").replace("minecraft:", "");
const dimLabel = (key) => ({ overworld: "Overworld", nether: "Nether", the_end: "The End" }[key] ?? key);
const usable = (e) => !!e && !e.pending && !e.legacyUnnamed;
const round2 = (n) => Math.round(n * 100) / 100;

function passable(b) {
    return b.isAir || (!b.isSolid && !b.isLiquid);
}

export const WaypointManager = {
    dimLabel,
    isEnabled() { return WAYPOINT.ENABLED >= 1; },
    isStone(typeId) { return typeId === WAYPOINT.BLOCK_ID; },
    isBlank(typeId) { return typeId === WAYPOINT.BLANK_ID; },

    all() { return Object.values(load().list); },
    get(id) { return load().list[String(id)] ?? null; },
    isAdmin(player) { return AdminManager.isAdmin(player); },

    // Stones that really exist now: named, not broken.
    active() { return this.all().filter((e) => usable(e) && !e.broken); },
    ownedActive(playerId) { return this.active().filter((e) => e.owner === playerId); },
    pendingOf(playerId) { return this.all().filter((e) => e.pending && e.owner === playerId); },

    // Any entry (pending or live, never a broken one) standing at this block.
    findAt(dimension, loc) {
        const d = dimKey(dimension), x = Math.floor(loc.x), y = Math.floor(loc.y), z = Math.floor(loc.z);
        return this.all().find((w) => !w.broken && w.dim === d && w.x === x && w.y === y && w.z === z) ?? null;
    },

    canManage(player, wp) {
        if (!wp) return false;
        return wp.owner === player.id || this.isAdmin(player);
    },

    unregister(id) {
        const r = load();
        if (!r.list[id]) return false;
        delete r.list[id];
        persist(id);
        return true;
    },

    // A broken stone nobody has saved any more is deleted for good.
    dropIfDead(wp) {
        if (wp && wp.broken && Object.keys(wp.savers).length === 0) this.unregister(wp.id);
    },

    // ---------- placing / naming ----------
    placementProblem(player, dimension, loc) {
        if (this.active().length >= WAYPOINT.WORLD_MAX) return `This world already has ${WAYPOINT.WORLD_MAX} Waypoint Stones.`;
        if (!this.isAdmin(player) && this.ownedActive(player.id).length >= WAYPOINT.PER_PLAYER_MAX) {
            return `You can own at most ${WAYPOINT.PER_PLAYER_MAX} Waypoint Stones.`;
        }
        if (this.knownIds(player).length >= WAYPOINT.SAVED_MAX) {
            return `Your saved list is full (${WAYPOINT.SAVED_MAX}/${WAYPOINT.SAVED_MAX}). Remove a stone in Manager first.`;
        }
        const d = dimKey(dimension);
        for (const w of this.active()) {
            if (w.dim !== d) continue;
            if (Math.hypot(w.x - loc.x, w.z - loc.z) < WAYPOINT.MIN_SPACING && Math.abs(w.y - loc.y) < WAYPOINT.MIN_SPACING) {
                return `Too close to "${w.name}" (keep ${WAYPOINT.MIN_SPACING} blocks apart).`;
            }
        }
        return null;
    },

    // New stone waiting for its name.
    register(dimension, loc, owner) {
        const r = load();
        const id = String(r.next++);
        try { world.setDynamicProperty(NEXT_KEY, r.next); } catch (_) {}
        const wp = {
            id, name: "", owner: owner?.id ?? null, ownerName: owner?.name ?? "World",
            dim: dimKey(dimension), x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z),
            v: 2, pending: true, savers: {},
        };
        r.list[id] = wp;
        persist(id);
        return wp;
    },

    // The owner typed a name: the stone goes live and is saved to the owner's list.
    finalizeName(player, id, name) {
        const wp = this.get(id);
        if (!wp || !wp.pending) return null;
        const clean = cleanName(name, "");
        if (!clean) return null;
        wp.name = clean;
        wp.pending = false;
        persist(wp.id);
        this.save(player, wp.id);
        return wp;
    },

    rename(id, name) {
        const wp = this.get(id);
        const clean = cleanName(name, "");
        if (!wp || !clean) return false;
        wp.name = clean;
        persist(wp.id);
        return true;
    },

    // ---------- the player's saved list ----------
    ensureMigrated(player) {
        try {
            if (player.getDynamicProperty(VER_KEY) === 2) return;
            const raw = player.getDynamicProperty(KNOWN_KEY);
            const old = typeof raw === "string" && raw ? JSON.parse(raw) : [];
            const kept = [];
            for (const id of Array.isArray(old) ? old : []) {
                const e = this.get(id);
                if (!usable(e) || kept.includes(String(id)) || kept.length >= WAYPOINT.SAVED_MAX) continue;
                e.savers[player.id] = player.name;
                persist(e.id);
                kept.push(String(id));
            }
            player.setDynamicProperty(KNOWN_KEY, JSON.stringify(kept));
            player.setDynamicProperty(VER_KEY, 2);
        } catch (error) { Logger.warn(`Waypoint list migration failed: ${error}`); }
    },

    knownIds(player) {
        this.ensureMigrated(player);
        try {
            const raw = player.getDynamicProperty(KNOWN_KEY);
            const arr = typeof raw === "string" && raw ? JSON.parse(raw) : [];
            if (!Array.isArray(arr)) return [];
            const seen = new Set();
            return arr.map(String).filter((id) => {
                if (seen.has(id)) return false;
                seen.add(id);
                const e = this.get(id);
                return usable(e) && !!e.savers[player.id];
            });
        } catch (_) { return []; }
    },

    known(player) { return this.knownIds(player).map((id) => this.get(id)).filter(Boolean); },
    isSaved(player, id) { return this.knownIds(player).includes(String(id)); },

    writeKnown(player, ids) {
        try { player.setDynamicProperty(KNOWN_KEY, JSON.stringify(ids)); } catch (_) {}
    },

    // "ok" | "already" | "full" | "missing"
    save(player, id) {
        const wp = this.get(id);
        if (!usable(wp)) return "missing";
        const ids = this.knownIds(player);
        if (ids.includes(wp.id)) return "already";
        if (ids.length >= WAYPOINT.SAVED_MAX) return "full";
        ids.push(wp.id);
        wp.savers[player.id] = player.name;
        persist(wp.id);
        this.writeKnown(player, ids);
        return "ok";
    },

    // The player removes a stone from their own list.
    unsave(player, id) {
        const key = String(id);
        this.writeKnown(player, this.knownIds(player).filter((x) => x !== key));
        const wp = this.get(key);
        if (wp) { delete wp.savers[player.id]; persist(wp.id); this.dropIfDead(wp); }
    },

    // The stone's owner / Admin removes another player's link to the stone (works for offline players too).
    removeSaver(stoneId, playerId) {
        const wp = this.get(stoneId);
        if (!wp || !wp.savers[playerId]) return false;
        delete wp.savers[playerId];
        persist(wp.id);
        const online = world.getAllPlayers().find((p) => p.id === playerId);
        if (online) this.writeKnown(online, this.knownIds(online));
        this.dropIfDead(wp);
        return true;
    },

    // how: "top" | "up" | "down"
    move(player, id, how) {
        const ids = this.knownIds(player);
        const i = ids.indexOf(String(id));
        if (i < 0) return false;
        const [item] = ids.splice(i, 1);
        const j = how === "top" ? 0 : how === "up" ? Math.max(0, i - 1) : Math.min(ids.length, i + 1);
        ids.splice(j, 0, item);
        this.writeKnown(player, ids);
        return true;
    },

    // ---------- Orb special points ----------
    specials(player) {
        try {
            const raw = player.getDynamicProperty(SPECIAL_KEY);
            const arr = typeof raw === "string" && raw ? JSON.parse(raw) : [];
            return (Array.isArray(arr) ? arr : []).filter((p) => p && typeof p.dim === "string" && Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z)).slice(0, WAYPOINT.SPECIAL_MAX);
        } catch (_) { return []; }
    },

    writeSpecials(player, list) {
        try { player.setDynamicProperty(SPECIAL_KEY, JSON.stringify(list)); } catch (_) {}
    },

    // null = list full
    addSpecial(player, name) {
        const list = this.specials(player);
        if (list.length >= WAYPOINT.SPECIAL_MAX) return null;
        const loc = player.location;
        const point = { name: cleanName(name, `Point ${list.length + 1}`), dim: dimKey(player.dimension), x: round2(loc.x), y: round2(loc.y), z: round2(loc.z) };
        list.push(point);
        this.writeSpecials(player, list);
        return point;
    },

    renameSpecial(player, index, name) {
        const list = this.specials(player);
        if (!list[index]) return false;
        list[index].name = cleanName(name, list[index].name);
        this.writeSpecials(player, list);
        return true;
    },

    removeSpecial(player, index) {
        const list = this.specials(player);
        if (!list[index]) return false;
        list.splice(index, 1);
        this.writeSpecials(player, list);
        return true;
    },

    // ---------- cost ----------
    horizontalDistance(player, wp) {
        return Math.hypot(wp.x + 0.5 - player.location.x, wp.z + 0.5 - player.location.z);
    },

    cost(player, wp) {
        if (dimKey(player.dimension) !== wp.dim) return WAYPOINT.MAX_COST;
        const raw = Math.ceil(this.horizontalDistance(player, wp) / Math.max(1, WAYPOINT.BLOCKS_PER_PEARL));
        return Math.max(WAYPOINT.MIN_COST, Math.min(WAYPOINT.MAX_COST, raw));
    },

    cooldownLeftSec(player, special = false) {
        const last = (special ? lastSpecialTp : lastStoneTp).get(player.id);
        if (last === undefined) return 0;
        const sec = special ? WAYPOINT.SPECIAL_COOLDOWN_SEC : WAYPOINT.COOLDOWN_SEC;
        return Math.max(0, Math.ceil((last + sec * 20 - system.currentTick) / 20));
    },

    // ---------- travel ----------
    // First free 2-block space above the stone (the top of the block). null = blocked. Unloaded chunk = trust y + 1.
    standY(dim, wp) {
        for (let dy = 1; dy <= 6; dy++) {
            try {
                const a = dim.getBlock({ x: wp.x, y: wp.y + dy, z: wp.z });
                const b = dim.getBlock({ x: wp.x, y: wp.y + dy + 1, z: wp.z });
                if (!a || !b) return wp.y + 1;
                if (passable(a) && passable(b)) return wp.y + dy;
            } catch (_) { return wp.y + 1; }
        }
        return null;
    },

    refund(player, amount) {
        try {
            const inv = player.getComponent("minecraft:inventory")?.container;
            let left = amount;
            while (left > 0) {
                const give = Math.min(left, 64);
                const stack = new ItemStack(WAYPOINT.COST_ITEM, give);
                const rest = inv ? inv.addItem(stack) : stack;
                if (rest) player.dimension.spawnItem(rest, player.location);
                left -= give;
            }
        } catch (_) {}
    },

    // Returns { ok, message }. Pays only when the teleport is really done.
    travelToStone(player, id) {
        if (!this.isEnabled()) return { ok: false, message: "Waypoint travel is turned off." };
        const wp = this.get(String(id));
        if (!usable(wp)) return { ok: false, message: "That Waypoint Stone no longer exists." };
        if (!this.isSaved(player, wp.id)) return { ok: false, message: "That stone is not in your list." };
        if (wp.broken) return { ok: false, message: `"${wp.name}" was destroyed, so you cannot travel there. Remove it in Manager when you like.` };
        const wait = this.cooldownLeftSec(player);
        if (wait > 0) return { ok: false, message: `Waypoint cooldown: ${wait}s left.` };

        const cost = this.cost(player, wp);
        const creative = player.getGameMode() === GameMode.Creative;
        if (!creative && CostManager.count(player, WAYPOINT.COST_ITEM) < cost) {
            return { ok: false, message: `You need ${cost} ${WAYPOINT.COST_NAME}${cost === 1 ? "" : "s"} to travel there.` };
        }

        let dest;
        try { dest = world.getDimension(wp.dim); }
        catch (_) { return { ok: false, message: "That dimension is not available." }; }

        let verified = false;
        try {
            const b = dest.getBlock({ x: wp.x, y: wp.y, z: wp.z });
            if (b) {
                if (b.typeId !== WAYPOINT.BLOCK_ID) {
                    wp.broken = true; persist(wp.id);
                    return { ok: false, message: `"${wp.name}" is gone, so you cannot travel there. Remove it in Manager when you like.` };
                }
                verified = true;
            }
        } catch (_) { /* chunk not loaded: checked after arrival */ }

        const y = this.standY(dest, wp);
        if (y === null) return { ok: false, message: `Something blocks the space above "${wp.name}".` };

        const origin = { x: player.location.x, y: player.location.y, z: player.location.z, dimension: player.dimension };
        try {
            player.teleport({ x: wp.x + 0.5, y, z: wp.z + 0.5 }, { dimension: dest });
        } catch (error) {
            Logger.warn(`Waypoint teleport failed: ${error}`);
            return { ok: false, message: "The teleport failed. Nothing was spent." };
        }
        if (!creative) CostManager.consume(player, WAYPOINT.COST_ITEM, cost);
        lastStoneTp.set(player.id, system.currentTick);
        try { player.playSound("mob.endermen.portal"); } catch (_) {}

        if (!verified) {
            system.runTimeout(() => {
                try {
                    const b = dest.getBlock({ x: wp.x, y: wp.y, z: wp.z });
                    if (b && b.typeId !== WAYPOINT.BLOCK_ID) {
                        wp.broken = true; persist(wp.id);
                        if (!player.isValid) return;
                        player.teleport({ x: origin.x, y: origin.y, z: origin.z }, { dimension: origin.dimension });
                        if (!creative) this.refund(player, cost);
                        lastStoneTp.delete(player.id);
                        player.sendMessage(`§e[Waypoint] "${wp.name}" was destroyed. You were sent back${creative ? "" : " and your pearls were returned"}.`);
                    }
                } catch (_) { /* still not ready: leave it */ }
            }, 20);
        }

        return { ok: true, message: `Arrived at "${wp.name}".${creative ? "" : ` (-${cost} ${WAYPOINT.COST_NAME}${cost === 1 ? "" : "s"})`}`, wp, cost };
    },

    // Orb special point: free, own cooldown, exact saved spot.
    travelToSpecial(player, index) {
        if (!this.isEnabled()) return { ok: false, message: "Waypoint travel is turned off." };
        const point = this.specials(player)[index];
        if (!point) return { ok: false, message: "That point no longer exists." };
        const wait = this.cooldownLeftSec(player, true);
        if (wait > 0) return { ok: false, message: `Special point cooldown: ${wait}s left.` };
        let dest;
        try { dest = world.getDimension(point.dim); }
        catch (_) { return { ok: false, message: "That dimension is not available." }; }
        try { player.teleport({ x: point.x, y: point.y, z: point.z }, { dimension: dest }); }
        catch (error) {
            Logger.warn(`Special point teleport failed: ${error}`);
            return { ok: false, message: "The teleport failed." };
        }
        lastSpecialTp.set(player.id, system.currentTick);
        try { player.playSound("mob.endermen.portal"); } catch (_) {}
        return { ok: true, message: `Arrived at "${point.name}".` };
    },

    // ---------- world events (called from event_router) ----------
    // Returns the new pending stone (the router then asks the placer for a name) or null.
    onPlace(event) {
        const { player, block } = event;
        if (!block || !player || block.typeId !== WAYPOINT.BLOCK_ID) return null;
        const loc = block.location, dimension = block.dimension;
        const problem = this.placementProblem(player, dimension, loc);
        if (problem) {
            try {
                block.setType("minecraft:air");
                if (player.getGameMode() !== GameMode.Creative) dimension.spawnItem(new ItemStack(WAYPOINT.BLOCK_ID, 1), { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 });
            } catch (_) {}
            player.sendMessage(`§c[Waypoint] ${problem}`);
            return null;
        }
        return this.register(dimension, loc, player);
    },

    // Stone: only the owner / an Admin may break it. Blank and unowned stones: anyone.
    canBreakBlock(player, block) {
        if (!block || block.typeId !== WAYPOINT.BLOCK_ID) return true;
        const wp = this.findAt(block.dimension, block.location);
        if (!wp || !wp.owner || wp.legacyUnnamed) return true;
        return this.canManage(player, wp);
    },

    // A stone block is gone (broken, picked up...): pending / old unnamed ones vanish, named ones stay in lists as "destroyed".
    markGone(dimension, loc, player = null) {
        const wp = this.findAt(dimension, loc);
        if (!wp) return;
        if (wp.pending || wp.legacyUnnamed) { this.unregister(wp.id); return; }
        wp.broken = true;      // entries stay in saved lists until their owners remove them
        persist(wp.id);
        try { player?.sendMessage(`§e[Waypoint] "${wp.name}" was destroyed. Players keep it in their list but cannot travel there.`); } catch (_) {}
    },

    onBreak(event) {
        if (event.brokenBlockPermutation?.type?.id !== WAYPOINT.BLOCK_ID) return;
        this.markGone(event.block.dimension, event.block.location, event.player);
    },

    // Old unnamed stones: destroy the block when its chunk is loaded, then forget it. Called on a slow timer.
    cleanupLegacy() {
        for (const wp of this.all()) {
            if (!wp.legacyUnnamed) continue;
            try {
                const block = world.getDimension(wp.dim).getBlock({ x: wp.x, y: wp.y, z: wp.z });
                if (!block) continue;
                if (block.typeId === WAYPOINT.BLOCK_ID) block.setType("minecraft:air");
                this.unregister(wp.id);
            } catch (_) { /* chunk not loaded yet: try again later */ }
        }
    },

    onPlayerLeave(playerId) { lastStoneTp.delete(playerId); lastSpecialTp.delete(playerId); },
};
