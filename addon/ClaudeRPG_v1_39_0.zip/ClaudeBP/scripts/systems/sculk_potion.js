// sculk_potion.js -- Sculk Potion: hit a monster while holding it to turn that monster into a Sculk Evolve.
// Works at any Ascension. Costs 1 potion per successful conversion (not in Creative). The converted mob drops no
// guaranteed Echo Shards (see EvolutionManager.onKill) so the potion cannot be farmed in a loop.

import { world, system } from "@minecraft/server";
import { EvolutionManager } from "../managers/evolution_manager.js";

export const SCULK_POTION_ID = "crpg:sculk_potion";

const REFUSALS = {
    ineligible: "\u00a7c[Sculk Potion] This creature cannot evolve \u00a78(bosses and some mobs are immune).",
    enchanted:  "\u00a7c[Sculk Potion] An Enchanted mob cannot be changed.",
    locked:     "\u00a7c[Sculk Potion] This mob's evolution cannot be changed.",
};
const MSG_COOLDOWN_MS = 1500;
const lastMsg = new Map();   // player id -> ms of the last refusal message

function consumeOne(player) {
    try {
        if (player.getGameMode?.() === "Creative") return;
        const inv = player.getComponent("inventory")?.container;
        const slot = player.selectedSlotIndex;
        const item = inv?.getItem(slot);
        if (!item || item.typeId !== SCULK_POTION_ID) return;
        if (item.amount > 1) { item.amount -= 1; inv.setItem(slot, item); }
        else inv.setItem(slot, undefined);
    } catch (_) {}
}

export const SculkPotion = {
    register() {
        world.afterEvents.entityHitEntity.subscribe((e) => {
            try {
                const player = e.damagingEntity;
                const target = e.hitEntity;
                if (player?.typeId !== "minecraft:player" || !target?.isValid) return;
                const held = player.getComponent("inventory")?.container?.getItem(player.selectedSlotIndex);
                if (held?.typeId !== SCULK_POTION_ID) return;
                const result = EvolutionManager.applySculkPotion(target);
                if (result === "ok") {
                    consumeOne(player);
                    try { target.dimension.spawnParticle("minecraft:soul_particle", { x: target.location.x, y: target.location.y + 1, z: target.location.z }); } catch (_) {}
                    return;
                }
                const msg = REFUSALS[result];
                if (!msg) return;
                const now = Date.now();
                if (now - (lastMsg.get(player.id) ?? 0) < MSG_COOLDOWN_MS) return;
                lastMsg.set(player.id, now);
                player.sendMessage(msg);
            } catch (_) {}
        });
        world.afterEvents.playerLeave.subscribe((e) => lastMsg.delete(e.playerId));
    },
};
