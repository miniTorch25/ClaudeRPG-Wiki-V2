// Salvage logic (no UI): computes and grants the rewards for breaking an item down.
// The UI lives in reforge.js (Salvage button); Vanilla-enchant essence values live in
// config/salvage_config.js so both systems share one table.

import { EntityComponentTypes, ItemStack } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { AugmentManager } from "./augment.js";
import { GemManager, SOCKET_COUNT, GEM_DUST_ID } from "./gem_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import {
    SALVAGE_MATERIALS, SALVAGE_MATERIAL_RATIO, SALVAGE_FULL_REFUND_CHANCE,
    SALVAGE_DUST_MIN, SALVAGE_DUST_MAX, MAX_AUGMENT_CRYSTALS, AUGMENT_CRYSTALS_PER_STAT,
    AUGMENT_CRYSTAL_ID, ENCHANT_ESSENCE_ID, essenceFromEnchant, normalizeEnchantId,
} from "../config/salvage_config.js";
import { AchievementManager } from "./achievement_manager.js";

export function prettyId(id) {
    return normalizeEnchantId(id).split("_").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}

// Roman numerals for enchant levels (I..X and beyond fall back to digits).
export function roman(n) {
    const t = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
    return t[n] ?? String(n);
}

export function isSalvageable(typeId) {
    return !!ITEM_REQUIREMENTS[typeId] && !!SALVAGE_MATERIALS[typeId];
}

// Preview of what salvaging `slot` would give. `materials` is the guaranteed half;
// `fullMaterials` is what a lucky roll returns instead.
export function previewSalvage(slot) {
    const item = slot.getItem();
    const req  = ITEM_REQUIREMENTS[item.typeId];
    const recipe = SALVAGE_MATERIALS[item.typeId] ?? [];

    const materials = [];
    const fullMaterials = [];
    for (const [id, count] of recipe) {
        fullMaterials.push({ id, count });
        materials.push({ id, count: Math.max(1, Math.floor(count * SALVAGE_MATERIAL_RATIO)) });
    }

    // Gems: one Gem Dust roll (1-10) per installed Gem
    let gemCount = 0;
    for (let i = 0; i < SOCKET_COUNT; i++) {
        const s = GemManager.getSlotState(slot, i);
        if (s !== "locked" && s !== "empty") gemCount++;
    }

    // Augment: 1 Crystal per rolled stat, 3 per maxed stat
    let crystals = 0;
    const defs   = AugmentManager.getDefsForType(req.type, item.typeId);
    const values = AugmentManager.getValues(slot, req.type);
    for (const [statName, def] of Object.entries(defs)) {
        const v = values[statName] ?? 0;
        if (v === 0) continue;
        crystals += v >= def.max ? MAX_AUGMENT_CRYSTALS : AUGMENT_CRYSTALS_PER_STAT;
    }

    // Enchants: rarity base + level each
    let essence = 0;
    const enchants = [];
    try {
        const list = item.getComponent("minecraft:enchantable")?.getEnchantments?.() ?? [];
        for (const e of list) {
            const gain = essenceFromEnchant(e.type.id, e.level);
            essence += gain;
            enchants.push({ id: e.type.id, level: e.level, gain });
        }
    } catch (_) { /* item has no enchantable component */ }

    return { materials, fullMaterials, gemCount, crystals, essence, enchants };
}

function giveItems(player, list) {
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    for (const { id, count } of list) {
        let left = count;
        while (left > 0) {
            const n = Math.min(64, left);
            left -= n;
            const stack = new ItemStack(id, n);
            const overflow = inv ? inv.addItem(stack) : stack;
            if (overflow) player.dimension.spawnItem(overflow, player.location);
        }
    }
}

// Removes the item and grants everything. Returns a summary for the chat message.
// perfect = true (paid with an Augment Core by the caller) always returns 100% of the materials.
export function performSalvage(player, slot, perfect = false) {
    const p = previewSalvage(slot);
    const full = perfect || Math.random() < SALVAGE_FULL_REFUND_CHANCE;

    const rewards = [...(full ? p.fullMaterials : p.materials)];
    let dust = 0;
    for (let i = 0; i < p.gemCount; i++) {
        dust += SALVAGE_DUST_MIN + Math.floor(Math.random() * (SALVAGE_DUST_MAX - SALVAGE_DUST_MIN + 1));
    }
    if (p.gemCount > 0) {
        MasteryManager.addXp(player, "gem", MASTERY.GEM_XP_SALVAGE_PER_GEM * p.gemCount);
    }
    if (dust > 0)       rewards.push({ id: GEM_DUST_ID,        count: dust });
    if (p.crystals > 0) rewards.push({ id: AUGMENT_CRYSTAL_ID, count: p.crystals });
    if (p.essence > 0)  rewards.push({ id: ENCHANT_ESSENCE_ID, count: p.essence });

    slot.setItem(undefined);
    giveItems(player, rewards);
    AchievementManager.event(player, "items_salvaged");
    if (p.gemCount > 0) AchievementManager.event(player, "gem_salvages");
    if (dust > 0) AchievementManager.add(player, "gem_dust_collected", dust);
    return { full, rewards };
}
