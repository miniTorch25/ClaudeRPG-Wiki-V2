// achievement_admin.js -- Admin tools for Achievements (Admin tag required by the callers).
// Commands:  status:admin ach info|grant <id|all>|revoke <id|all>|reset|set <counter> <value>|on|off [player]
import { AchievementManager } from "./achievement_manager.js";
import { AdminManager } from "../managers/admin_manager.js";
import { ACH_CATEGORIES } from "../config/achievement_data.js";

const fail = (text) => ({ ok: false, text: `§c${text}` });
function done(admin, target, what) {
    const who = target && target.id !== admin.id ? ` for ${target.name}` : "";
    AdminManager.log(admin.name, `Achievements: ${what}${who}`);
    return { ok: true, text: `§a${what}${who}.` };
}

export const AchievementAdmin = {
    info(target) {
        const lines = [`§6[Achievements] §f${target.name}: §a${AchievementManager.unlockedCount(target)}§f/${AchievementManager.engine.total} §8(system ${AchievementManager.isEnabled() ? "on" : "off"})`];
        for (const cat of ACH_CATEGORIES) lines.push(`${cat.color}${cat.name}§f: ${AchievementManager.unlockedCount(target, cat.id)}/${AchievementManager.defsOf(cat.id).length}`);
        return { ok: true, text: lines.join("\n") };
    },
    grant(admin, target, idOrAll) {
        const key = String(idOrAll ?? "").trim();
        if (key.toLowerCase() === "all") {
            let n = 0;
            for (const d of AchievementManager.engine.defs) if (!AchievementManager.isUnlocked(target, d.id)) { AchievementManager.adminGrant(target, d.id); n++; }
            return done(admin, target, `granted ${n} Achievement(s)`);
        }
        const def = AchievementManager.engine.byId.get(key.toUpperCase());
        if (!def) return fail(`Unknown Achievement id "${key}" (examples: CB01, MN05, MC12).`);
        if (AchievementManager.isUnlocked(target, def.id)) return fail(`${def.id} is already completed.`);
        AchievementManager.adminGrant(target, def.id);
        return done(admin, target, `granted ${def.id} ${def.name}`);
    },
    revoke(admin, target, idOrAll) {
        const key = String(idOrAll ?? "").trim();
        if (key.toLowerCase() === "all") {
            let n = 0;
            for (const d of AchievementManager.engine.defs) if (AchievementManager.adminRevoke(target, d.id)) n++;
            return done(admin, target, `revoked ${n} Achievement(s)`);
        }
        const def = AchievementManager.engine.byId.get(key.toUpperCase());
        if (!def) return fail(`Unknown Achievement id "${key}".`);
        if (!AchievementManager.adminRevoke(target, def.id)) return fail(`${def.id} is not completed.`);
        return done(admin, target, `revoked ${def.id} ${def.name}`);
    },
    reset(admin, target) {
        AchievementManager.adminReset(target);
        return done(admin, target, "reset all Achievement progress");
    },
    setCounter(admin, target, key, raw) {
        const k = String(key ?? "").trim();
        const v = Number(raw);
        if (!AchievementManager.engine.hasCounter(k)) return fail(`Unknown counter "${k}". Use the counter name of an Achievement, e.g. melee_hits.`);
        if (!Number.isFinite(v) || v < 0) return fail("The value must be a number, 0 or more.");
        AchievementManager.adminSetProgress(target, k, v);
        return done(admin, target, `set counter ${k} = ${v}`);
    },
    toggle(admin, on) {
        AdminManager.setValue("ach.enabled", on ? 1 : 0);
        return done(admin, null, `Achievement system turned ${on ? "on" : "off"}`);
    },
};
