// ascension_gui.js -- Ascension menu + confirm window (shows the impact before pressing).
// Back navigation uses callbacks so this file never imports the menus that open it.

import { ActionFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { AscensionManager } from "../managers/ascension_manager.js";
import { ASCENSION, ACTION_COSTS } from "../config/progression_config.js";
import { CostManager } from "../managers/cost_manager.js";
import { onMenuOpened } from "./achievement_hooks.js";

const SCREEN = "systems.ascension_gui.js";

const x = (n) => `×${Math.round(n * 100) / 100}`;

function impactLines(from, to) {
    const P = ProgressionManager;
    const lines = [
        `§7Mob HP: §f${x(P.getMobHpMult(from))} §8→ §c${x(P.getMobHpMult(to))}`,
        `§7Mob Damage: §f${x(P.getMobDamageMult(from))} §8→ §c${x(P.getMobDamageMult(to))}`,
        `§7Boss HP: §f${x(P.getBossHpMult(from))} §8→ §c${x(P.getBossHpMult(to))}`,
        `§7Boss Damage: §f${x(P.getBossDamageMult(from))} §8→ §c${x(P.getBossDamageMult(to))}`,
        `§7Your damage to mobs: §f${x(P.getPlayerDamageMult(from))} §8→ §a${x(P.getPlayerDamageMult(to))}`,
    ];
    const tier = ASCENSION.EVOLUTION_TIERS[to];
    if (tier) lines.push(`§7New mob Evolution: §d${tier}`);
    const note = ASCENSION.UNLOCK_NOTES[to];
    if (note) lines.push(`§7Opens: §a${note}`);
    return lines;
}

export const AscensionGui = {

    openMenu(player, onBack = null) {
        onMenuOpened(player, "ascension");
        const c = AscensionManager.check(player);
        const by = world.getDynamicProperty("prog_ascension_by");

        let status;
        if (c.reason === "max") status = "§8The world is at the highest Ascension.";
        else if (c.ok) status = `§aYou can raise the world to Ascension ${c.next}.`;
        else status = `§cNext Ascension needs Prestige ${c.requiredPrestige} §8(you: P${ProgressionManager.getPrestige(player)})`;

        const cost = CostManager.ascensionStatus(player, c.current);
        const costLine = c.reason === "max" ? "" : `§7Cost: ${cost.ok ? "§a" : "§c"}${cost.need} ${cost.name} §8(you have ${cost.have})\n\n`;

        const body =
            `§7World Ascension: §c${c.current}` + (by && c.current > 0 ? ` §8(last raised by ${by})` : "") + "\n" +
            "§8One player presses, everyone shoulders it. It can never go down.\n\n" +
            (c.reason === "max" ? "" : `§fIf raised to ${c.next}:\n${impactLines(c.current, c.next).join("\n")}\n\n`) +
            costLine +
            status;

        const form = new ActionFormData().title("§l§4ASCENSION").body(body);
        form.button(c.ok ? `§cRaise to Ascension ${c.next}\n§8[Affects the whole world]` : "§8Raise §c[Locked]", "textures/icons/ascension");
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            if (r.selection === 0) {
                if (!c.ok) {
                    player.sendMessage(c.reason === "max"
                        ? "§c[Ascension] Already at the highest Ascension."
                        : `§c[Ascension] You need Prestige ${c.requiredPrestige}.`);
                    return this.openMenu(player, onBack);
                }
                if (!cost.ok) {
                    player.sendMessage(`§c[Ascension] You need ${cost.need} ${cost.name} (you have ${cost.have}).`);
                    return this.openMenu(player, onBack);
                }
                return this.openConfirm(player, onBack);
            }
            if (onBack) onBack();
        }).catch((e) => console.warn(`[Ascension] Menu error: ${e}`));
    },

    openConfirm(player, onBack) {
        const c = AscensionManager.check(player);
        if (!c.ok) return this.openMenu(player, onBack);

        const others = world.getAllPlayers().length - 1;
        const form = new ActionFormData()
            .title("§l§4Confirm Ascension")
            .body(
                `§cThis raises the WHOLE WORLD to Ascension ${c.next}.\n` +
                `§7${others > 0 ? `${others} other player(s) online will be affected too. ` : ""}Everyone, including players who are offline, faces it.\n` +
                "§4It cannot be lowered.\n\n" +
                impactLines(c.current, c.next).join("\n") +
                `\n\n§eCost:§7 ${CostManager.ascensionCost(c.current)} ${ACTION_COSTS.ASCENSION.NAME} §8(consumed)` +
                "\n\n§8Everyone will be told that you did this."
            )
            .button("§4Raise the world", "textures/icons/ascension")
            .button("§8Cancel", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection === 1) return this.openMenu(player, onBack);
            const result = AscensionManager.perform(player);
            if (!result.success) {
                player.sendMessage(result.reason === "cost"
                    ? `§c[Ascension] You need ${result.need} ${result.name} (you have ${result.have}).`
                    : "§c[Ascension] It can no longer be raised.");
            }
            this.openMenu(player, onBack);
        }).catch((e) => console.warn(`[Ascension] Confirm error: ${e}`));
    },
};
