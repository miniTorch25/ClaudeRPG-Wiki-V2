// stellar_core.js -- Stellar Core: right-click a hostile mob to force-evolve it.
// Options depend on the world's Ascension (tiers unlocked so far) and never include Core.
// Bosses and mobs that cannot evolve are refused. Costs STELLAR_FORCE.COST Stellar Core(s).

import { system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { GemManager } from "./gem_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { STELLAR_FORCE } from "../config/evolution_config.js";
import { AchievementManager } from "./achievement_manager.js";

export const STELLAR_CORE_ID = "crpg:stellar_core";

const REFUSALS = {
    ineligible: "§c[Stellar Core] This creature cannot evolve §8(bosses and some mobs are immune).",
    core:       "§c[Stellar Core] A Core cannot be changed.",
    nothing:    "§c[Stellar Core] This mob has nothing left to gain.",
};

export const StellarCore = {

    // Called from the playerInteractWithEntity handler (already cancelled there).
    open(player, target) {
        system.run(() => {
            try {
                if (!player?.isValid || !target?.isValid) return;
                const { options, error } = EvolutionManager.forceOptions(target);
                if (error) { player.sendMessage(REFUSALS[error] ?? REFUSALS.ineligible); return; }

                const have = GemManager.countItem(player, STELLAR_CORE_ID);
                const form = new ActionFormData()
                    .title("§l§mStellar Core")
                    .body(
                        `§7Force this mob to evolve.\n` +
                        `§7Cost: §f${STELLAR_FORCE.COST}× Stellar Core §8(have: ${have})\n` +
                        `§8Choices follow the world's Ascension.`
                    );
                for (const o of options) form.button(`${o.color}${o.name}`, "textures/icons/mob_evolution");
                form.button("§8< Cancel", "textures/icons/back");

                GuiService.show(player, form, "systems.stellar_core.js").then((r) => {
                    if (r.canceled || r.selection === options.length) return;
                    const pick = options[r.selection];
                    if (!pick || !target.isValid) return;

                    if (GemManager.countItem(player, STELLAR_CORE_ID) < STELLAR_FORCE.COST) {
                        player.sendMessage(`§c[Stellar Core] You need §f${STELLAR_FORCE.COST}× Stellar Core§c.`);
                        return;
                    }
                    // Re-check: the mob may have changed while the form was open.
                    const again = EvolutionManager.forceOptions(target);
                    if (!again.options.some((o) => o.id === pick.id)) {
                        player.sendMessage("§c[Stellar Core] That option is no longer available.");
                        return;
                    }
                    if (!EvolutionManager.forceApply(target, pick.id)) {
                        player.sendMessage("§c[Stellar Core] The evolution failed. Nothing was spent.");
                        return;
                    }
                    for (let i = 0; i < STELLAR_FORCE.COST; i++) GemManager.consumeItem(player, STELLAR_CORE_ID);
                    AchievementManager.event(player, "stellar_upgrades");
                    try { player.playSound("random.levelup"); } catch (_) {}
                    player.sendMessage(`§m[Stellar Core] §fThe mob evolved: ${pick.color}${pick.name}§f!`);
                }).catch((e) => console.warn(`[StellarCore] form error: ${e}`));
            } catch (e) { console.warn(`[StellarCore] open error: ${e}`); }
        });
    },
};
