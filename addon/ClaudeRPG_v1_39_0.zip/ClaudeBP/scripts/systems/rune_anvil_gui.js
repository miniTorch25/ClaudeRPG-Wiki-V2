// rune_anvil_gui.js — Anvil > Rune page (replaces the old Rune Enchanting in the Ultimate Enchanter).
//
//   Recarved        re-roll the GRADE of a Rune item (Gamma - Omega) and the rune inside
//   Reroll          re-roll the rune inside (same grade)
//   Selective reroll  re-roll the rune inside, restricted to a chosen Type (same grade)
//   Insert          install a Rune item into the weapon/tool in your mainhand
//   Remove          take the rune out of your mainhand item and get it back as a Rune item
//
// Recarved / Reroll / Selective work on Rune ITEMS in your inventory. Costs: Resonant Ink.

import { ActionFormData } from "@minecraft/server-ui";
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { RUNE_REGISTRY, RUNE_PROP_KEY } from "../rune/rune_registry.js";
import { installRune, removeRune, isRuneCompatible } from "../rune/rune_manager.js";
import { formatRuneName } from "../rune/rune_lore.js";
import {
    isRuneItemId, getGradeOfTypeId, rollGrade, applyRuneToItem, createRuneItem, giveRuneItem,
    getRuneTypeLabel,
} from "../rune/rune_item.js";
import { RUNE_GRADES, RUNE_TYPE_LABELS, SELECTABLE_TYPES, RESONANT_INK_ID, RUNE_ANVIL_COSTS } from "../config/rune_item_config.js";
import { DISABLED_POOLS } from "../config/rune_catalog.js";
import { RUNE_LEVEL_PROP_KEY, DEFAULT_LEVEL, clampLevel, LEVEL_LABEL } from "../config/level_config.js";
import { canHoldRune, getCategoryLabel } from "../config/item_category_config.js";
import { GemManager } from "./gem_manager.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { onRuneEtched } from "./achievement_hooks.js";

const SRC = "systems.rune_anvil_gui.js";
const ERR = (e) => console.warn(`[Rune Anvil] ${e}`);

// ─── Helpers ─────────────────────────────────────────────────────────────────

const countInk   = (player) => GemManager.countItem(player, RESONANT_INK_ID);
function consumeInk(player, amount) {
    for (let i = 0; i < amount; i++) if (!GemManager.consumeItem(player, RESONANT_INK_ID)) return false;
    return true;
}
const getInv = (player) => player.getComponent(EntityComponentTypes.Inventory)?.container;
const getMainhandSlot = (player) =>
    player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);

// Rune items in the inventory that hold a valid rune: [{ index, item, runeId, level, grade }]
function listRuneItems(player) {
    const inv = getInv(player);
    const out = [];
    if (!inv) return out;
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (!it || !isRuneItemId(it.typeId)) continue;
        const runeId = it.getDynamicProperty(RUNE_PROP_KEY);
        if (typeof runeId !== "string" || !RUNE_REGISTRY[runeId]) continue;
        out.push({
            index: i, item: it, runeId,
            level: clampLevel(it.getDynamicProperty(RUNE_LEVEL_PROP_KEY) ?? DEFAULT_LEVEL),
            grade: getGradeOfTypeId(it.typeId),
        });
    }
    return out;
}

function runeButtonText(r) {
    return `${r.item.nameTag ?? r.grade.label + " Rune"}\n§8${formatRuneName(r.runeId)} · ${LEVEL_LABEL[r.level]}`;
}

// Re-reads slot `index` and makes sure it is still the same rune item (the player may have moved it).
function resolveRuneSlot(player, r) {
    const inv = getInv(player);
    const it = inv?.getItem(r.index);
    if (!it || it.typeId !== r.item.typeId || it.getDynamicProperty(RUNE_PROP_KEY) !== r.runeId) return null;
    return { inv, it };
}

function pickOther(ids, current) {
    const others = ids.filter((id) => id !== current);
    const pool = others.length ? others : ids;
    return pool[Math.floor(Math.random() * pool.length)];
}

const idsOfTier = (tier, category = null) =>
    Object.keys(RUNE_REGISTRY).filter((id) => RUNE_REGISTRY[id].tier === tier && !DISABLED_POOLS.includes(RUNE_REGISTRY[id].category) && (!category || RUNE_REGISTRY[id].category === category));

// ─── GUI ─────────────────────────────────────────────────────────────────────

export class RuneAnvilGui {

    static open(player, onBack = null) {
        if (!ProgressionManager.guard(player, "rune")) return;
        const form = new ActionFormData()
            .title("§l§bAnvil — Rune")
            .body(`§7Resonant Ink: §f${countInk(player)}\n§8Rune items are made by carving an Uncarved Rune with an Engraver.`)
            .button("§dRecarved\n§8[Re-roll the grade: Gamma - Omega]", "textures/icons/rune_enchant")
            .button("§bReroll\n§8[New effect, same grade]",            "textures/icons/rune_enchant")
            .button("§9Selective reroll\n§8[New effect of a chosen type]", "textures/icons/select_rune_enchant")
            .button("§aInsert\n§8[Install a Rune into your weapon/tool]", "textures/icons/rune")
            .button("§cRemove\n§8[Take the Rune out as an item]",       "textures/icons/trash_can")
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            switch (r.selection) {
                case 0: return this.openPick(player, "recarved", onBack);
                case 1: return this.openPick(player, "reroll", onBack);
                case 2: return this.openPick(player, "select", onBack);
                case 3: return this.openInsert(player, onBack);
                case 4: return this.openRemove(player, onBack);
                default: if (onBack) onBack();
            }
        }).catch(ERR);
    }

    // ── pick a Rune item for Recarved / Reroll / Selective ──
    static openPick(player, mode, onBack, note = null) {
        const runes = listRuneItems(player);
        const title = { recarved: "Recarved", reroll: "Reroll", select: "Selective reroll" }[mode];
        const form = new ActionFormData().title(`§l§b${title}`);
        let body = `§7Resonant Ink: §f${countInk(player)}`;
        if (note) body += `\n${note}`;
        form.body(runes.length ? body + "\n§7Pick a Rune item." : body + "\n§cNo Rune items in your inventory.");
        for (const r of runes) form.button(runeButtonText(r) + `\n§8Cost: ${this.cost(mode, r.grade.tier)} Ink`, getItemIconPath(r.item));
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((res) => {
            if (res.canceled) return;
            if (res.selection >= runes.length) return this.open(player, onBack);
            const r = runes[res.selection];
            if (mode === "select") return this.openTypePick(player, r, onBack);
            this.doReroll(player, mode, r, null, onBack);
        }).catch(ERR);
    }

    static cost(mode, tier) {
        if (mode === "recarved") return RUNE_ANVIL_COSTS.recarved;
        if (mode === "reroll")   return RUNE_ANVIL_COSTS.rerollPerTier * tier;
        return RUNE_ANVIL_COSTS.selectPerTier * tier;
    }

    // ── Selective reroll: choose the Type ──
    static openTypePick(player, r, onBack) {
        const types = SELECTABLE_TYPES.filter((k) => idsOfTier(r.grade.tier, k).length > 0);
        const form = new ActionFormData()
            .title("§l§9Selective reroll")
            .body(`§7${r.item.nameTag}\n§7Cost: §f${this.cost("select", r.grade.tier)} Ink\n§7Pick the Type of the new effect.`);
        for (const k of types) form.button(`§f${RUNE_TYPE_LABELS[k]}\n§8[${idsOfTier(r.grade.tier, k).length} effects at T${r.grade.tier}]`);
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((res) => {
            if (res.canceled) return;
            if (res.selection >= types.length) return this.openPick(player, "select", onBack);
            this.doReroll(player, "select", r, types[res.selection], onBack);
        }).catch(ERR);
    }

    // ── perform Recarved / Reroll / Selective ──
    static doReroll(player, mode, r, category, onBack) {
        const slot = resolveRuneSlot(player, r);
        if (!slot) return this.openPick(player, mode, onBack, "§cThat Rune item moved. Pick again.");
        const cost = this.cost(mode, r.grade.tier);
        if (countInk(player) < cost) {
            player.sendMessage(`§c[Rune] Not enough Resonant Ink! Need §f${cost}§c.`);
            return this.openPick(player, mode, onBack);
        }

        let grade = r.grade, runeId;
        if (mode === "recarved") {
            grade = rollGrade();
            runeId = pickOther(idsOfTier(grade.tier), grade.tier === r.grade.tier ? r.runeId : null);
        } else if (mode === "reroll") {
            runeId = pickOther(idsOfTier(grade.tier), r.runeId);
        } else {
            runeId = pickOther(idsOfTier(grade.tier, category), r.runeId);
        }
        if (!runeId) {
            player.sendMessage("§c[Rune] No Rune of that kind exists at this grade.");
            return this.openPick(player, mode, onBack);
        }

        if (!consumeInk(player, cost)) return this.openPick(player, mode, onBack);
        // Same grade -> keep the item and rewrite it; new grade -> a new item of that grade (same Lv).
        const fresh = createRuneItem(grade);
        applyRuneToItem(fresh, runeId, r.level);
        slot.inv.setItem(r.index, fresh);

        player.playSound("random.anvil_use");
        const word = mode === "recarved" ? (grade.id === r.grade.id ? "same grade" : `${r.grade.label} -> ${grade.color}${grade.label}`) : null;
        player.sendMessage(`§b[Rune] §f${fresh.nameTag}§b: §f${formatRuneName(runeId)}${word ? ` §8(${word}§8)` : ""}`);
        this.openPick(player, mode, onBack);
    }

    // ── Insert ──
    static openInsert(player, onBack, note = null) {
        const mh = getMainhandSlot(player);
        const target = mh?.hasItem() ? mh.getItem() : null;
        if (!target || !canHoldRune(target.typeId)) {
            player.sendMessage("§c[Rune] Hold a Weapon or Tool in your mainhand (Armor, Shears and Consumables can't hold Runes).");
            return this.open(player, onBack);
        }
        if (target.getDynamicProperty(RUNE_PROP_KEY)) {
            player.sendMessage("§c[Rune] This item already holds a Rune. Remove it first.");
            return this.open(player, onBack);
        }
        const runes = listRuneItems(player).filter((r) => isRuneCompatible(r.runeId, target.typeId));
        const form = new ActionFormData().title("§l§aInsert Rune");
        let body = `§7Item: §f${getCategoryLabel(target.typeId, "en", target)}`;
        if (note) body += `\n${note}`;
        form.body(runes.length ? body + "\n§7Pick a Rune item to install." : body + "\n§cNo compatible Rune items in your inventory.");
        for (const r of runes) form.button(runeButtonText(r), getItemIconPath(r.item));
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((res) => {
            if (res.canceled) return;
            if (res.selection >= runes.length) return this.open(player, onBack);
            const r = runes[res.selection];
            const tier = RUNE_REGISTRY[r.runeId].tier;
            if (!MasteryManager.isRuneTierOpen(player, tier)) {
                return this.openInsert(player, onBack, `§cRune Mastery has not unlocked T${tier} Runes yet.`);
            }
            const slot = resolveRuneSlot(player, r);
            if (!slot) return this.openInsert(player, onBack, "§cThat Rune item moved. Pick again.");
            const still = getMainhandSlot(player);
            if (!still?.hasItem() || still.typeId !== target.typeId) return this.open(player, onBack);

            const res2 = installRune(player, r.runeId, r.level);
            if (!res2.ok) {
                const msg = res2.reason.startsWith("exclusive:") ? "§cConflicts with a Rune on your other hand." : "§cThat Rune can't be installed here.";
                return this.openInsert(player, onBack, msg);
            }
            // consume the Rune item (one slot, one item)
            const it = slot.inv.getItem(r.index);
            if (it && it.amount > 1) { it.amount -= 1; slot.inv.setItem(r.index, it); } else slot.inv.setItem(r.index, undefined);

            player.playSound("random.anvil_use");
            player.sendMessage(`§a[Rune] Installed §f${formatRuneName(r.runeId)} §a${LEVEL_LABEL[r.level]}.`);
            try { onRuneEtched(player, r.runeId, 0); } catch (_) { /* achievement hook is optional */ }
            this.open(player, onBack);
        }).catch(ERR);
    }

    // ── Remove ──
    static openRemove(player, onBack) {
        const mh = getMainhandSlot(player);
        const item = mh?.hasItem() ? mh.getItem() : null;
        const runeId = item?.getDynamicProperty(RUNE_PROP_KEY);
        if (!item || typeof runeId !== "string" || !RUNE_REGISTRY[runeId]) {
            player.sendMessage("§c[Rune] Your mainhand item has no Rune.");
            return this.open(player, onBack);
        }
        const level = clampLevel(item.getDynamicProperty(RUNE_LEVEL_PROP_KEY) ?? DEFAULT_LEVEL);
        const grade = RUNE_GRADES.find((g) => g.tier === RUNE_REGISTRY[runeId].tier) ?? RUNE_GRADES[0];

        const form = new ActionFormData()
            .title("§l§cRemove Rune")
            .body(`§7${getCategoryLabel(item.typeId, "en", item)}\n§7Rune: §f${formatRuneName(runeId)} §7(${grade.color}${grade.label}§7, ${LEVEL_LABEL[level]})\n§7You get it back as a Rune item. Cost: §f${RUNE_ANVIL_COSTS.remove} Ink`)
            .button("§cRemove")
            .button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((res) => {
            if (res.canceled || res.selection !== 0) return this.open(player, onBack);
            if (countInk(player) < RUNE_ANVIL_COSTS.remove || !consumeInk(player, RUNE_ANVIL_COSTS.remove)) {
                player.sendMessage("§c[Rune] Not enough Resonant Ink.");
                return this.open(player, onBack);
            }
            const removed = removeRune(player);
            if (!removed) return this.open(player, onBack);
            const stack = createRuneItem(grade);
            applyRuneToItem(stack, removed, level);
            giveRuneItem(player, stack);
            player.playSound("random.anvil_use");
            player.sendMessage(`§c[Rune] Removed §f${formatRuneName(removed)} §c-> ${stack.nameTag}`);
            this.open(player, onBack);
        }).catch(ERR);
    }
}
