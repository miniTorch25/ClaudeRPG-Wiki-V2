// discovery_gui.js -- Discovery Log screens: overview -> checklist per section.
import { ActionFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { DISCOVERY } from "../config/exploration_config.js";
import { DiscoveryManager } from "./discovery_manager.js";

const SCREEN = "systems.discovery_gui.js";
const ICON = "textures/icons/discovery";

const SECTIONS = [
    { id: "overworld",  label: "Overworld Biomes", color: "§a" },
    { id: "nether",     label: "Nether Biomes",    color: "§c" },
    { id: "the_end",    label: "End Biomes",       color: "§d" },
    { id: "structures", label: "Structures",       color: "§6" },
    { id: "dimensions", label: "Dimensions",       color: "§b" },
];

function sectionCount(player, id) {
    const list = DiscoveryManager.checklist(player, id);
    return { found: list.filter((x) => x.found).length, total: list.length };
}

export const DiscoveryGui = {
    openMain(player) {
        const t = DiscoveryManager.totals(player);
        const other = DiscoveryManager.checklist(player, "other");
        const form = new ActionFormData().title("§l§bDISCOVERY LOG")
            .body(`§7Biomes: §f${t.biomeFound}/${t.biomeTotal}§7   Structures: §f${t.structureFound}/${t.structureTotal}§7   Dimensions: §f${t.dimFound}/${t.dimTotal}\n` +
                  `§8First finds give one-time Travel Mastery XP (Travel line must be unlocked).`);
        for (const s of SECTIONS) {
            const c = sectionCount(player, s.id);
            form.button(`${s.color}${s.label}\n§8${c.found}/${c.total}`, ICON);
        }
        if (other.length) form.button(`§7Other biomes\n§8${other.length} found`, ICON);
        form.button("§8Close");
        GuiService.show(player, form, SCREEN).then((res) => {
            if (res.canceled) return;
            if (res.selection < SECTIONS.length) return this.openSection(player, SECTIONS[res.selection].id);
            if (other.length && res.selection === SECTIONS.length) return this.openSection(player, "other");
        }).catch((e) => console.warn(`[Discovery] ${e}`));
    },

    openSection(player, sectionId) {
        const sec = SECTIONS.find((s) => s.id === sectionId) ?? { label: "Other biomes", color: "§7" };
        const list = DiscoveryManager.checklist(player, sectionId);
        const show = DISCOVERY.SHOW_UNDISCOVERED_NAMES >= 1;
        const lines = list.map((x) => x.found ? `§a[+] §f${x.name}` : `§8[ ] ${show ? x.name : "???"}`);
        const found = list.filter((x) => x.found).length;
        const form = new ActionFormData().title(`${sec.color}§l${sec.label}`)
            .body(`§7Found §f${found}/${list.length}\n\n${lines.join("\n") || "§8Nothing here yet."}`)
            .button("§8Back");
        GuiService.show(player, form, SCREEN).then((res) => {
            if (res.canceled) return;
            this.openMain(player);
        }).catch((e) => console.warn(`[Discovery] ${e}`));
    },
};
