// toast_composer_gui.js -- Script Tool > Toast Composer: build a custom toast and send it (or preview it on yourself).
// Sending to yourself is free; to another player it costs TOAST.SEND_COST Common Gems (see toast_send.js).
import { ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { TOAST, TOAST_COST_ITEM, TOAST_COST_NAME } from "../config/toast_config.js";
import { CostManager } from "../managers/cost_manager.js";
import { ToastSend, normalizeSpec, FRAME_NAMES } from "./toast_send.js";

const SCREEN = "systems.toast_composer_gui.js";

const FRAME_LABELS = [
    "\u00a77Java Grey", "\u00a79Java Blue", "\u00a7eJava Yellow", "\u00a76Bronze", "\u00a77Silver",
    "\u00a7eGold", "\u00a7bPlatinum", "\u00a7dMythic", "\u00a7cAscension (red)", "\u00a7aDiscovery (green)",
];
const ICONS = [
    { label: "None", key: "-" }, { label: "Discovery", key: "TDSC" }, { label: "Biome", key: "TBIO" },
    { label: "Structure", key: "TSTR" }, { label: "Dimension", key: "TDIM" }, { label: "Ascension", key: "TASC" },
];
const SOUND_KEYS = ["default", "none", "levelup", "orb"];
const SOUND_LABELS = ["Default (toast)", "None", "Level up", "Orb"];

export const ToastComposerGui = {
    /** state = previous answers, so a rejected form re-opens with the player's text kept. */
    open(player, state = {}) {
        const admin = ToastSend.isPrivileged(player);
        if (!admin && TOAST.SEND_ENABLED < 1) { player.sendMessage("\u00a7c[Toast] Custom toasts are turned off on this server."); return; }

        const others = world.getAllPlayers().filter((p) => p.id !== player.id).sort((a, b) => a.name.localeCompare(b.name));
        const targets = [{ label: "Myself (free)", ids: [player.id] }];
        for (const p of others) targets.push({ label: `${p.name}${admin ? "" : ` (${TOAST.SEND_COST} ${TOAST_COST_NAME}s)`}`, ids: [p.id] });
        if (admin && others.length) targets.push({ label: "\u00a7cEveryone (Admin)", ids: world.getAllPlayers().map((p) => p.id) });

        const have = admin ? 0 : CostManager.count(player, TOAST_COST_ITEM);
        const form = new ModalFormData().title("\u00a7l\u00a7dTOAST COMPOSER")
            .dropdown(admin ? "Send to" : `Send to  \u00a78(others cost ${TOAST.SEND_COST} ${TOAST_COST_NAME}s, you have ${have})`, targets.map((t) => t.label), { defaultValueIndex: Math.min(state.target ?? 0, targets.length - 1) })
            .dropdown("Frame", FRAME_LABELS, { defaultValueIndex: state.frame ?? 5 })
            .dropdown("Icon", ICONS.map((i) => i.label), { defaultValueIndex: state.icon ?? 1 })
            .textField("Custom icon key \u00a78(optional, 4 characters, e.g. CB01 - overrides Icon)", "leave empty to use Icon", { defaultValue: state.custom ?? "" })
            .textField(`Header \u00a78(English only, max 28)`, "e.g. Hello", { defaultValue: state.header ?? "" })
            .textField("Body \u00a78(any language, ~22 characters fit. Colours: &a &b &c &d &e &f, &l bold)", "e.g. &eWelcome back!", { defaultValue: state.body ?? "" })
            .dropdown("Sound", SOUND_LABELS, { defaultValueIndex: state.sound ?? 0 })
            .toggle("Preview only (shows on you, free, nothing is sent)", { defaultValue: state.preview ?? false });

        GuiService.show(player, form, SCREEN).then((res) => {
            if (res.canceled || !res.formValues) return;
            const [ti, fi, ii, custom, header, body, si, preview] = res.formValues;
            const keep = { target: ti, frame: fi, icon: ii, custom: custom ?? "", header: header ?? "", body: body ?? "", sound: si, preview: !!preview };
            const fail = (msg) => { player.sendMessage(`\u00a7c[Toast] ${msg}`); this.open(player, keep); };

            const norm = normalizeSpec({
                frame: FRAME_NAMES[fi], icon: String(custom ?? "").trim() || ICONS[ii].key,
                header, body, sound: SOUND_KEYS[si],
            });
            if (!norm.ok) { fail(norm.error); return; }

            const recipients = (preview ? [player.id] : targets[ti]?.ids ?? [])
                .map((id) => world.getAllPlayers().find((p) => p.id === id)).filter(Boolean);
            if (!recipients.length) { fail("That player is no longer online."); return; }

            const r = ToastSend.send(player, recipients, norm.spec);
            if (!r.ok) { fail(r.message); return; }
            if (preview) player.sendMessage("\u00a7d[Toast] \u00a77Preview shown. Nothing was sent.");
            else if (r.cost > 0 || recipients.length > 1 || recipients[0].id !== player.id) player.sendMessage(`\u00a7a[Toast] ${r.message}`);
        }).catch((e) => console.warn(`[ToastComposer] ${e}`));
    },
};
