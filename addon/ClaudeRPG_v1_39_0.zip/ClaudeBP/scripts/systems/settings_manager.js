// settings_manager.js -- personal on/off switches (Script Tool > Settings).
// Storage: player dynamic property "crpg:settings" = { id: 0|1 } (only values that differ from the default are kept).
// Never reset by Prestige / Reset All / Delete All. Other systems call SettingsManager.get(player, "id").
// Server-wide master switches (Admin Config Editor) still win: a personal "on" never overrides a global "off".

const KEY = "crpg:settings";

// order = order shown in the panel
export const SETTING_DEFS = [
    { id: "toast_ui",       label: "Toast pop-ups",               desc: "Pop-up cards for Achievement, Discovery, Ascension. Off = classic chat / action bar.", def: 1 },
    { id: "ach_chat",       label: "Achievement chat messages",   desc: "Chat line when you unlock an achievement (quip stays in chat with Toast on).", def: 1 },
    { id: "ach_actionbar",  label: "Achievement action bar",      desc: "Action bar text for achievements (Toast off only).", def: 1 },
    { id: "disc_chat",      label: "Discovery chat messages",     desc: "Chat line for new biomes / structures (Toast off only).", def: 1 },
    { id: "disc_actionbar", label: "Discovery action bar",        desc: "Action bar text for discoveries (Toast off only).", def: 1 },
    { id: "stash_hotbar",   label: "Quick Stash includes hotbar", desc: "Also move hotbar items (the held item stays).",    def: 0 },
    { id: "chorus_aura",    label: "Chorus Aura",                 desc: "Particles around you from your Chorus armor.",     def: 1 },
    { id: "gq_notify",      label: "Guide Quest notifications",   desc: "Pop-up / chat line when you finish a Guide Quest step and when the next one starts.", def: 1 },
    { id: "gq_thai",        label: "Guide Quest in Thai",         desc: "On = Thai text in the Guide Quest menu and pop-ups. Off = English.",                   def: 0 },
];

const cache = new Map();   // playerId -> overrides object

function overrides(player) {
    let o = cache.get(player.id);
    if (o) return o;
    o = {};
    try {
        const raw = player.getDynamicProperty(KEY);
        if (typeof raw === "string" && raw) {
            const p = JSON.parse(raw);
            if (p && typeof p === "object") for (const [k, v] of Object.entries(p)) o[k] = v ? 1 : 0;
        }
    } catch (_) { /* defaults */ }
    cache.set(player.id, o);
    return o;
}

export const SettingsManager = {
    defs: SETTING_DEFS,

    define(def) {                                    // lets later systems add a switch
        if (!SETTING_DEFS.some((d) => d.id === def.id)) SETTING_DEFS.push(def);
    },

    get(player, id) {
        const def = SETTING_DEFS.find((d) => d.id === id);
        if (!def) return true;
        const o = overrides(player);
        return (id in o ? o[id] : def.def) >= 1;
    },

    set(player, id, value) {
        const def = SETTING_DEFS.find((d) => d.id === id);
        if (!def) return;
        const o = overrides(player);
        const v = value ? 1 : 0;
        if (v === def.def) delete o[id]; else o[id] = v;
        try { player.setDynamicProperty(KEY, JSON.stringify(o)); } catch (_) {}
    },

    onPlayerLeave(playerId) { cache.delete(playerId); },
};
