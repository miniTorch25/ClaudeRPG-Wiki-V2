// toast_command.js -- /scriptevent toast:send <target> | <frame> | <icon> | <header> | <body> [| <sound>]
//                     /scriptevent toast:help
// Works from chat, command blocks (use @a / @p / @r / a name) and the console. See the manual (TOAST_MANUAL_TH.md).
import { world, system } from "@minecraft/server";
import { ToastSend, normalizeSpec, FRAME_NAMES, SOUNDS } from "./toast_send.js";
import { TOAST, TOAST_COST_NAME } from "../config/toast_config.js";

export const usage = () => [
    "\u00a76[Toast] \u00a7f/scriptevent toast:send <target> | <frame> | <icon> | <header> | <body> [| <sound>]",
    "\u00a77target: @s (you, free) or a player name" + ` (to someone else: ${TOAST.SEND_COST} ${TOAST_COST_NAME}s). Admin / command block: also @a @p @r`,
    `\u00a77frame: ${FRAME_NAMES.join(", ")} (or 0-9)   icon: 4-char key (CB01, TDSC...) or -`,
    "\u00a77header: English letters/numbers, max 28   body: any text, &c colour codes   sound: " + Object.keys(SOUNDS).join(", "),
    "\u00a77example: /scriptevent toast:send @s | gold | CB01 | Hello | &eWelcome back!",
].join("\n");

/** Split the message on "|" (trimmed). Pure; used by tests. */
export function parseMessage(message) {
    const parts = String(message ?? "").split("|").map((s) => s.trim());
    if (parts.length < 4) return { ok: false, error: "Need at least: target | frame | icon | header" };
    const [target, frame, icon, header, body = "", sound = "default"] = parts;
    return { ok: true, target, raw: { frame, icon, header, body, sound } };
}

function resolveTargets(event, sender, privileged, target) {
    const t = target.replace(/^"(.*)"$/, "$1").trim();
    const all = world.getAllPlayers();
    const low = t.toLowerCase();
    if (low === "@s") return sender ? { players: [sender] } : { error: "@s needs a player source. Use @a, @p, @r or a name here." };
    if (low === "@a" || low === "@p" || low === "@r") {
        if (!privileged) return { error: "Only Admin / command blocks can use @a, @p, @r. Use a player name." };
        if (low === "@a") return { players: all };
        if (low === "@r") return { players: all.length ? [all[Math.floor(Math.random() * all.length)]] : [] };
        const block = event.sourceBlock, origin = block ?? sender;
        if (!origin) return { players: [] };
        const near = origin.dimension.getPlayers({ location: origin.location, closest: 1 });
        return { players: near };
    }
    const p = all.find((x) => x.name.toLowerCase() === low);
    return p ? { players: [p] } : { error: `Player "${t}" is not online.` };
}

function handle(event) {
    const sender = event.sourceEntity?.typeId === "minecraft:player" ? event.sourceEntity : null;
    const reply = (m) => { if (sender) sender.sendMessage(m); else console.warn("[Toast] " + String(m).replace(/\u00a7./g, "")); };
    if (event.id === "toast:help") { reply(usage()); return; }

    const parsed = parseMessage(event.message);
    if (!parsed.ok) { reply(`\u00a7c[Toast] ${parsed.error}\n` + usage()); return; }
    const norm = normalizeSpec(parsed.raw);
    if (!norm.ok) { reply(`\u00a7c[Toast] ${norm.error}`); return; }
    const t = resolveTargets(event, sender, ToastSend.isPrivileged(sender), parsed.target);
    if (t.error) { reply(`\u00a7c[Toast] ${t.error}`); return; }
    const r = ToastSend.send(sender, t.players, norm.spec);
    // players get feedback only when something worth saying happened (errors, or a paid send); free self-sends stay quiet
    if (!r.ok) reply(`\u00a7c[Toast] ${r.message}`);
    else if (r.cost > 0 || t.players.length > 1 || (sender && t.players[0].id !== sender.id)) reply(`\u00a7a[Toast] ${r.message}`);
}

export const ToastCommand = {
    register() {
        system.afterEvents.scriptEventReceive.subscribe((e) => {
            if (e.id !== "toast:send" && e.id !== "toast:help") return;
            try { handle(e); } catch (err) { console.warn(`[Toast] command error: ${err}`); }
        });
    },
};
