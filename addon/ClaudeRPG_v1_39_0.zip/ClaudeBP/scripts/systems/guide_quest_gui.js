// guide_quest_gui.js -- Guide Quest menu: overview + current step, chapter list, chapter detail. No rewards.
import { ActionFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { GuideQuest } from "./guide_quest.js";
import { SettingsManager } from "./settings_manager.js";
import { GUIDE } from "../config/guide_quest_config.js";

const SCREEN = "systems.guide_quest_gui.js";
const ICON = "textures/icons/ach/";
const BACK_ICON = "textures/icons/back";

const bar = (value, total, width = 20) => {
    const filled = total > 0 ? Math.max(0, Math.min(width, Math.floor((value / total) * width))) : 0;
    return `§a${"|".repeat(filled)}§8${"|".repeat(width - filled)}`;
};

function show(player, form, onResult) {
    GuiService.show(player, form, SCREEN).then((r) => { if (!r.canceled) onResult(r); })
        .catch((error) => console.warn(`[Guide Quest] ${error}`));
}

const tx = (lang, o) => o[lang] ?? o.en;
const word = (lang, en, th) => (lang === "th" ? th : en);

export const GuideQuestGui = {
    // onBack: optional () => void, called by the first screen's Back button.
    openMain(player, onBack = null) {
        const lang = GuideQuest.lang(player);
        const W = (en, th) => word(lang, en, th);
        const form = new ActionFormData().title(`§l§aGUIDE QUEST`);
        if (GUIDE.ENABLED < 1) {
            form.body(W("§cThe Guide Quest is switched off on this world.", "§cGuide Quest ถูกปิดในโลกนี้"));
            form.button("§8< Back", BACK_ICON);
            return show(player, form, () => { if (onBack) onBack(); });
        }
        GuideQuest.check(player);   // refresh right now so the menu is never behind
        const total = GuideQuest.requiredCount;
        const done = GuideQuest.doneCount(player);
        const cur = GuideQuest.current(player);
        let body = `${W("§7Progress", "§7ความคืบหน้า")}: §f${done}§8/${total}  ${bar(done, total)}\n`;
        if (cur) {
            const ch = GuideQuest.chapters.find((c) => c.id === cur.ch);
            body += `\n§6${W("Chapter", "บท")} ${ch.id}: ${tx(lang, ch.name)}\n§l§f${cur.id}  ${tx(lang, cur.title)}§r\n§7${tx(lang, cur.how)}\n`;
            const side = GuideQuest.chapterSteps(cur.ch).filter((s) => s.optional && !GuideQuest.isDone(player, s.id));
            if (side.length) body += `\n§8${W("Side tasks", "เควสเสริม")}: §7${side.map((s) => `${s.id} ${tx(lang, s.title)}`).join(" · ")}`;
            body += `\n\n§8${W("It checks itself: just play. No rewards.", "ตรวจเองอัตโนมัติ เล่นตามปกติได้เลย ไม่มีรางวัล")}`;
        } else {
            body += `\n§d§l${W("Guide Quest complete!", "จบ Guide Quest แล้ว!")}§r\n§7${W("You have unlocked and used every system the guide covers. Enjoy!", "คุณปลดล็อกและลองใช้ทุกระบบที่ไกด์สอนครบแล้ว ขอให้สนุก!")}`;
        }
        form.body(body)
            .button(`§b${W("Chapters", "รายการบท")}\n§8${W("All steps and what comes next", "ทุกขั้นและสิ่งที่จะตามมา")}`, "textures/icons/progression")
            .button(`§e${W("Language: English", "ภาษา: ไทย")}\n§8${W("Tap to switch / กดเพื่อสลับภาษา", "กดเพื่อสลับ / Tap to switch")}`, "textures/icons/gear")
            .button("§8< Back", BACK_ICON);
        show(player, form, (r) => {
            if (r.selection === 0) return this.openChapters(player, onBack);
            if (r.selection === 1) { SettingsManager.set(player, "gq_thai", !SettingsManager.get(player, "gq_thai")); return this.openMain(player, onBack); }
            if (onBack) onBack();
        });
    },

    openChapters(player, onBack = null) {
        const lang = GuideQuest.lang(player);
        const W = (en, th) => word(lang, en, th);
        const cur = GuideQuest.current(player);
        const form = new ActionFormData().title(`§l§a${W("CHAPTERS", "รายการบท")}`)
            .body(`§7${W("Pick a chapter to see its steps.", "เลือกบทเพื่อดูรายการขั้น")}`);
        for (const ch of GuideQuest.chapters) {
            const p = GuideQuest.chapterProgress(player, ch.id);
            const mark = p.done >= p.total ? "§a✔ " : (cur && cur.ch === ch.id ? "§e► " : "§7");
            form.button(`${mark}${W("Chapter", "บท")} ${ch.id}: ${tx(lang, ch.name)}\n§8${p.done}/${p.total}`, `${ICON}${ch.icon}`);
        }
        form.button("§8< Back", BACK_ICON);
        show(player, form, (r) => {
            if (r.selection < GuideQuest.chapters.length) return this.openChapter(player, GuideQuest.chapters[r.selection].id, onBack);
            this.openMain(player, onBack);
        });
    },

    openChapter(player, chId, onBack = null) {
        const lang = GuideQuest.lang(player);
        const W = (en, th) => word(lang, en, th);
        const ch = GuideQuest.chapters.find((c) => c.id === chId);
        if (!ch) return this.openChapters(player, onBack);
        const cur = GuideQuest.current(player);
        const p = GuideQuest.chapterProgress(player, chId);
        let body = `§7${W("Done", "เสร็จแล้ว")}: §f${p.done}§8/${p.total}  ${bar(p.done, p.total)}\n`;
        for (const s of GuideQuest.chapterSteps(chId)) {
            const done = GuideQuest.isDone(player, s.id);
            const isCur = cur && cur.id === s.id;
            const mark = done ? "§a✔" : (isCur ? "§e►" : (s.optional ? "§b◇" : "§8○"));
            const side = s.optional ? ` §8(${W("side task", "เควสเสริม")})` : "";
            body += `\n${mark} §f${s.id} ${tx(lang, s.title)}${side}`;
            // How-to only for the current step and the side tasks of a reached chapter; the rest stays a roadmap
            const reached = !cur || cur.ch >= chId;
            if (isCur || (s.optional && !done && reached)) body += `\n   §7${tx(lang, s.how)}`;
        }
        const form = new ActionFormData().title(`§l§a${W("Chapter", "บท")} ${ch.id}`).body(body)
            .button("§8< Back", BACK_ICON);
        show(player, form, () => this.openChapters(player, onBack));
    },
};
