// toast_send.js -- custom toasts: validation, price and delivery. Used by the toast:send command and the Toast Composer.
//
// Rules
//   * Admin (tag) and non-player sources (command blocks, console) send free, to anyone.
//   * A normal player may send to ONE player. Sending to yourself is free; sending to someone else costs
//     TOAST.SEND_COST Common Gems (all-or-nothing: not enough gems = nothing is sent), with a short cooldown.
//   * Recipients with Toast switched off get the same text as a chat line.
import { system } from "@minecraft/server";
import { TOAST, TOAST_COST_ITEM, TOAST_COST_NAME } from "../config/toast_config.js";
import { ToastManager, frameChar, stripCodes } from "./toast_manager.js";
import { CostManager } from "../managers/cost_manager.js";
import { AdminManager } from "../managers/admin_manager.js";

export const FRAME_NAMES = ["grey", "blue", "yellow", "bronze", "silver", "gold", "platinum", "mythic", "ascension", "discovery"];
export const SOUNDS = { default: undefined, none: null, toast: "random.toast", levelup: "random.levelup", orb: "random.orb" };

const lastPaid = new Map();   // playerId -> tick

/** "&a" -> "§a" (format codes only), control characters removed. */
export function colorize(s) { return String(s ?? "").replace(/&([0-9a-fk-orA-FK-OR])/g, "\u00a7$1").replace(/[\u0000-\u001f\u007f]/g, " "); }

/** Parse a frame given as name / digit. Returns the name, or null. */
export function parseFrame(v) {
    const t = String(v ?? "").trim().toLowerCase();
    if (FRAME_NAMES.includes(t)) return t;
    if (/^[0-9]$/.test(t)) return FRAME_NAMES[+t];
    return null;
}

/** Validate user input -> { ok, spec } | { ok:false, error }. */
export function normalizeSpec(raw) {
    const frame = parseFrame(raw.frame);
    if (!frame) return { ok: false, error: `Unknown frame "${raw.frame}". Use: ${FRAME_NAMES.join(", ")} (or 0-9).` };
    let icon = String(raw.icon ?? "").trim();
    if (!icon || icon === "-" || icon.toLowerCase() === "none") icon = "----";
    if (!/^[A-Za-z0-9-]{4}$/.test(icon)) return { ok: false, error: `Icon must be a 4-character key (e.g. CB01, TDSC) or "-" for none.` };
    const header = colorize(raw.header).trim();
    if (!header) return { ok: false, error: "Header cannot be empty." };
    if (/[^\x20-\x7e\u00a7]/.test(header)) return { ok: false, error: "Header: English letters / numbers only (Thai and other languages go in the body)." };
    const soundKey = String(raw.sound ?? "default").trim().toLowerCase() || "default";
    if (!(soundKey in SOUNDS)) return { ok: false, error: `Sound must be one of: ${Object.keys(SOUNDS).join(", ")}.` };
    return { ok: true, spec: { frame, icon, header, body: colorize(raw.body).trim(), sound: SOUNDS[soundKey] } };
}

function deliver(recipient, spec, fromName) {
    if (ToastManager.isActive(recipient)) {
        ToastManager.show(recipient, spec);
    } else {   // Toast off: same content as chat
        recipient.sendMessage(`\u00a76[Toast] \u00a7e${stripCodes(spec.header)}${spec.body ? `\u00a77 - \u00a7f${spec.body}` : ""}`);
    }
    if (fromName) recipient.sendMessage(`\u00a78[Toast from ${fromName}]`);
}

export const ToastSend = {
    isPrivileged(sender) { return !sender || AdminManager.isAdmin(sender); },

    /**
     * sender    : Player, or null for command blocks / console
     * recipients: Player[]
     * spec      : result of normalizeSpec().spec
     * returns { ok, message, cost }
     */
    send(sender, recipients, spec) {
        recipients = (recipients ?? []).filter((p) => p?.isValid);
        if (!recipients.length) return { ok: false, message: "No matching player is online." };
        const privileged = this.isPrivileged(sender);

        if (!privileged) {
            if (TOAST.SEND_ENABLED < 1) return { ok: false, message: "Custom toasts are turned off on this server." };
            if (recipients.length !== 1) return { ok: false, message: "You can send a toast to one player at a time." };
        }
        const target = recipients[0];
        const toSelf = !!sender && recipients.length === 1 && target.id === sender.id;
        const paid = !privileged && !toSelf && TOAST.SEND_COST > 0;

        if (!privileged && !toSelf) {   // checks that must pass BEFORE anything is charged
            const wait = (lastPaid.get(sender.id) ?? -1e9) + TOAST.SEND_COOLDOWN_SEC * 20 - system.currentTick;
            if (wait > 0) return { ok: false, message: `Wait ${Math.ceil(wait / 20)}s before sending another toast.` };
            if (!ToastManager.canAccept(target)) return { ok: false, message: `${target.name} has too many toasts waiting. Try again soon.` };
        }
        if (paid) {
            const have = CostManager.count(sender, TOAST_COST_ITEM);
            if (have < TOAST.SEND_COST) return { ok: false, message: `Not enough ${TOAST_COST_NAME}s: need ${TOAST.SEND_COST}, you have ${have}. Cancelled.` };
            if (!CostManager.consume(sender, TOAST_COST_ITEM, TOAST.SEND_COST)) return { ok: false, message: "Payment failed. Cancelled." };
        }
        if (!privileged && !toSelf) lastPaid.set(sender.id, system.currentTick);

        const fromName = sender && !toSelf && !privileged ? sender.name : null;
        for (const r of recipients) deliver(r, spec, fromName);
        const who = recipients.length === 1 ? recipients[0].name : `${recipients.length} players`;
        return { ok: true, cost: paid ? TOAST.SEND_COST : 0, message: `Toast sent to ${who}${paid ? ` (-${TOAST.SEND_COST} ${TOAST_COST_NAME}s)` : ""}.` };
    },

    onPlayerLeave(id) { lastPaid.delete(id); },
};
