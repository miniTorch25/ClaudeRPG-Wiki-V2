// rarity_name.js — Rarity-colored item names.
//
// Items that carry a Rune (weapons/tools) or an installed Gem (armor) get a
// name prefix "§r§l§r§<tier color>" so the Item Rarity UI can tint the
// tooltip/slot. The prefix is added, replaced, or removed automatically.
//
// A player-chosen (anvil) name is kept; if no custom name exists the item's
// default name is used and the name is reset again when the Rune/Gem leaves.
import { RUNE_PROP_KEY, RUNE_REGISTRY } from "../rune/rune_registry.js";
import { GemManager, GEM_TIERS, SOCKET_COUNT } from "./gem_manager.js";

// Color codes already include "§" (e.g. "§4"), so the prefix stops before it.
export const RARITY_PREFIX = "§r§l§r";
const PREFIX_RE = /^§r§l§r§./;
// v28 bug: prefix was written as "§r§l§r§§4" and the stray "4" stacked up.
// Names in that damaged form are repaired here.
const LEGACY_RE = /^§r§l§r§§(.)\1*/;
const AUTO_PROP = "crpg_auto_name";

// Rune tier (T1-T7) -> color code. Same scale as Gem rarity.
const TIER_COLOR = { 1: "§f", 2: "§e", 3: "§a", 4: "§3", 5: "§9", 6: "§u", 7: "§4" };

export function stripRarityPrefix(name) {
    if (typeof name !== "string") return name;
    return name.replace(LEGACY_RE, "").replace(PREFIX_RE, "");
}

// "minecraft:diamond_sword" -> "Diamond Sword"
export function prettyItemName(typeId) {
    return typeId.replace(/^[^:]*:/, "").split("_")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}

// Name for menus/messages: custom name without the rarity prefix, else default name.
export function displayName(item) {
    const tag = stripRarityPrefix(item.nameTag);
    return tag ? tag : prettyItemName(item.typeId);
}

// Color code for the item's Rune or highest installed Gem; null if it has neither.
function getRarityColor(slot) {
    const runeId = slot.getDynamicProperty(RUNE_PROP_KEY);
    if (runeId) {
        const tier = RUNE_REGISTRY[runeId]?.tier;
        if (TIER_COLOR[tier]) return TIER_COLOR[tier];
    }
    let best = -1;
    for (let i = 0; i < SOCKET_COUNT; i++) {
        const idx = GEM_TIERS.findIndex((t) => t.id === GemManager.getSlotState(slot, i));
        if (idx > best) best = idx;
    }
    return best >= 0 ? GEM_TIERS[best].color : null;
}

// Applies/updates/removes the rarity prefix on the item in `slot`.
export function syncRarityName(slot) {
    try {
        if (!slot?.hasItem()) return;
        const color = getRarityColor(slot);
        const cur = slot.nameTag;
        const stripped = cur ? stripRarityPrefix(cur) : undefined;
        const pretty = prettyItemName(slot.typeId);
        const wasAuto = slot.getDynamicProperty(AUTO_PROP) === true;
        const isDefault = !stripped || stripped === pretty;

        if (color) {
            const want = RARITY_PREFIX + color + (stripped || pretty);
            if (cur !== want) slot.nameTag = want;
            const auto = isDefault && (!cur || wasAuto);
            if (auto !== wasAuto) slot.setDynamicProperty(AUTO_PROP, auto ? true : undefined);
        } else if (cur && cur !== stripped) {
            slot.nameTag = wasAuto && isDefault ? undefined : stripped;
            if (wasAuto) slot.setDynamicProperty(AUTO_PROP, undefined);
        }
    } catch { /* slot changed mid-tick; retry next pass */ }
}
