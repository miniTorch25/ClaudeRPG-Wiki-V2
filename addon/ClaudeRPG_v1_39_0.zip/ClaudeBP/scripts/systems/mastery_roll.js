// mastery_roll.js -- deterministic per-level random rolls for Mastery effects.
// A player has one stored seed per line. The seed + effect key + level always give the same
// result, so rolls never change, need no storage of tables, and always add up to exactly `max`
// at the line's max level. Pure functions (no game API) so they are easy to test.

import { MASTERY } from "../config/mastery_config.js";

function hashString(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
}

function mulberry32(a) {
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

const cache = new Map();   // "seed|key|maxLevel|variance" -> Float64Array of cumulative weight fractions

// cum[L] = fraction (0..1) of the effect's max reached at level L (cum[0]=0, cum[maxLevel]=1)
function cumulative(seed, key, maxLevel) {
    const variance = Math.max(0, Math.min(0.95, MASTERY.RANDOM?.VARIANCE ?? 0.6));
    const ck = `${seed}|${key}|${maxLevel}|${variance}`;
    let cum = cache.get(ck);
    if (cum) return cum;
    const rnd = mulberry32((hashString(key) ^ (seed >>> 0)) >>> 0);
    const w = [];
    let total = 0;
    for (let i = 0; i < maxLevel; i++) { const x = 1 + variance * (rnd() * 2 - 1); w.push(x); total += x; }
    cum = new Float64Array(maxLevel + 1);
    let run = 0;
    for (let i = 0; i < maxLevel; i++) { run += w[i]; cum[i + 1] = run / total; }
    cum[maxLevel] = 1;
    if (cache.size > 2000) cache.clear();
    cache.set(ck, cum);
    return cum;
}

export function newSeed() { return Math.floor(Math.random() * 2147483647) + 1; }

// Value of one effect at a given level.
//  effect: config entry ({ max, kind, per, integer, decimals }); key must be unique per effect
//  (e.g. "melee.heavy.melee_crit_chance") so effects roll independently.
export function rolledValue(seed, key, effect, level, maxLevel) {
    const lv = Math.max(0, Math.min(maxLevel, Math.floor(level)));
    if (lv <= 0) return 0;
    if (effect.kind === "fixed") return effect.per * lv;
    const raw = effect.max * cumulative(seed, key, maxLevel)[lv];
    if (effect.integer) return Math.round(raw);
    const d = effect.decimals ?? 2;
    const f = Math.pow(10, d);
    return Math.round(raw * f) / f;
}

// The per-level table [level 1..max] of one effect (for GUI / admin views).
export function rolledTable(seed, key, effect, maxLevel) {
    const out = [];
    let prev = 0;
    for (let l = 1; l <= maxLevel; l++) {
        const v = rolledValue(seed, key, effect, l, maxLevel);
        out.push({ level: l, total: v, gain: Math.round((v - prev) * 100) / 100 });
        prev = v;
    }
    return out;
}
