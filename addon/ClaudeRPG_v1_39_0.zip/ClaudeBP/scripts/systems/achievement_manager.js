// achievement_manager.js -- Minecraft-facing Achievement manager.
// Hooks call AchievementManager.add / max / event; everything else (storage, caching,
// unlock notifications, anti-cheat) lives here. Data is per player and never reset by Prestige.
import { world } from "@minecraft/server";
import { ACH_DEFS, ACH_MAX_COUNTERS, ACH_TIERS, ACH_CATEGORIES } from "../config/achievement_data.js";
import { ACHIEVEMENT } from "../config/achievement_config.js";
import { createEngine } from "./achievement_engine.js";
import { Scheduler } from "../core/scheduler.js";
import { EventBus } from "../core/event_bus.js";
import { SettingsManager } from "./settings_manager.js";
import { ToastManager } from "./toast_manager.js";
import { Logger } from "../core/logger.js";

const engine = createEngine(ACH_DEFS, ACH_MAX_COUNTERS);
const cache = new Map();            // playerId -> { data, dirty }
const queue = new Map();            // playerId -> defs waiting for a notification
const stateProviders = [];          // (player) => { counterKey: value }  (current-state counters such as Level / Prestige)
let registered = false;

function entry(player) {
    let e = cache.get(player.id);
    if (!e) {
        let raw;
        try { raw = player.getDynamicProperty(ACHIEVEMENT.PROPERTY); } catch (_) { /* fresh */ }
        e = { data: engine.parse(raw), dirty: false };
        cache.set(player.id, e);
    }
    return e;
}

function canCount(player) {
    if (ACHIEVEMENT.ENABLED < 1 || !player?.isValid) return false;
    try {
        const gm = String(player.getGameMode?.() ?? "").toLowerCase();
        return ACHIEVEMENT.COUNT_GAMEMODES.includes(gm);
    } catch (_) { return false; }
}

function save(player, e) {
    try {
        player.setDynamicProperty(ACHIEVEMENT.PROPERTY, engine.serialize(e.data));
        e.dirty = false;
    } catch (error) { Logger.warn(`Achievement save failed: ${error}`); }
}

function notify(player, def) {
    const tier = ACH_TIERS[def.tier];
    const cat = ACH_CATEGORIES.find((c) => c.id === def.cat);
    const N = ACHIEVEMENT.NOTIFY;
    try {
        if (ToastManager.isActive(player)) {
            // Toast replaces the unlock line + action bar; the cheeky quip stays in chat (if the chat switch is on).
            ToastManager.show(player, { frame: def.tier, icon: def.id, header: "Achievement Unlocked", body: `${tier.color}${def.name}`, sound: N.SOUND });
            if (N.CHAT >= 1 && def.quip && SettingsManager.get(player, "ach_chat")) player.sendMessage(`§7§o"${def.quip}"`);
            return;
        }
        if (N.CHAT >= 1 && SettingsManager.get(player, "ach_chat")) {
            player.sendMessage(`§6[Achievement Unlocked] ${tier.color}${def.name} §8(${tier.name}${cat ? ` · ${cat.name}` : ""})`);
            if (def.quip) player.sendMessage(`§7§o"${def.quip}"`);
        }
        if (N.ACTIONBAR >= 1 && SettingsManager.get(player, "ach_actionbar")) player.onScreenDisplay.setActionBar(`§6Achievement Unlocked: ${tier.color}${def.name}`);
        player.playSound(N.SOUND);
    } catch (_) { /* player left */ }
}

function handleUnlocked(player, e, unlocked) {
    if (!unlocked.length) return unlocked;
    save(player, e);   // unlocks are written immediately
    const q = queue.get(player.id) ?? [];
    q.push(...unlocked);
    queue.set(player.id, q);
    drain(player);
    for (const def of unlocked) EventBus.emit("achievementUnlocked", { player, def });
    return unlocked;
}

function drain(player) {
    const q = queue.get(player.id);
    if (!q?.length) return;
    const batch = q.splice(0, ACHIEVEMENT.NOTIFY.MAX_PER_TICK);
    for (const def of batch) notify(player, def);
    if (!q.length) queue.delete(player.id);
}

export const AchievementManager = {
    engine,
    isEnabled() { return ACHIEVEMENT.ENABLED >= 1; },

    // --- counting API used by feature hooks -------------------------------
    add(player, key, amount = 1) {
        if (!canCount(player)) return [];
        const e = entry(player);
        const unlocked = engine.add(e.data, key, amount);
        e.dirty = true;
        return handleUnlocked(player, e, unlocked);
    },
    max(player, key, value) {
        if (!canCount(player)) return [];
        const e = entry(player);
        const before = engine.get(e.data, key);
        const unlocked = engine.max(e.data, key, value);
        if (engine.get(e.data, key) !== before) e.dirty = true;
        return handleUnlocked(player, e, unlocked);
    },
    event(player, key) { return this.add(player, key, 1); },

    // "Distinct things seen" counters (menus opened, Knowledge Book topics): remembers each id once,
    // then keeps the best count in `countKey`.
    markSeen(player, group, id, countKey) {
        if (!canCount(player)) return;
        const e = entry(player);
        const key = `seen_${group}_${id}`;
        if (e.data.c[key]) return;
        e.data.c[key] = 1;
        e.dirty = true;
        const prefix = `seen_${group}_`;
        this.max(player, countKey, Object.keys(e.data.c).filter((k) => k.startsWith(prefix)).length);
    },

    // --- read API used by the GUI ----------------------------------------
    getData(player) { return entry(player).data; },
    isUnlocked(player, id) { return engine.isUnlocked(entry(player).data, id); },
    progress(player, id) { return engine.progress(entry(player).data, id); },
    counter(player, key) { return engine.get(entry(player).data, key); },
    unlockedCount(player, catId = null) {
        const data = entry(player).data;
        if (!catId) return engine.unlockedCount(data);
        return ACH_DEFS.filter((d) => d.cat === catId && engine.isUnlocked(data, d.id)).length;
    },
    defsOf(catId) { return ACH_DEFS.filter((d) => d.cat === catId); },

    // --- admin helpers (bypass anti-cheat) --------------------------------
    adminGrant(player, id) { const e = entry(player); const u = engine.grant(e.data, id); e.dirty = true; return handleUnlocked(player, e, u); },
    adminRevoke(player, id) { const e = entry(player); const ok = engine.revoke(e.data, id); if (ok) { e.dirty = true; save(player, e); } return ok; },
    adminSetProgress(player, key, value) { const e = entry(player); const u = engine.setProgress(e.data, key, value); e.dirty = true; return handleUnlocked(player, e, u); },
    adminReset(player) { const e = entry(player); engine.reset(e.data); e.dirty = true; save(player, e); },

    // --- state counters (Level, Prestige, Mastery ...) are read from existing systems ---
    // This is also how existing players get their old progress back (backfill from current stats).
    registerStateProvider(fn) { if (typeof fn === "function") stateProviders.push(fn); },
    syncState(player) {
        if (!canCount(player)) return;
        for (const provider of stateProviders) {
            Logger.guard("achievement state provider", () => {
                const values = provider(player) ?? {};
                for (const [key, value] of Object.entries(values)) this.max(player, key, Number(value));
            });
        }
    },

    flush(player) { const e = cache.get(player.id); if (e?.dirty) save(player, e); },
    flushAll() { for (const player of world.getAllPlayers()) this.flush(player); },
    forget(playerId) { cache.delete(playerId); queue.delete(playerId); },

    register() {
        if (registered) return false;
        registered = true;
        Scheduler.every("ach_flush", ACHIEVEMENT.FLUSH_INTERVAL_TICKS, () => {
            for (const player of world.getAllPlayers()) {
                this.flush(player);
                drain(player);
                this.syncState(player);
            }
        });
        EventBus.on("playerLeave", (event) => {
            const id = event?.playerId;
            if (!id) return;
            // the data was already flushed by the beforeEvents.playerLeave handler below
            this.forget(id);
        });
        world.beforeEvents.playerLeave.subscribe((event) => { Logger.guard("achievement leave flush", () => { this.flush(event.player); this.forget(event.player.id); }); });
        return true;
    },
};
