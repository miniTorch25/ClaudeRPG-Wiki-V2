// ClaudeRPG Augment Registry — single source of truth for Augment metadata.
// Persistent values live on ItemStacks; this registry only defines what those
// values mean and where they are valid.
import { EquipmentSlot } from "@minecraft/server";
import { getToolCategory } from "../config/tool_config.js";

// Every item type has its own Augment stat list.
export const AUGMENT_DEFINITIONS = Object.freeze({
    melee: Object.freeze({
        attackDamage: { key: "add_atkdmg", label: "Attack Damage", min: 0, max: 6, percent: false },
        chainAttack: { key: "add_chain", label: "Chain Attack", min: 0, max: 3, percent: false },
        chainChance: { key: "add_chainchance", label: "Chain Chance", min: 0, max: 70, percent: true },
        chainDamage: { key: "add_chaindmg", label: "Chain Damage", min: 0, max: 100, percent: true },
        movementSpeed: { key: "add_movespeed", label: "Movement Speed", min: 0, max: 10, percent: true }
    }),
    ranged: Object.freeze({
        attackDamage: { key: "add_atkdmg", label: "Attack Damage", min: 0, max: 6, percent: false },
        stunt: { key: "add_stunt", label: "Stunt", min: 0, max: 60, percent: true },
        movementSpeed: { key: "add_movespeed", label: "Movement Speed", min: 0, max: 25, percent: true },
        scavenging: { key: "add_scavenging", label: "Scavenging", min: 0, max: 80, percent: true }
    }),
    tool: Object.freeze({
        attackDamage: { key: "add_atkdmg", label: "Attack Damage", min: 0, max: 10, percent: false },
        vein: { key: "add_vein", label: "Vein", min: 0, max: 10, percent: false }
    }),
    armor: Object.freeze({
        movementSpeed: { key: "add_movespeed", label: "Movement Speed", min: 0, max: 10, percent: true },
        armor: { key: "add_armor", label: "Armor", min: 0, max: 10, percent: false },
        health: { key: "add_health", label: "Health", min: 0, max: 10, percent: false },
        evasion: { key: "add_evasion", label: "Evasion", min: 0, max: 5, percent: true },
        mana: { key: "add_mana", label: "Mana", min: -10, max: 100, percent: false },
        manaRegen: { key: "add_manaregen", label: "Mana Regen", min: 0, max: 5, percent: false, suffix: "ps" }
    })
});

export const PICKAXE_ONLY_DEFS = Object.freeze({
    luck: { key: "add_luck", label: "Luck", min: 0, max: 75, percent: true }
});

// Shears are a tool, but only Vein can be rolled on them.
export const SHEARS_ONLY_DEFS = Object.freeze({
    vein: AUGMENT_DEFINITIONS.tool.vein
});

export const AUGMENT_KEYS = Object.freeze({
    attackDamage: "add_atkdmg", chainAttack: "add_chain", chainChance: "add_chainchance",
    chainDamage: "add_chaindmg", evasion: "add_evasion", armor: "add_armor",
    mana: "add_mana", manaRegen: "add_manaregen", vein: "add_vein",
    scavenging: "add_scavenging", stunt: "add_stunt", luck: "add_luck"
});

export const AUGMENT_SLOT_TYPE_MAP = Object.freeze({
    [EquipmentSlot.Mainhand]: ["melee", "ranged", "tool"],
    [EquipmentSlot.Head]: ["armor"],
    [EquipmentSlot.Chest]: ["armor"],
    [EquipmentSlot.Legs]: ["armor"],
    [EquipmentSlot.Feet]: ["armor"],
    [EquipmentSlot.Offhand]: ["armor"]
});

export function getAugmentDefinitions(type, itemTypeId = "") {
    const base = AUGMENT_DEFINITIONS[type] ?? {};
    if (type === "tool" && getToolCategory(itemTypeId) === "shears") return SHEARS_ONLY_DEFS;
    if (type === "tool" && getToolCategory(itemTypeId) === "pickaxe") {
        return { ...base, ...PICKAXE_ONLY_DEFS };
    }
    return base;
}

export function getAugmentDefinition(type, statName, itemTypeId = "") {
    return getAugmentDefinitions(type, itemTypeId)[statName] ?? null;
}

export function getAugmentStatNames() {
    const names = new Set();
    for (const defs of Object.values(AUGMENT_DEFINITIONS)) for (const name of Object.keys(defs)) names.add(name);
    for (const name of Object.keys(PICKAXE_ONLY_DEFS)) names.add(name);
    return [...names];
}

export function getAugmentDisplayDefinition(statName) {
    for (const defs of Object.values(AUGMENT_DEFINITIONS)) if (defs[statName]) return defs[statName];
    return PICKAXE_ONLY_DEFS[statName] ?? null;
}
