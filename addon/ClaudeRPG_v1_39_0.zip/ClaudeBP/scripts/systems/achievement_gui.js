// achievement_gui.js -- Achievements menu: 3 categories -> page selector -> 10 per page -> detail.
// Colour icon = done, grey icon = not yet. Hidden Achievements show "???" until completed.
import { ActionFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { AchievementManager } from "./achievement_manager.js";
import { ACH_CATEGORIES, ACH_TIERS } from "../config/achievement_data.js";
import { ACHIEVEMENT } from "../config/achievement_config.js";

const SCREEN = "systems.achievement_gui.js";
const ICON = "textures/icons/ach/";
const BACK_ICON = "textures/icons/back";
const PER_PAGE = ACHIEVEMENT.ITEMS_PER_PAGE;

const fmt = (n) => String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
const pageCount = (defs) => Math.max(1, Math.ceil(defs.length / PER_PAGE));
const pageDefs = (defs, page) => defs.slice(page * PER_PAGE, (page + 1) * PER_PAGE);
const bar = (value, target, width = 20) => {
    const filled = Math.max(0, Math.min(width, Math.floor((value / target) * width)));
    return `§a${"|".repeat(filled)}§8${"|".repeat(width - filled)}`;
};
const dateText = (ms) => { try { return new Date(ms).toISOString().slice(0, 10); } catch (_) { return "-"; } };

function show(player, form, onResult) {
    GuiService.show(player, form, SCREEN).then((r) => { if (!r.canceled) onResult(r); })
        .catch((error) => console.warn(`[Achievements] ${error}`));
}

export const AchievementGui = {
    // onBack: optional () => void; called by the first screen's Back button.
    openMain(player, onBack = null) {
        AchievementManager.markSeen(player, "menu", "achievements", "menus_distinct");
        const total = AchievementManager.engine.total;
        const form = new ActionFormData()
            .title("§l§6ACHIEVEMENTS")
            .body(`§7Completed: §f${AchievementManager.unlockedCount(player)} §8/ ${total}\n§8No rewards, only bragging rights. Pick a category:`);
        for (const cat of ACH_CATEGORIES) {
            const defs = AchievementManager.defsOf(cat.id);
            form.button(`${cat.color}§l${cat.name}\n§8${AchievementManager.unlockedCount(player, cat.id)} / ${defs.length}`, `${ICON}cat_${cat.id}`);
        }
        form.button("§8< Back", BACK_ICON);
        show(player, form, (r) => {
            if (r.selection < ACH_CATEGORIES.length) return this.openCategory(player, ACH_CATEGORIES[r.selection].id, onBack);
            AchievementManager.event(player, "back_presses");
            if (onBack) onBack();
        });
    },

    // Page selector of one category.
    openCategory(player, catId, onBack = null) {
        const cat = ACH_CATEGORIES.find((c) => c.id === catId);
        if (!cat) return this.openMain(player, onBack);
        const defs = AchievementManager.defsOf(catId);
        const pages = pageCount(defs);
        const form = new ActionFormData()
            .title(`${cat.color}§l${cat.name}`)
            .body(`§7Completed: §f${AchievementManager.unlockedCount(player, catId)} §8/ ${defs.length}\n§7Pick a page:`);
        for (let p = 0; p < pages; p++) {
            const slice = pageDefs(defs, p);
            const done = slice.filter((d) => AchievementManager.isUnlocked(player, d.id)).length;
            const groups = [...new Set(slice.map((d) => d.group))].join(" / ");
            form.button(`§fPage ${p + 1} §8(${done}/${slice.length})\n§8${groups}`, `${ICON}cat_${catId}`);
        }
        form.button("§8< Back", BACK_ICON);
        show(player, form, (r) => {
            if (r.selection < pages) return this.openPage(player, catId, r.selection, onBack);
            AchievementManager.event(player, "back_presses");
            this.openMain(player, onBack);
        });
    },

    openPage(player, catId, page, onBack = null) {
        const cat = ACH_CATEGORIES.find((c) => c.id === catId);
        const defs = AchievementManager.defsOf(catId);
        const pages = pageCount(defs);
        page = Math.max(0, Math.min(pages - 1, page));
        const slice = pageDefs(defs, page);
        const done = slice.filter((d) => AchievementManager.isUnlocked(player, d.id)).length;
        const form = new ActionFormData()
            .title(`${cat.color}§l${cat.name} §r§8${page + 1}/${pages}`)
            .body(`§7Page §f${page + 1}§7/${pages}  §8·  §7Completed on this page: §f${done}§7/${slice.length}`);
        for (const d of slice) {
            const got = AchievementManager.isUnlocked(player, d.id);
            const tier = ACH_TIERS[d.tier];
            if (!got && d.hidden) { form.button("§8???\n§8Hidden", `${ICON}hidden`); continue; }
            const pr = AchievementManager.progress(player, d.id);
            const second = got ? "§aDone" : (pr.target > 1 ? `§8${fmt(pr.value)} / ${fmt(pr.target)}` : "§8Not yet");
            form.button(`${got ? tier.color : "§7"}${d.name}\n${second}`, `${ICON}${d.id}${got ? "" : "_off"}`);
        }
        const hasPrev = page > 0, hasNext = page < pages - 1;
        if (hasPrev) form.button("§bPrevious", "textures/icons/previous");
        if (hasNext) form.button("§bNext", "textures/icons/next");
        form.button("§8< Back", BACK_ICON);
        show(player, form, (r) => {
            let i = r.selection;
            if (i < slice.length) return this.openDetail(player, slice[i], page, onBack);
            i -= slice.length;
            if (hasPrev) { if (i === 0) { AchievementManager.event(player, "ach_pages_flipped"); return this.openPage(player, catId, page - 1, onBack); } i--; }
            if (hasNext) { if (i === 0) { AchievementManager.event(player, "ach_pages_flipped"); return this.openPage(player, catId, page + 1, onBack); } i--; }
            AchievementManager.event(player, "back_presses");
            this.openCategory(player, catId, onBack);
        });
    },

    openDetail(player, def, page, onBack = null) {
        const got = AchievementManager.isUnlocked(player, def.id);
        const tier = ACH_TIERS[def.tier];
        const cat = ACH_CATEGORIES.find((c) => c.id === def.cat);
        const pr = AchievementManager.progress(player, def.id);
        let body;
        if (!got && def.hidden) {
            body = "§8??? §7Hidden Achievement\n\n§7Keep playing, and maybe do something silly.";
        } else {
            body = [
                `${tier.color}${tier.name} §8· §7${cat.name} §8· §7${def.group}`,
                "",
                `§f${def.cond}`,
                "",
                got
                    ? `§aCompleted §8on ${dateText(pr.at)}`
                    : (pr.target > 1 ? `${bar(pr.value, pr.target)}\n§7${fmt(pr.value)} §8/ §7${fmt(pr.target)}` : "§7Not completed yet"),
                ...(got && def.quip ? ["", `§7§o"${def.quip}"`] : []),
            ].join("\n");
        }
        const form = new ActionFormData()
            .title(`${got || !def.hidden ? tier.color : "§8"}§l${!got && def.hidden ? "???" : def.name}`)
            .body(body)
            .button("§8< Back", BACK_ICON);
        show(player, form, () => {
            AchievementManager.event(player, "back_presses");
            this.openPage(player, def.cat, Math.floor(AchievementManager.defsOf(def.cat).findIndex((d) => d.id === def.id) / PER_PAGE), onBack);
        });
    },
};
