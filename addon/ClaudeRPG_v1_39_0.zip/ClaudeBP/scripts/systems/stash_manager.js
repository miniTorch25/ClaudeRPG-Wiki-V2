// stash_manager.js -- Quick Stash: one tap moves inventory items into nearby containers
// that ALREADY hold the same item type. Never moves the held item, never touches armor/offhand,
// skips the hotbar unless the player's setting says otherwise, skips lore items (runes/gems/augments/reforged).
import { system, EntityComponentTypes } from "@minecraft/server";
import { STASH } from "../config/qol_config.js";
import { SettingsManager } from "./settings_manager.js";

const lastUse = new Map();   // playerId -> tick

function nearbyContainers(player) {
    const dim = player.dimension, c = player.location, r = Math.max(1, STASH.RADIUS | 0);
    const bx = Math.floor(c.x), by = Math.floor(c.y), bz = Math.floor(c.z);
    const found = [];
    for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) for (let dz = -r; dz <= r; dz++) {
        let block;
        try { block = dim.getBlock({ x: bx + dx, y: by + dy, z: bz + dz }); } catch (_) { continue; }
        if (!block || !STASH.CONTAINERS.includes(block.typeId)) continue;
        let container;
        try { container = block.getComponent("minecraft:inventory")?.container; } catch (_) { continue; }
        if (container) found.push({ container, d: dx * dx + dy * dy + dz * dz });
    }
    found.sort((a, b) => a.d - b.d);
    return found.slice(0, Math.max(1, STASH.MAX_CONTAINERS | 0)).map((f) => f.container);
}

function typesIn(container) {
    const set = new Set();
    for (let i = 0; i < container.size; i++) { const it = container.getItem(i); if (it) set.add(it.typeId); }
    return set;
}

export const StashManager = {
    // Returns { ok, message }.
    run(player) {
        if (STASH.ENABLED < 1) return { ok: false, message: "Quick Stash is turned off." };
        const last = lastUse.get(player.id);
        if (last !== undefined && system.currentTick - last < STASH.COOLDOWN_SEC * 20) return { ok: false, message: "Quick Stash is cooling down." };
        lastUse.set(player.id, system.currentTick);

        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        if (!inv) return { ok: false, message: "Could not read your inventory." };
        const containers = nearbyContainers(player);
        if (!containers.length) return { ok: false, message: `No chest or barrel within ${STASH.RADIUS} blocks.` };

        const includeHotbar = SettingsManager.get(player, "stash_hotbar");
        const held = player.selectedSlotIndex;
        let moved = 0, usedContainers = 0;

        for (const container of containers) {
            const wanted = typesIn(container);
            if (!wanted.size) continue;
            let touched = false;
            for (let i = 0; i < inv.size; i++) {
                if (i === held) continue;
                if (i < 9 && !includeHotbar) continue;
                const it = inv.getItem(i);
                if (!it || !wanted.has(it.typeId)) continue;
                if (STASH.SKIP_LORE >= 1) { let lore = []; try { lore = it.getLore(); } catch (_) {} if (lore.length) continue; }
                const before = it.amount;
                let left;
                try { left = container.addItem(it); } catch (_) { continue; }
                const remaining = left ? left.amount : 0;
                if (remaining === before) continue;
                inv.setItem(i, left ?? undefined);
                moved += before - remaining;
                touched = true;
            }
            if (touched) usedContainers++;
        }

        if (!moved) return { ok: false, message: "Nothing to stash: no nearby container holds the same items as your inventory." };
        return { ok: true, message: `Stashed ${moved} item${moved === 1 ? "" : "s"} into ${usedContainers} container${usedContainers === 1 ? "" : "s"}.`, moved };
    },

    onPlayerLeave(playerId) { lastUse.delete(playerId); },
};
