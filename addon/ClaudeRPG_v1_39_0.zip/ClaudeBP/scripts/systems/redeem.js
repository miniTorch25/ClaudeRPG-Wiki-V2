import { GuiService } from "../gui/gui_service.js";
import { world, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { REDEEM_CONFIG } from "../config/redeem_config.js";
import { giveItemSafely } from "../managers/item_helper.js";
import { onMenuOpened } from "./achievement_hooks.js";

const CODE_PROPERTY_PREFIX = "redeem_code_";
const EPOCH_PROPERTY = "redeem_epoch";

// ---------------------------------------------------------------
// Reset support: instead of having to reach every online AND offline
// player to clear their redeem counts, we keep a single global "epoch"
// number. Each player remembers the epoch they last synced against; if it
// doesn't match the world's current epoch, their code counters are treated
// as stale and get wiped the next time they interact with the redeem
// system (works correctly even for players who were offline at reset time).
// ---------------------------------------------------------------

function getWorldEpoch() {
    return world.getDynamicProperty(EPOCH_PROPERTY) ?? 0;
}

function ensureEpochSynced(player) {
    const worldEpoch = getWorldEpoch();
    const playerEpoch = player.getDynamicProperty(EPOCH_PROPERTY) ?? 0;
    if (playerEpoch === worldEpoch) return;

    for (const id of player.getDynamicPropertyIds()) {
        if (id.startsWith(CODE_PROPERTY_PREFIX)) {
            player.setDynamicProperty(id, undefined);
        }
    }
    player.setDynamicProperty(EPOCH_PROPERTY, worldEpoch);
}

function findCodeKey(input) {
    const normalized = input.trim().toUpperCase();
    return Object.keys(REDEEM_CONFIG).find((key) => key.toUpperCase() === normalized);
}

function getUsedCount(player, codeKey) {
    return player.getDynamicProperty(`${CODE_PROPERTY_PREFIX}${codeKey}`) ?? 0;
}

export class RedeemManager {
    // Resets everyone's redeem history at once (see epoch explanation above).
    // Items already granted are NOT taken back.
    static resetAll() {
        const current = getWorldEpoch();
        world.setDynamicProperty(EPOCH_PROPERTY, current + 1);
    }

    // 1. Main Redeem menu: Enter Code / List Redeemed Codes
    static openRedeemMenu(player) {
        onMenuOpened(player, "redeem");
        ensureEpochSynced(player);

        const form = new ActionFormData()
            .title("§l§6Redeem Code")
            .body("§7Enter a code to receive items, or view the codes you've already redeemed.")
            .button("§aEnter Code")
            .button("§bList Redeemed Codes");

        GuiService.show(player, form, "systems.redeem.js").then((response) => {
            if (response.canceled) return;

            if (response.selection === 0) {
                this.openCodeEntryMenu(player);
            } else {
                this.openRedeemedListMenu(player);
            }
        }).catch((error) => {
            console.warn(`[Redeem] Failed to open Redeem Menu: ${error}`);
        });
    }

    // 2. Code entry: a text field to type the code, Submit acts as "confirm"
    static openCodeEntryMenu(player) {
        ensureEpochSynced(player);

        const form = new ModalFormData()
            .title("§l§6Redeem Code")
            .textField("Enter your code:", "e.g. WELCOME2026");

        GuiService.show(player, form, "systems.redeem.js").then((response) => {
            if (response.canceled) return this.openRedeemMenu(player);

            const [input] = response.formValues;
            this.redeemCode(player, input);
        }).catch((error) => {
            console.warn(`[Redeem] Failed to open Code Entry Menu: ${error}`);
        });
    }

    // Validates and applies a code, if it exists and the player hasn't used
    // up their allowed redemptions for it yet.
    static redeemCode(player, input) {
        if (!input || input.trim().length === 0) {
            player.sendMessage("§cPlease enter a code!");
            return;
        }

        const codeKey = findCodeKey(input);
        if (!codeKey) {
            player.sendMessage("§cThat code isn't valid!");
            return;
        }

        const codeDef = REDEEM_CONFIG[codeKey];
        const used = getUsedCount(player, codeKey);

        if (used >= codeDef.maxUses) {
            player.sendMessage(`§cYou've already redeemed this code the maximum number of times (${codeDef.maxUses})!`);
            return;
        }

        let totalDropped = 0;
        for (const grant of codeDef.items) {
            const stack  = new ItemStack(grant.item, grant.amount ?? 1);
            const result = giveItemSafely(player, stack);
            totalDropped += result.dropped;
        }

        // Mark as used only after items have been dispatched (given or dropped)
        player.setDynamicProperty(`${CODE_PROPERTY_PREFIX}${codeKey}`, used + 1);
        player.sendMessage(codeDef.message ?? "§aCode redeemed!");
        if (totalDropped > 0) {
            player.sendMessage("§e[Redeem] Your inventory was full — some items were dropped at your feet.");
        }
        player.playSound("random.levelup");
    }

    // 3. List of codes this player has successfully redeemed, with counts
    static openRedeemedListMenu(player) {
        ensureEpochSynced(player);

        const lines = [];
        for (const codeKey of Object.keys(REDEEM_CONFIG)) {
            const used = getUsedCount(player, codeKey);
            if (used <= 0) continue;

            const codeDef = REDEEM_CONFIG[codeKey];
            const countText = codeDef.maxUses > 1 ? ` §8(${used}/${codeDef.maxUses})` : "";
            lines.push(`§a${codeKey}${countText}`);
        }

        const body = lines.length > 0 ? lines.join("\n") : "§7You haven't redeemed any codes yet.";

        const form = new ActionFormData()
            .title("§l§6Redeemed Codes")
            .body(body)
            .button("§8< Back");

        GuiService.show(player, form, "systems.redeem.js").then((response) => {
            if (response.canceled) return;
            this.openRedeemMenu(player);
        }).catch((error) => {
            console.warn(`[Redeem] Failed to open Redeemed List Menu: ${error}`);
        });
    }
}
