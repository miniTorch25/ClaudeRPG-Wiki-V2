import { EntityComponentTypes, EquipmentSlot, ItemStack, system } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { getToolCategory } from "../config/tool_config.js";
import { XP_CONFIG } from "../config/xp_config.js";
import { PICKAXE_VEIN_BLOCKS } from "../vein/pickaxe.js";
import { AXE_VEIN_BLOCKS } from "../vein/axe.js";
import { SHOVEL_VEIN_BLOCKS } from "../vein/shovel.js";
import { HOE_VEIN_BLOCKS } from "../vein/hoe.js";
import { SHEARS_VEIN_BLOCKS } from "../vein/shears.js";
import { LootBonus } from "./loot_bonus.js";
import { StatsManager } from "../managers/stats_manager.js";
import { XPManager } from "../managers/xp_manager.js";
import { XpNotifier } from "../managers/xp_notifier.js";
import { registerSuppressGetter, fireSuppressedDamage, isSplashTarget } from "../managers/damage_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { DamageIndicator } from "./damage_indicator.js";
import { HPManager } from "../managers/hp_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { MovementManager } from "../managers/movement_manager.js";
import { CooldownManager } from "../managers/cooldown_manager.js";
import { RUNE_CONFIG, useRuneLevelOf } from "../config/rune_config.js";
import { AUGMENT_KEYS as KEY, AUGMENT_SLOT_TYPE_MAP as SLOT_TYPE_MAP, getAugmentDefinitions, getAugmentStatNames, getAugmentDisplayDefinition } from "./augment_registry.js";
import { AugmentState } from "./augment_state.js";
import { onVeinFinished } from "./achievement_hooks.js";
import { AutoReplant } from "./autoreplant.js";

// Lazy-loaded module references — populated on first use, avoids circular dep at load time
let _runeEffects = null;
async function getRuneEffects() {
    return (_runeEffects ??= await import("../rune/rune_effects.js"));
}
let _runeManager = null;
async function getRuneManager() {
    return (_runeManager ??= await import("../rune/rune_manager.js"));
}
let _runeConfig = null;
async function getRuneLevelUse() {
    return ((_runeConfig ??= await import("../config/rune_config.js")).useRuneLevelOf);
}
async function getRUNE_CONFIG() {
    return ((_runeConfig ??= await import("../config/rune_config.js")).RUNE_CONFIG);
}

// GemAbility lazy loader (gem_ability.js imports augment indirectly via mana — keep lazy)
let _GemAbility = null;
function getGemAbility() {
    if (!_GemAbility) {
        import("./gem_ability.js").then((m) => { _GemAbility = m.GemAbility; }).catch(() => {});
    }
    return _GemAbility;
}

// RuneCN (Curse/Neutral rune modifiers) lazy loader — same reason as GemAbility above.
let _RuneCN = null;
function getRuneCN() {
    if (!_RuneCN) {
        import("../rune/rune_curseneutral.js").then((m) => { _RuneCN = m; }).catch(() => {});
    }
    return _RuneCN;
}

const VEIN_BLOCKS_BY_CATEGORY = {
    pickaxe: PICKAXE_VEIN_BLOCKS,
    axe:     AXE_VEIN_BLOCKS,
    shovel:  SHOVEL_VEIN_BLOCKS,
    hoe:     HOE_VEIN_BLOCKS,
    shears:  SHEARS_VEIN_BLOCKS
};

// Vein breaks its blocks one at a time, this many ticks apart (2 ticks = 0.1s).
const VEIN_BREAK_INTERVAL_TICKS = 2;
// Positions already queued by a running Vein ("dimension:x,y,z"), so two Veins never fight over a block.
const pendingVein = new Set();

const NEIGHBOR_OFFSETS = [
    { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 }, { x: 0, y: -1, z: 0 },
    { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 }
];

// Runtime-only guards and cache are owned by AugmentState/RuntimeState.
const suppressRedirect = AugmentState.getSuppressRedirect();
const suppressChainOnly = AugmentState.getSuppressChainOnly();
registerSuppressGetter(() => AugmentState.getSuppressRedirect());


function dist2(a, b) { const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return dx * dx + dy * dy + dz * dz; }

function buildEquipmentHash(player) {
    const equipment = player.getComponent(EntityComponentTypes.Equippable);
    if (!equipment) return "";
    const parts = [];
    for (const slotId of [
        EquipmentSlot.Mainhand,
        EquipmentSlot.Head, EquipmentSlot.Chest,
        EquipmentSlot.Legs, EquipmentSlot.Feet, EquipmentSlot.Offhand
    ]) {
        const slot = equipment.getEquipmentSlot(slotId);
        if (!slot?.hasItem()) { parts.push("empty"); continue; }
        const item = slot.getItem();
        parts.push(`${item.typeId}:${item.getLore().join("|")}`);
    }
    return parts.join(";");
}

export class AugmentManager {

    // --- Rolling / reading ---

    static getDefsForType(type, itemTypeId) {
        return getAugmentDefinitions(type, itemTypeId);
    }

    // Biased toward low values; landing on max is intentionally rare
    static rollBiasedValue(min, max) {
        return Math.round(min + Math.pow(Math.random(), 4) * (max - min));
    }

    static rollForType(slot, type) {
        if (!slot?.hasItem()) return false;
        const defs = this.getDefsForType(type, slot.typeId);
        for (const def of Object.values(defs)) {
            slot.setDynamicProperty(def.key, this.rollBiasedValue(def.min, def.max));
        }
        return true;
    }

    static rerollRespectingLocks(slot, type) {
        if (!slot?.hasItem()) return false;
        const defs = this.getDefsForType(type, slot.typeId);
        for (const def of Object.values(defs)) {
            if (slot.getDynamicProperty(`locked_${def.key}`)) continue;
            slot.setDynamicProperty(def.key, this.rollBiasedValue(def.min, def.max));
        }
        return true;
    }

    static maxStat(slot, type, statName) {
        if (!slot?.hasItem()) return false;
        const def = this.getDefsForType(type, slot.typeId)[statName];
        if (!def) return false;
        slot.setDynamicProperty(def.key, def.max);
        return true;
    }

    static isLocked(slot, type, statName) {
        if (!slot) return false;
        const def = this.getDefsForType(type, slot.typeId)[statName];
        if (!def) return false;
        return slot.getDynamicProperty(`locked_${def.key}`) === true;
    }

    static setLocked(slot, type, statName, locked) {
        if (!slot?.hasItem()) return false;
        const def = this.getDefsForType(type, slot.typeId)[statName];
        if (!def) return false;
        slot.setDynamicProperty(`locked_${def.key}`, locked ? true : undefined);
        return true;
    }

    static removeAll(slot, type) {
        if (!slot?.hasItem()) return false;
        const defs = this.getDefsForType(type, slot.typeId);
        for (const def of Object.values(defs)) {
            slot.setDynamicProperty(def.key, undefined);
            slot.setDynamicProperty(`locked_${def.key}`, undefined);
        }
        return true;
    }

    static getValues(slotOrItem, type) {
        if (!slotOrItem) return {};
        const defs   = this.getDefsForType(type, slotOrItem.typeId);
        const values = {};
        for (const [statName, def] of Object.entries(defs)) {
            values[statName] = slotOrItem.getDynamicProperty(def.key) ?? 0;
        }
        return values;
    }

    // --- Per-player on/off settings ---

    static isStatDisabled(player, statName) {
        return player.getDynamicProperty(`augoff_${statName}`) === true;
    }

    static setStatDisabled(player, statName, disabled) {
        player.setDynamicProperty(`augoff_${statName}`, disabled ? true : undefined);
    }

    // Reads a stat directly off an item slot, but returns 0 if the player disabled that stat
    static getItemStatValue(player, slot, statName, key) {
        if (this.isStatDisabled(player, statName)) return 0;
        return slot?.getDynamicProperty(key) ?? 0;
    }

    static getAllStatNames() {
        return getAugmentStatNames();
    }

    static findDisplayDef(statName) {
        return getAugmentDisplayDefinition(statName);
    }

    // --- Aggregation across equipped gear ---

    // Called on player leave — purges stale cache entry so rejoining player gets fresh stats
    static clearPlayerCache(playerId) {
        AugmentState.clearPlayer(playerId);
    }

    static onPlayerRespawn(player) {
        if (!player) return;
        this.clearPlayerCache(player.id);
    }

    static onPlayerLeave(playerId) {
        this.clearPlayerCache(playerId);
    }

    static clearRuntimeState() {
        AugmentState.clearAll();
    }

    static getEquippedTotal(player, statName) {
        if (this.isStatDisabled(player, statName)) return 0;

        const equipment = player.getComponent(EntityComponentTypes.Equippable);
        if (!equipment) return 0;

        let total = 0;
        for (const [slotId, allowedTypes] of Object.entries(SLOT_TYPE_MAP)) {
            const slot = equipment.getEquipmentSlot(slotId);
            if (!slot?.hasItem()) continue;

            const item = slot.getItem();
            const req  = ITEM_REQUIREMENTS[item.typeId];
            if (!req || !allowedTypes.includes(req.type)) continue;

            const def = this.getDefsForType(req.type, item.typeId)[statName];
            if (!def) continue;

            total += slot.getDynamicProperty(def.key) ?? 0;
        }
        return total;
    }

    static getAllEquippedTotals(player) {
        const totals = {};
        for (const statName of this.getAllStatNames()) {
            totals[statName] = this.getEquippedTotal(player, statName);
        }
        return totals;
    }

    // --- Lore ---

    static buildLoreLines(type, values, slot) {
        const defs  = this.getDefsForType(type, slot?.typeId);
        const lines = [];

        for (const [statName, def] of Object.entries(defs)) {
            const value = values[statName] ?? 0;
            if (value === 0) continue;

            const unit       = def.percent ? "\uE21F" : (def.suffix ?? "");
            const rangeSuffix = value >= def.max ? "§4(Max)" : `(${def.min}${unit}~${def.max}${unit})`;
            const lockSuffix  = slot?.getDynamicProperty(`locked_${def.key}`) ? " §r§8\uE20B" : "";
            const sign        = value >= 0 ? "+" : "";
            lines.push(`§r§9${sign}${value}${unit} ${def.label} ${rangeSuffix}${lockSuffix}`);
        }

        if (lines.length === 0) return [];
        return ["§r§7Augment:", ...lines];
    }

    // --- Passive stats (Health, Movement Speed) ---

    static applyPassiveStats(player) {
        // Cache calculated Augment totals, but always re-apply transient engine effects.
        // This prevents health_boost/movement effects from expiring while the loadout is unchanged.
        const hash = buildEquipmentHash(player);
        let cache = AugmentState.getEquipmentCache(player.id);
        if (!cache || cache.hash !== hash) {
            cache = { hash, totals: this.getAllEquippedTotals(player) };
            AugmentState.setEquipmentCache(player.id, cache);
        }
        const totals = cache.totals ?? {};

        const health = totals.health ?? 0;
        // Real Max HP from this stat is applied via the augment_health dynamic
        // property below, read by HPManager.recalcMaxHP. The vanilla health_boost
        // effect that used to be applied here was purely cosmetic (and could
        // desync from the real value on things like drinking milk) — removed
        // as part of the Vanilla Effect -> Script conversion (Phase 6).

        const augmentSpeed = totals.movementSpeed ?? 0;
        const gemSpeed = getGemAbility()?.getGemSpeedBonus(player) ?? 0;
        const runeSpeed = getRuneCN()?.getSpeedModPercent(player) ?? 0;
        const dimId = player.dimension?.id ?? "minecraft:overworld";
        const dimKey = dimId === "minecraft:nether" ? "move_speed_nether" : dimId === "minecraft:the_end" ? "move_speed_end" : "move_speed_overworld";
        const masterySpeed = MasteryManager.getBonus(player, "move_speed") + MasteryManager.getBonus(player, dimKey);
        // Mastery speed (Heavy melee is very negative) can never push the total below the floor.
        const moveSpeedPercent = Math.max(MASTERY.MOVE_SPEED_FLOOR_PCT,
            augmentSpeed + gemSpeed + runeSpeed + ProgressionManager.getPerkValue(player, "move_speed") + masterySpeed);
        // Movement: only cache the % here; MovementManager.tick applies it every 2 ticks
        // and keeps vanilla Sprint / Speed / Slowness intact.
        MovementManager.setBonus(player, moveSpeedPercent);

        player.setDynamicProperty("augment_health", health);
        HPManager.recalcMaxHP(player);
    }

    // Pure combat reads used by CombatPipeline. These methods never cancel or
    // reissue the hit; final damage is resolved exactly once by DamageManager.
    static getCombatAttackModifiers(event) {
        const attacker = event.damageSource?.damagingEntity;
        if (!attacker || attacker.typeId !== "minecraft:player") return { flatBonus: 0, multipliers: [] };
        const equipment = attacker.getComponent(EntityComponentTypes.Equippable);
        const slot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!slot?.hasItem()) return { flatBonus: 0, multipliers: [] };
        const projectile = event.damageSource?.damagingProjectile;
        const weaponTypeId = projectile?.getDynamicProperty("crpg:weapon_typeid") ?? slot.typeId;
        const req = ITEM_REQUIREMENTS[weaponTypeId];
        if (!req || !["melee", "ranged", "tool"].includes(req.type)) return { flatBonus: 0, multipliers: [] };
        return { flatBonus: this.getItemStatValue(attacker, slot, "attackDamage", KEY.attackDamage), multipliers: [] };
    }

    static getDamageReductionPercent(player, attacker = null) {
        const augmentArmor = this.getEquippedTotal(player, "armor");
        const gemArmor = getGemAbility()?.getGemArmorBonus(player) ?? 0;
        const masteryArmor = MasteryManager.getBonus(player, "armor");
        let reduction = Math.min((augmentArmor + gemArmor + masteryArmor) * 4, 60);
        return reduction;
    }

    // --- Defensive effects (victim side) ---

    static applyEvasion(event) {
        const player = event.hurtEntity;
        if (!player || player.typeId !== "minecraft:player") return false;
        if (suppressRedirect.has(player.id)) return false;

        const augmentEvasion = this.getEquippedTotal(player, "evasion");
        const gemEvasion     = getGemAbility()?.getGemEvasionBonus(player) ?? 0;
        const total          = augmentEvasion + gemEvasion + MasteryManager.getBonus(player, "evasion");
        if (total <= 0 || Math.random() * 100 >= total) return false;

        event.cancel = true;
        player.onScreenDisplay.setActionBar("§b[Evasion] You dodged the attack!");
        try { getGemAbility()?.onDodge(player); } catch (_) { /* gem hook must never break combat */ }
        return true;
    }

    // Attack chaining remains a post-resolution effect.
    // Chain hits are secondary damage: they go straight to the mob's HP pool (Core hit cap and burst
    // window included) via fireSuppressedDamage, so they are NOT re-run through the combat pipeline.
    // That keeps them from being multiplied a second time (flat bonus / Ascension), from chaining
    // again, and from re-triggering Rune / Gem / Chorus on-hit effects.
    static applyChainAttack(attacker, victim, baseDamage, mainhandSlot) {
        if (suppressChainOnly.has(victim?.id)) return;   // this victim is itself a chain target
        const chainAttack = this.getItemStatValue(attacker, mainhandSlot, "chainAttack", KEY.chainAttack);
        if (chainAttack <= 0) return;

        const chainChance = this.getItemStatValue(attacker, mainhandSlot, "chainChance", KEY.chainChance);
        if (chainChance <= 0 || Math.random() * 100 >= chainChance) return;

        const chainDamagePercent = this.getItemStatValue(attacker, mainhandSlot, "chainDamage", KEY.chainDamage);
        const chainDamage        = Math.ceil(baseDamage * (chainDamagePercent / 100));
        if (chainDamage <= 0 || !victim.isValid) return;

        const vl = victim.location;
        const nearby = victim.dimension
            .getEntities({ location: vl, maxDistance: 3, excludeTypes: ["minecraft:player", "minecraft:item"] })
            .filter((e) => e.id !== victim.id && e.id !== attacker.id && isSplashTarget(e))
            .sort((a, b) => dist2(a.location, vl) - dist2(b.location, vl))
            .slice(0, chainAttack);

        let hits = 0;
        for (const target of nearby) {
            suppressChainOnly.add(target.id);
            try {
                if (!target.isValid) continue;
                if (EvolutionManager.tryAbsorb(target, attacker)) continue;   // Enchanted shield still blocks chain hits
                const out = {};
                fireSuppressedDamage(target, attacker, chainDamage, "entity_attack", out);
                hits++;
                try { DamageIndicator.onDamage({ attacker, victim: target, finalDamage: chainDamage, meta: { appliedDamage: out.applied ?? chainDamage } }); } catch (_) { /* cosmetic */ }
            } catch (error) {
                console.warn(`[ClaudeRPG] Failed to apply chain attack damage: ${error}`);
            } finally {
                // fireSuppressedDamage finishes in a system.run; keep the guard until then
                system.run(() => suppressChainOnly.delete(target.id));
            }
        }

        if (hits > 0) attacker.onScreenDisplay.setActionBar(`§b[Chain Attack] Hit ${hits} more target(s)!`);
    }

    // Stunt approximates a stun with stacked Slowness/Weakness/Mining Fatigue (~2 sec)
    static applyStunt(event) {
        const attacker = event.damageSource?.damagingEntity;
        const victim   = event.hurtEntity;
        if (!attacker || attacker.typeId !== "minecraft:player" || !victim) return;

        const equipment    = attacker.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!mainhandSlot?.hasItem()) return;

        const item = mainhandSlot.getItem();
        const req  = ITEM_REQUIREMENTS[item.typeId];
        if (!req || req.type !== "ranged") return;

        const stunt = this.getItemStatValue(attacker, mainhandSlot, "stunt", KEY.stunt);
        if (stunt <= 0 || Math.random() * 100 >= stunt) return;

        victim.addEffect("slowness",      40, { amplifier: 10, showParticles: false });
        victim.addEffect("weakness",      40, { amplifier: 10, showParticles: false });
        victim.addEffect("mining_fatigue",40, { amplifier: 10, showParticles: false });
        attacker.onScreenDisplay.setActionBar("§b[Stunt] Target stunned!");
    }

    static applyScavenging(event) {
        const { deadEntity, damageSource } = event;
        const attacker = damageSource?.damagingEntity;
        if (!attacker || attacker.typeId !== "minecraft:player") return;

        const equipment    = attacker.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!mainhandSlot?.hasItem()) return;

        const item = mainhandSlot.getItem();
        const req  = ITEM_REQUIREMENTS[item.typeId];
        if (!req || req.type !== "ranged") return;

        const scavenging = this.getItemStatValue(attacker, mainhandSlot, "scavenging", KEY.scavenging) + MasteryManager.getBonus(attacker, "scavenging");
        if (scavenging <= 0 || Math.random() * 100 >= scavenging) return;

        const killLocation = { x: deadEntity.location.x, y: deadEntity.location.y, z: deadEntity.location.z };
        const dimension    = deadEntity.dimension;

        // Snapshot item entity IDs that already exist at kill site BEFORE vanilla drops spawn.
        // Any new item entity appearing within 3 ticks is attributable to this kill.
        const preExistingIds = new Set(
            dimension
                .getEntities({ location: killLocation, maxDistance: 2, type: "minecraft:item" })
                .map((e) => e.id)
        );

        // Wait for vanilla drops to appear (vanilla spawns drops on the same tick as entityDie
        // fires, but they become query-able after a short delay)
        system.runTimeout(() => {
            const allDrops  = dimension.getEntities({ location: killLocation, maxDistance: 2, type: "minecraft:item" });
            // Only clone items that were NOT there before the kill
            const killDrops = allDrops.filter((e) => !preExistingIds.has(e.id));

            for (const drop of killDrops) {
                const itemComp = drop.getComponent(EntityComponentTypes.Item);
                if (!itemComp?.itemStack) continue;
                dimension.spawnItem(itemComp.itemStack.clone(), killLocation);
            }
            if (killDrops.length > 0) {
                attacker.onScreenDisplay.setActionBar("§b[Scavenging] Drops x2!");
            }
        }, 3);
    }

    // --- Mining effects ---

    static async applyVein(event) {
        const { player, brokenBlockPermutation } = event;
        const blockTypeId = brokenBlockPermutation?.type?.id;
        if (!blockTypeId) return;

        const equipment    = player.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!mainhandSlot?.hasItem()) return;

        const item = mainhandSlot.getItem();
        const req  = ITEM_REQUIREMENTS[item.typeId];
        if (!req || req.type !== "tool") return;

        const vein = this.getItemStatValue(player, mainhandSlot, "vein", KEY.vein) + Math.round(MasteryManager.getBonus(player, "vein"));
        // Vein Boost Rune: bonus vein blocks on top of Augment, capped globally
        let earthBonus = 0;
        const veinCap = 48;
        try {
            const re = await getRuneEffects();
            earthBonus = re.getRuneVeinBonus(player);
            if (Math.min(vein + earthBonus, veinCap) <= 0) return;
        } catch (_) {}
        if (vein + earthBonus <= 0) return;

        const category  = getToolCategory(item.typeId);
        const blockList = VEIN_BLOCKS_BY_CATEGORY[category];
        if (!blockList) return;

        const config = blockList[blockTypeId];
        if (!config) return;

        const enchantComp     = item.getComponent("minecraft:enchantable");
        const hasSilkTouch    = enchantComp?.hasEnchantment("silk_touch") ?? false;
        const fortuneLevel    = enchantComp?.getEnchantment("fortune")?.level ?? 0;

        const dimension  = player.dimension;
        const origin     = event.block.location;
        const limit      = Math.min(vein + earthBonus, 48, veinCap);
        const toolTypeId = item.typeId;

        // 1) Find the connected blocks first (nothing is broken yet).
        const visited = new Set([`${origin.x},${origin.y},${origin.z}`]);
        const queue   = [origin];
        const targets = [];

        while (queue.length > 0 && targets.length < limit) {
            const pos = queue.shift();

            for (const offset of NEIGHBOR_OFFSETS) {
                if (targets.length >= limit) break;

                const neighborPos = { x: pos.x + offset.x, y: pos.y + offset.y, z: pos.z + offset.z };
                const neighborKey = `${neighborPos.x},${neighborPos.y},${neighborPos.z}`;
                if (visited.has(neighborKey)) continue;
                visited.add(neighborKey);

                if (pendingVein.has(`${dimension.id}:${neighborKey}`)) continue;   // already queued by another Vein
                const neighborBlock = dimension.getBlock(neighborPos);
                if (!neighborBlock || neighborBlock.typeId !== blockTypeId) continue;
                if (!this.isVeinBlockReady(neighborBlock, config)) continue;

                targets.push(neighborPos);
                queue.push(neighborPos);
            }
        }
        if (targets.length === 0) return;

        for (const t of targets) pendingVein.add(`${dimension.id}:${t.x},${t.y},${t.z}`);

        // 2) Break them one at a time, VEIN_BREAK_INTERVAL_TICKS apart.
        let index = 0, destroyed = 0, bonusXp = 0;
        const finish = (handle) => {
            system.clearRun(handle);
            for (let i = index; i < targets.length; i++) pendingVein.delete(`${dimension.id}:${targets[i].x},${targets[i].y},${targets[i].z}`);
            try {
                if (destroyed > 0 && player.isValid) {
                    onVeinFinished(player, blockTypeId, destroyed);
                    MasteryManager.addXp(player, "gathering", destroyed * MASTERY.GATHER_XP_PER_BLOCK);
                    if (bonusXp > 0) {
                        XPManager.addXp(player, bonusXp, "Vein", { notify: false });
                        XpNotifier.notify(player, bonusXp, "Vein");
                    }
                }
            } catch (_) {}
        };

        const handle = system.runInterval(() => {
            try {
                if (index >= targets.length) return finish(handle);
                const pos = targets[index++];
                pendingVein.delete(`${dimension.id}:${pos.x},${pos.y},${pos.z}`);

                const block = dimension.getBlock(pos);
                if (!block || block.typeId !== blockTypeId || !this.isVeinBlockReady(block, config)) return;   // changed meanwhile: skip

                // Tool must still be the same item in the mainhand: the loot command and the
                // durability cost both use it. Swapped/dropped/broken tool => stop the Vein.
                const slotNow = player.isValid
                    ? player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand)
                    : undefined;
                if (!slotNow?.hasItem() || slotNow.typeId !== toolTypeId) return finish(handle);

                const creative = this.isCreative(player);
                if (!creative) this.spawnVeinLoot(player, dimension, pos, blockTypeId, config, hasSilkTouch, fortuneLevel);
                block.setType("minecraft:air");
                AutoReplant.afterVein(player, dimension, pos, blockTypeId, toolTypeId);
                destroyed++;
                bonusXp += config.xp ?? 0;
                if (!creative && this.damageVeinTool(player, slotNow)) return finish(handle);   // tool broke
                if (index >= targets.length) finish(handle);
            } catch (e) {
                // chunk unloaded / dimension gone: stop cleanly
                finish(handle);
            }
        }, VEIN_BREAK_INTERVAL_TICKS);
    }

    static isCreative(player) {
        try { return player.getGameMode() === "Creative"; } catch { return false; }
    }

    // Drops come from the vanilla loot table: "/loot spawn ... mine <pos> mainhand" reads the
    // tool in the player's hand, so Fortune, Silk Touch and block state (crop age etc.) behave
    // exactly like a normal break. If the command is unavailable/fails, fall back to the
    // script-defined drop (Silk Touch drops the block itself, Fortune uses a simple roll).
    static spawnVeinLoot(player, dimension, pos, blockTypeId, config, hasSilkTouch, fortuneLevel) {
        try {
            const r = player.runCommand(`loot spawn ${pos.x} ${pos.y} ${pos.z} mine ${pos.x} ${pos.y} ${pos.z} mainhand`);
            if ((r?.successCount ?? 0) > 0) return true;
        } catch (_) {}

        try {
            if (hasSilkTouch) {
                dimension.spawnItem(new ItemStack(blockTypeId, 1), pos);
                return true;
            }
            if (!config.drop) return false;
            const baseCount  = config.dropCount ?? 1;
            const extraRolls = fortuneLevel > 0
                ? Math.max(0, Math.floor(Math.random() * (fortuneLevel + 2)) - 1)
                : 0;
            dimension.spawnItem(new ItemStack(config.drop, baseCount + extraRolls), pos);
            return true;
        } catch (_) {}
        return false;
    }

    // 1 durability per Vein block (Unbreaking aware). Returns true if the tool broke.
    static damageVeinTool(player, slot) {
        try {
            const item = slot.getItem();
            const dur  = item?.getComponent("minecraft:durability");
            if (!dur) return false;
            const unbreaking = item.getComponent("minecraft:enchantable")?.getEnchantment("unbreaking")?.level ?? 0;
            if (unbreaking > 0 && Math.random() >= 1 / (unbreaking + 1)) return false;
            if (dur.damage + 1 >= dur.maxDurability) {
                slot.setItem(undefined);
                player.playSound("random.break");
                return true;
            }
            dur.damage += 1;
            slot.setItem(item);
        } catch (_) {}
        return false;
    }

    // For Hoe crops: only count a neighbor as eligible if it's fully grown
    static isVeinBlockReady(block, config) {
        if (!config.growthState) return true;
        try {
            return block.permutation.getState(config.growthState) >= config.maxGrowth;
        } catch {
            return true;
        }
    }

    static applyLuck(event) {
        const { player, block, brokenBlockPermutation } = event;
        const blockTypeId = brokenBlockPermutation?.type?.id;
        const config      = XP_CONFIG[blockTypeId];
        if (!config || config.type !== "block" || !config.drop) return;

        const equipment    = player.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!mainhandSlot?.hasItem()) return;

        const luck = this.getItemStatValue(player, mainhandSlot, "luck", KEY.luck) + MasteryManager.getBonus(player, "luck");
        if (luck <= 0 || Math.random() * 100 >= luck) return;

        // Bonus drop mirrors a real break of this block: Silk Touch -> the block itself,
        // otherwise the normal drop with the vanilla Fortune multiplier.
        const toolItem  = mainhandSlot.getItem();
        const enchComp  = toolItem?.getComponent("minecraft:enchantable");
        try {
            if (enchComp?.hasEnchantment("silk_touch")) {
                player.dimension.spawnItem(new ItemStack(blockTypeId, 1), block.location);
            } else {
                const mult = LootBonus.fortuneMultiplier(enchComp?.getEnchantment("fortune")?.level ?? 0);
                player.dimension.spawnItem(new ItemStack(config.drop, (config.dropCount ?? 1) * mult), block.location);
            }
        } catch (_) { return; }
        player.onScreenDisplay.setActionBar("§b[Luck] Bonus drop!");
    }
}
