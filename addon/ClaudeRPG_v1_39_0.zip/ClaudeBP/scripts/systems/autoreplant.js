// autoreplant.js -- Auto-Replant. Hooked from the normal break event (first block) and from the Vein loop (neighbors).
// A crop is replanted only when: fully grown, harvested with a Hoe (REQUIRE_HOE), the player is not in Creative,
// the Hoe carries the Re-Crops Rune (chance = the rune's value at its level), the soil is still right, and a seed is available.
import { system, ItemStack, GameMode } from "@minecraft/server";
import { REPLANT } from "../config/qol_config.js";
import { HOE_VEIN_BLOCKS } from "../vein/hoe.js";
import { getToolCategory } from "../config/tool_config.js";
import { runeFxValue } from "../rune/rune_effects.js";
import { CostManager } from "../managers/cost_manager.js";

function allowed(player, toolTypeId) {
    if (REPLANT.ENABLED < 1 || !player?.isValid) return false;
    if (REPLANT.REQUIRE_HOE >= 1 && getToolCategory(toolTypeId) !== "hoe") return false;
    try { if (player.getGameMode() === GameMode.Creative) return false; } catch (_) { return false; }
    return Math.random() * 100 < runeFxValue(player, "replant");   // Re-Crops Rune (Hoe)
}

// Take one seed out of the drops lying around `pos`. Returns true when a seed was taken.
function takeDroppedSeed(dimension, pos, seedId) {
    let items;
    try {
        items = dimension.getEntities({ type: "minecraft:item", location: { x: pos.x + 0.5, y: pos.y + 0.5, z: pos.z + 0.5 }, maxDistance: Math.max(1, REPLANT.DROP_RADIUS) });
    } catch (_) { return false; }
    for (const e of items) {
        let stack;
        try { stack = e.getComponent("minecraft:item")?.itemStack; } catch (_) { continue; }
        if (!stack || stack.typeId !== seedId) continue;
        const loc = e.location, left = stack.amount - 1;
        try {
            e.remove();
            if (left > 0) dimension.spawnItem(new ItemStack(seedId, left), loc);
        } catch (_) { continue; }
        return true;
    }
    return false;
}

function schedule(player, dimension, pos, cropId) {
    const crop = REPLANT.CROPS[cropId];
    if (!crop) return;
    system.runTimeout(() => {
        try {
            const block = dimension.getBlock(pos);
            if (!block || block.typeId !== "minecraft:air") return;                       // something else is there now
            const soil = dimension.getBlock({ x: pos.x, y: pos.y - 1, z: pos.z });
            if (!soil || !crop.soil.includes(soil.typeId)) return;
            let paid = takeDroppedSeed(dimension, pos, crop.seed);
            if (!paid && REPLANT.USE_INVENTORY >= 1 && player.isValid && CostManager.count(player, crop.seed) >= 1) {
                paid = CostManager.consume(player, crop.seed, 1) !== false;
            }
            if (!paid) return;
            block.setType(cropId);
        } catch (_) { /* chunk unloaded: skip */ }
    }, Math.max(1, REPLANT.DELAY_TICKS | 0));
}

export const AutoReplant = {
    // afterEvents.playerBreakBlock
    onBreak(event) {
        const { player, block, brokenBlockPermutation: perm } = event;
        const cropId = perm?.type?.id;
        const crop = REPLANT.CROPS[cropId];
        if (!crop || !block) return;
        const tool = event.itemStackBeforeBreak?.typeId;
        if (!allowed(player, tool)) return;
        const cfg = HOE_VEIN_BLOCKS[cropId];
        try { if (cfg?.growthState && Number(perm.getState(cfg.growthState)) < cfg.maxGrowth) return; } catch (_) { return; }   // not ripe
        schedule(player, block.dimension, block.location, cropId);
    },

    // Vein loop: the block was ripe (checked by Vein) and has just been turned into air.
    afterVein(player, dimension, pos, cropId, toolTypeId) {
        if (!REPLANT.CROPS[cropId] || !allowed(player, toolTypeId)) return;
        schedule(player, dimension, { x: pos.x, y: pos.y, z: pos.z }, cropId);
    },
};
