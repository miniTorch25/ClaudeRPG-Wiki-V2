// admin_ops.js -- the actual admin actions. Shared by the chat commands and the Admin panel.
// Every action returns { ok, text }, writes the Audit Log, and tells the target player when
// someone else changed their data.

import { world } from "@minecraft/server";
import { AdminManager } from "../managers/admin_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { XPManager } from "../managers/xp_manager.js";
import { StatsManager, STAT_CAPS, DEFAULT_STAT_CAP } from "../managers/stats_manager.js";
import { HPManager } from "../managers/hp_manager.js";
import { ManaManager } from "../managers/mana_manager.js";
import { HudManager } from "../managers/hud_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { EVOLUTION, ENCHANTED } from "../config/evolution_config.js";
import { PROGRESSION, PROG_KEYS, PRESTIGE_KEYS } from "../config/progression_config.js";

export const STAT_NAMES = ["str", "def", "agi", "psi", "exc", "mag", "wis", "con", "vit"];
export const MOB_TYPES = [
    "minecraft:zombie", "minecraft:husk", "minecraft:skeleton", "minecraft:stray",
    "minecraft:spider", "minecraft:cave_spider", "minecraft:pillager", "minecraft:vindicator", "minecraft:enderman",
];

const fail = (text) => ({ ok: false, text: `§c${text}` });

// Parses a whole number in [min, max]; returns null when invalid.
export function toInt(raw, min = 0, max = 1000000) {
    const text = String(raw ?? "").trim();
    if (!/^-?\d+(\.\d+)?$/.test(text)) return null;
    const n = Math.round(Number(text));
    return n >= min && n <= max ? n : null;
}

function done(admin, target, what) {
    const who = target && target.id !== admin.id ? ` for ${target.name}` : "";
    AdminManager.log(admin.name, `${what}${who}`);
    if (target && target.id !== admin.id) {
        try { target.sendMessage(`§6[Admin] §f${admin.name} changed your data: ${what}.`); } catch (_) {}
    }
    return { ok: true, text: `§a${what}${who}.` };
}

function refresh(target) {
    try { HPManager.recalcMaxHP(target); } catch (_) {}
    try { HudManager.markDirty(target); } catch (_) {}
}

export const AdminOps = {

    summary(target) {
        const P = ProgressionManager;
        const lines = [
            `§e${target.name}`,
            `§7Level §f${P.getLevel(target)}§8/${P.getMaxLevel(target)}  §7XP §f${Math.floor(StatsManager.getStat(target, "stat_xp", 0))}  §7Points §f${StatsManager.getStat(target, "stat_points", 0)}`,
            `§7Prestige §f${P.getPrestige(target)}  §7Perk picks waiting §f${P.getPendingPerks(target)}  §7Stat caps §fx${P.getStatCapMultiplier(target).toFixed(2)}`,
            "§7Stats §f" + STAT_NAMES.map((s) => `${s} ${StatsManager.getStat(target, `stat_${s}`, 0)}`).join(", "),
            "§7Mastery §f" + Object.keys(MASTERY.LINES).map((l) => `${l} ${MasteryManager.getLevel(target, l)}`).join(", "),
            `§7Unlocked by level §f${target.getDynamicProperty(PROG_KEYS.UNLOCKS) || "none"}`,
            `§7Insomnia §f${target.getDynamicProperty("prog_last_sleep_day") === undefined ? "?" : world.getDay() - target.getDynamicProperty("prog_last_sleep_day")} day(s)`,
            `§7World Ascension §f${P.getAscension()}`,
        ];
        return lines.join("\n");
    },

    // ── Level / XP / Points ──
    level(admin, target, mode, raw) {
        const n = toInt(raw, mode === "add" ? -100000 : 0, 100000);
        if (n === null) return fail("Level must be a whole number (0 - 100000).");
        const next = Math.max(0, mode === "add" ? ProgressionManager.getLevel(target) + n : n);
        XPManager.setLevel(target, next);
        refresh(target);
        return done(admin, target, `Level ${mode === "add" ? "+" + n + " -> " : "set to "}${next}`);
    },
    xp(admin, target, mode, raw) {
        const n = toInt(raw, mode === "add" ? -100000000 : 0, 100000000);
        if (n === null) return fail("XP must be a whole number.");
        const next = Math.max(0, mode === "add" ? StatsManager.getStat(target, "stat_xp", 0) + n : n);
        StatsManager.setStat(target, "stat_xp", next);
        return done(admin, target, `XP ${mode === "add" ? "+" + n + " -> " : "set to "}${next}`);
    },
    points(admin, target, mode, raw) {
        const n = toInt(raw, mode === "add" ? -100000 : 0, 100000);
        if (n === null) return fail("Points must be a whole number.");
        const next = Math.max(0, mode === "add" ? StatsManager.getStat(target, "stat_points", 0) + n : n);
        StatsManager.setStat(target, "stat_points", next);
        return done(admin, target, `Points ${mode === "add" ? "+" + n + " -> " : "set to "}${next}`);
    },
    stat(admin, target, stat, raw) {
        if (!STAT_NAMES.includes(stat)) return fail(`Unknown stat. Use: ${STAT_NAMES.join(", ")}`);
        const n = toInt(raw, 0, 100000);
        if (n === null) return fail("Stat value must be a whole number.");
        StatsManager.setStat(target, `stat_${stat}`, n);
        StatsManager._afterStatMutation(target);
        const cap = StatsManager.getStatCap(stat, target);
        return done(admin, target, `${stat.toUpperCase()} set to ${n}${n > cap ? ` (above its cap ${cap})` : ""}`);
    },
    resetStats(admin, target) {
        StatsManager.resetAllStats(target);
        refresh(target);
        return done(admin, target, "Level, XP, Points and all stats reset");
    },

    // ── Prestige / Perks ──
    prestige(admin, target, raw) {
        const n = toInt(raw, 0, 1000);
        if (n === null) return fail("Prestige must be a whole number (0 - 1000).");
        target.setDynamicProperty(PROG_KEYS.PRESTIGE, n);
        refresh(target);
        return done(admin, target, `Prestige set to ${n} (Max Level ${ProgressionManager.getMaxLevel(target)})`);
    },
    perks(admin, target, mode, raw) {
        const n = toInt(raw, mode === "add" ? -1000 : 0, 1000);
        if (n === null) return fail("Perk picks must be a whole number.");
        const next = Math.max(0, mode === "add" ? ProgressionManager.getPendingPerks(target) + n : n);
        target.setDynamicProperty(PRESTIGE_KEYS.PENDING, next);
        return done(admin, target, `Waiting Perk picks set to ${next}`);
    },
    clearPerks(admin, target) {
        target.setDynamicProperty(PRESTIGE_KEYS.PERKS, "");
        target.setDynamicProperty(PRESTIGE_KEYS.PENDING, 0);
        refresh(target);
        return done(admin, target, "All Perks and waiting picks cleared");
    },

    // ── Mastery ──
    masteryLevel(admin, target, line, raw) {
        if (!MASTERY.LINES[line]) return fail(`Unknown line. Use: ${Object.keys(MASTERY.LINES).join(", ")}`);
        const maxLv = MASTERY.LINES[line].maxLevel;
        const n = toInt(raw, 0, maxLv);
        if (n === null) return fail(`Mastery level must be 0 - ${maxLv}.`);
        MasteryManager.adminSetXp(target, line, MasteryManager.xpForLevel(n, line));
        refresh(target);
        return done(admin, target, `${MASTERY.LINES[line].name} Mastery set to Lv.${n}`);
    },
    masteryPath(admin, target, line, pathId) {
        if (!MASTERY.LINES[line]?.paths) return fail("That line has no paths.");
        const clear = pathId === "none";
        if (!clear && !MASTERY.LINES[line].paths[pathId]) return fail(`Unknown path. Use: none, ${Object.keys(MASTERY.LINES[line].paths).join(", ")}`);
        MasteryManager.adminSetPath(target, line, clear ? null : pathId);
        return done(admin, target, `${MASTERY.LINES[line].name} path set to ${clear ? "none" : pathId}`);
    },
    masteryReroll(admin, target, line) {
        if (!MASTERY.LINES[line]) return fail("Unknown line.");
        MasteryManager.adminRerollSeed(target, line);
        return done(admin, target, `${MASTERY.LINES[line].name} Mastery values re-rolled`);
    },
    masteryXp(admin, target, line, raw) {
        if (!MASTERY.LINES[line]) return fail(`Unknown line. Use: ${Object.keys(MASTERY.LINES).join(", ")}`);
        const n = toInt(raw, -100000000, 100000000);
        if (n === null) return fail("XP must be a whole number.");
        MasteryManager.adminSetXp(target, line, MasteryManager.getXp(target, line) + n);
        return done(admin, target, `${MASTERY.LINES[line].name} Mastery XP ${n >= 0 ? "+" : ""}${n}`);
    },

    // -- Feature unlocks: Prestige / Ascension based now, there are no Level gates any more --
    unlock(admin, target, feature, on) {
        const f = PROGRESSION.FEATURES[feature];
        if (!f) return fail(`Unknown feature. Use: ${Object.keys(PROGRESSION.FEATURES).join(", ")}`);
        return fail(`${f.name} now needs ${ProgressionManager.requirementText(feature)} (Prestige/Ascension). Set Prestige or Ascension instead, or edit the gate in the Config Editor.`);
    },

    // ── Misc player tools ──
    insomnia(admin, target, raw) {
        const n = toInt(raw, 0, 1000);
        if (n === null) return fail("Days must be a whole number.");
        target.setDynamicProperty("prog_last_sleep_day", Math.max(0, world.getDay() - n));
        target.setDynamicProperty("prog_insomnia_level", 0);
        return done(admin, target, `Insomnia set to ${n} day(s)`);
    },
    heal(admin, target) {
        try { HPManager.recalcMaxHP(target); HPManager.setHP(target, HPManager.getMaxHP(target)); } catch (_) {}
        try { ManaManager.setMana(target, ManaManager.getMaxMana(target)); } catch (_) {}
        HudManager.markDirty(target);
        return done(admin, target, "HP and Mana fully restored");
    },

    // ── World tools ──
    ascension(admin, raw) {
        const n = toInt(raw, 0, 1000);
        if (n === null) return fail("Ascension must be a whole number (0 - 1000).");
        const before = ProgressionManager.getAscension();
        world.setDynamicProperty(PROG_KEYS.ASCENSION, n);
        ProgressionManager.invalidateAscension();
        world.setDynamicProperty("prog_ascension_by", admin.name);
        try { world.sendMessage(`§8[Admin] World Ascension is now §c${n}§8.`); } catch (_) {}
        return done(admin, null, `World Ascension ${before} -> ${n}`);
    },
    spawn(admin, tier, typeId, count) {
        if (!EVOLUTION.TIERS[tier] && tier !== "enchanted") return fail(`Unknown tier. Use: ${[...Object.keys(EVOLUTION.TIERS), "enchanted"].join(", ")}`);
        const type = String(typeId).includes(":") ? String(typeId) : `minecraft:${typeId}`;
        const n = toInt(count ?? 1, 1, 10);
        if (n === null) return fail("Count must be 1 - 10.");
        let spawned = 0;
        const loc = admin.location;
        const view = admin.getViewDirection?.() ?? { x: 0, z: 1 };
        for (let i = 0; i < n; i++) {
            try {
                const mob = admin.dimension.spawnEntity(type, { x: loc.x + view.x * 4 + (i - (n - 1) / 2), y: loc.y, z: loc.z + view.z * 4 });
                mob.addTag("crpg_summoned");
                EvolutionManager.makeEvolved(mob, tier);
                spawned++;
            } catch (_) {}
        }
        if (!spawned) return fail(`Could not spawn ${type} here.`);
        return done(admin, null, `Spawned ${spawned}x ${(EVOLUTION.TIERS[tier] ?? ENCHANTED).name} ${type.replace("minecraft:", "")}`);
    },
    purge(admin, radius) {
        const r = toInt(radius ?? 48, 4, 256);
        if (r === null) return fail("Radius must be 4 - 256.");
        let removed = 0;
        try {
            for (const mob of admin.dimension.getEntities({ tags: ["crpg_evo"], location: admin.location, maxDistance: r })) {
                try { mob.remove(); removed++; } catch (_) {}
            }
        } catch (_) {}
        return done(admin, null, `Removed ${removed} evolved mob(s) within ${r} blocks`);
    },

    // ── Config Editor ──
    configSet(admin, id, raw) {
        const e = AdminManager.entry(id);
        if (!e) return fail(`Unknown setting "${id}". Try: /scriptevent status:admin config list`);
        const p = AdminManager.parse(e, raw);
        if (!p.ok) return fail(`${e.label}: ${p.error}`);
        const before = AdminManager.format(e);
        AdminManager.setValue(id, p.value);
        return done(admin, null, `Config ${id}: ${before} -> ${AdminManager.format(e)}`);
    },
    configReset(admin, id) {
        const e = AdminManager.entry(id);
        if (!e) return fail(`Unknown setting "${id}".`);
        AdminManager.resetValue(id);
        return done(admin, null, `Config ${id} reset to default (${AdminManager.format(e)})`);
    },
    configResetAll(admin) {
        const n = AdminManager.resetAll();
        return done(admin, null, `All config overrides reset (${n})`);
    },
};

export { STAT_CAPS, DEFAULT_STAT_CAP };
