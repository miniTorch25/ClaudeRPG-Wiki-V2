// ClaudeRPG AugmentState — runtime-only Augment state.
// ItemStack dynamic properties remain the persistent source of Augment values.
import { RuntimeState } from "../core/runtime_state.js";

function state(playerId) {
    const root = RuntimeState.player(playerId);
    if (!root.augment || typeof root.augment !== "object") root.augment = {};
    return root.augment;
}

function globals() {
    const root = RuntimeState.global("augment");
    if (!(root.suppressRedirect instanceof Set)) root.suppressRedirect = new Set();
    if (!(root.suppressChainOnly instanceof Set)) root.suppressChainOnly = new Set();
    return root;
}

export const AugmentState = {
    get(playerId) { return state(playerId); },
    getEquipmentCache(playerId) { return state(playerId).equipmentCache ?? null; },
    setEquipmentCache(playerId, value) { state(playerId).equipmentCache = value; },
    getSuppressRedirect() { return globals().suppressRedirect; },
    getSuppressChainOnly() { return globals().suppressChainOnly; },
    clearPlayer(playerId) { const root = RuntimeState.peek(playerId); if (root) root.augment = {}; },
    clearAll() {
        const root = RuntimeState.global("augment");
        root.suppressRedirect?.clear();
        root.suppressChainOnly?.clear();
    }
};
