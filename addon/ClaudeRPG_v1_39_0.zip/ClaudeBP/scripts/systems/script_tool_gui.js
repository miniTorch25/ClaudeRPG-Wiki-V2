// script_tool_gui.js -- the Script Tool item (crpg:script_tool).
// One menu that holds every /scriptevent action, so players never type commands.
// Event_router calls the same ScriptActions for the matching scriptevents (single source of truth).

import { ItemStack, EntityComponentTypes, EquipmentSlot, GameMode } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { CONFIG } from "../config/config.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { giveItemSafely } from "../managers/item_helper.js";
import { AdminManager } from "../managers/admin_manager.js";
import { AugmentManager } from "./augment.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { RedeemManager } from "./redeem.js";
import { AdminGui } from "./admin_gui.js";
import { onMenuOpened } from "./achievement_hooks.js";
import { AchievementManager } from "./achievement_manager.js";
import { StashManager } from "./stash_manager.js";

const SCREEN = "systems.script_tool_gui.js";

export const ScriptActions = {
    giveStatsBook(player) {
        const r = giveItemSafely(player, new ItemStack(CONFIG.STATS_BOOK_ITEM, 1));
        player.sendMessage(r.dropped > 0 ? "§aStats Book dropped at your feet (inventory full)!" : "§aYou received the §r§bStats Book§a!");
    },
    giveScriptTool(player) {
        const r = giveItemSafely(player, new ItemStack(CONFIG.SCRIPT_TOOL_ITEM, 1));
        player.sendMessage(r.dropped > 0 ? "§aScript Tool dropped at your feet (inventory full)!" : "§aYou received the §r§6Script Tool§a!");
    },
    openRuneCreative(player, open) {
        if (player.getGameMode() !== GameMode.Creative) player.sendMessage("§c[Rune Tool] This tool only works in Creative Mode!");
        else open("rune_creative");
    },
    rollAdditional(player) {
        const slot = player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!slot?.hasItem()) return player.sendMessage("§cHold an item in your mainhand first!");
        const item = slot.getItem(), req = ITEM_REQUIREMENTS[item.typeId];
        if (!req) return player.sendMessage("§cThis item doesn't support Augment rolls!");
        AugmentManager.rollForType(slot, req.type);
        ItemRestrictionManager.updateSlotLore(slot);
        player.sendMessage(`§aRolled new Augment stats for §e${item.typeId}§a!`);
    },
    resetRedeem(player) {
        RedeemManager.resetAll();
        player.sendMessage("§aAll redeem code usage has been reset! Codes can be redeemed again.");
    },
};

function confirm(player, title, body, onYes) {
    const form = new MessageFormData().title(title).body(body).button1("§cYes, do it").button2("§8Cancel");
    GuiService.show(player, form, SCREEN).then((r) => { if (!r.canceled && r.selection === 0) onYes(); }).catch(() => {});
}

// Menu layout (same idea as the Knowledge Book): a short list of categories, each opening its own page.
function buildCategories(player, open) {
    const isAdmin = AdminManager.isAdmin(player);
    const creative = player.getGameMode() === GameMode.Creative;
    const creativeAdmin = [];
    if (creative) creativeAdmin.push({ label: "§5Rune Creative\n§8[Creative mode: install or give any Rune]", icon: "textures/icons/rune", run: () => ScriptActions.openRuneCreative(player, open) });
    if (isAdmin) {
        creativeAdmin.push(
            { label: "§cAdmin Panel\n§8[Admin tag]",                        icon: "textures/icons/admin",     run: () => AdminGui.openMain(player) },
            { label: "§cRoll Additional Augment\n§8[Admin: item in hand]",  icon: "textures/icons/red_reroll", run: () => ScriptActions.rollAdditional(player) },
            { label: "§cReset Redeem Usage\n§8[Admin: affects everyone]",   icon: "textures/icons/trash_can",  run: () => confirm(player, "§l§cReset Redeem Usage", "§fThis resets redeem code usage for §call players§f. Continue?", () => ScriptActions.resetRedeem(player)) },
        );
    }
    return [
        { id: "char", title: "§bCharacter & Logs", desc: "Your stats, progress and what you have found.", icon: "textures/icons/total_stats", entries: [
            { label: "§bStatus Menu\n§8[Stats, Chorus, Prestige, Mastery]", icon: "textures/icons/total_stats", run: () => open("status") },
            { label: "§dChorus\n§8[Armor element sockets]",                 icon: "textures/icons/chorus",      run: () => open("chorus") },
            { label: "§eAchievements\n§8[Your progress, no rewards]",       icon: "textures/icons/achievement", run: () => open("achievements") },
            { label: "§bDiscovery Log\n§8[Biomes, structures, dimensions]",  icon: "textures/icons/discovery",   run: () => open("discovery") },
            { label: "§bWaypoints\n§8[Saved stones: sort, remove]",          icon: "textures/icons/waypoint",    run: () => open("waypoints") },
        ] },
        { id: "gear", title: "§9Gear & Enchanting", desc: "Make your weapons, tools and armor stronger.", icon: "textures/icons/gem", entries: [
            { label: "§9Gem / Ultimate Enchant\n§8[Carve, engrave, socket]", icon: "textures/icons/gem",         run: () => open("gem") },
            { label: "§6Reforge\n§8[Augments, Gem Fusion, Salvage, Rune]",  icon: "textures/icons/blue_reroll", run: () => open("reforge") },
        ] },
        { id: "util", title: "§aUtilities", desc: "Everyday helpers.", icon: "textures/icons/gear", entries: [
            { label: "§aQuick Stash\n§8[Move items into nearby chests]",   icon: "textures/icons/stash",       run: () => { const r = StashManager.run(player); player.sendMessage(r.ok ? `§b[Stash] §f${r.message}` : `§e[Stash] ${r.message}`); } },
            { label: "§eRedeem Code\n§8[Enter a code]",                     icon: "textures/icons/progression", run: () => open("redeem") },
            { label: "§dToast Composer\n§8[Send a pop-up to yourself or others]", icon: "textures/icons/ach/TDSC", run: () => open("toast") },
            { label: "§7Settings\n§8[Personal on/off switches]",            icon: "textures/icons/gear",        run: () => open("settings") },
        ] },
        { id: "guide", title: "§aGuides & Items", desc: "Learn the game and get your books.", icon: "textures/items/knowledge_book", entries: [
            { label: "§aGuide Quest\n§8[Step-by-step: what to do next]",       icon: "textures/icons/progression",   run: () => open("guide") },
            { label: "§aKnowledge Book\n§8[How everything works]",          icon: "textures/items/knowledge_book", run: () => open("knowledge") },
            { label: "§bGet Stats Book\n§8[Receive the item]",              icon: "textures/items/stats_book",  run: () => ScriptActions.giveStatsBook(player) },
        ] },
        { id: "admin", title: "§5Creative & Admin", desc: "Only shown in Creative mode or to Admins.", icon: "textures/icons/admin", entries: creativeAdmin },
    ].filter((c) => c.entries.length > 0);
}

export const ScriptToolGui = {
    // open(route) = GuiRouter.open bound to this player (passed in to avoid an import cycle).
    openMain(player, open) {
        onMenuOpened(player, "script_tool"); AchievementManager.event(player, "script_tool_used");
        const cats = buildCategories(player, open);
        const form = new ActionFormData().title("§l§6SCRIPT TOOL").body("§7Every command in one place. No typing needed.\n§8Pick a category.");
        for (const c of cats) form.button(`${c.title}\n§8${c.desc}`, c.icon);
        form.button("§8Close");
        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled || r.selection >= cats.length) return;
            this.openCategory(player, open, cats[r.selection].id);
        }).catch((e) => console.warn(`[ScriptTool] ${e}`));
    },

    openCategory(player, open, id) {
        const cat = buildCategories(player, open).find((c) => c.id === id);
        if (!cat) return this.openMain(player, open);
        const form = new ActionFormData().title(`§l${cat.title}`).body(`§7${cat.desc}`);
        for (const e of cat.entries) form.button(e.label, e.icon);
        form.button("§8< Back", "textures/icons/back");
        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            if (r.selection >= cat.entries.length) return this.openMain(player, open);
            cat.entries[r.selection].run();
        }).catch((e) => console.warn(`[ScriptTool] ${e}`));
    },
};
