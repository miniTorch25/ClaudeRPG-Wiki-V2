// chorus_manager.js — Chorus core logic (storage + set computation).
//
// Persistent data lives on the armor ItemStack / slot dynamic properties:
//   chorus_tier : "echo" | "resonance" | "transcend" | "awaken" | "melodious" | "genesis"   (locked by first element)
//   chorus_e1   : element id  (socket #1)
//   chorus_e2   : element id  (socket #2)
//
// `item` params accept anything with get/setDynamicProperty (ItemStack or
// ContainerSlot). No gameplay effects live here — see chorus_effects.js (Phase 2).

import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import {
    CHORUS_SLOTS_PER_ITEM, CHORUS_THRESHOLDS, CHORUS_MAX_SLOTS,
    CHORUS_TIERS, CHORUS_ELEMENTS, CHORUS_HYBRIDS, CHORUS_FUSION, hybridKey,
} from "../config/chorus_config.js";

const PROP_TIER = "chorus_tier";
const PROP_E    = (i) => `chorus_e${i + 1}`;
const PROP_LOCK = (i) => `chorus_lock${i + 1}`;
const PROP_HYBRID = "chorus_hybrid";   // player setting; anything but false = Hybrid mixing is ON

const ARMOR_EQUIP_SLOTS = [
    [EquipmentSlot.Head,  "head"],
    [EquipmentSlot.Chest, "chest"],
    [EquipmentSlot.Legs,  "legs"],
    [EquipmentSlot.Feet,  "feet"],
];

export const ChorusManager = {

    // ─── Eligibility ─────────────────────────────────────────────────────────

    // Armor pieces only — the shield (offhand) has no Chorus slots.
    isEligibleType(typeId) {
        const req = ITEM_REQUIREMENTS[typeId];
        return !!req && req.type === "armor" && req.slot !== "offhand";
    },

    // ─── Item storage ────────────────────────────────────────────────────────

    getTier(item) {
        const t = item?.getDynamicProperty?.(PROP_TIER);
        return typeof t === "string" && CHORUS_TIERS[t] ? t : null;
    },

    getElement(item, index) {
        const e = item?.getDynamicProperty?.(PROP_E(index));
        return typeof e === "string" && CHORUS_ELEMENTS[e] ? e : null;
    },

    getElements(item) {
        return Array.from({ length: CHORUS_SLOTS_PER_ITEM }, (_, i) => this.getElement(item, i));
    },

    hasAnyElement(item) {
        return this.getElements(item).some(Boolean);
    },

    // Returns true on success. Fails if the element's tier conflicts with the
    // tier already locked in by the piece's other socket.
    setElement(item, index, elementId) {
        const def = CHORUS_ELEMENTS[elementId];
        if (!def || index < 0 || index >= CHORUS_SLOTS_PER_ITEM) return false;
        const otherFilled = this.getElements(item).some((e, i) => i !== index && e);
        const lockedTier  = otherFilled ? this.getTier(item) : null;
        if (lockedTier && lockedTier !== def.tier) return false;
        item.setDynamicProperty(PROP_TIER, def.tier);
        item.setDynamicProperty(PROP_E(index), elementId);
        return true;
    },

    clearElement(item, index) {
        item.setDynamicProperty(PROP_E(index), undefined);
        item.setDynamicProperty(PROP_LOCK(index), undefined);
        if (!this.hasAnyElement(item)) item.setDynamicProperty(PROP_TIER, undefined);
    },

    // ─── Locks & rolling ─────────────────────────────────────────────────────

    isLocked(item, index) {
        return item?.getDynamicProperty?.(PROP_LOCK(index)) === true && !!this.getElement(item, index);
    },

    // Only a socket that holds an element can be locked.
    setLocked(item, index, locked) {
        if (!this.getElement(item, index)) return false;
        if (locked && this.isFused(item)) return false;   // Awaken+ pieces cannot be locked
        item.setDynamicProperty(PROP_LOCK(index), locked ? true : undefined);
        return true;
    },

    // Tier the piece is bound to by its locked sockets (null = free to pick any tier).
    getForcedTier(item) {
        const anyLocked = Array.from({ length: CHORUS_SLOTS_PER_ITEM }, (_, i) => this.isLocked(item, i)).some(Boolean);
        return anyLocked ? this.getTier(item) : null;
    },

    // Sockets a roll would re-roll (everything that is not locked).
    getRollTargets(item) {
        const out = [];
        for (let i = 0; i < CHORUS_SLOTS_PER_ITEM; i++) if (!this.isLocked(item, i)) out.push(i);
        return out;
    },

    // Random element of `tier` for every unlocked socket. Returns [{ index, elementId }], or null
    // when the tier is not allowed (a locked socket binds the piece to another tier) or nothing
    // can be rolled.
    roll(item, tier, random = Math.random) {
        if (!CHORUS_TIERS[tier] || CHORUS_TIERS[tier].fusion) return null;   // fusion tiers are never rolled
        if (this.isFused(item)) return null;                                 // a fused piece cannot be rolled
        const forced = this.getForcedTier(item);
        if (forced && forced !== tier) return null;
        const targets = this.getRollTargets(item);
        if (targets.length === 0) return null;
        const pool = Object.keys(CHORUS_ELEMENTS).filter((id) => CHORUS_ELEMENTS[id].tier === tier);
        if (pool.length === 0) return null;

        item.setDynamicProperty(PROP_TIER, tier);
        const results = [];
        for (const index of targets) {
            const elementId = pool[Math.min(pool.length - 1, Math.floor(random() * pool.length))];
            item.setDynamicProperty(PROP_E(index), elementId);
            results.push({ index, elementId });
        }
        return results;
    },

    // ─── Fusion (Awaken / Melodious / Genesis) ───────────────────────────────

    // True when the piece holds an Awaken-or-higher element (cannot be rolled or locked).
    isFused(item) {
        const t = this.getTier(item);
        return !!t && CHORUS_TIERS[t].fusion === true && this.hasAnyElement(item);
    },

    // Which element would Fusion create from these 1 or 2 armor items? Returns the element id or null.
    //   1 item : its 2 sockets must be two DIFFERENT elements forming a pieces:1 recipe.
    //   2 items: each item must have BOTH sockets on one element; the two elements form a pieces:2 recipe.
    fusionTarget(items) {
        if (!Array.isArray(items) || items.length < 1 || items.length > 2) return null;
        const sameSet = (from, a, b) => (from[0] === a && from[1] === b) || (from[0] === b && from[1] === a);
        if (items.length === 1) {
            const [a, b] = this.getElements(items[0]);
            if (!a || !b || a === b) return null;
            for (const [id, r] of Object.entries(CHORUS_FUSION)) {
                if (r.pieces === 1 && sameSet(r.from, a, b)) return id;
            }
            return null;
        }
        const uniform = (it) => {
            const [a, b] = this.getElements(it);
            return a && a === b ? a : null;
        };
        const x = uniform(items[0]);
        const y = uniform(items[1]);
        if (!x || !y || x === y) return null;
        for (const [id, r] of Object.entries(CHORUS_FUSION)) {
            if (r.pieces === 2 && sameSet(r.from, x, y)) return id;
        }
        return null;
    },

    // Applies Fusion: every socket of every given item becomes `targetId`, the tier is re-bound and
    // all locks are cleared. Returns false (and changes nothing) if the items do not form that recipe.
    fuse(items, targetId) {
        if (!CHORUS_ELEMENTS[targetId] || this.fusionTarget(items) !== targetId) return false;
        const tier = CHORUS_ELEMENTS[targetId].tier;
        for (const item of items) {
            item.setDynamicProperty(PROP_TIER, tier);
            for (let i = 0; i < CHORUS_SLOTS_PER_ITEM; i++) {
                item.setDynamicProperty(PROP_E(i), targetId);
                item.setDynamicProperty(PROP_LOCK(i), undefined);
            }
        }
        return true;
    },

    // ─── Player setting: Hybrid mixing ───────────────────────────────────────

    isHybridEnabled(player) {
        return player?.getDynamicProperty?.(PROP_HYBRID) !== false;
    },

    setHybridEnabled(player, enabled) {
        player.setDynamicProperty(PROP_HYBRID, enabled ? undefined : false);
    },

    // Tier the piece is locked to when socket `index` is edited (null = free choice).
    getLockedTierFor(item, index) {
        const otherFilled = this.getElements(item).some((e, i) => i !== index && e);
        return otherFilled ? this.getTier(item) : null;
    },

    // ─── Set computation ─────────────────────────────────────────────────────

    // entries: [{ elements: [id|null, id|null] }, ...]  (one per armor piece)
    // Returns { totalSlots, sets: [...] } sorted by count (desc).
    // set = { id, kind: "single"|"hybrid", name, color, elements[], parts{id:n}, unpaired, count, reached[] }
    // opts.hybrid === false: two different same-tier elements are NOT merged into a hybrid set;
    // each element then counts on its own as a single set.
    computeSets(entries, opts = {}) {
        const allowHybrid = opts.hybrid !== false;
        const counts = {};
        for (const entry of entries) {
            for (const e of entry.elements ?? []) {
                if (e && CHORUS_ELEMENTS[e]) counts[e] = (counts[e] ?? 0) + 1;
            }
        }
        const ids = Object.keys(counts);
        const totalSlots = ids.reduce((n, id) => n + counts[id], 0);
        const sets = [];

        const reachedOf = (count) => CHORUS_THRESHOLDS.filter((t) => count >= t);

        // Hybrids exist only for Echo / Resonance / Transcend. Awaken and above never merge: each counts alone.
        if (allowHybrid && ids.length === 2 && CHORUS_ELEMENTS[ids[0]].tier === CHORUS_ELEMENTS[ids[1]].tier
            && !CHORUS_TIERS[CHORUS_ELEMENTS[ids[0]].tier].fusion) {
            const [a, b] = ids;
            const key = hybridKey(a, b);
            const hybrid = CHORUS_HYBRIDS[key];
            const count = Math.min(counts[a], counts[b]) * 2;
            sets.push({
                id: key, kind: "hybrid",
                name: hybrid?.name ?? `${CHORUS_ELEMENTS[a].label}+${CHORUS_ELEMENTS[b].label}`,
                color: "§d",
                elements: hybrid?.elements ?? [a, b].sort(),
                parts: { [a]: counts[a], [b]: counts[b] },
                unpaired: Math.abs(counts[a] - counts[b]),
                count, reached: reachedOf(count),
            });
        } else {
            for (const id of ids) {
                const def = CHORUS_ELEMENTS[id];
                sets.push({
                    id, kind: "single", name: def.label, color: def.color,
                    elements: [id], parts: { [id]: counts[id] }, unpaired: 0,
                    count: counts[id], reached: reachedOf(counts[id]),
                });
            }
        }
        sets.sort((x, y) => y.count - x.count);
        return { totalSlots, sets };
    },

    // ─── Player loadout ──────────────────────────────────────────────────────

    // [{ name: "head", item: ItemStack|null, elements: [..] }, ...]
    getPlayerPieces(player) {
        const eq = player?.getComponent(EntityComponentTypes.Equippable);
        return ARMOR_EQUIP_SLOTS.map(([es, name]) => {
            let item = null;
            try {
                const slot = eq?.getEquipmentSlot(es);
                item = slot?.hasItem() ? slot.getItem() : null;
            } catch { item = null; }
            const ok = item && this.isEligibleType(item.typeId);
            return { name, item: ok ? item : null, elements: ok ? this.getElements(item) : [null, null] };
        });
    },

    getPlayerSets(player) {
        return this.computeSets(this.getPlayerPieces(player), { hybrid: this.isHybridEnabled(player) });
    },

    // Convenience for Phase 2 effects: is `setId` at or above `threshold`?
    hasEffect(player, setId, threshold) {
        const { sets } = this.getPlayerSets(player);
        return sets.some((s) => s.id === setId && s.count >= threshold);
    },

    MAX_SLOTS: CHORUS_MAX_SLOTS,
};
