// gem_lore.js — builds the in-game lore lines shown under an enchanted Gem
// socket on armor, describing what the installed skill does.
//
// Format per skill (varies by what's relevant, same shape as rune_lore.js):
//
//   §r§8<Flavour / effect description>
//   §r§7Cost: §f<Mana cost>            (if any)
//   §r§7Cooldown: §f<Xs>               (if any)
//   §r§7Stacks: §f<n>/<max>            (live counters, e.g. Guardian Shield)
//
// player is optional — pass it to include live counter values (stacks,
// cooldown remaining). All other lines are static from GEM_ABILITY_CONFIG.

import { Synergy } from "./synergy.js";
import { getScaledGemConfig } from "../config/gem_ability_config.js";
import { wrapLoreLines } from "../config/lore_wrap.js";
import { normalizeGemAbility, GEM_DEFS } from "./gem_registry.js";
import { GemState } from "./gem_state.js";
import { CooldownManager } from "../managers/cooldown_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";

// % glyph used across the addon's lore ("\uE21F")
const P = (v) => `${v}\uE21F`;
const line = (t) => `§r§8${t}`;
const cd = (sec) => `§r§7Cooldown: §f${sec}s`;

// One entry per ability key (84). cfg = this ability's config, scaled by the player's Gem Potency.
const GEM_LORE_DEFS = {
    // ===== Tier 1 · Common =====
    vitality: (c) => [line(`+${c.maxHpBonus} Max HP.`)],
    swiftness: (c) => [line(`+${P(c.speedPct)} movement speed.`)],
    toughness: (c) => [line(`-${P(c.dmgReduction)} damage taken.`)],
    recovery: (c) => [line(`Regenerate +${c.regenBonus} HP/s.`)],
    keen_eyes: () => [line("Permanent Night Vision.")],
    marksman: (c) => [line(`+${P(c.rangedBonus)} ranged damage.`)],
    focus: (c) => [line(`+${c.maxMana} Max Mana.`)],
    mana_trickle: (c) => [line(`Regenerate +${c.manaRegen} Mana/s.`)],
    padded_plate: (c) => [line(`-${P(c.projReduction)} damage taken from projectiles.`)],
    brawler: (c) => [line(`+${P(c.meleeBonus)} melee damage.`)],
    sure_step: (c) => [line(`-${P(c.knockbackReduction)} knockback taken.`)],
    soft_landing: (c) => [line(`-${P(c.fallReduction)} fall damage.`)],

    // ===== Tier 2 · Uncommon =====
    hearty: (c) => [line(`+${c.maxHpBonus} Max HP.`)],
    vigor: (c) => [line(`Regenerate +${c.regenBonus} HP/s.`)],
    tenacity: (c) => [line(`Below ${P(c.hpThresholdPct)} HP: -${P(c.dmgReduction)} damage taken.`)],
    intuition: (c) => [line(`+${P(c.dodge)} Dodge.`)],
    spell_ward: (c) => [line(`-${P(c.magicReduction)} Magic, Poison and Wither damage taken.`)],
    clear_mind: (c) => [line(`Regenerate +${c.manaRegen} Mana/s.`)],
    eagle_eye: (c) => [line(`+${P(c.rangedBonus)} ranged damage.`)],
    aqua_lung: () => [line("Breathe underwater without limit and see clearly while submerged.")],
    stoneskin: (c) => [line(`-${P(c.meleeReduction)} melee damage taken.`)],
    brute_force: (c) => [line(`+${P(c.meleeBonus)} melee damage.`)],
    thorns: (c) => [line(`Melee attackers take ${c.damage} damage back.`)],
    marathon: (c) => [line(`-${P(c.hungerReduction)} hunger from sprinting.`)],

    // ===== Tier 3 · Rare =====
    fortitude: (c) => [line(`+${c.maxHpBonus} Max HP.`)],
    adrenaline: (c) => [line(`Below ${P(c.hpThresholdPct)} HP: +${P(c.meleeBonus)} melee damage.`)],
    resolve: (c) => [line(`-${P(c.dmgReduction)} damage taken.`)],
    swift_strides: (c) => [line(`+${P(c.speedPct)} movement speed.`)],
    assassination: (c) => [line(`+${P(c.sneakBonus)} damage dealt while sneaking.`)],
    arcane_reservoir: (c) => [line(`+${c.maxMana} Max Mana and +${c.manaRegen} Mana/s.`)],
    spellbreaker: (c) => [line(`-${P(c.magicFireReduction)} Magic and Fire damage taken.`)],
    reflexes: (c) => [line(`+${P(c.dodge)} Dodge.`)],
    sanctuary: (c) => [line(`Sneaking and standing still: -${P(c.dmgReduction)} damage taken and +${c.healPerSec} HP/s.`)],
    plate_wall: (c) => [line(`-${P(c.projReduction)} damage taken from projectiles.`)],
    cats_grace: (c) => [line(`No fall damage from up to ${c.safeFallBlocks} blocks.`)],
    killers_rush: (c) => [line(`Killing an enemy grants Speed II for ${c.speedSeconds}s.`)],

    // ===== Tier 4 · Unique =====
    arcane_surge: (c) => [line(`+${c.maxMana} Max Mana and +${c.manaRegen} Mana/s.`)],
    clairvoyance: (c) => [line(`Night Vision, and hostile mobs within ${c.radius} blocks glow.`)],
    spell_mirror: (c) => [line(`${P(c.chance)} chance to reflect Magic attacks back at the attacker.`)],
    reflection: (c) => [line(`${P(c.chance)} chance (${P(c.shieldChance)} while holding a shield) to reflect damage back at the attacker.`)],
    second_wind: (c) => [line(`Below ${P(c.hpThresholdPct)} HP: heal ${c.healAmount} HP.`), cd(c.cooldownSec)],
    glacial_presence: (c) => [line(`Frost aura slows enemies within ${c.radius} blocks; heals you while standing in Powder Snow.`)],
    cinderveil: (c) => [line(`Fire aura burns and slows nearby enemies; you gain Fire Resistance.`)],
    warpath: (c) => [line(`Hits within ${c.windowSec}s of each other stack +${P(c.perStack)} damage (max ${c.maxStacks} stacks).`)],
    executioners_gait: (c) => [line(`+${P(c.dmgBonus)} damage against targets below ${P(c.hpThresholdPct)} HP.`)],
    wind_walker: (c) => [line(`+${P(c.speedPct)} movement speed. No fall damage from up to ${c.safeFallBlocks} blocks.`)],
    frost_walker: () => [line("Water under your feet freezes. Immune to Powder Snow freezing.")],
    evasion: (c) => [line(`+${P(c.dodge)} Dodge. A successful dodge grants Speed II for ${c.speedSeconds}s.`)],

    // ===== Tier 5 · Legend =====
    immunity: (c) => [line("Sneak twice: cleanse all negative effects."), cd(c.cooldownSec)],
    lucid_mind: (c) => [line(`-${P(c.cooldownReduction)} cooldown on Runes and Gems.`)],
    soulward: (c) => [line(`-${P(c.magicReduction)} Magic damage taken. Immune to Wither.`)],
    guardian_shield: (c, player) => {
        const lines = [line(`Gains a shield stack every ${c.chargeSec}s (max ${c.maxStacks}). Each stack absorbs ${c.absorb} damage.`)];
        if (player) lines.push(`§r§7Stacks: §f${GemState.getGuardianStacks(player.id)}/${c.maxStacks}`);
        return lines;
    },
    bulletproof: (c) => [line(`-${P(c.dmgReduction)} damage taken from projectiles.`)],
    unyielding: (c) => [line(`A single hit can never deal more than ${P(c.maxHitPct)} of your Max HP.`)],
    bloodthirst: (c) => [line(`Heal ${P(c.lifestealPct)} of melee damage dealt.`)],
    overpower: (c) => [line(`+${P(c.meleeBonus)} melee damage and ignore ${P(c.armorPenPct)} of enemy armor.`)],
    momentum_strike: (c) => [line(`Sprinting builds +${P(c.perSec)} damage per second (max +${P(c.maxBonus)}), kept for ${c.lingerSec}s after you stop.`)],
    void_escape: () => [line("Falling below the void teleports you back to your spawn.")],
    skystep: () => [line("Jump a second time in mid-air (Double Jump).")],
    quicksilver: (c) => [line(`When hit: +${P(c.speedPct)} movement speed for ${c.seconds}s.`)],

    // ===== Tier 6 · Epic =====
    archmages_crown: (c) => [line(`+${c.maxMana} Max Mana and +${c.manaRegen} Mana/s.`)],
    premonition: (c) => [line(`Every ${c.intervalSec}s the first incoming attack is dodged automatically.`)],
    dragons_gaze: (c) => [line(`+${P(c.rangedBonus)} ranged damage and ignore ${P(c.armorPenPct)} of enemy armor.`)],
    frostflare: (c) => [line(`Fire + ice aura (${c.radius} blocks): slows, burns and freezes enemies. You are immune to fire and heal in fire / Powder Snow.`)],
    static_field: (c) => [line(`Deals ${c.damage} damage to every enemy within ${c.radius} blocks every ${c.intervalSec}s.`)],
    titan_heart: (c) => [line(`+${c.maxHpBonus} Max HP and +${c.regenBonus} HP/s.`)],
    vampirism: (c) => [line(`Heal ${P(c.lifestealPct)} of melee damage dealt.`)],
    rampage: (c) => [line(`Each kill: +${P(c.perKill)} damage for ${c.seconds}s (stacks up to ${c.maxStacks}).`)],
    thunder_stride: (c) => [line(`Hitting while sprinting releases a shockwave: ${c.damage} damage, ${c.radius}-block radius.`), cd(c.cooldownSec)],
    flight: (c) => [line("Grants Flight while this armor is worn."), `§r§7Cost: §f${c.manaPerSec} Mana/s while flying`],
    phase_step: (c) => [line(`When hit: ${P(c.chance)} chance to dodge and blink ${c.distance} blocks away.`), cd(c.cooldownSec)],
    earthshaker: (c) => [line(`Landing from ${c.minHeight}+ blocks: no fall damage and a shockwave of ${c.damage} damage (${c.radius}-block radius).`)],

    // ===== Tier 7 · Mythical =====
    ascended_mind: (c) => [line(`+${c.maxMana} Max Mana, +${c.manaRegen} Mana/s and -${P(c.manaCostReduction)} Mana cost on every skill.`)],
    mind_over_matter: (c) => [line(`${P(c.absorbPct)} of damage taken is paid with Mana 1:1 until your Mana runs out.`)],
    third_eye: (c) => [line(`Immune to Blindness, Darkness and Nausea. Enemies within ${c.radius} blocks glow and take +${P(c.extraDamagePct)} damage.`)],
    undying: (c) => [line("Cheats death once, healing to full when HP drops critically low."), cd(c.cooldownSec)],
    colossus: (c) => [line(`+${c.maxHpBonus} Max HP and -${P(c.dmgReduction)} damage taken, always active.`)],
    domain: (c) => [line(`[Sneak] Pushes hostile mobs within ${c.radius} blocks away and deals ${c.damage} damage.`), cd(c.cooldownSec)],
    berserker: (c) => [line(`Below ${P(c.hpThresholdPct)} HP: +${P(c.dmgBonus)} damage dealt and -${P(c.dmgReduction)} damage taken.`)],
    warlords_might: (c) => [line(`+${P(c.meleeBonus)} melee damage. Every ${c.stunEvery}th hit on a target stuns it for ${c.stunSec}s.`)],
    reapers_due: (c) => [line(`Killing an enemy restores ${P(c.healPct)} of your Max HP.`)],
    godspeed: (c) => [line(`+${P(c.speedPct)} movement speed. Immune to Slowness.`)],
    voidstep: (c) => [line(`Sneak twice: teleport ${c.distance} blocks forward.`), cd(c.cooldownSec)],
    earthbound: () => [line("You cannot be knocked back and take no fall damage.")],
};

// ─── Public API ───────────────────────────────────────────────────────────────

// Builds the extra lore lines for one enchanted Gem socket's skill.
// skillName is the display name as stored on the item (e.g. "Second Wind").
// player is optional — pass it to include live counter values.
// Returns an array of lore strings (empty if the skill has no definition).
export function buildGemSkillLoreLines(skillName, player = null) {
    if (!skillName) return [];
    const key   = normalizeGemAbility(skillName);
    const defFn = GEM_LORE_DEFS[key];
    if (!defFn) return [];
    const cfg = getScaledGemConfig(key, player ? MasteryManager.getGemPotency(player) : 0) ?? {};
    const aff = Synergy.affinityLine("gem", key);
    const stack = GEM_DEFS[key]?.stackable ? [`§r§8Stacks across armor pieces.`] : [];
    return [...wrapLoreLines([...defFn(cfg, player), ...stack]), ...(aff ? [aff] : [])];
}
