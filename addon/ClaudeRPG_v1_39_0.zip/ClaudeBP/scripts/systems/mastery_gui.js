// mastery_gui.js -- Mastery overview, per-line detail, path choice and ability on/off.
// Back navigation uses callbacks so this file never imports the menu that opens it.

import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { GuiService } from "../gui/gui_service.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { onMenuOpened } from "./achievement_hooks.js";

const SCREEN = "systems.mastery_gui.js";

function bar(into, need, len = 10) {
    const filled = need > 0 ? Math.min(len, Math.floor((into / need) * len)) : len;
    return `§a${"|".repeat(filled)}§8${"|".repeat(len - filled)}`;
}

function num(v) { return Math.round(v * 100) / 100; }
function fmt(v, unit = "") { const n = num(v); return `${n >= 0 ? "+" : ""}${n}${unit}`; }

// 1234567 -> "1,234,567" (total XP score can grow without limit after max level)
function bigNum(v) { return Math.floor(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); }

function pathName(line, pathId) { return MASTERY.LINES[line]?.paths?.[pathId]?.name ?? "-"; }

function progressText(player, line) {
    const p = MasteryManager.getProgress(player, line);
    const max = MASTERY.LINES[line].maxLevel;
    if (p.max) return `Lv.${p.level}§8/${max}  §6MAX §8| §7Total XP: §f${bigNum(MasteryManager.getXp(player, line))}`;
    return `Lv.${p.level}§8/${max}  ${bar(p.into, p.need)} §8${p.into}/${p.need}`;
}

export const MasteryGui = {
    // ─── Overview ─────────────────────────────────────────────────────────────
    openMenu(player, onBack = null) {
        onMenuOpened(player, "mastery");
        const lines = Object.entries(MASTERY.LINES);
        const form = new ActionFormData()
            .title("§l§bMASTERY")
            .body("§8Permanent. Prestige never resets Mastery.\n§7Values grow at random each level and reach their full amount at max level.");
        for (const [line, def] of lines) {
            if (!MasteryManager.isUnlocked(player, line)) {
                form.button(`§8${def.name} §c[Locked]\n§8${MasteryManager.requirementText(line)}`, "textures/icons/lock");
                continue;
            }
            const lv = MasteryManager.getLevel(player, line);
            const path = def.paths ? MasteryManager.getPath(player, line) : null;
            const tag = def.paths ? (path ? ` §8[${pathName(line, path)}]` : " §e[Pick a path]") : "";
            form.button(`${def.icon}${def.name} §fLv.${lv}§8/${def.maxLevel}${tag}\n§8${def.gain}`, `textures/icons/mastery_lines/${line}`);
        }
        form.button("§8< Back", "textures/icons/back");
        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            if (r.selection >= lines.length) { if (onBack) onBack(); return; }
            const [line] = lines[r.selection];
            if (!MasteryManager.isUnlocked(player, line)) {
                player.sendMessage(`§c[Mastery] ${MASTERY.LINES[line].name} unlocks at ${MasteryManager.requirementText(line)}.`);
                return this.openMenu(player, onBack);
            }
            this.openLine(player, line, () => this.openMenu(player, onBack));
        }).catch((e) => console.warn(`[Mastery] Menu error: ${e}`));
    },

    // ─── One line ─────────────────────────────────────────────────────────────
    openLine(player, line, onBack) {
        const def = MASTERY.LINES[line];
        const d = MasteryManager.describeLine(player, line);
        const body = [`${def.icon}§l${def.name}§r  ${progressText(player, line)}`, `§8Gain: ${def.gain}`, ""];

        if (def.paths) {
            body.push(d.path ? `§7Path: §f${pathName(line, d.path)}` : "§ePick a path to activate this Mastery's bonuses.");
            const wait = MasteryManager.pathCooldownLeft(player, line);
            if (wait > 0) body.push(`§8Path change ready in ${wait}s`);
            body.push("");
        }
        if (d.rows.length) {
            body.push("§7Abilities (now / full):");
            for (const r of d.rows) {
                body.push(`  §f${r.name}: §a${fmt(r.value, r.unit)} §8/ ${fmt(r.full, r.unit)}${r.enabled ? "" : " §c[OFF]"}`);
            }
        }
        if (d.unlocks.length) {
            body.push("", "§7Unlocks:");
            for (const u of d.unlocks) body.push(`  ${u.open ? "§a✔ " : "§8🔒 "}${u.name} §8(Lv.${u.level})`);
        }

        const form = new ActionFormData().title(`§l${def.icon}${def.name}`).body(body.join("\n"));
        const actions = [];
        if (def.paths) { form.button(d.path ? `§bChange Path\n§8[${pathName(line, d.path)}]` : "§eChoose Path"); actions.push("path"); }
        if (d.rows.some((r) => r.toggle)) { form.button("§aAbilities On/Off\n§8[Switch bonuses]"); actions.push("toggle"); }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            const act = actions[r.selection];
            if (act === "path") return this.openPath(player, line, onBack);
            if (act === "toggle") return this.openToggles(player, line, onBack);
            if (onBack) onBack();
        }).catch((e) => console.warn(`[Mastery] Line error: ${e}`));
    },

    // ─── Path choice ──────────────────────────────────────────────────────────
    openPath(player, line, onBack) {
        const def = MASTERY.LINES[line];
        const cur = MasteryManager.getPath(player, line);
        const ids = Object.keys(def.paths);
        const body = ["§7Pick ONE path. Changing is free (1 minute between changes).", "§8Your Mastery level carries over to any path.", ""];
        for (const id of ids) {
            const p = def.paths[id];
            body.push(`§f${p.name}${id === cur ? " §a(active)" : ""} §8- ${p.desc ?? ""}`);
            for (const e of Object.values(p.effects)) body.push(`  §7${e.name}: §f${fmt(e.max, e.unit)}§8 at max`);
        }
        const form = new ActionFormData().title(`§l${def.icon}${def.name} Path`).body(body.join("\n"));
        for (const id of ids) form.button(`${id === cur ? "§a✔ " : "§f"}${def.paths[id].name}`);
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SCREEN).then((r) => {
            if (r.canceled) return;
            if (r.selection >= ids.length) return this.openLine(player, line, onBack);
            const res = MasteryManager.setPath(player, line, ids[r.selection]);
            if (res.ok) {
                player.sendMessage(`§b[Mastery] ${def.name} path: §f${pathName(line, ids[r.selection])}`);
                player.playSound("random.orb");
            } else if (res.reason === "cooldown") {
                player.sendMessage(`§c[Mastery] You can change path again in ${res.wait}s.`);
            } else if (res.reason !== "same") {
                player.sendMessage("§c[Mastery] Cannot change path right now.");
            }
            this.openLine(player, line, onBack);
        }).catch((e) => console.warn(`[Mastery] Path error: ${e}`));
    },

    // ─── Ability on/off ───────────────────────────────────────────────────────
    openToggles(player, line, onBack) {
        const def = MASTERY.LINES[line];
        const rows = MasteryManager.describeLine(player, line).rows.filter((r) => r.toggle);
        const form = new ModalFormData().title(`§l${def.icon}${def.name} Abilities`);
        for (const r of rows) form.toggle(`${r.name} (${fmt(r.value, r.unit)})`, { defaultValue: r.enabled });
        GuiService.show(player, form, SCREEN).then((r) => {
            if (!r.canceled && r.formValues) {
                rows.forEach((row, i) => MasteryManager.setEffectEnabled(player, line, row.path, row.id, !!r.formValues[i]));
                player.sendMessage(`§b[Mastery] ${def.name} abilities updated. §8(XP is still earned while off)`);
            }
            this.openLine(player, line, onBack);
        }).catch((e) => console.warn(`[Mastery] Toggle error: ${e}`));
    },
};
