// synergy.js -- Chorus Synergy engine (v1_21). Pure logic; every number lives in
// config/synergy_config.js. Imports only Chorus + config so Gem / Rune config code can use it
// without import cycles (HPManager is loaded lazily for the same reason).
//
//   Synergy.runeLevelBonus(player, runeId)    extra Levels for the Rune on the weapon
//   Synergy.onPlayerHit(attacker, victim, {gemSkills, runeId})  -> { damagePct }  (offense riders)
//   Synergy.onPlayerHurt(victim, attacker, gemSkills)           (defense riders)

import { system } from "@minecraft/server";
import { ChorusManager } from "./chorus_manager.js";
import { CHORUS_ELEMENTS, CHORUS_FUSION } from "../config/chorus_config.js";
import {
    SYNERGY, ELEMENT_HIT, ELEMENT_GUARD, GEM_AFFINITY, RUNE_AFFINITY,
} from "../config/synergy_config.js";

let HP = null;
import("../managers/hp_manager.js").then((m) => { HP = m.HPManager; }).catch(() => {});

const countCache = new Map();   // playerId -> { tick, counts }
const cooldowns  = new Map();   // `${playerId}:${kind}` -> tick

// A fused element counts as ALL of its parent elements for affinity: Awaken = 2, Melodious = 4, Genesis = all 8.
const parentCache = new Map();
function parentsOf(e) {
    let hit = parentCache.get(e);
    if (!hit) {
        const rec = CHORUS_FUSION[e];
        hit = rec ? [...new Set(rec.from.flatMap(parentsOf))] : [e];
        parentCache.set(e, hit);
    }
    return hit;
}

// Per socket: the set of elements it stands for. Cached briefly.
//   { sockets: Set<string>[], genesis: number of Genesis sockets }
function slotCounts(player) {
    const tick = system.currentTick;
    const hit = countCache.get(player.id);
    if (hit && tick - hit.tick < SYNERGY.CACHE_TICKS) return hit.counts;
    const counts = { sockets: [], genesis: 0 };
    try {
        for (const piece of ChorusManager.getPlayerPieces(player)) {
            for (const e of piece.elements) {
                if (!e || !CHORUS_ELEMENTS[e]) continue;
                counts.sockets.push(new Set(parentsOf(e)));
                if (CHORUS_ELEMENTS[e].tier === "genesis") counts.genesis++;
            }
        }
    } catch (_) { /* no equipment -> no synergy */ }
    countCache.set(player.id, { tick, counts });
    return counts;
}

// { slots, dominant, genesis }: slots = sockets standing for ANY affinity element;
// dominant = the affinity element the most sockets stand for.
function match(player, elements) {
    if (!SYNERGY.ENABLED || !elements?.length) return { slots: 0, dominant: null, genesis: 0 };
    const { sockets, genesis } = slotCounts(player);
    let slots = 0;
    const per = {};
    for (const set of sockets) {
        let any = false;
        for (const e of elements) if (set.has(e)) { per[e] = (per[e] ?? 0) + 1; any = true; }
        if (any) slots++;
    }
    let dominant = null, best = 0;
    for (const e of elements) if ((per[e] ?? 0) > best) { best = per[e]; dominant = e; }
    return { slots, dominant, genesis };
}

function levelBonusOf({ slots, dominant, genesis = 0 }) {
    let bonus = 0;
    for (const [need, lv] of Object.entries(SYNERGY.LEVEL_BONUS)) if (slots >= Number(need)) bonus = Math.max(bonus, lv);
    if (bonus > 0 && slots >= 4 && dominant && CHORUS_ELEMENTS[dominant]?.tier === "transcend") bonus += SYNERGY.TRANSCEND_EXTRA_LEVEL;
    if (bonus > 0 && slots >= 4 && genesis >= SYNERGY.GENESIS_MIN_SOCKETS) bonus += SYNERGY.GENESIS_EXTRA_LEVEL;   // Genesis armor: one more level
    return bonus;
}

function riderScale(slots) {
    let s = 0;
    for (const [need, f] of Object.entries(SYNERGY.RIDER_SCALE)) if (slots >= Number(need)) s = f;
    return s;
}

function ready(player, kind) {
    const key = `${player.id}:${kind}`;
    const now = system.currentTick;
    if (now - (cooldowns.get(key) ?? -Infinity) < SYNERGY.RIDER_COOLDOWN_TICKS) return false;
    cooldowns.set(key, now);
    return true;
}

// Each step is isolated: one bad effect id / vanished target never cancels the others.
function later(...steps) {
    system.run(() => { for (const fn of steps) { try { fn(); } catch (_) { /* target gone */ } } });
}

function giveEffect(entity, spec, scale) {
    if (!spec || !entity?.isValid) return;
    const [name, ticks, amp] = spec;
    entity.addEffect(name, Math.round(ticks * scale), { amplifier: amp, showParticles: false });
}

function heal(player, pct, scale) {
    if (!pct || !HP || !player?.isValid) return;
    HP.heal(player, HP.getMaxHP(player) * (pct * scale) / 100);
}

function elementLabels(elements) {
    return elements.filter((e) => CHORUS_ELEMENTS[e]).map((e) => `${CHORUS_ELEMENTS[e].color}${CHORUS_ELEMENTS[e].label}`).join("\u00a78, ");
}

export const Synergy = {

    // Lore line telling the player which Chorus elements boost this Gem skill / Rune (or null).
    affinityLine(kind, id) {
        const els = kind === "gem" ? GEM_AFFINITY[id]?.elements : RUNE_AFFINITY[id];
        if (!els?.length) return null;
        return `\u00a7r\u00a78Chorus Synergy: ${elementLabels(els)}`;
    },

    // --- Level bonus (Runes only: Gems have no levels) ----------------------
    runeLevelBonus(player, runeId) {
        return levelBonusOf(match(player, RUNE_AFFINITY[runeId]));
    },

    // --- Info for menus / book ---------------------------------------------
    // [{ type: "gem"|"rune", id, slots, dominant, levelBonus, rider: bool }] for the given actives
    describe(player, gemSkills = [], runeId = null) {
        const out = [];
        for (const s of gemSkills) {
            const aff = GEM_AFFINITY[s]; if (!aff) continue;
            const m = match(player, aff.elements);
            if (m.slots > 0) out.push({ type: "gem", id: s, ...m, levelBonus: 0, rider: m.slots >= SYNERGY.RIDER_MIN_SLOTS });
        }
        if (runeId && RUNE_AFFINITY[runeId]) {
            const m = match(player, RUNE_AFFINITY[runeId]);
            if (m.slots > 0) out.push({ type: "rune", id: runeId, ...m, levelBonus: levelBonusOf(m), rider: m.slots >= SYNERGY.RIDER_MIN_SLOTS });
        }
        return out;
    },

    // --- Offense riders -------------------------------------------------------
    // Returns { damagePct }. Effects are applied next tick (before-events are read-only).
    onPlayerHit(attacker, victim, { gemSkills = [], runeId = null } = {}) {
        const none = { damagePct: 0 };
        if (!SYNERGY.ENABLED || !attacker?.isValid || !victim?.isValid) return none;

        const cands = [];
        if (runeId && RUNE_AFFINITY[runeId]) cands.push(match(attacker, RUNE_AFFINITY[runeId]));
        let bestGem = null;
        for (const s of gemSkills) {
            const aff = GEM_AFFINITY[s];
            if (aff?.kind !== "hit") continue;
            const m = match(attacker, aff.elements);
            if (!bestGem || m.slots > bestGem.slots) bestGem = m;
        }
        if (bestGem) cands.push(bestGem);

        let damagePct = 0;
        const used = new Set();
        const effects = [];
        for (const m of cands) {
            if (!m.dominant || m.slots < SYNERGY.RIDER_MIN_SLOTS || used.has(m.dominant)) continue;
            const r = ELEMENT_HIT[m.dominant]; if (!r) continue;
            used.add(m.dominant);
            const scale = riderScale(m.slots);
            if (r.bonusPct) damagePct += r.bonusPct * scale;
            if (r.chance && Math.random() * 100 < Math.min(100, r.chance * scale)) effects.push({ r, scale });
        }
        damagePct = Math.min(SYNERGY.MAX_BONUS_DAMAGE_PCT, damagePct);

        if (effects.length && ready(attacker, "hit")) {
            for (const { r, scale } of effects) {
                later(
                    () => { if (r.burn && victim.isValid) victim.setOnFire(Math.round(r.burn * scale), true); },
                    () => { if (r.target) giveEffect(victim, r.target, scale); },
                    () => { if (r.self) giveEffect(attacker, r.self, scale); },
                    () => { if (r.healPct) heal(attacker, r.healPct, scale); },
                );
            }
        }
        return { damagePct };
    },

    // --- Defense riders ---------------------------------------------------------
    onPlayerHurt(victim, attacker, gemSkills = []) {
        if (!SYNERGY.ENABLED || !victim?.isValid) return;
        let best = null;
        for (const s of gemSkills) {
            const aff = GEM_AFFINITY[s];
            if (aff?.kind !== "guard") continue;
            const m = match(victim, aff.elements);
            if (!best || m.slots > best.slots) best = m;
        }
        if (!best?.dominant || best.slots < SYNERGY.RIDER_MIN_SLOTS) return;
        const r = ELEMENT_GUARD[best.dominant]; if (!r) return;
        const scale = riderScale(best.slots);
        if (!(Math.random() * 100 < Math.min(100, (r.chance ?? 0) * scale))) return;
        if (!ready(victim, "guard")) return;
        later(
            () => { if (r.burnAttacker && attacker?.isValid) attacker.setOnFire(Math.round(r.burnAttacker * scale), true); },
            () => { if (r.attacker && attacker?.isValid) giveEffect(attacker, r.attacker, scale); },
            () => { if (r.self) giveEffect(victim, r.self, scale); },
            () => { if (r.healPct) heal(victim, r.healPct, scale); },
        );
    },

    onPlayerLeave(playerId) {
        countCache.delete(playerId);
        for (const k of cooldowns.keys()) if (k.startsWith(`${playerId}:`)) cooldowns.delete(k);
    },
};
