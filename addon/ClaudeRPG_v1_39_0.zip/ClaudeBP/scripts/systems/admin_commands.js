// admin_commands.js -- /scriptevent status:admin ...   (Admin tag required)
//
//   status:admin                          open the Admin panel
//   status:admin help
//   status:admin info [player]
//   status:admin set  level|xp|points|prestige|perks <n> [player]
//   status:admin add  level|xp|points|perks <n> [player]
//   status:admin set stat <str|def|agi|psi|exc|mag|wis|con|vit> <n> [player]
//   status:admin set mastery <line> <level> [player]      add mastery <line> <xp> [player]
//   status:admin set insomnia <days> [player]
//   status:admin quest info|skip|set <step id|start>|complete|reset [player]      (Guide Quest)
//   status:admin set ascension <n>                         (the whole world)
//   status:admin grant|revoke <augment|chorus|gem> [player]
//   status:admin heal | clearperks | resetstats [player]
//   status:admin spawn <tier> <mob> [count]    purge [radius]
//   status:admin config list [group] | get <id> | set <id> <value> | reset <id> | resetall
//   status:admin ach info | grant <id|all> | revoke <id|all> | reset | set <counter> <n>   [player]   ach on | off
//   status:admin disc probe | info | clear | give <biome|structure|dimension> <id>   [player]
//   status:admin toast test [player]                       (shows every toast frame once)
//   status:admin log
// Player names with spaces: put them in quotes.

import { GuideQuestAdmin } from "./guide_quest.js";
import { world } from "@minecraft/server";
import { AdminManager, GROUPS, ADMIN_TAG } from "../managers/admin_manager.js";
import { AdminOps, STAT_NAMES } from "./admin_ops.js";
import { AdminGui } from "./admin_gui.js";
import { AchievementAdmin } from "./achievement_admin.js";
import { DiscoveryManager } from "./discovery_manager.js";
import { ToastManager } from "./toast_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { EVOLUTION } from "../config/evolution_config.js";

const HELP = [
    "§6[Admin] §fCommands (/scriptevent status:admin ...):",
    "§7(none) §fopen the panel   §7info [player]   §7log",
    "§7set level|xp|points|prestige|perks <n> [player]",
    "§7add level|xp|points|perks <n> [player]",
    "§7set stat <stat> <n> [player]   §7set insomnia <days> [player]",
    "§7set mastery <line> <level> [player]   §7add mastery <line> <xp> [player]",
    "§7set ascension <n>   §7grant|revoke <feature> [player]",
    "§7heal | clearperks | resetstats [player]",
    "§7spawn <tier> <mob> [count]   §7purge [radius]",
    "§7ach info|grant <id|all>|revoke <id|all>|reset|set <counter> <n> [player]   §7ach on|off",
    "§7disc probe|info|clear|give <biome|structure|dimension> <id> [player]",
    "§7quest info|skip|set <step id|start>|complete|reset [player]",
    "§7toast test [player]",
    "§7config list [group] | get <id> | set <id> <value> | reset <id> | resetall",
    `§8Lines: ${Object.keys(MASTERY.LINES).join(", ")}  Tiers: ${[...Object.keys(EVOLUTION.TIERS), "enchanted"].join(", ")}  Stats: ${STAT_NAMES.join(", ")}`,
].join("\n");

function tokenize(message) {
    const out = [];
    const re = /"([^"]*)"|(\S+)/g;
    let m;
    while ((m = re.exec(String(message ?? ""))) !== null) out.push(m[1] ?? m[2]);
    return out;
}

function findPlayer(name) {
    const want = String(name).toLowerCase();
    return world.getAllPlayers().find((p) => p.name.toLowerCase() === want) ?? null;
}

export function handleAdminCommand(player, message) {
    const say = (m) => player.sendMessage(m);
    if (!AdminManager.isAdmin(player)) {
        say(`§c[Admin] You need the "${ADMIN_TAG}" tag. An operator can run: /tag ${player.name} add ${ADMIN_TAG}`);
        return;
    }

    const tokens = tokenize(message);
    if (!tokens.length) { AdminGui.openMain(player); return; }

    const cmd = tokens.shift().toLowerCase();

    // Takes `n` fixed arguments, then an optional player name.
    const withTarget = (n, run) => {
        if (tokens.length < n) { say("§c[Admin] Missing arguments. Try: /scriptevent status:admin help"); return; }
        const args = tokens.splice(0, n);
        let target = player;
        if (tokens.length) {
            target = findPlayer(tokens[0]);
            if (!target) { say(`§c[Admin] Player "${tokens[0]}" is not online.`); return; }
        }
        say(run(args, target).text);
    };
    const plain = (n, run) => {
        if (tokens.length < n) { say("§c[Admin] Missing arguments. Try: /scriptevent status:admin help"); return; }
        say(run(tokens.splice(0, n)).text);
    };

    switch (cmd) {
        case "help": say(HELP); return;
        case "panel": AdminGui.openMain(player); return;
        case "info": withTarget(0, (_, t) => ({ text: AdminOps.summary(t) })); return;
        case "log": {
            const rows = AdminManager.getLog();
            say(rows.length ? "§6[Admin] §fRecent actions:\n" + rows.map((r) => `§8${new Date(r.t).toISOString().slice(5, 16).replace("T", " ")} §7${r.who}: §f${r.text}`).join("\n") : "§6[Admin] §7No actions logged yet.");
            return;
        }
        case "set":
        case "add": {
            const what = (tokens.shift() ?? "").toLowerCase();
            const mode = cmd;
            switch (what) {
                case "level":    return withTarget(1, ([v], t) => AdminOps.level(player, t, mode, v));
                case "xp":       return withTarget(1, ([v], t) => AdminOps.xp(player, t, mode, v));
                case "points":   return withTarget(1, ([v], t) => AdminOps.points(player, t, mode, v));
                case "perks":    return withTarget(1, ([v], t) => AdminOps.perks(player, t, mode, v));
                case "prestige":
                    if (mode === "add") { say("§c[Admin] Use: set prestige <n>"); return; }
                    return withTarget(1, ([v], t) => AdminOps.prestige(player, t, v));
                case "stat":
                    if (mode === "add") { say("§c[Admin] Use: set stat <stat> <n>"); return; }
                    return withTarget(2, ([s, v], t) => AdminOps.stat(player, t, s.toLowerCase(), v));
                case "mastery":
                    return withTarget(2, ([l, v], t) => mode === "set" ? AdminOps.masteryLevel(player, t, l.toLowerCase(), v) : AdminOps.masteryXp(player, t, l.toLowerCase(), v));
                case "insomnia":
                    return withTarget(1, ([v], t) => AdminOps.insomnia(player, t, v));
                case "ascension":
                    if (mode === "add") { say("§c[Admin] Use: set ascension <n>"); return; }
                    return plain(1, ([v]) => AdminOps.ascension(player, v));
                default: say("§c[Admin] Unknown target. Try: /scriptevent status:admin help"); return;
            }
        }
        case "grant":  return withTarget(1, ([f], t) => AdminOps.unlock(player, t, f.toLowerCase(), true));
        case "revoke": return withTarget(1, ([f], t) => AdminOps.unlock(player, t, f.toLowerCase(), false));
        case "heal":       return withTarget(0, (_, t) => AdminOps.heal(player, t));
        case "clearperks": return withTarget(0, (_, t) => AdminOps.clearPerks(player, t));
        case "resetstats": return withTarget(0, (_, t) => AdminOps.resetStats(player, t));
        case "spawn":
            if (tokens.length < 2) { say("§c[Admin] Use: spawn <tier> <mob> [count]"); return; }
            say(AdminOps.spawn(player, tokens[0].toLowerCase(), tokens[1].toLowerCase(), tokens[2]).text);
            return;
        case "purge": say(AdminOps.purge(player, tokens[0]).text); return;
        case "ach":
        case "achievement": {
            const sub = (tokens.shift() ?? "info").toLowerCase();
            switch (sub) {
                case "info":   return withTarget(0, (_, t) => AchievementAdmin.info(t));
                case "grant":  return withTarget(1, ([id], t) => AchievementAdmin.grant(player, t, id));
                case "revoke": return withTarget(1, ([id], t) => AchievementAdmin.revoke(player, t, id));
                case "reset":  return withTarget(0, (_, t) => AchievementAdmin.reset(player, t));
                case "set":    return withTarget(2, ([k, v], t) => AchievementAdmin.setCounter(player, t, k, v));
                case "on":
                case "off":    say(AchievementAdmin.toggle(player, sub === "on").text); return;
                default: say("§c[Admin] Use: ach info | grant <id|all> | revoke <id|all> | reset | set <counter> <n> | on | off");
            }
            return;
        }
        case "quest":
        case "guide": {
            const sub = (tokens.shift() ?? "info").toLowerCase();
            switch (sub) {
                case "info":     return withTarget(0, (_, t) => GuideQuestAdmin.info(t));
                case "skip":     return withTarget(0, (_, t) => GuideQuestAdmin.skip(player, t));
                case "set":      return withTarget(1, ([id], t) => GuideQuestAdmin.set(player, t, id));
                case "complete": return withTarget(0, (_, t) => GuideQuestAdmin.complete(player, t));
                case "reset":    return withTarget(0, (_, t) => GuideQuestAdmin.reset(player, t));
                default: say("§c[Admin] Use: quest info | skip | set <step id|start> | complete | reset  [player]");
            }
            return;
        }
        case "disc":
        case "discovery": {
            const sub = (tokens.shift() ?? "probe").toLowerCase();
            switch (sub) {
                case "probe": {
                    const r = DiscoveryManager.probe(player);
                    say(`§6[Admin] §fDiscovery API check:\n§7getBiome: §f${r.biomeApi ? "available" : "MISSING"}  §7getBlocks: §f${r.blocksApi ? "available" : "MISSING"}\n§7Biome here: §f${r.biome}`);
                    return;
                }
                case "info": return withTarget(0, (_, t) => {
                    const x = DiscoveryManager.totals(t);
                    return { text: `§6[Admin] §f${t.name}: biomes ${x.biomeFound}/${x.biomeTotal} (+${x.other} other), structures ${x.structureFound}/${x.structureTotal}, dimensions ${x.dimFound}/${x.dimTotal}` };
                });
                case "clear": return withTarget(0, (_, t) => { DiscoveryManager.adminClear(t); return { text: `§6[Admin] §fCleared the Discovery Log of ${t.name}.` }; });
                case "give": return withTarget(2, ([kind, id], t) => {
                    const k = String(kind).toLowerCase();
                    if (!["biome", "structure", "dimension"].includes(k)) return { text: "§c[Admin] Kind must be biome, structure or dimension." };
                    const added = DiscoveryManager.record(t, k, String(id).replace("minecraft:", ""));
                    return { text: added ? `§6[Admin] §fRecorded ${k} ${id} for ${t.name}.` : `§6[Admin] §7${t.name} already has ${k} ${id}.` };
                });
                default: say("§c[Admin] Use: disc probe | info | clear | give <biome|structure|dimension> <id>");
            }
            return;
        }
        case "toast": {
            const sub = (tokens.shift() ?? "test").toLowerCase();
            if (sub !== "test") { say("§c[Admin] Use: toast test [player]"); return; }
            return withTarget(0, (_, t) => (t.sendMessage("§7[Toast test] If you can read this normal chat line, HUD chat is on."), { text: `§6[Admin] §fSent ${ToastManager.demo(t)} test toasts to ${t.name}.` }));
        }
        case "config": {
            const sub = (tokens.shift() ?? "list").toLowerCase();
            if (sub === "list") {
                const g = tokens[0] ? GROUPS.find((x) => x.id === tokens[0].toLowerCase()) : null;
                if (!g) {
                    say("§6[Admin] §fConfig groups (use: config list <group>):\n" +
                        GROUPS.map((x) => `§e${x.id} §7- ${x.label} §8(${AdminManager.entriesOf(x.id).length})`).join("\n") +
                        `\n§8${AdminManager.overrideCount()} override(s) active.`);
                } else {
                    say(`§6[Admin] §f${g.label}:\n` + AdminManager.entriesOf(g.id).map((e) =>
                        `§7${e.id} §f${AdminManager.format(e)}${AdminManager.isOverridden(e.id) ? " §6*" : ""} §8(default ${AdminManager.format(e, e.def)})`).join("\n"));
                }
                return;
            }
            if (sub === "get") {
                const e = AdminManager.entry(tokens[0] ?? "");
                if (!e) { say("§c[Admin] Unknown setting id."); return; }
                say(`§6[Admin] §f${e.label}\n§7${e.id} = §f${AdminManager.format(e)} §8(default ${AdminManager.format(e, e.def)}, ${AdminManager.describeRange(e)})`);
                return;
            }
            if (sub === "set") {
                if (tokens.length < 2) { say("§c[Admin] Use: config set <id> <value>"); return; }
                say(AdminOps.configSet(player, tokens[0], tokens[1]).text);
                return;
            }
            if (sub === "reset") { say(AdminOps.configReset(player, tokens[0] ?? "").text); return; }
            if (sub === "resetall") { say(AdminOps.configResetAll(player).text); return; }
            say("§c[Admin] Use: config list | get | set | reset | resetall");
            return;
        }
        default:
            say("§c[Admin] Unknown command. Try: /scriptevent status:admin help");
    }
}
