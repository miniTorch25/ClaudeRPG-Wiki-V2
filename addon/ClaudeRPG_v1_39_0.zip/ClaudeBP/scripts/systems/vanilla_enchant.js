// Ultench > Vanilla Enchant
// Enchant an item with any compatible vanilla enchantment at a freely chosen level
// (up to the vanilla max), paying Enchant Essence. Costs live in config/salvage_config.js.

import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { EntityComponentTypes, EquipmentSlot, EnchantmentTypes } from "@minecraft/server";
import { GuiService } from "../gui/gui_service.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { getCategoryLabel } from "../config/item_category_config.js";
import { GemManager } from "./gem_manager.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { prettyId, roman } from "./salvage.js";
import {
    ENCHANT_ESSENCE_ID, essenceCostForLevel, normalizeEnchantId,
} from "../config/salvage_config.js";
import { displayName } from "./rarity_name.js";

const SRC = "systems.vanilla_enchant.js";

function resolveSlot(player, ref) {
    if (ref.kind === "inventory") {
        return player.getComponent(EntityComponentTypes.Inventory)?.container?.getSlot(ref.index);
    }
    return player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(ref.slot);
}

function collectItems(player) {
    const results = [];
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const eq  = player.getComponent(EntityComponentTypes.Equippable);
    if (inv) {
        for (let i = 0; i < inv.size; i++) {
            const s = inv.getSlot(i);
            if (s.hasItem() && ITEM_REQUIREMENTS[s.typeId]) results.push({ kind: "inventory", index: i });
        }
    }
    if (eq) {
        for (const slotId of [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs,
                              EquipmentSlot.Feet, EquipmentSlot.Offhand]) {
            const s = eq.getEquipmentSlot(slotId);
            if (s?.hasItem() && ITEM_REQUIREMENTS[s.typeId]) results.push({ kind: "equipment", slot: slotId });
        }
    }
    return results;
}

function consumeEssence(player, amount) {
    for (let i = 0; i < amount; i++) {
        if (!GemManager.consumeItem(player, ENCHANT_ESSENCE_ID)) return false;
    }
    return true;
}

export class VanillaEnchantManager {

    // back: () => void — returns to the Ultench main menu.
    static open(player, back) {
        const refs = collectItems(player).filter((r) => {
            const s = resolveSlot(player, r);
            return s?.hasItem() && s.getItem().getComponent("minecraft:enchantable");
        });

        if (refs.length === 0) {
            player.sendMessage("§cYou don't have any items that can be enchanted!");
            return back();
        }

        const essence = GemManager.countItem(player, ENCHANT_ESSENCE_ID);
        const form = new ActionFormData()
            .title("§l§bVanilla Enchant")
            .body(`§7Enchant Essence: §f${essence}\n§7Pick an item.`);

        for (const ref of refs) {
            const item = resolveSlot(player, ref).getItem();
            form.button(`§f${displayName(item)}\n§8[${getCategoryLabel(item.typeId, "en", item) || ITEM_REQUIREMENTS[item.typeId].type}]`, getItemIconPath(item));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection === refs.length) return back();
            this.openEnchantList(player, refs[r.selection], back);
        }).catch((e) => console.warn(`[VanillaEnchant] Item menu error: ${e}`));
    }

    static openEnchantList(player, ref, back) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) { player.sendMessage("§cThat item is no longer available!"); return this.open(player, back); }

        const item = slot.getItem();
        const comp = item.getComponent("minecraft:enchantable");
        const entries = [];
        for (const type of EnchantmentTypes.getAll()) {
            const id = normalizeEnchantId(type.id);
            const current = comp.getEnchantment(type)?.level ?? 0;
            let ok = current > 0;
            if (!ok) { try { ok = comp.canAddEnchantment({ type, level: 1 }); } catch (_) { ok = false; } }
            if (!ok) continue;
            const vanillaMax = type.maxLevel ?? 1;
            entries.push({ type, id, current, vanillaMax, cap: vanillaMax });
        }

        if (entries.length === 0) {
            player.sendMessage("§cNo enchantments are compatible with this item!");
            return this.open(player, back);
        }

        const form = new ActionFormData()
            .title("§l§bChoose Enchantment")
            .body(`§f${displayName(item)}\n§7Essence: §f${GemManager.countItem(player, ENCHANT_ESSENCE_ID)}`);
        for (const e of entries) {
            const cur = e.current > 0 ? `§a${roman(e.current)}` : "§8-";
            form.button(`§f${prettyId(e.id)}\n§8Now: ${cur} §8| Max: ${roman(e.cap)}`);
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return;
            if (r.selection === entries.length) return this.open(player, back);
            this.openLevelPicker(player, ref, entries[r.selection], back);
        }).catch((e) => console.warn(`[VanillaEnchant] List error: ${e}`));
    }

    static openLevelPicker(player, ref, entry, back) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) { player.sendMessage("§cThat item is no longer available!"); return this.open(player, back); }

        const have = GemManager.countItem(player, ENCHANT_ESSENCE_ID);
        const min  = entry.current + 1;
        const max  = entry.cap;

        if (min > max) {
            player.sendMessage(`§e${prettyId(entry.id)} is already at the maximum level!`);
            return this.openEnchantList(player, ref, back);
        }

        const baseCost = entry.current > 0 ? essenceCostForLevel(entry.id, entry.current) : 0;
        const costOf   = (l) => essenceCostForLevel(entry.id, l) - baseCost;

        const priceLines = [];
        for (let l = min; l <= max; l++) {
            priceLines.push(`${roman(l)} = §f${costOf(l)}§7`);
        }
        const info = `§7Essence: §f${have}\n§7Cost: ${priceLines.join("  §8|§7  ")}` +
                     (entry.current > 0 ? `\n§8(Upgrade from ${roman(entry.current)}: difference only)` : "");

        const apply = (level) => {
            const cost = costOf(level);
            if (GemManager.countItem(player, ENCHANT_ESSENCE_ID) < cost) {
                player.sendMessage(`§cYou need ${cost}x Enchant Essence for ${prettyId(entry.id)} ${roman(level)}!`);
                return this.openLevelPicker(player, ref, entry, back);
            }
            if (!slot.hasItem()) { player.sendMessage("§cThat item is no longer available!"); return this.open(player, back); }

            const item = slot.getItem();
            const comp = item.getComponent("minecraft:enchantable");
            try {
                if ((comp.getEnchantment(entry.type)?.level ?? 0) > 0) comp.removeEnchantment(entry.type);
                comp.addEnchantment({ type: entry.type, level });
            } catch (err) {
                player.sendMessage(`§cCould not apply ${prettyId(entry.id)} ${roman(level)}. No Essence was spent.`);
                console.warn(`[VanillaEnchant] addEnchantment failed (${entry.id} ${level}): ${err}`);
                return this.openLevelPicker(player, ref, entry, back);
            }

            slot.setItem(item);
            consumeEssence(player, cost);
            try { ItemRestrictionManager.updateSlotLore(slot, player); } catch (_) {}
            player.sendMessage(`§a${prettyId(entry.id)} ${roman(level)} applied! §7(-${cost} Essence)`);
            player.playSound("random.levelup");
            this.openEnchantList(player, ref, back);
        };

        // Only one level to choose (e.g. Mending I): a slider needs 2+ values, so confirm instead.
        if (min === max) {
            const form = new MessageFormData()
                .title(`§l§b${prettyId(entry.id)}`)
                .body(`§f${prettyId(entry.id)} ${roman(min)}\n\n${info}`)
                .button1(`§aEnchant (${costOf(min)} Essence)`)
                .button2("§8Cancel");
            return GuiService.show(player, form, SRC).then((r) => {
                if (r.canceled || r.selection !== 0) return this.openEnchantList(player, ref, back);
                apply(min);
            }).catch((e) => console.warn(`[VanillaEnchant] Confirm error: ${e}`));
        }

        const form = new ModalFormData().title(`§l§b${prettyId(entry.id)}`);
        let labelSupported = false;
        if (typeof form.label === "function") { form.label(info); labelSupported = true; }
        form.slider(labelSupported ? "§fLevel" : `${info}\n\n§fLevel`, min, max, { valueStep: 1, defaultValue: max });

        GuiService.show(player, form, SRC).then((r) => {
            if (r.canceled) return this.openEnchantList(player, ref, back);
            const level = r.formValues.find((x) => typeof x === "number");
            if (!level || level < min || level > max) return this.openEnchantList(player, ref, back);
            apply(level);
        }).catch((e) => console.warn(`[VanillaEnchant] Level picker error: ${e}`));
    }
}
