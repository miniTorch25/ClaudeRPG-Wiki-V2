import { EntityComponentTypes, EquipmentSlot, ItemComponentTypes } from "@minecraft/server";
import { StatsManager } from "../managers/stats_manager.js";
import { AugmentManager } from "./augment.js";
import { buildRuneLoreLines } from "../rune/rune_lore.js";
import { RUNE_PROP_KEY, RUNE_VER_KEY, RUNE_VER, RUNE_FORCED_KEY, runeFitsItem, migrateStoredRune } from "../rune/rune_registry.js";
import { RUNE_LEVEL_PROP_KEY } from "../config/level_config.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { GemManager } from "./gem_manager.js";
import { CONFIG } from "../config/config.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { syncRarityName } from "./rarity_name.js";
import { ChorusManager } from "./chorus_manager.js";
import { CHORUS_TIERS, CHORUS_ELEMENTS } from "../config/chorus_config.js";

const ARMOR_SLOTS = [
    { slot: EquipmentSlot.Head,    name: "head"    },
    { slot: EquipmentSlot.Chest,   name: "chest"   },
    { slot: EquipmentSlot.Legs,    name: "legs"    },
    { slot: EquipmentSlot.Feet,    name: "feet"    },
    { slot: EquipmentSlot.Offhand, name: "offhand" }
];

const STAT_DISPLAY = {
    str: { name: "\uE200", color: "§c" },
    def: { name: "\uE201", color: "§a" },
    agi: { name: "\uE202", color: "§b" },
    psi: { name: "\uE203", color: "§u" },
    exc: { name: "\uE204", color: "§6" },
    mag: { name: "\uE205", color: "§w" },
    wis: { name: "\uE206", color: "§f" }
};

export class ItemRestrictionManager {

    // --- Requirement helpers ---

    static getEnchantCount(itemStack) {
        if (!itemStack) return 0;
        try {
            return itemStack.getComponent(ItemComponentTypes.Enchantable)?.getEnchantments().length ?? 0;
        } catch {
            return 0;
        }
    }

    static getEffectiveRequirement(itemStack, req) {
        const enchantBonus = this.getEnchantCount(itemStack) * CONFIG.PSI_PER_ENCHANT;
        return { ...req, psi: (req.psi ?? 0) + enchantBonus };
    }

    static checkStats(stats, req) {
        for (const stat of Object.keys(STAT_DISPLAY)) {
            if ((req[stat] ?? 0) > (stats[stat] ?? 0)) return false;
        }
        return true;
    }

    static getMissingStatsLabel(stats, req) {
        const missing = [];
        for (const [stat, display] of Object.entries(STAT_DISPLAY)) {
            if ((req[stat] ?? 0) > (stats[stat] ?? 0)) {
                missing.push(`${display.color}${display.name}`);
            }
        }
        return missing.length > 0 ? ` §8( ${missing.join(" ")} §8)` : "";
    }

    // --- Lore rendering ---

    // playerLevel is optional; omit for inventory lore refresh (uses 0 → shows lock messages)
    static buildLoreLines(itemDef, effectiveReq, type, additionalValues, slot, playerLevel = 0, player = null) {
        const lines = [];

        if (itemDef.lore) {
            lines.push(`§r§f${itemDef.lore}`);
        }

        // Augment section
        const augmentLines = AugmentManager.buildLoreLines(type, additionalValues ?? {}, slot);
        if (augmentLines.length > 0) {
            lines.push("", ...augmentLines);
        }

        // Gem section (armor only)
        if (type === "armor") {
            const gemLines = GemManager.buildGemLoreLines(slot, playerLevel, player);
            lines.push("", ...gemLines);

            // Chorus section (armor only, not the shield)
            const chorusTier = ChorusManager.getTier(slot);
            if (chorusTier && slot?.typeId && ChorusManager.isEligibleType(slot.typeId)) {
                const t = CHORUS_TIERS[chorusTier];
                const els = ChorusManager.getElements(slot).map((id, i) => {
                    const d = CHORUS_ELEMENTS[id];
                    const lock = ChorusManager.isLocked(slot, i) ? " §6[Locked]" : "";
                    return `§r§8#${i + 1} ${d ? d.color + d.label : "§8Empty"}${lock}`;
                });
                lines.push("", `§r§7Chorus: ${t.color}${t.label}`, els.join("§r§8, "));
            }
        }

        // Requirements section
        const parts = [];
        for (const [stat, display] of Object.entries(STAT_DISPLAY)) {
            const value = effectiveReq[stat] ?? 0;
            if (value > 0) {
                parts.push(`§r§8${display.name} ${display.color}${value}`);
            }
        }

        if (parts.length > 0) {
            lines.push("", "§r§7Requirements:");
            for (let i = 0; i < parts.length; i += 3) {
                lines.push(parts.slice(i, i + 3).join(" "));
            }
        }

        // Rune lore block (weapons only — armor has no rune slot)
        if (type !== "armor" && slot) {
            const runeId = slot.getDynamicProperty?.(RUNE_PROP_KEY) ?? null;
            if (runeId) {
                // player is not available here — caller can pass it via updateSlotLore
                // for live counters; null gives static lore which is fine for tick refresh
                const runeBonus = player ? MasteryManager.getItemLevelBonus(player, "rune") : 0;   // per-holder Mastery levels
                const runeLines = buildRuneLoreLines(runeId, player, slot.getDynamicProperty?.(RUNE_LEVEL_PROP_KEY) ?? 1, runeBonus, slot.typeId);
                lines.push(...runeLines);
                if (!runeFitsItem(runeId, slot.typeId)) lines.push("§r§c⚠ Wrong type: this Rune does not work on this item");
            }
        }

        return lines;
    }

    static loreArraysEqual(a, b) {
        if (!a || !b || a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) return false;
        }
        return true;
    }

    // player is optional — pass it to bake the real level into Gem lore
    static updateSlotLore(slot, player = null) {
        if (!slot || !slot.hasItem()) return;

        // Migrate removed / renamed / re-categorised Runes (v5 roster) before anything reads them:
        // an old rune becomes its replacement when the weapon can hold it, otherwise it is removed for free.
        // The rune's Level is kept 1:1.
        // Rune ITEMS (crpg:rune_*) hold their rune in the same property but are not weapons: never migrate them.
        const storedRune = (slot.typeId?.startsWith("crpg:rune_") || slot.getDynamicProperty?.(RUNE_FORCED_KEY)) ? null : slot.getDynamicProperty?.(RUNE_PROP_KEY);
        if (storedRune) {
            const ver = slot.getDynamicProperty?.(RUNE_VER_KEY) ?? 0;
            const mig = migrateStoredRune(storedRune, slot.typeId, ver);
            if (mig.changed) {
                slot.setDynamicProperty(RUNE_PROP_KEY, mig.id ?? undefined);
                slot.setDynamicProperty(RUNE_VER_KEY, mig.id ? RUNE_VER : undefined);
                if (!mig.id) slot.setDynamicProperty(RUNE_LEVEL_PROP_KEY, undefined);
            }
        }

        const itemStack = slot.getItem();
        const req       = ITEM_REQUIREMENTS[itemStack.typeId];
        if (!req) return;

        const playerLevel      = player ? (StatsManager.getStat(player, "stat_level", 0)) : 0;
        const effectiveReq     = this.getEffectiveRequirement(itemStack, req);
        const additionalValues = AugmentManager.getValues(slot, req.type);
        const desiredLore      = this.buildLoreLines(req, effectiveReq, req.type, additionalValues, slot, playerLevel, player);
        const currentLore      = slot.getLore();

        if (!this.loreArraysEqual(currentLore, desiredLore)) {
            slot.setLore(desiredLore);
        }
        syncRarityName(slot);
    }

    // --- Per-tick pass ---

    static checkPlayerEquipment(player, refreshInventory = true) {
        const stats       = StatsManager.getPlayerData(player);
        const inventoryComp = player.getComponent(EntityComponentTypes.Inventory);
        const equipment   = player.getComponent(EntityComponentTypes.Equippable);
        const inventory   = inventoryComp?.container;

        if (!equipment) return;

        // Worn armor / offhand are not in the container: refresh their lore too (Mastery levels change per holder)
        if (refreshInventory) {
            for (const armor of ARMOR_SLOTS) this.updateSlotLore(equipment.getEquipmentSlot(armor.slot), player);
        }

        // Lore refresh on all restricted items in inventory (pass player for Gem lore)
        if (inventory && refreshInventory) {
            for (let i = 0; i < inventory.size; i++) {
                this.updateSlotLore(inventory.getSlot(i), player);
            }
        }

        // Mainhand stat warning
        const mainhandSlot = equipment.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (mainhandSlot?.hasItem()) {
            const mainhandItem = mainhandSlot.getItem();
            const req          = ITEM_REQUIREMENTS[mainhandItem.typeId];

            if (req && ["melee", "ranged", "tool"].includes(req.type)) {
                const effectiveReq = this.getEffectiveRequirement(mainhandItem, req);
                if (!this.checkStats(stats, effectiveReq)) {
                    player.onScreenDisplay.setActionBar(
                        `§c[!] Insufficient stats to use this item${this.getMissingStatsLabel(stats, effectiveReq)}`
                    );
                }
            }
        }

        // Auto-unequip armor the player no longer qualifies for
        for (const armor of ARMOR_SLOTS) {
            const armorSlot = equipment.getEquipmentSlot(armor.slot);
            if (!armorSlot?.hasItem()) continue;
            syncRarityName(armorSlot);   // worn armor is not in the inventory container

            const armorItem = armorSlot.getItem();
            const req       = ITEM_REQUIREMENTS[armorItem.typeId];
            if (!req || req.type !== "armor") continue;

            const effectiveReq = this.getEffectiveRequirement(armorItem, req);
            const statsFail    = !this.checkStats(stats, effectiveReq);

            // Gem level restriction: Lv.75+ required when any gem is installed (req 8)
            const gemLevel    = GemManager.getGemEquipLevel(armorSlot);
            const gemFail     = gemLevel > 0 && stats.level < gemLevel;

            if (!statsFail && !gemFail) continue;

            armorSlot.setItem(undefined);

            if (inventory && inventory.emptySlotsCount > 0) {
                inventory.addItem(armorItem);
            } else {
                player.dimension.spawnItem(armorItem, player.location);
            }

            if (gemFail) {
                player.sendMessage(`§c[!] ${armorItem.typeId} was unequipped: Lv.${gemLevel}+ required to equip armor with Gems!`);
            } else {
                player.sendMessage(`§c[!] ${armorItem.typeId} was unequipped: insufficient stats!`);
            }
        }
    }

    // --- Hard blocks ---

    static checkItemUse(event) {
        const { source: player, itemStack } = event;
        if (!player || !itemStack) return;

        const req = ITEM_REQUIREMENTS[itemStack.typeId];
        if (!req || req.type !== "ranged") return;

        const stats        = StatsManager.getPlayerData(player);
        const effectiveReq = this.getEffectiveRequirement(itemStack, req);

        if (!this.checkStats(stats, effectiveReq)) {
            event.cancel = true;
            player.onScreenDisplay.setActionBar(
                `§c[!] Insufficient stats to use this item${this.getMissingStatsLabel(stats, effectiveReq)}`
            );
        }
    }

    static checkMeleeDamage(event) {
        const attacker = event.damageSource?.damagingEntity;
        if (!attacker || attacker.typeId !== "minecraft:player") return;

        const equipment    = attacker.getComponent(EntityComponentTypes.Equippable);
        const mainhandSlot = equipment?.getEquipmentSlot(EquipmentSlot.Mainhand);
        if (!mainhandSlot?.hasItem()) return;

        const mainhandItem = mainhandSlot.getItem();
        const req          = ITEM_REQUIREMENTS[mainhandItem.typeId];
        if (!req || req.type !== "melee") return;

        const stats        = StatsManager.getPlayerData(attacker);
        const effectiveReq = this.getEffectiveRequirement(mainhandItem, req);

        if (!this.checkStats(stats, effectiveReq)) {
            event.cancel = true;
            attacker.onScreenDisplay.setActionBar(
                `§c[!] Insufficient stats to use this weapon${this.getMissingStatsLabel(stats, effectiveReq)}`
            );
        }
    }

    static checkBlockBreak(event) {
        const { player, itemStack } = event;
        if (!player || !itemStack) return;

        const req = ITEM_REQUIREMENTS[itemStack.typeId];
        if (!req || req.type !== "tool") return;

        const stats        = StatsManager.getPlayerData(player);
        const effectiveReq = this.getEffectiveRequirement(itemStack, req);

        if (!this.checkStats(stats, effectiveReq)) {
            event.cancel = true;
            player.onScreenDisplay.setActionBar(
                `§c[!] Insufficient Exc to mine with this tool${this.getMissingStatsLabel(stats, effectiveReq)}`
            );
        }
    }
}
