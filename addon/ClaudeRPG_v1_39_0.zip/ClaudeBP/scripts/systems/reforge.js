import { GuiService } from "../gui/gui_service.js";
import { ActionFormData } from "@minecraft/server-ui";
import { EntityComponentTypes, EquipmentSlot, ItemComponentTypes, ItemStack } from "@minecraft/server";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { getCategoryLabel } from "../config/item_category_config.js";
import { AugmentManager } from "./augment.js";
import { ItemRestrictionManager } from "./item_restriction.js";
import { GemManager, GEM_TIERS } from "./gem_manager.js";
import { getItemIconPath } from "../managers/item_helper.js";
import { previewSalvage, performSalvage, isSalvageable, prettyId, roman } from "./salvage.js";
import {
    AUGMENT_CRYSTAL_ID, AUGMENT_CORE_ID, MAX_AUGMENT_CORES, AUGMENT_CRYSTAL_COST,
    PERFECT_SALVAGE_CORES, CORE_FUSION_GEMS, CORE_FUSION_CORES, SALVAGE_HAMMER_DURABILITY,
    SALVAGE_MATERIAL_RATIO, SALVAGE_FULL_REFUND_CHANCE, ENCHANT_ESSENCE_ID,
} from "../config/salvage_config.js";
import { GEM_DUST_ID } from "./gem_manager.js";
import { displayName } from "./rarity_name.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { onAugmentReroll, onAugmentMax, onAugmentLock, onGemFusion } from "./achievement_hooks.js";
import { onMenuOpened } from "./achievement_hooks.js";
import { RuneAnvilGui } from "./rune_anvil_gui.js";

export const ANVIL_BLOCK_TYPES = ["minecraft:anvil", "minecraft:chipped_anvil", "minecraft:damaged_anvil"];

// Hammers ordered from weakest to strongest — the system always uses the
// lowest-tier hammer first, only moving up when that tier runs out.
export const HAMMER_ITEMS = [
    "crpg:reforge_hammer",
    "crpg:diamond_reforge_hammer",
    "crpg:netherite_reforge_hammer",
    "crpg:eternal_hammer"
];

// Eternal Hammer passive: while it sits anywhere in the player's inventory,
// all Augment durability costs (on whichever hammer is actually used) are halved.
function hasEternalHammer(player) {
    const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
    if (!inventory) return false;

    for (let i = 0; i < inventory.size; i++) {
        const slot = inventory.getSlot(i);
        if (slot.hasItem() && slot.typeId === "crpg:eternal_hammer") return true;
    }
    return false;
}

const HAMMER_DURABILITY_COST = {
    reroll: 8,
    max:    100,
    lock:   20,
    unlock: 8,
    fusion: 40
};

// Gem Fusion: this many Gems of the same tier combine into 1 Gem one tier higher.
const GEM_FUSION_COUNT = 5;

// --- Hammer helpers ---

// Scans the inventory for all hammer slots, grouped by tier index.
// Returns them sorted so the lowest-tier hammer with remaining durability
// is always tried first; within the same tier, picks the most-damaged one
// (use it up before touching a fresh copy of the same tier).
function findHammerSlot(player) {
    const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
    if (!inventory) return undefined;

    let best = undefined;
    let bestTier = Infinity;
    let bestRemaining = Infinity;

    for (let i = 0; i < inventory.size; i++) {
        const slot = inventory.getSlot(i);
        if (!slot.hasItem()) continue;

        const tier = HAMMER_ITEMS.indexOf(slot.typeId);
        if (tier === -1) continue;

        let remaining = Infinity;
        try {
            const dur = slot.getItem().getComponent(ItemComponentTypes.Durability);
            if (dur) remaining = dur.maxDurability - dur.damage;
        } catch { /* treat as full if unreadable */ }

        // Prefer lower tier; within same tier prefer the one with less remaining (use it up first)
        if (tier < bestTier || (tier === bestTier && remaining < bestRemaining)) {
            best           = slot;
            bestTier       = tier;
            bestRemaining  = remaining;
        }
    }

    return best;
}

function hasHammer(player) {
    return findHammerSlot(player) !== undefined;
}

function getHammerDurabilityText(player) {
    const slot = findHammerSlot(player);
    if (!slot) return "§cNo Reforge Hammer!";
    try {
        const item       = slot.getItem();
        const durability = item.getComponent(ItemComponentTypes.Durability);
        if (!durability) return "";
        const remaining  = durability.maxDurability - durability.damage;
        const tierLabel  = slot.typeId === "crpg:eternal_hammer"           ? "§6Eternal"
                         : slot.typeId === "crpg:netherite_reforge_hammer" ? "§5Netherite"
                         : slot.typeId === "crpg:diamond_reforge_hammer"   ? "§bDiamond"
                         : "§7Iron";
        return `${tierLabel} §f${remaining}/${durability.maxDurability}`;
    } catch (error) {
        console.warn(`[Reforge] Failed to read hammer durability: ${error}`);
        return "§7Unknown";
    }
}

// Returns false only if no hammer is found at all.
// Fail-open on read/write errors so a durability bug never hard-blocks the player.
function damageHammer(player, amount) {
    const slot = findHammerSlot(player);
    if (!slot) return false;
    try {
        const item       = slot.getItem();
        const durability = item.getComponent(ItemComponentTypes.Durability);
        if (!durability) return true;

        // Eternal Hammer passive: halve the durability cost (rounded down) if one is carried.
        const effectiveAmount = hasEternalHammer(player) ? Math.floor(amount / 2) : amount;

        durability.damage = Math.min(durability.maxDurability, durability.damage + effectiveAmount);

        if (durability.damage >= durability.maxDurability) {
            slot.setItem(undefined);
            const tierName = slot.typeId === "crpg:eternal_hammer"           ? "Eternal Hammer"
                           : slot.typeId === "crpg:netherite_reforge_hammer" ? "Netherite Reforge Hammer"
                           : slot.typeId === "crpg:diamond_reforge_hammer"   ? "Diamond Reforge Hammer"
                           : "Reforge Hammer";
            player.sendMessage(`§cYour ${tierName} broke!`);
        } else {
            slot.setItem(item);
        }
        return true;
    } catch (error) {
        console.warn(`[Reforge] Failed to damage hammer: ${error}`);
        return true;
    }
}

// --- Slot reference helpers ---
// A "ref" can be an inventory index or an equipment slot id,
// so the item selection menu can include worn armor

function resolveSlot(player, ref) {
    if (ref.kind === "inventory") {
        return player.getComponent(EntityComponentTypes.Inventory)?.container?.getSlot(ref.index);
    }
    return player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(ref.slot);
}

function collectEligibleSlots(player) {
    const results   = [];
    const inventory = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const equipment = player.getComponent(EntityComponentTypes.Equippable);

    if (inventory) {
        for (let i = 0; i < inventory.size; i++) {
            const slot = inventory.getSlot(i);
            if (slot.hasItem() && ITEM_REQUIREMENTS[slot.getItem().typeId]) {
                results.push({ kind: "inventory", index: i });
            }
        }
    }

    if (equipment) {
        for (const slotId of [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs,
                               EquipmentSlot.Feet, EquipmentSlot.Offhand]) {
            const slot = equipment.getEquipmentSlot(slotId);
            if (slot?.hasItem() && ITEM_REQUIREMENTS[slot.getItem().typeId]) {
                results.push({ kind: "equipment", slot: slotId });
            }
        }
    }

    return results;
}

export class ReforgeManager {

    // 1. Main menu
    static openReforgeMenu(player) {
        onMenuOpened(player, "reforge");
        const form = new ActionFormData()
            .title("§l§6Reforge")
            .body("§7Choose what you'd like to work on.")
            .button(ProgressionManager.canUse(player, "augment") ? "§9Augment" : `§8Augment §c[Locked]\n§8${ProgressionManager.requirementText("augment")}`, "textures/items/reforge_hammer")
            .button(ProgressionManager.canUse(player, "gem") ? "§bGem Fusion" : `§8Gem Fusion §c[Locked]\n§8${ProgressionManager.requirementText("gem")}`, "textures/icons/gem")
            .button(`§cSalvage\n§8[${SALVAGE_HAMMER_DURABILITY} Durability]`, "textures/icons/trash_can")
            .button(ProgressionManager.canUse(player, "rune") ? "§dRune\n§8[Recarved, Reroll, Insert, Remove]" : `§8Rune §c[Locked]\n§8${ProgressionManager.requirementText("rune")}`, "textures/icons/rune");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled) return;

            if (response.selection === 0) {
                if (!ProgressionManager.guard(player, "augment")) return;
                if (!hasHammer(player)) {
                    player.sendMessage("§cYou need a Reforge Hammer in your inventory to use Augment!");
                    return;
                }
                this.openItemSelectMenu(player);
            } else if (response.selection === 1) {
                if (!ProgressionManager.guard(player, "gem")) return;
                this.openGemFusionMenu(player);
            } else if (response.selection === 2) {
                if (!hasHammer(player)) {
                    player.sendMessage("§cYou need a Reforge Hammer in your inventory to use Salvage!");
                    return;
                }
                this.openSalvageSelectMenu(player);
            } else if (response.selection === 3) {
                if (!ProgressionManager.guard(player, "rune")) return;
                RuneAnvilGui.open(player, () => this.openReforgeMenu(player));
            }
        }).catch((error) => console.warn(`[Reforge] Failed to open Reforge Menu: ${error}`));
    }

    // 2. Item selection
    static openItemSelectMenu(player) {
        const eligible = collectEligibleSlots(player);

        if (eligible.length === 0) {
            player.sendMessage("§cYou don't have any eligible items!");
            return;
        }

        const form = new ActionFormData().title("§l§6Select an Item");

        for (const ref of eligible) {
            const slot  = resolveSlot(player, ref);
            const item  = slot.getItem();
            const req   = ITEM_REQUIREMENTS[item.typeId];
            const label = displayName(item);
            form.button(`§f${label}\n§8[${req.type}]`, getItemIconPath(item));
        }

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled) return;
            this.openAugmentMenu(player, eligible[response.selection]);
        }).catch((error) => console.warn(`[Reforge] Failed to open Item Select Menu: ${error}`));
    }

    // 2b. Salvage — item selection
    static openSalvageSelectMenu(player) {
        const eligible = collectEligibleSlots(player).filter((ref) => {
            const slot = resolveSlot(player, ref);
            return slot?.hasItem() && isSalvageable(slot.typeId);
        });

        if (eligible.length === 0) {
            player.sendMessage("§cYou don't have any items that can be salvaged!");
            return this.openReforgeMenu(player);
        }

        const form = new ActionFormData()
            .title("§l§cSalvage")
            .body(`§7Pick an item to break down.\n§7Hammer: ${getHammerDurabilityText(player)}`);

        for (const ref of eligible) {
            const slot  = resolveSlot(player, ref);
            const item  = slot.getItem();
            const label = displayName(item);
            form.button(`§f${label}\n§8[${getCategoryLabel(item.typeId, "en", item) || ITEM_REQUIREMENTS[item.typeId].type}]`, getItemIconPath(item));
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled) return;
            if (response.selection === eligible.length) return this.openReforgeMenu(player);
            this.openSalvageConfirmMenu(player, eligible[response.selection]);
        }).catch((error) => console.warn(`[Reforge] Failed to open Salvage Select Menu: ${error}`));
    }

    // 2c. Salvage — preview + confirm
    static openSalvageConfirmMenu(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem() || !isSalvageable(slot.typeId)) {
            player.sendMessage("§cThat item is no longer available!");
            return this.openSalvageSelectMenu(player);
        }

        const item  = slot.getItem();
        const label = displayName(item);
        const p     = previewSalvage(slot);
        const pct   = Math.round(SALVAGE_FULL_REFUND_CHANCE * 100);
        const half  = Math.round(SALVAGE_MATERIAL_RATIO * 100);

        const lines = [`§f${label}`, "", `§7Materials §8(${half}\uE21F back, ${pct}\uE21F chance of 100\uE21F):`];
        p.materials.forEach((m, i) => {
            lines.push(`  §f${m.count}x ${prettyId(m.id)} §8(full: ${p.fullMaterials[i].count})`);
        });
        if (p.gemCount > 0)  lines.push(`§7Gem Dust: §f${p.gemCount} Gem(s) x random 1-10`);
        if (p.crystals > 0)  lines.push(`§7Augment Crystal: §f${p.crystals}`);
        if (p.essence > 0) {
            lines.push(`§7Enchant Essence: §f${p.essence}`);
            for (const e of p.enchants) lines.push(`  §8${prettyId(e.id)} ${roman(e.level)} → ${e.gain}`);
        }
        lines.push("", `§7Cost: §f${SALVAGE_HAMMER_DURABILITY} Durability §8(Hammer: ${getHammerDurabilityText(player)})`,
                   `§7Perfect Salvage: §f+${PERFECT_SALVAGE_CORES}x Augment Core §8(have: ${GemManager.countItem(player, AUGMENT_CORE_ID)}) §7-> §f100\uE21F §7materials`,
                   "§c*The item will be destroyed!");

        const form = new ActionFormData()
            .title("§l§cConfirm Salvage")
            .body(lines.join("\n"))
            .button("§cSalvage", "textures/icons/trash_can")
            .button(`§6Perfect Salvage\n§8[${PERFECT_SALVAGE_CORES} Augment Core]`, "textures/icons/trash_can")
            .button("§8< Back",  "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled) return;
            if (response.selection === 2) return this.openSalvageSelectMenu(player);
            const perfect = response.selection === 1;
            if (perfect && GemManager.countItem(player, AUGMENT_CORE_ID) < PERFECT_SALVAGE_CORES) {
                player.sendMessage(`§cPerfect Salvage needs ${PERFECT_SALVAGE_CORES}x Augment Core!`);
                return this.openSalvageConfirmMenu(player, ref);
            }

            if (!slot.hasItem() || !isSalvageable(slot.typeId)) {
                player.sendMessage("§cThat item is no longer available!");
                return this.openSalvageSelectMenu(player);
            }
            if (!damageHammer(player, SALVAGE_HAMMER_DURABILITY)) {
                player.sendMessage("§cYou need a Reforge Hammer to salvage an item!");
                return this.openSalvageSelectMenu(player);
            }

            if (perfect) for (let i = 0; i < PERFECT_SALVAGE_CORES; i++) GemManager.consumeItem(player, AUGMENT_CORE_ID);
            const { full, rewards } = performSalvage(player, slot, perfect);
            const summary = rewards.map((r) => `${r.count}x ${prettyId(r.id)}`).join(", ");
            player.sendMessage(`§a${perfect ? "§6Perfect Salvage! §aFull materials returned. " : full ? "§6Lucky! §aFull materials returned. " : ""}Salvaged §f${label}§a: §f${summary}`);
            player.playSound("random.anvil_use");
            this.openSalvageSelectMenu(player);
        }).catch((error) => console.warn(`[Reforge] Failed to open Salvage Confirm Menu: ${error}`));
    }

    // 3. Augment Menu
    static openAugmentMenu(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cThat item is no longer available!");
            return;
        }

        const item         = slot.getItem();
        const req          = ITEM_REQUIREMENTS[item.typeId];
        const values       = AugmentManager.getValues(slot, req.type);
        const augmentLines = AugmentManager.buildLoreLines(req.type, values, slot);

        const label = displayName(item);
        const body  = augmentLines.length > 0
            ? `§f${label}\n\n${augmentLines.join("\n")}`
            : `§f${label}\n\n§7No Augment stats rolled yet.`;

        const form = new ActionFormData()
            .title("§l§6Augment Menu")
            .body(body)
            .button(`§9Reroll Aug.\n§8[${HAMMER_DURABILITY_COST.reroll} Durability + ${AUGMENT_CRYSTAL_COST.reroll} Crystal]`, "textures/icons/blue_reroll")
            .button(`§dMax Aug.\n§8[${HAMMER_DURABILITY_COST.max} Durability + ${MAX_AUGMENT_CORES} Augment Core]`,        "textures/icons/blue_plus")
            .button(`§eLock Aug.\n§8[${HAMMER_DURABILITY_COST.lock} Dur. + ${AUGMENT_CRYSTAL_COST.lock} Crystals / ${HAMMER_DURABILITY_COST.unlock} Dur.]`, "textures/icons/lock")
            .button("§cRemove Aug.\n§8[Free]",                                         "textures/icons/trash_can")
            .button("§8< Back",                                                        "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled) return;
            switch (response.selection) {
                case 0: this.openRerollMenu(player, ref);  break;
                case 1: this.openMaxMenu(player, ref);     break;
                case 2: this.openLockMenu(player, ref);    break;
                case 3: this.handleRemoveAll(player, ref); break;
                case 4: this.openItemSelectMenu(player);   break;
            }
        }).catch((error) => console.warn(`[Reforge] Failed to open Augment Menu: ${error}`));
    }

    // 3.1 Reroll
    static openRerollMenu(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cThat item is no longer available!");
            return;
        }

        const item         = slot.getItem();
        const req          = ITEM_REQUIREMENTS[item.typeId];
        const values       = AugmentManager.getValues(slot, req.type);
        const augmentLines = AugmentManager.buildLoreLines(req.type, values, slot);
        const statsText    = augmentLines.length > 0 ? augmentLines.join("\n") : "§7No Augment stats rolled yet.";
        const hammerText   = getHammerDurabilityText(player);

        const form = new ActionFormData()
            .title("§l§9Reroll Augment")
            .body(`${statsText}\n\n§7Cost: §f${HAMMER_DURABILITY_COST.reroll} Durability §8(Hammer: ${hammerText})\n§7+ §f${AUGMENT_CRYSTAL_COST.reroll}x Augment Crystal §8(have: ${GemManager.countItem(player, AUGMENT_CRYSTAL_ID)})\n§7Locked stats are kept as-is.`)
            .button("§9Reroll")
            .button("§8Back", "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled || response.selection === 1) {
                return this.openAugmentMenu(player, ref);
            }

            if (GemManager.countItem(player, AUGMENT_CRYSTAL_ID) < AUGMENT_CRYSTAL_COST.reroll) {
                player.sendMessage(`§cYou need ${AUGMENT_CRYSTAL_COST.reroll}x Augment Crystal to reroll!`);
                return this.openRerollMenu(player, ref);
            }
            if (!damageHammer(player, HAMMER_DURABILITY_COST.reroll)) {
                player.sendMessage("§cYou need a Reforge Hammer to reroll!");
                return this.openRerollMenu(player, ref);
            }
            for (let i = 0; i < AUGMENT_CRYSTAL_COST.reroll; i++) GemManager.consumeItem(player, AUGMENT_CRYSTAL_ID);

            const hadStats = Object.values(values).some((v) => v !== 0);
            AugmentManager.rerollRespectingLocks(slot, req.type);
            ItemRestrictionManager.updateSlotLore(slot);
            onAugmentReroll(player, slot, req.type, hadStats, AUGMENT_CRYSTAL_COST.reroll);
            player.sendMessage("§aRerolled Augment stats!");
            player.playSound("random.anvil_use");
            this.openRerollMenu(player, ref);
        }).catch((error) => console.warn(`[Reforge] Failed to open Reroll Menu: ${error}`));
    }

    // 3.2 Max
    static openMaxMenu(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cThat item is no longer available!");
            return;
        }

        const item          = slot.getItem();
        const req           = ITEM_REQUIREMENTS[item.typeId];
        const defs          = AugmentManager.getDefsForType(req.type, item.typeId);
        const values        = AugmentManager.getValues(slot, req.type);
        const rollableStats = Object.entries(defs).filter(([statName]) => (values[statName] ?? 0) !== 0);

        if (rollableStats.length === 0) {
            player.sendMessage("§cThis item has no rolled Augment stats to max!");
            return this.openAugmentMenu(player, ref);
        }

        const hammerText = getHammerDurabilityText(player);
        const form = new ActionFormData()
            .title("§l§dMax Augment")
            .body(`§7Cost: §f${HAMMER_DURABILITY_COST.max} Durability §8(Hammer: ${hammerText})\n§7+ §f${MAX_AUGMENT_CORES}x Augment Core §8(have: ${GemManager.countItem(player, AUGMENT_CORE_ID)})\n§7Pick a stat to set to its maximum.`);

        for (const [statName, def] of rollableStats) {
            const locked = AugmentManager.isLocked(slot, req.type, statName);
            form.button(`§f${def.label} §8(${values[statName]}/${def.max})${locked ? " §8[Locked]" : ""}`);
        }
        form.button("§8Back", "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled || response.selection === rollableStats.length) {
                return this.openAugmentMenu(player, ref);
            }

            const [statName] = rollableStats[response.selection];

            if (AugmentManager.isLocked(slot, req.type, statName)) {
                player.sendMessage("§cThat stat is locked!");
                return this.openMaxMenu(player, ref);
            }

            if (GemManager.countItem(player, AUGMENT_CORE_ID) < MAX_AUGMENT_CORES) {
                player.sendMessage(`§cYou need ${MAX_AUGMENT_CORES}x Augment Core to max a stat!`);
                return this.openMaxMenu(player, ref);
            }

            if (!damageHammer(player, HAMMER_DURABILITY_COST.max)) {
                player.sendMessage("§cYou need a Reforge Hammer to max a stat!");
                return this.openMaxMenu(player, ref);
            }

            for (let i = 0; i < MAX_AUGMENT_CORES; i++) GemManager.consumeItem(player, AUGMENT_CORE_ID);

            AugmentManager.maxStat(slot, req.type, statName);
            ItemRestrictionManager.updateSlotLore(slot);
            onAugmentMax(player, slot, req.type);
            player.sendMessage("§aStat maxed out!");
            player.playSound("random.anvil_use");
            this.openAugmentMenu(player, ref);
        }).catch((error) => console.warn(`[Reforge] Failed to open Max Menu: ${error}`));
    }

    // 3.3 Lock / Unlock
    static openLockMenu(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cThat item is no longer available!");
            return;
        }

        const item          = slot.getItem();
        const req           = ITEM_REQUIREMENTS[item.typeId];
        const defs          = AugmentManager.getDefsForType(req.type, item.typeId);
        const values        = AugmentManager.getValues(slot, req.type);
        const rollableStats = Object.entries(defs).filter(([statName]) => (values[statName] ?? 0) > 0);

        if (rollableStats.length === 0) {
            player.sendMessage("§cThis item has no rolled Augment stats to lock!");
            return this.openAugmentMenu(player, ref);
        }

        const hammerText = getHammerDurabilityText(player);
        const form = new ActionFormData()
            .title("§l§eLock Augment")
            .body(`§7Lock: §f${HAMMER_DURABILITY_COST.lock} Durability + ${AUGMENT_CRYSTAL_COST.lock}x Augment Crystal §8| §7Unlock: §f${HAMMER_DURABILITY_COST.unlock} Durability §8(Hammer: ${hammerText}, Crystals: ${GemManager.countItem(player, AUGMENT_CRYSTAL_ID)})`);

        for (const [statName, def] of rollableStats) {
            const locked = AugmentManager.isLocked(slot, req.type, statName);
            const icon   = locked ? "textures/icons/green_lock" : "textures/icons/gray_unlock";
            form.button(`§f${def.label} §8(${values[statName]}/${def.max}) ${locked ? "§a[Locked]" : "§8[Unlocked]"}`, icon);
        }
        form.button("§8Back", "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled || response.selection === rollableStats.length) {
                return this.openAugmentMenu(player, ref);
            }

            const [statName] = rollableStats[response.selection];
            const locked     = AugmentManager.isLocked(slot, req.type, statName);

            if (locked) {
                if (!damageHammer(player, HAMMER_DURABILITY_COST.unlock)) {
                    player.sendMessage("§cYou need a Reforge Hammer to unlock!");
                    return this.openLockMenu(player, ref);
                }
                AugmentManager.setLocked(slot, req.type, statName, false);
                player.sendMessage("§aStat unlocked!");
            } else {
                if (GemManager.countItem(player, AUGMENT_CRYSTAL_ID) < AUGMENT_CRYSTAL_COST.lock) {
                    player.sendMessage(`§cYou need ${AUGMENT_CRYSTAL_COST.lock}x Augment Crystal to lock a stat!`);
                    return this.openLockMenu(player, ref);
                }
                if (!damageHammer(player, HAMMER_DURABILITY_COST.lock)) {
                    player.sendMessage("§cYou need a Reforge Hammer to lock!");
                    return this.openLockMenu(player, ref);
                }
                for (let i = 0; i < AUGMENT_CRYSTAL_COST.lock; i++) GemManager.consumeItem(player, AUGMENT_CRYSTAL_ID);
                AugmentManager.setLocked(slot, req.type, statName, true);
                onAugmentLock(player);
                player.sendMessage("§aStat locked!");
            }

            ItemRestrictionManager.updateSlotLore(slot);
            player.playSound("random.anvil_use");
            this.openLockMenu(player, ref);
        }).catch((error) => console.warn(`[Reforge] Failed to open Lock Menu: ${error}`));
    }

    // 3.4 Remove all
    static handleRemoveAll(player, ref) {
        const slot = resolveSlot(player, ref);
        if (!slot?.hasItem()) {
            player.sendMessage("§cThat item is no longer available!");
            return;
        }

        const req = ITEM_REQUIREMENTS[slot.getItem().typeId];
        AugmentManager.removeAll(slot, req.type);
        ItemRestrictionManager.updateSlotLore(slot);
        player.sendMessage("§aAll Augment stats removed!");
        player.playSound("random.anvil_use");
        this.openAugmentMenu(player, ref);
    }

    // Fuse All (Standard only): walk from the lowest tier up, fusing every full set of
    // GEM_FUSION_COUNT gems into the next tier (results can be fused again one tier later).
    // Stops when nothing is left to fuse or the Hammer runs out / breaks.
    static fuseAllGems(player) {
        if (!hasHammer(player)) {
            player.sendMessage("§cYou need a Reforge Hammer in your inventory to use Gem Fusion!");
            return;
        }
        const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
        const giveGems = (itemId, amount) => {
            while (amount > 0) {
                const stack = Math.min(amount, 64);
                const item = new ItemStack(itemId, stack);
                if (inv && inv.emptySlotsCount > 0) inv.addItem(item);
                else player.dimension.spawnItem(item, player.location);
                amount -= stack;
            }
        };

        const used = new Array(GEM_TIERS.length).fill(0);       // gems consumed per tier
        const made = new Array(GEM_TIERS.length).fill(0);       // gems produced per tier
        let fusions = 0, hammerGone = false;

        for (let i = 0; i < GEM_TIERS.length - 1 && !hammerGone; i++) {
            const tier = GEM_TIERS[i];
            const sets = Math.floor(GemManager.countItem(player, tier.itemId) / GEM_FUSION_COUNT);
            let done = 0;
            for (let k = 0; k < sets; k++) {
                if (!damageHammer(player, HAMMER_DURABILITY_COST.fusion)) { hammerGone = true; break; }
                done++;
                if (!hasHammer(player)) { hammerGone = true; break; }   // that hit broke it
            }
            if (done > 0) {
                for (let n = 0; n < done * GEM_FUSION_COUNT; n++) GemManager.consumeItem(player, tier.itemId);
                giveGems(GEM_TIERS[i + 1].itemId, done);
                used[i] += done * GEM_FUSION_COUNT;
                made[i + 1] += done;
                fusions += done;
            }
        }

        if (fusions === 0) {
            player.sendMessage(hammerGone
                ? "§c[Gem Fusion] No Reforge Hammer left, nothing was fused."
                : `§c[Gem Fusion] No Gem set to fuse (need ${GEM_FUSION_COUNT}× of one tier).`);
            return;
        }
        const parts = [];
        for (let i = 0; i < GEM_TIERS.length; i++) {
            const t = GEM_TIERS[i];
            if (used[i] > 0 || made[i] > 0) parts.push(`${t.color}${t.label}§f ${made[i] > 0 ? "+" + made[i] : ""}${used[i] > 0 ? " -" + used[i] : ""}`);
        }
        onGemFusion(player, fusions);
        player.sendMessage(`§d[Fuse All] §f${fusions} fusion(s): ${parts.join("§8, ")}${hammerGone ? " §c(Hammer ran out)" : ""}`);
        player.playSound("random.anvil_use");
    }

    // 4. Gem Fusion — two ways to turn Gems into 1 Gem one tier higher:
    //    Standard: GEM_FUSION_COUNT Gems of one tier (Hammer durability only).
    //    Core:     CORE_FUSION_GEMS Gems of one tier + CORE_FUSION_CORES Augment Core (Hammer durability too).
    static openGemFusionMenu(player, mode = null) {
        if (!hasHammer(player)) {
            player.sendMessage("§cYou need a Reforge Hammer in your inventory to use Gem Fusion!");
            return;
        }

        const hammerText = getHammerDurabilityText(player);

        // Step 1: pick the fusion type
        if (mode === null) {
            const cores = GemManager.countItem(player, AUGMENT_CORE_ID);
            const pick = new ActionFormData()
                .title("§l§bGem Fusion")
                .body(
                    `§7Cost: §f${HAMMER_DURABILITY_COST.fusion} Durability §8(Hammer: ${hammerText})\n` +
                    `§7Standard: §f${GEM_FUSION_COUNT}× §7Gems of one tier -> §f1× §7one tier higher.\n` +
                    `§7Core: §f${CORE_FUSION_GEMS}× §7Gems + §f${CORE_FUSION_CORES}x Augment Core §8(have: ${cores}) §7-> §f1× §7one tier higher.`
                )
                .button(`§bStandard\n§8[${GEM_FUSION_COUNT} Gems]`)
                .button(`§6Core\n§8[${CORE_FUSION_GEMS} Gems + ${CORE_FUSION_CORES} Augment Core]`)
                .button("§8< Back", "textures/icons/back");
            return GuiService.show(player, pick, "systems.reforge.js").then((response) => {
                if (response.canceled || response.selection === 2) return this.openReforgeMenu(player);
                this.openGemFusionMenu(player, response.selection === 1 ? "core" : "std");
            }).catch((error) => console.warn(`[Reforge] Failed to open Gem Fusion Menu: ${error}`));
        }

        // Step 2: pick the tier
        const core        = mode === "core";
        const need        = core ? CORE_FUSION_GEMS : GEM_FUSION_COUNT;
        const coreCost    = core ? CORE_FUSION_CORES : 0;
        const fusableTiers = GEM_TIERS.slice(0, GEM_TIERS.length - 1); // all but the max tier
        const cores       = GemManager.countItem(player, AUGMENT_CORE_ID);

        const form = new ActionFormData()
            .title(core ? "§l§6Gem Fusion (Core)" : "§l§bGem Fusion")
            .body(
                `§7Combine §f${need}× §7Gems of one tier${core ? ` §7+ §f${coreCost}x Augment Core §8(have: ${cores})` : ""} §7into §f1× §7Gem, one tier higher.\n` +
                `§7Cost: §f${HAMMER_DURABILITY_COST.fusion} Durability §8(Hammer: ${hammerText})`
            );

        for (let i = 0; i < fusableTiers.length; i++) {
            const tier    = fusableTiers[i];
            const next    = GEM_TIERS[i + 1];
            const count   = GemManager.countItem(player, tier.itemId);
            const canFuse = count >= need && cores >= coreCost;
            form.button(
                `${canFuse ? tier.color : "§8"}${tier.label} Gem §8x${count}\n` +
                `§8-> ${next.color}${next.label} Gem`,
                getItemIconPath(tier.itemId)
            );
        }
        // Standard fusion only: one button that fuses everything upward as far as possible.
        const fuseAllIndex = core ? -1 : fusableTiers.length;
        if (!core) {
            form.button(`§dFuse All\n§8[Every gem -> highest tier possible]`, "textures/icons/blue_plus");
        }
        form.button("§8< Back", "textures/icons/back");

        GuiService.show(player, form, "systems.reforge.js").then((response) => {
            if (response.canceled || response.selection === fusableTiers.length + (core ? 0 : 1)) {
                return this.openGemFusionMenu(player, null);
            }
            if (response.selection === fuseAllIndex) {
                this.fuseAllGems(player);
                return this.openGemFusionMenu(player, mode);
            }

            const tier  = fusableTiers[response.selection];
            const next  = GEM_TIERS[response.selection + 1];
            const count = GemManager.countItem(player, tier.itemId);

            if (count < need) {
                player.sendMessage(`§cNeed §f${need}× ${tier.label} Gem §c(have: ${count}).`);
                return this.openGemFusionMenu(player, mode);
            }
            if (GemManager.countItem(player, AUGMENT_CORE_ID) < coreCost) {
                player.sendMessage(`§cNeed §f${coreCost}x Augment Core §cfor Core Fusion.`);
                return this.openGemFusionMenu(player, mode);
            }

            if (!damageHammer(player, HAMMER_DURABILITY_COST.fusion)) {
                player.sendMessage("§cYou need a Reforge Hammer to fuse Gems!");
                return this.openGemFusionMenu(player, mode);
            }

            for (let i = 0; i < need; i++) GemManager.consumeItem(player, tier.itemId);
            for (let i = 0; i < coreCost; i++) GemManager.consumeItem(player, AUGMENT_CORE_ID);

            const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
            const resultItem = new ItemStack(next.itemId, 1);
            if (inv && inv.emptySlotsCount > 0) inv.addItem(resultItem);
            else player.dimension.spawnItem(resultItem, player.location);

            player.sendMessage(`§b[Gem Fusion] §f${need}× ${tier.color}${tier.label} Gem${core ? ` + ${coreCost}x Augment Core` : ""} §b-> §f1× ${next.color}${next.label} Gem!`);
            onGemFusion(player, 1);
            player.playSound("random.anvil_use");
            this.openGemFusionMenu(player, mode);
        }).catch((error) => console.warn(`[Reforge] Failed to open Gem Fusion Menu: ${error}`));
    }
}
