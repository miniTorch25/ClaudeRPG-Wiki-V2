// damage_indicator_core.js -- spawn logic for floating damage numbers. No direct engine imports so it can
// be tested with fakes; damage_indicator.js wires in the real world and scheduler.
import { DAMAGE_INDICATOR as C } from "../config/damage_indicator_config.js";
import { formatHp } from "./health_display_name.js";

export function createDamageIndicator(deps) {
    const { defer, getTick, random = Math.random } = deps;
    const merging = new Map();  // "attackerId|victimId" -> { tick, sum, crit, entity } of the number still open for merging
    const alive = new Map();   // attacker id -> expiry ticks of the numbers it still has on screen

    function liveCount(id, now) {
        const list = (alive.get(id) ?? []).filter((t) => t > now);
        if (list.length) alive.set(id, list); else alive.delete(id);
        return list.length;
    }

    // ctx: DamageContext after resolving. Read-only here; spawning happens one tick later via defer().
    function onDamage(ctx) {
        if (!C.ENABLED) return false;
        const attacker = ctx?.attacker, victim = ctx?.victim;
        if (attacker?.typeId !== "minecraft:player" || !victim?.isValid) return false;
        if (victim.typeId === "minecraft:player" || victim.typeId === C.ENTITY_ID) return false;
        const amount = Math.round(Number(ctx.meta?.appliedDamage ?? ctx.finalDamage));
        if (!(amount > 0)) return false;

        let a, v, head, dim;
        try { a = attacker.location; v = victim.location; dim = victim.dimension; } catch (_) { return false; }
        try { head = victim.getHeadLocation(); } catch (_) { head = { x: v.x, y: v.y + 1, z: v.z }; }
        const dist = Math.hypot(a.x - v.x, a.y - v.y, a.z - v.z);
        if (dist > C.VIEW_RADIUS) return false;

        const now = getTick();
        const crit = ctx.meta?.crit === true;
        const key = `${attacker.id}|${victim.id}`;
        // Merge: another hit within MERGE_TICKS adds to the number that is already floating.
        const open = merging.get(key);
        if (open && now - open.tick < (C.MERGE_TICKS ?? 0)) {
            open.sum += amount;
            open.crit = open.crit || crit;
            const label = `${open.crit ? C.COLOR_CRIT : C.COLOR_NORMAL}${formatHp(open.sum)}`;
            defer(() => { try { if (open.entity?.isValid) open.entity.nameTag = label; } catch (_) {} });
            return true;
        }
        if (merging.size > 128) for (const [k, v] of merging) if (now - v.tick >= (C.MERGE_TICKS ?? 0)) merging.delete(k);
        if (liveCount(attacker.id, now) >= C.MAX_PER_PLAYER) return false;
        alive.set(attacker.id, [...(alive.get(attacker.id) ?? []), now + C.LIFETIME_TICKS]);

        const angle = random() * Math.PI * 2;
        const r = C.RADIUS_MIN + random() * Math.max(0, C.RADIUS_MAX - C.RADIUS_MIN);
        const at = {
            x: v.x + Math.cos(angle) * r,
            y: head.y + C.HEIGHT_MIN + random() * Math.max(0, C.HEIGHT_MAX - C.HEIGHT_MIN),
            z: v.z + Math.sin(angle) * r,
        };
        const text = `${crit ? C.COLOR_CRIT : C.COLOR_NORMAL}${formatHp(amount)}`;
        const rec = { tick: now, sum: amount, crit, entity: null };
        merging.set(key, rec);
        defer(() => {
            try {
                const e = dim.spawnEntity(C.ENTITY_ID, at);
                e.nameTag = rec.crit === crit && rec.sum === amount ? text : `${rec.crit ? C.COLOR_CRIT : C.COLOR_NORMAL}${formatHp(rec.sum)}`;
                rec.entity = e;
            } catch (_) { /* chunk not loaded or entity not available */ }
        });
        return true;
    }

    return { onDamage, forget: (id) => alive.delete(id), _alive: alive };
}
