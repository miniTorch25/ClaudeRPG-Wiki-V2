// ClaudeRPG Gem Registry — single source of truth for Gem tiers, the 84 Gem abilities and their armor categories.
//
// 7 tiers (Common … Mythical) × 12 abilities = 84.
// Armor categories:  H = Helm (head)   C = Chest   L = Legs   B = Boots (feet)
//   Tiers 1-3 (Common / Uncommon / Rare): 4 universal abilities (HCLB) + 8 paired abilities (2 categories each),
//     so every category sees 8 of the 12. These stack: the same ability on several pieces adds up.
//   Tiers 4-7 (Unique / Legend / Epic / Mythical): 3 abilities per category, one category each.
//
// An ability has no level: fixed values per ability (gem_ability_config.js), boosted only by Gem Potency.

export const GEM_CATEGORY_BY_SLOT = Object.freeze({ head: "H", chest: "C", legs: "L", feet: "B" });
export const GEM_CATEGORY_NAME = Object.freeze({ H: "Helm", C: "Chest", L: "Legs", B: "Boots" });

// [display name, categories]
const TIERS = [
    ["common", [
        ["Vitality", "HCLB"], ["Swiftness", "HCLB"], ["Toughness", "HCLB"], ["Recovery", "HCLB"],
        ["Keen Eyes", "HB"], ["Marksman", "HB"], ["Focus", "HC"], ["Mana Trickle", "HL"],
        ["Padded Plate", "CL"], ["Brawler", "CL"], ["Sure Step", "CB"], ["Soft Landing", "LB"],
    ]],
    ["uncommon", [
        ["Hearty", "HCLB"], ["Vigor", "HCLB"], ["Tenacity", "HCLB"], ["Intuition", "HCLB"],
        ["Spell Ward", "HC"], ["Clear Mind", "HL"], ["Eagle Eye", "HB"], ["Aqua Lung", "HB"],
        ["Stoneskin", "CL"], ["Brute Force", "CL"], ["Thorns", "CB"], ["Marathon", "LB"],
    ]],
    ["rare", [
        ["Fortitude", "HCLB"], ["Adrenaline", "HCLB"], ["Resolve", "HCLB"], ["Swift Strides", "HCLB"],
        ["Assassination", "HL"], ["Arcane Reservoir", "HC"], ["Spellbreaker", "HC"], ["Reflexes", "HB"],
        ["Sanctuary", "CL"], ["Plate Wall", "CB"], ["Cat's Grace", "LB"], ["Killer's Rush", "LB"],
    ]],
    ["unique", [
        ["Arcane Surge", "H"], ["Clairvoyance", "H"], ["Spell Mirror", "H"],
        ["Reflection", "C"], ["Second Wind", "C"], ["Glacial Presence", "C"],
        ["Cinderveil", "L"], ["Warpath", "L"], ["Executioner's Gait", "L"],
        ["Wind Walker", "B"], ["Frost Walker", "B"], ["Evasion", "B"],
    ]],
    ["legend", [
        ["Immunity", "H"], ["Lucid Mind", "H"], ["Soulward", "H"],
        ["Guardian Shield", "C"], ["Bulletproof", "C"], ["Unyielding", "C"],
        ["Bloodthirst", "L"], ["Overpower", "L"], ["Momentum Strike", "L"],
        ["Void Escape", "B"], ["Skystep", "B"], ["Quicksilver", "B"],
    ]],
    ["epic", [
        ["Archmage's Crown", "H"], ["Premonition", "H"], ["Dragon's Gaze", "H"],
        ["Frostflare", "C"], ["Static Field", "C"], ["Titan Heart", "C"],
        ["Vampirism", "L"], ["Rampage", "L"], ["Thunder Stride", "L"],
        ["Flight", "B"], ["Phase Step", "B"], ["Earthshaker", "B"],
    ]],
    ["mythical", [
        ["Ascended Mind", "H"], ["Mind Over Matter", "H"], ["Third Eye", "H"],
        ["Undying", "C"], ["Colossus", "C"], ["Domain", "C"],
        ["Berserker", "L"], ["Warlord's Might", "L"], ["Reaper's Due", "L"],
        ["Godspeed", "B"], ["Voidstep", "B"], ["Earthbound", "B"],
    ]],
];

// "Cat's Grace" -> "cats_grace", "Executioner's Gait" -> "executioners_gait"
export function normalizeGemAbility(skillName) {
    return String(skillName ?? "").trim().toLowerCase().replace(/['’]/g, "").replace(/\s+/g, "_");
}

// key -> { key, name, tier, tierIndex (1-7), cats: "HCLB"-style string, stackable }
export const GEM_DEFS = {};
const _registry = {};
TIERS.forEach(([tier, list], i) => {
    _registry[tier] = { skills: [], abilities: [] };
    for (const [name, cats] of list) {
        const key = normalizeGemAbility(name);
        GEM_DEFS[key] = Object.freeze({ key, name, tier, tierIndex: i + 1, cats, stackable: i < 3 });
        _registry[tier].skills.push(name);
        _registry[tier].abilities.push(key);
    }
    Object.freeze(_registry[tier]);
});
Object.freeze(GEM_DEFS);

// tier id -> { skills: [display names], abilities: [keys] }   (all 12 of the tier, any category)
export const GEM_REGISTRY = Object.freeze(_registry);

export function getGemDefinition(tierId) {
    return GEM_REGISTRY[tierId] ?? null;
}

export function getAbilityDef(skillNameOrKey) {
    return GEM_DEFS[normalizeGemAbility(skillNameOrKey)] ?? null;
}

// All abilities of the tier (any category).
export function getGemAbilities(tierId) {
    return getGemDefinition(tierId)?.abilities ?? [];
}

// Abilities of the tier that an armor piece of category `cat` ("H" | "C" | "L" | "B") can carry.
// With no category, returns the whole tier.
export function getEligibleAbilities(tierId, cat) {
    const all = getGemAbilities(tierId);
    return cat ? all.filter((k) => GEM_DEFS[k].cats.includes(cat)) : all;
}

export function isGemAbilityValid(tierId, skillName, cat = null) {
    const def = getAbilityDef(skillName);
    if (!def || def.tier !== tierId) return false;
    return cat ? def.cats.includes(cat) : true;
}

// ─── Migration of v1_24 and older Gems ───────────────────────────────────────
// Old skill key -> new ability key. Applied only when the new ability exists in the SAME tier and fits the
// armor category; otherwise the socket is re-rolled for free inside its tier + category.
export const LEGACY_GEM_MAP = Object.freeze({
    swiftness: "swiftness",   vitality: "vitality",   featherfall: "soft_landing", keen_eyes: "keen_eyes",
    bulwark: "toughness",     intuition: "intuition", tenacity: "tenacity",        vigor: "vigor",
    reservoir: "arcane_reservoir", assassination: "assassination", fortress: "sanctuary", adrenaline: "adrenaline",
    reflection: "reflection", cinderveil: "cinderveil", glacial_presence: "glacial_presence", second_wind: "second_wind",
    immunity: "immunity",     void_escape: "void_escape", guardian_shield: "guardian_shield", bulletproof: "bulletproof",
    frostflare: "frostflare", flight: "flight",       vampirism: "vampirism",      static_field: "static_field",
    undying: "undying",       domain: "domain",       berserker: "berserker",      colossus: "colossus",
});

// Decides what a stored skill becomes on armor of category `cat` in a gem of `tierId`.
// Returns { name, changed } ; `reroll: true` when the socket was re-rolled inside its tier + category.
export function migrateGemSkill(tierId, storedSkill, cat, random = Math.random) {
    const key = normalizeGemAbility(storedSkill);
    if (isGemAbilityValid(tierId, key, cat)) return { name: GEM_DEFS[key].name, changed: false };
    const mapped = LEGACY_GEM_MAP[key];
    if (mapped && isGemAbilityValid(tierId, mapped, cat)) return { name: GEM_DEFS[mapped].name, changed: true };
    const pool = getEligibleAbilities(tierId, cat);
    if (pool.length === 0) return { name: null, changed: true };
    return { name: GEM_DEFS[pool[Math.min(pool.length - 1, Math.floor(random() * pool.length))]].name, changed: true, reroll: true };
}
