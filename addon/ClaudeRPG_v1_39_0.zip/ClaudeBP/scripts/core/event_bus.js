// ClaudeRPG EventBus — internal application events, separate from Bedrock events.
// Bedrock subscriptions belong to EventRouter; feature systems communicate through this bus.
const channels = new Map();

function getChannel(name) {
    let listeners = channels.get(name);
    if (!listeners) {
        listeners = new Set();
        channels.set(name, listeners);
    }
    return listeners;
}

export const EventBus = {
    on(name, listener) {
        if (typeof listener !== "function") throw new TypeError(`Listener for ${name} must be a function`);
        const listeners = getChannel(name);
        listeners.add(listener);
        return () => listeners.delete(listener);
    },
    emit(name, payload) {
        const listeners = channels.get(name);
        if (!listeners) return;
        for (const listener of [...listeners]) {
            try { listener(payload); }
            catch (error) { console.warn(`[ClaudeRPG] EventBus ${name} listener error: ${error}`); }
        }
    },
    clear(name = null) {
        if (name === null) channels.clear();
        else channels.delete(name);
    },
};
