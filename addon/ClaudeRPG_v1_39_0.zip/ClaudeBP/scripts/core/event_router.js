// ClaudeRPG EventRouter — single owner for the main gameplay event channels.
// Managers/systems expose handlers; they do not subscribe to world events here.
import { world, system, ItemStack, EntityComponentTypes, EquipmentSlot, GameMode } from "@minecraft/server";
import { CONFIG } from "../config/config.js";
import { ITEM_REQUIREMENTS } from "../config/req_config.js";
import { giveItemSafely } from "../managers/item_helper.js";
import { ScoreboardManager } from "../managers/scoreboard_manager.js";
import { XPManager } from "../managers/xp_manager.js";
import { HPManager } from "../managers/hp_manager.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { HealthDisplay } from "../systems/health_display.js";
import { HEALTH_DISPLAY } from "../config/health_display_config.js";
import { DamageIndicator } from "../systems/damage_indicator.js";
import { SpecialMobManager } from "../managers/special_mob_manager.js";
import { SPECIAL } from "../config/special_config.js";
import { EVOLUTION } from "../config/evolution_config.js";
import { NightmareManager } from "../managers/nightmare_manager.js";
import { handleAdminCommand } from "../systems/admin_commands.js";
import { ScriptActions } from "../systems/script_tool_gui.js";
import { AdminManager } from "../managers/admin_manager.js";
import { DeathManager } from "../managers/death_manager.js";
import { PlayerManager } from "../managers/player_manager.js";
import { EquipmentManager } from "../managers/equipment_manager.js";
import { DamageManager, isSuppressed } from "../managers/damage_manager.js";
import { HudManager } from "../managers/hud_manager.js";
import { ManaManager } from "../managers/mana_manager.js";
import { GemAbility } from "../systems/gem_ability.js";
import { ChorusEffects } from "../systems/chorus_effects.js";
import { GemManager, UNCARVED_GEM_ID, GEM_DUST_ID, HAMMER_ITEM_IDS } from "../systems/gem_manager.js";
import { carveUncarvedRunes } from "../rune/rune_item.js";
import { UNCARVED_RUNE_ID, RUNE_GRADES } from "../config/rune_item_config.js";
import { AugmentManager } from "../systems/augment.js";
import { MovementManager } from "../managers/movement_manager.js";
import { ItemRestrictionManager } from "../systems/item_restriction.js";
import { ReforgeManager, ANVIL_BLOCK_TYPES, HAMMER_ITEMS } from "../systems/reforge.js";
import { RuneCreativeGui } from "../systems/rune_creative_gui.js";
import { UltenchGui } from "../systems/ultench_gui.js";
import { StellarCore, STELLAR_CORE_ID } from "../systems/stellar_core.js";
import { RedeemManager } from "../systems/redeem.js";
import { GuiManager } from "../gui/gui_manager.js";
import { GuiRouter } from "../gui/gui_router.js";
import { GuiService } from "../gui/gui_service.js";
import { KnowledgeManager } from "../systems/knowledge_book.js";
import { WaypointManager } from "../systems/waypoint_manager.js";
import { WaypointGui } from "../systems/waypoint_gui.js";
import { DiscoveryManager } from "../systems/discovery_manager.js";
import { SettingsManager } from "../systems/settings_manager.js";
import { ToastManager } from "../systems/toast_manager.js";
import { GuideQuest } from "../systems/guide_quest.js";
import { ToastSend } from "../systems/toast_send.js";
import { StashManager } from "../systems/stash_manager.js";
import { AutoReplant } from "../systems/autoreplant.js";
import { ChorusAura } from "../systems/chorus_aura.js";
import { RuneManager, getEquippedRuneId, isActiveRune } from "../rune/rune_manager.js";
import { handleProjectileSpawn, handleProjectileHitEntity, handleProjectileHitBlock, tickProjectileSystem } from "../rune/rune_projectile.js";
import * as RuneCN from "../rune/rune_curseneutral.js";
import { RuntimeState } from "./runtime_state.js";
import { Scheduler } from "./scheduler.js";
import { EventBus } from "./event_bus.js";
import { GemState } from "../systems/gem_state.js";
import { Logger } from "./logger.js";
import { CombatPipeline } from "./combat_pipeline.js";
import { MineXpManager } from "../managers/mine_xp.js";
import { ConsumeXpManager } from "../managers/consume_xp.js";
import { FishingXpManager } from "../managers/fishing_xp.js";
import { ULTIMATE_PICKER_BLACKLIST } from "../config/ultimate_picker_blacklist.js";

const guard = (label, fn) => Logger.guard(label, fn);
let routerRegistered = false;
let jobsRegistered = false;

function handleItemUse(event) {
    const { source: player, itemStack } = event;
    if (!player) return;
    ItemRestrictionManager.checkItemUse(event);
    if (itemStack?.typeId === CONFIG.STATS_BOOK_ITEM) {
        system.run(() => guard("open status menu", () => GuiRouter.open(player, "status")));
    }
    if (itemStack?.typeId === CONFIG.KNOWLEDGE_BOOK_ITEM) {
        system.run(() => guard("open knowledge menu", () => GuiRouter.open(player, "knowledge")));
    }
    if (itemStack?.typeId === CONFIG.SCRIPT_TOOL_ITEM) {
        system.run(() => guard("open script tool", () => GuiRouter.open(player, "script_tool")));
    }
    if (itemStack?.typeId === "crpg:waypoint_orb") {
        system.run(() => guard("open waypoint orb", () => WaypointGui.openOrb(player)));
    }
    if (itemStack?.typeId === "crpg:insight_lens" && player.isSneaking) {
        system.run(() => guard("open insight lens self status", () => GuiRouter.open(player, "status")));
    }

    const runeId = getEquippedRuneId(player);
    if (player.isSneaking && isActiveRune(runeId)) {
        event.cancel = true;
        system.run(async () => guard("active rune", async () => {
            const { onActivate } = await import("../rune/rune_active.js");
            onActivate(player, runeId);
        }));
        return;
    }

    const offhand = player.getComponent("minecraft:equippable")?.getEquipmentSlot("Offhand");
    if (!offhand?.hasItem()) return;
    if (itemStack?.typeId === UNCARVED_RUNE_ID) {
        // Uncarved Rune + Engraver -> random Rune item (Shift = x16)
        if (offhand.typeId === "crpg:engraver" || offhand.typeId === "crpg:eternal_engraver") {
            event.cancel = true;
            system.run(() => guard("carve uncarved rune", () => {
                const grades = carveUncarvedRunes(player, player.isSneaking);
                if (!grades || grades.length === 0) return;
                const tally = {};
                for (const g of grades) tally[g.id] = (tally[g.id] ?? 0) + 1;
                const parts = RUNE_GRADES.filter((g) => tally[g.id]).map((g) => `${g.color}x${tally[g.id]} ${g.label}`);
                const best = Math.max(...grades.map((g) => g.tier));
                player.sendMessage(grades.length > 1
                    ? `§b[×${grades.length} Carved] §fGot: §7${parts.join("§f, ")} §fRune`
                    : `§b[Carve] Got §f${parts[0]} §fRune!`);
                player.playSound(best >= 5 ? "random.levelup" : "random.orb");
            }));
        }
        return;
    }
    if (itemStack?.typeId !== UNCARVED_GEM_ID) return;
    const offhandTypeId = offhand.typeId;
    if (HAMMER_ITEM_IDS.includes(offhandTypeId)) {
        event.cancel = true;
        system.run(() => guard("crush uncarved gem", () => {
            const inv = player.getComponent("minecraft:inventory")?.container;
            if (player.isSneaking) {
                // ×16 Carved — crush up to 16 Uncarved Gems in one click
                const batch = GemManager.crushUncarvedGemBatch(player, 16);
                if (!batch || batch.consumed <= 0) return;
                giveStackSplit(player, inv, GEM_DUST_ID, batch.dustCount);
                player.sendMessage(`§b[×${batch.consumed} Crushed] §fInto §fx${batch.dustCount} Gem Dust!`);
                player.playSound("random.glass");
                return;
            }
            const dustCount = GemManager.crushUncarvedGem(player);
            if (dustCount <= 0) return;
            const stack = new ItemStack(GEM_DUST_ID, dustCount);
            if (inv && inv.emptySlotsCount > 0) inv.addItem(stack); else player.dimension.spawnItem(stack, player.location);
            player.sendMessage(`§b[Uncarved Gem] Crushed into §fx${dustCount} Gem Dust!`);
            player.playSound("random.glass");
        }));
    } else if (offhandTypeId === "crpg:engraver" || offhandTypeId === "crpg:eternal_engraver") {
        event.cancel = true;
        system.run(() => guard("carve uncarved gem", async () => {
            const inv = player.getComponent("minecraft:inventory")?.container;
            const { GEM_TIERS } = await import("../systems/gem_manager.js");
            if (player.isSneaking) {
                // ×16 Carved — carve up to 16 Uncarved Gems in one click
                const batch = GemManager.carveUncarvedGemBatch(player, 16);
                if (!batch || batch.consumed <= 0) return;
                const parts = [];
                for (const [tierId, gemCount] of Object.entries(batch.results)) {
                    const tier = GEM_TIERS.find(t => t.id === tierId);
                    const gemItemId = tier?.itemId ?? "crpg:common_gem";
                    giveStackSplit(player, inv, gemItemId, gemCount);
                    parts.push(`${tier?.color ?? ""}x${gemCount} ${tier?.label ?? tierId}`);
                }
                player.sendMessage(
                    `§b[×${batch.consumed} Carved] §fGot: §7${parts.join("§f, ")}` +
                    (batch.perfectCount > 0 ? ` §6(${batch.perfectCount} Perfect!)` : "")
                );
                player.playSound(batch.perfectCount > 0 ? "random.levelup" : "random.orb");
                return;
            }
            const result = GemManager.carveUncarvedGem(player);
            if (!result) return;
            const { tierId, count, isPerfect } = result;
            const tier = GEM_TIERS.find(t => t.id === tierId);
            const gemItemId = tier?.itemId ?? "crpg:common_gem";
            for (let i = 0; i < count; i++) {
                const stack = new ItemStack(gemItemId, 1);
                if (inv && inv.emptySlotsCount > 0) inv.addItem(stack); else player.dimension.spawnItem(stack, player.location);
            }
            player.sendMessage(isPerfect ? `§6[Perfect Carved!] §fx${count} ${tier?.color ?? ""}${tier?.label ?? tierId} Gem!` : `§b[Carve] Got §f${tier?.color ?? ""}${tier?.label ?? tierId} Gem!`);
            player.playSound(isPerfect ? "random.levelup" : "random.orb");
        }));
    }
}

// Gives `amount` of an item to the player, split into ≤64 stacks (max stack
// size for gems/dust) since a single batch (×16 Carved) can exceed that.
function giveStackSplit(player, inv, itemId, amount) {
    let remaining = amount;
    while (remaining > 0) {
        const give = Math.min(remaining, 64);
        const stack = new ItemStack(itemId, give);
        if (inv && inv.emptySlotsCount > 0) inv.addItem(stack); else player.dimension.spawnItem(stack, player.location);
        remaining -= give;
    }
}

function handleHurtBefore(event) {
    if (isSuppressed(event.hurtEntity?.id)) return;
    guard("combat pipeline", () => CombatPipeline.before(event));
}

function handleBreakBefore(event) {
    if (!WaypointManager.canBreakBlock(event.player, event.block)) {
        event.cancel = true;
        const who = event.player;
        system.run(() => { try { who.sendMessage("§c[Waypoint] Only the owner (or an Admin) can break this Waypoint Stone."); } catch (_) {} });
        return;
    }
    ItemRestrictionManager.checkBlockBreak(event);
}
function handleBreakAfter(event) {
    AugmentManager.applyVein(event);
    AugmentManager.applyLuck(event);
    RuneManager.handleBlockBreak(event);
    WaypointManager.onBreak(event);
    AutoReplant.onBreak(event);
}

// Ultimate Picker — pick up ANY block (even unbreakable ones) directly into the
// player's inventory as its real item form. block.getItemStack(1, true) (withData)
// captures block-entity data too, so a chest keeps its contents, a sign keeps its
// text, etc. — and since it's a genuine block item, vanilla placement just works,
// no custom place-back handling needed. Returns true if it handled the interaction.
function handleUltimatePicker(player, block, itemStack) {
    if (itemStack?.typeId !== "crpg:ultimate_picker") return false;
    if (!block || block.typeId === "minecraft:air") return true;

    if (ULTIMATE_PICKER_BLACKLIST.includes(block.typeId) && player.getGameMode() !== GameMode.Creative) {
        player.sendMessage("§c[Ultimate Picker] This block can only be picked up in Creative Mode!");
        return true;
    }

    if (!WaypointManager.canBreakBlock(player, block)) {
        player.sendMessage("§c[Waypoint] Only the owner (or an Admin) can pick up this Waypoint Stone.");
        return true;
    }

    const container = player.getComponent(EntityComponentTypes.Inventory)?.container;
    if (!container) return true;

    const blockItemStack = block.getItemStack(1, true);
    if (!blockItemStack) {
        player.sendMessage("§c[Ultimate Picker] This block can't be picked up!");
        return true;
    }

    const dimension = block.dimension;
    const location  = { x: block.location.x, y: block.location.y, z: block.location.z };

    system.run(() => guard("ultimate picker pick", () => {
        try {
            if (block.typeId === "crpg:waypoint_stone") WaypointManager.markGone(dimension, location, player);
            dimension.getBlock(location)?.setType("minecraft:air");
            const leftover = container.addItem(blockItemStack);
            if (leftover) dimension.spawnItem(leftover, location);
            player.playSound("random.pop");
        } catch (error) {
            console.warn(`[Ultimate Picker] Failed to pick up block: ${error}`);
        }
    }));
    return true;
}

function handleInteract(event) {
    if (!event.isFirstEvent) return;
    const { player, block, itemStack } = event;
    if (handleUltimatePicker(player, block, itemStack)) { event.cancel = true; return; }
    if (block.typeId === "crpg:ultimate_enchanter") {
        event.cancel = true;
        system.run(() => guard("open ultench menu", () => GuiRouter.open(player, "ultench")));
        return;
    }
    if (block.typeId === "crpg:waypoint_stone" || block.typeId === "crpg:waypoint_stone_blank") {
        // Sneak + holding an item keeps normal block placing against the stone.
        if (player.isSneaking && itemStack) return;
        event.cancel = true;
        const blank = block.typeId === "crpg:waypoint_stone_blank";
        system.run(() => guard("open waypoint stone", () => (blank ? WaypointGui.openBlank(player) : WaypointGui.openStone(player, block))));
        return;
    }
    if (!ANVIL_BLOCK_TYPES.includes(block.typeId)) return;
    const holdingHammer = itemStack && HAMMER_ITEMS.includes(itemStack.typeId);
    if (!player?.isSneaking && !holdingHammer) return;
    event.cancel = true;
    system.run(() => guard("open reforge menu", () => ReforgeManager.openReforgeMenu(player)));
}

// Insight Lens: right-click another player to open a read-only view of their Status Menu.
function handleInteractEntity(event) {
    const { player, target, itemStack } = event;
    if (itemStack?.typeId === STELLAR_CORE_ID) {
        if (!target || target.typeId === "minecraft:player") return;
        event.cancel = true;
        StellarCore.open(player, target);
        return;
    }
    if (itemStack?.typeId !== "crpg:insight_lens") return;
    if (!target || target.typeId !== "minecraft:player") return;
    event.cancel = true;
    system.run(() => guard("open insight lens", () => GuiManager.openViewOnlyStatusMenu(player, target)));
}

function handleSpawn(event) {
    guard("player spawn", () => {
        XPManager.normalizeXp(event.player);   // old fractional XP -> whole number
        if (event.initialSpawn) {
            PlayerManager.onInitialSpawn(event.player);
            MasteryManager.cleanupOldData(event.player);
            GuideQuest.onPlayerSpawn(event.player);
        } else {
            PlayerManager.onRespawn(event.player);
            DeathManager.onRespawn(event.player);
            RuneManager.onPlayerRespawn(event.player);
            GemState.clearPlayer(event.player.id);
            MovementManager.clear(event.player.id);
            AugmentManager.onPlayerRespawn?.(event.player);
        }
    });
}

function handleLeave(event) {
    const id = event.playerId;
    GuiService.clear(id);
    RuneManager.onPlayerLeave(id);
    GemState.clearPlayer(id);
    GemAbility.onPlayerLeave(id);
    PlayerManager.onLeave(id);
    AugmentManager.onPlayerLeave?.(id);
    WaypointManager.onPlayerLeave(id);
    DiscoveryManager.onPlayerLeave(id);
    SettingsManager.onPlayerLeave(id);
    GuideQuest.onPlayerLeave(id);
    ToastManager.onPlayerLeave(id);
    ToastSend.onPlayerLeave(id);
    StashManager.onPlayerLeave(id);
    ChorusAura.onPlayerLeave(id);
}

function handleScriptEvent(event) {
    const { id, sourceEntity: player } = event;
    if (!player || player.typeId !== "minecraft:player") return;
    switch (id) {
        case "status:get_book": ScriptActions.giveStatsBook(player); break;
        case "status:get_script_tool": ScriptActions.giveScriptTool(player); break;
        case "status:open_tool": GuiRouter.open(player, "script_tool"); break;
        case "status:open_knowledge": GuiRouter.open(player, "knowledge"); break;
        case "status:open_chorus": GuiRouter.open(player, "chorus"); break;
        case "status:open_achievements": GuiRouter.open(player, "achievements"); break;
        case "status:open_guide": GuiRouter.open(player, "guide"); break;
        case "status:open_waypoints": GuiRouter.open(player, "waypoints"); break;
        case "status:open_discovery": GuiRouter.open(player, "discovery"); break;
        case "status:open_settings": GuiRouter.open(player, "settings"); break;
        case "status:open_toast": GuiRouter.open(player, "toast"); break;
        case "status:quick_stash": { const r = StashManager.run(player); player.sendMessage(r.ok ? `§b[Stash] §f${r.message}` : `§e[Stash] ${r.message}`); break; }
        case "status:open_gui": GuiRouter.open(player, "status"); break;
        case "status:open_reforge": GuiRouter.open(player, "reforge"); break;
        case "status:open_gem": GuiRouter.open(player, "gem"); break;
        case "status:open_rune_creative": ScriptActions.openRuneCreative(player, (r) => GuiRouter.open(player, r)); break;
        case "status:open_redeem": GuiRouter.open(player, "redeem"); break;
        case "status:admin": handleAdminCommand(player, event.message); break;
        case "status:prog": player.sendMessage("§6[Progression] §fThis command moved. Use §b/scriptevent status:admin §f(needs the Admin tag)."); break;
        case "status:reset_redeem": ScriptActions.resetRedeem(player); break;
        case "status:roll_additional": ScriptActions.rollAdditional(player); break;
    }
}

export function registerEventRouter() {
    if (routerRegistered) return false;
    routerRegistered = true;
    world.beforeEvents.itemUse.subscribe(e => { guard("itemUse", () => handleItemUse(e)); EventBus.emit("itemUse", e); });
    world.beforeEvents.entityHurt.subscribe(e => { guard("entityHurt.before", () => handleHurtBefore(e)); EventBus.emit("entityHurt.before", e); });
    world.beforeEvents.playerBreakBlock.subscribe(e => guard("break.before", () => handleBreakBefore(e)));
    world.afterEvents.playerBreakBlock.subscribe(e => guard("break.after", () => { handleBreakAfter(e); MineXpManager.handleBreak(e); }));
    world.beforeEvents.playerInteractWithBlock.subscribe(e => guard("interact", () => handleInteract(e)));
    world.beforeEvents.playerInteractWithEntity.subscribe(e => guard("interact.entity", () => handleInteractEntity(e)));
    world.afterEvents.playerPlaceBlock.subscribe(e => guard("waypoint.place", () => {
        const wp = WaypointManager.onPlace(e);
        if (wp) system.run(() => guard("waypoint.name", () => WaypointGui.promptName(e.player, wp.id)));
    }));
    world.afterEvents.playerSpawn.subscribe(e => { handleSpawn(e); EventBus.emit("playerSpawn", e); });
    world.afterEvents.playerLeave.subscribe(e => { handleLeave(e); EventBus.emit("playerLeave", e); });
    world.afterEvents.itemCompleteUse.subscribe(e => guard("itemCompleteUse", () => ConsumeXpManager.handleCompleteUse(e)));
    world.afterEvents.entitySpawn.subscribe(e => guard("projectile spawn", () => handleProjectileSpawn(e)));
    world.afterEvents.entitySpawn.subscribe(e => guard("chorus.spawn", () => ChorusEffects.handleEntitySpawn(e)));
    world.afterEvents.entitySpawn.subscribe(e => guard("fishing.spawn", () => FishingXpManager.handleEntitySpawn(e)));
    world.afterEvents.entitySpawn.subscribe(e => guard("evolution.spawn", () => EvolutionManager.onSpawn(e.entity)));
    world.afterEvents.entityRemove.subscribe(e => guard("fishing.remove", () => FishingXpManager.handleEntityRemove(e)));
    world.afterEvents.projectileHitEntity.subscribe(e => guard("projectile hit entity", () => handleProjectileHitEntity(e)));
    world.afterEvents.projectileHitBlock.subscribe(e => guard("projectile hit block", () => handleProjectileHitBlock(e)));
    system.afterEvents.scriptEventReceive.subscribe(e => guard(`scriptevent ${e.id}`, () => handleScriptEvent(e)));
    world.afterEvents.worldLoad.subscribe(() => guard("scoreboard init", () => ScoreboardManager.setupObjectives()));
    world.afterEvents.worldLoad.subscribe(() => guard("admin config overrides", () => {
        const n = AdminManager.applyStored();
        if (n > 0) console.warn(`[Admin] Applied ${n} stored config override(s).`);
    }));
}

export function registerScheduledJobs() {
    if (jobsRegistered) return false;
    jobsRegistered = true;
    const sneakState = new Map();
    EventBus.on("playerLeave", (event) => {
        if (event?.playerId) { DamageIndicator.forget(event.playerId); sneakState.delete(event.playerId); MovementManager.onLeave(event.playerId); ScoreboardManager.forget(event.playerId); }
    });
    Scheduler.every("movement_2", 2, () => {
        for (const player of world.getAllPlayers()) guard("movement", () => MovementManager.tick(player));
    });
    Scheduler.every("player_tick_10", 10, () => {
        for (const player of world.getAllPlayers()) guard("player_tick_10", () => {
            // Full inventory lore sweep only every 4th pass (40 ticks); the cheap checks run every pass.
            EquipmentManager.refresh(player, system.currentTick % 40 < 10);
            ScoreboardManager.syncPlayer(player);
            const slot = player.getComponent("minecraft:equippable")?.getEquipmentSlot("Mainhand");
            if (slot?.hasItem() && slot.getDynamicProperty("crpg:rune_id")) ItemRestrictionManager.updateSlotLore(slot, player);
            AugmentManager.applyPassiveStats(player);
            GemAbility.tickPassive(player);
            RuneManager.tickPassive(player);
            const state = sneakState.get(player.id) ?? { last: 0, was: false };
            if (player.isSneaking && !state.was) {
                const now = Date.now();
                if (now - state.last < 400) { GemAbility.onDoubleSneak(player); }
                state.last = now;
            }
            state.was = player.isSneaking; sneakState.set(player.id, state);
        });
    });
    Scheduler.every("regen_20", 20, () => {
        for (const player of world.getAllPlayers()) guard("regen", () => { ManaManager.regenTick(player); HPManager.regenTick(player); RuneCN.tickCurseEffects(player); GemAbility.tickFlightCheck(player); });
    });
    Scheduler.every("evolution_tick", EVOLUTION.SCAN_INTERVAL_TICKS, () => guard("evolution tick", () => { EvolutionManager.tick(world.getAllPlayers()); EvolutionManager.trimCache(); }));
    EventBus.on("damage:after", (ctx) => guard("damage indicator", () => DamageIndicator.onDamage(ctx)));
    Scheduler.every("health_display", HEALTH_DISPLAY.SCAN_INTERVAL_TICKS, () => guard("health display", () => HealthDisplay.tick(world.getAllPlayers())));
    Scheduler.every("special_boss", SPECIAL.BOSS_SCAN_INTERVAL_TICKS, () => guard("special bosses", () => SpecialMobManager.tickBosses()));
    Scheduler.every("special_cleanup", SPECIAL.CLEANUP.INTERVAL_TICKS, () => guard("special cleanup", () => SpecialMobManager.cleanup()));
    Scheduler.every("nightmare_20", 20, () => guard("nightmare", () => NightmareManager.tick(world.getAllPlayers())));
    Scheduler.every("chorus_aura_10", 10, () => guard("chorus aura", () => ChorusAura.tick(world.getAllPlayers())));
    Scheduler.every("waypoint_pending_60", 60, () => {
        for (const player of world.getAllPlayers()) guard("waypoint pending", () => WaypointGui.checkPending(player));
    });
    Scheduler.every("waypoint_cleanup", 200, () => guard("waypoint cleanup", () => WaypointManager.cleanupLegacy()));
    Scheduler.every("discovery_20", 20, () => guard("discovery", () => DiscoveryManager.tick(world.getAllPlayers())));
    Scheduler.every("mastery_travel", 20, () => guard("mastery travel", () => MasteryManager.tickTravel(world.getAllPlayers())));
    Scheduler.every("fishing_track", 1, () => guard("fishing tick", () => FishingXpManager.tick()));
    Scheduler.every("hud_5", 5, () => guard("hud", () => HudManager.tick()));
    Scheduler.every("projectile_cleanup", 100, () => guard("projectile tick", tickProjectileSystem));
}
