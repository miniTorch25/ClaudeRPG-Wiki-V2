// ClaudeRPG Combat Pipeline — single owner of entityHurt damage resolution.
import { system, EquipmentSlot, EntityComponentTypes } from "@minecraft/server";
import { DamageManager, normalizeDamageCause, isSuppressed } from "../managers/damage_manager.js";
import { ItemRestrictionManager } from "../systems/item_restriction.js";
import { GemAbility } from "../systems/gem_ability.js";
import { AugmentManager } from "../systems/augment.js";
import { RuneManager } from "../rune/rune_manager.js";
import { EventBus } from "./event_bus.js";
import { AchievementManager } from "../systems/achievement_manager.js";
import { RuntimeState } from "./runtime_state.js";
import { CONFIG } from "../config/config.js";
import { MasteryManager } from "../managers/mastery_manager.js";
import { MASTERY } from "../config/mastery_config.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { MobHpManager } from "../managers/mob_hp_manager.js";
import { EvolutionManager } from "../managers/evolution_manager.js";
import { Synergy } from "../systems/synergy.js";
import { RUNE_PROP_KEY } from "../rune/rune_registry.js";
import { RuneState } from "../rune/rune_state.js";

const ENV_CAUSES = new Set(["fall","fire","fire_tick","lava","in_fire","drowning","freeze","starve","suffocation","lightning","contact","block_explosion","projectile","void","out_of_world"]);
// Causes that represent continuous contact (still standing in the hazard) rather
// than a single discrete event. These need the tick-interval throttle below;
// one-off causes (fall, void, lightning, projectile, block_explosion) don't repeat
// on their own and are left alone.
const CONTINUOUS_ENV_CAUSES = new Set(["fire","fire_tick","lava","in_fire","drowning","freeze","suffocation","contact"]);
const isPlayer = (e) => e?.typeId === "minecraft:player";

export class CombatPipeline {
    static before(event) {
        if (isSuppressed(event.hurtEntity?.id)) return;
        ItemRestrictionManager.checkMeleeDamage(event);
        if (event.cancel) return;
        // Enchanted mobs: the shield swallows one whole hit (before any on-hit effects run).
        if (event.damageSource?.damagingEntity && EvolutionManager.tryAbsorb(event.hurtEntity, event.damageSource.damagingEntity)) {
            event.cancel = true;
            return;
        }
        RuneManager.handleHurtBefore(event);
        if (event.cancel) return;
        GemAbility.onHurtBefore(event);
        if (event.cancel) return;
        if (AugmentManager.applyEvasion(event)) return;

        const attacker = event.damageSource?.damagingEntity;
        const victim = event.hurtEntity;
        const ctx = DamageManager.createContext(attacker, victim, event.damage);
        ctx.phase = "before";
        ctx.cause = normalizeDamageCause(event.damageSource?.cause ?? "unknown");
        ctx.source = event.damageSource;
        ctx.originalEvent = event;

        // Bug fix: continuous hazards (lava, fire, drowning, etc.) re-fire an
        // entityHurt event almost every tick once we always cancel the vanilla
        // event below, since vanilla's own hit-immunity timer only gets set as a
        // side effect of damage actually landing on the health component — which
        // never happens here. Throttle those causes ourselves so contact damage
        // lands at roughly the same rate vanilla would use, instead of stacking
        // 15-20 hits per second and killing the player almost instantly.
        if (isPlayer(victim) && CONTINUOUS_ENV_CAUSES.has(ctx.cause)) {
            const combatState = RuntimeState.player(victim.id).combat;
            const lastTick = combatState.envDamageTick ?? -Infinity;
            const interval = ctx.cause === "lava" ? CONFIG.ENV_LAVA_TICK_INTERVAL : CONFIG.ENV_DAMAGE_TICK_INTERVAL;
            if (system.currentTick - lastTick < interval) {
                event.cancel = true;
                return;
            }
            combatState.envDamageTick = system.currentTick;
        }

        if (isPlayer(attacker)) {
            const mods = AugmentManager.getCombatAttackModifiers(event);
            ctx.flatBonus += mods.flatBonus;
            const assassination = GemAbility.getAssassinationMultiplier(attacker);
            if (assassination > 0) ctx.multipliers.push(assassination);
            // Ranged runes that tag the arrow at shoot time (Sniper's Patience, Hairtrigger, Reckless Volley): +/- % damage
            try {
                const projMod = event.damageSource?.damagingProjectile?.getDynamicProperty("crpg:rune_dmg_mod");
                if (typeof projMod === "number" && projMod !== 0) ctx.multipliers.push(projMod);
            } catch (_) { /* projectile gone */ }
            const gemAtkBonus = GemAbility.getGemAttackBonusPercent(attacker, { ranged: !!event.damageSource?.damagingProjectile, victim });
            if (gemAtkBonus > 0) ctx.multipliers.push(gemAtkBonus);

            // Chorus Synergy: matching armor elements add effects to Rune / Gem-skill hits.
            if (victim && !isPlayer(victim)) {
                try {
                    const mh = attacker.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);
                    const runeId = mh?.hasItem() ? mh.getItem().getDynamicProperty(RUNE_PROP_KEY) : null;
                    const syn = Synergy.onPlayerHit(attacker, victim, { gemSkills: GemAbility.getAbilities(attacker), runeId: typeof runeId === "string" ? runeId : null });
                    if (syn.damagePct > 0) { ctx.multipliers.push(syn.damagePct); AchievementManager.event(attacker, "synergy_triggers"); }
                } catch (_) { /* synergy must never break combat */ }
            }

            // Mastery (Melee / Ranged paths): flat Attack Damage (melee), Crit Chance, Crit Damage.
            // A crit is a vanilla falling hit (melee) OR a Crit Chance roll; chance crits get CRIT_BASE_BONUS.
            const isProjectile = !!event.damageSource?.damagingProjectile;
            const isMeleeHit = !isProjectile && ctx.cause === "entity_attack";
            if (isProjectile || isMeleeHit) {
                const line = isProjectile ? "ranged" : "melee";
                if (isMeleeHit) {
                    const atk = MasteryManager.getBonus(attacker, "melee_attack_damage");
                    if (atk) ctx.flatBonus += atk;
                }
                let crit = isMeleeHit && attacker.isFalling && !attacker.isOnGround && !attacker.isInWater && !attacker.isClimbing && !attacker.isGliding;
                if (!crit) {
                    const chance = MasteryManager.getBonus(attacker, `${line}_crit_chance`);
                    if (chance > 0 && Math.random() * 100 < chance) {
                        crit = true;
                        if (MASTERY.CRIT_BASE_BONUS > 0) ctx.multipliers.push(MASTERY.CRIT_BASE_BONUS);
                    }
                }
                if (crit) {
                    ctx.meta.crit = true;   // read by the Damage Indicator (orange number)
                    const cd = MasteryManager.getBonus(attacker, `${line}_crit_damage`);
                    if (cd > 0) ctx.multipliers.push(cd);
                    MasteryManager.onCrit(attacker, line);
                    try { attacker.playSound("game.player.attack.crit", { volume: 0.6 }); } catch (_) {}
                }
            }
        }

        if (isPlayer(victim) && (!attacker || !isPlayer(attacker) || ENV_CAUSES.has(ctx.cause))) {
            if (ctx.cause === "lava") {
                ctx.baseDamage = CONFIG.ENV_DAMAGE_LAVA_PER_SEC;
            } else {
                ctx.baseDamage *= DamageManager.getEnvironmentalScale(ctx.cause);
            }
        }
        // Ascension: players hit hostile mobs harder (offsets the mob HP pool)
        if (isPlayer(attacker) && victim && !isPlayer(victim)) {
            const pm = MobHpManager.getPlayerAttackMult(victim);
            if (pm > 1) ctx.multipliers.push((pm - 1) * 100);
        }
        // Ascension: hostile mobs hit harder (Mob Damage multiplier, capped in config)
        if (isPlayer(victim) && attacker && !isPlayer(attacker) && MobHpManager.isScalable(attacker)) {
            const dmgMult = MobHpManager.getAttackMult(attacker);
            if (dmgMult > 1) {
                ctx.multipliers.push((dmgMult - 1) * 100);
                ctx.meta.ascensionMobHit = true;
            }
            EvolutionManager.onHitPlayer(attacker, victim);   // Inferno burn / Nightmare blind
        }
        if (isPlayer(victim) && attacker && !isPlayer(attacker)) {
            try { Synergy.onPlayerHurt(victim, attacker, GemAbility.getAbilities(victim)); } catch (_) {}
        }
        if (isPlayer(victim)) {
            // Cat's Grace / Wind Walker / Earthbound: falls up to a safe height do no damage
            // (checked before any reduction math runs; baseDamage ~ height - 3)
            if (ctx.cause === "fall" && GemAbility.onFall(victim, ctx.baseDamage)) {
                ctx.cancelled = true;
            } else {
                let reduction = AugmentManager.getDamageReductionPercent(victim, attacker);
                // Overpower / Dragon's Gaze: part of the armor is ignored
                if (isPlayer(attacker) && reduction > 0) {
                    const pen = GemAbility.getArmorPenetration(attacker, { ranged: !!event.damageSource?.damagingProjectile });
                    if (pen > 0) reduction *= Math.max(0, 1 - pen / 100);
                }
                // Unyielding (hit cap) and Mind Over Matter (Mana pays part of the damage) are applied
                // by DamageManager.applyToRpgHP once the final damage is known.
                ctx.meta.maxHitFraction = GemAbility.getMaxHitFraction(victim);
                ctx.meta.manaAbsorb = GemAbility.makeManaAbsorb(victim);
                const gemReduction = GemAbility.getGemDamageReductionPercent(victim, ctx.cause);
                const totalReduction = reduction + gemReduction;
                if (totalReduction > 0) ctx.multipliers.push(-totalReduction);
            }
        }

        EventBus.emit("damage:before", ctx);
        if (ctx.cancelled) {
            event.cancel = true;
            return;
        }
        event.cancel = true;
        this._resolve(ctx);
    }

    static _resolve(ctx) {
        const victim = ctx.victim;
        const attacker = ctx.attacker;
        if (!victim?.isValid || ctx.cancelled) return;
        ctx.phase = "resolving";
        ctx.finalDamage = victim.typeId === "minecraft:player"
            ? DamageManager.applyToRpgHP(ctx)
            : DamageManager.applyFinalDamage(ctx);
        ctx.resolved = true;
        EventBus.emit("damage:after", ctx);
        system.run(() => {
            try {
                if (!victim.isValid) return;
                // Native Bedrock event objects expose their fields via prototype
                // getters, not own enumerable properties, so {...ctx.originalEvent}
                // silently produced an object with only `cancel` set — hurtEntity
                // and damageSource were always undefined here. Build it explicitly
                // from ctx's live references instead.
                const event = { hurtEntity: victim, damageSource: ctx.source, damage: ctx.finalDamage, cancel: false };
                // Remember the real arrow damage: ranged runes work in "% of the arrow's damage" (see rune_projectile.js)
                if (attacker?.typeId === "minecraft:player" && ctx.source?.damagingProjectile && ctx.finalDamage > 0) {
                    const rs = RuneState.get(attacker.id);
                    rs.lastArrowDamage = ctx.finalDamage;
                    rs.lastArrowTime = Date.now();
                }
                AugmentManager.applyStunt(event);
                GemAbility.onHurtAfter(event);
                RuneManager.handleHurtAfter(event);
                if (attacker?.typeId === "minecraft:player" && ctx.finalDamage > 0) {
                    const slot = attacker.getComponent("minecraft:equippable")?.getEquipmentSlot("Mainhand");
                    // Base = damage that really landed (a Core only took its capped share), not the raw uncapped number
                    AugmentManager.applyChainAttack(attacker, victim, ctx.meta?.appliedDamage ?? ctx.finalDamage, slot);
                    const gemMelee = !ctx.source?.damagingProjectile && (ctx.cause === "entity_attack" || ctx.cause === "mace_smash");
                    GemAbility.applyLifesteal(attacker, ctx.finalDamage, gemMelee);
                    GemAbility.afterHit(attacker, { victim, melee: gemMelee, damage: ctx.finalDamage });
                }
            } catch (e) { console.warn(`[CombatPipeline] post-hook error: ${e}`); }
        });
    }
}
