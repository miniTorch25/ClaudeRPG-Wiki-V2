// ClaudeRPG RuntimeState — central in-memory state for temporary gameplay data.
// Persistent player data belongs in dynamic properties / managers; this module
// only owns state that can safely disappear on reload.
const playerState = new Map();
const globalState = new Map();

function getPlayerState(playerId) {
    let state = playerState.get(playerId);
    if (!state) {
        state = { lifecycle: {}, combat: {}, cooldown: {}, progression: {}, rune: {}, gem: {}, augment: {} };
        playerState.set(playerId, state);
    }
    return state;
}

export const RuntimeState = {
    player(playerId) { return getPlayerState(playerId); },
    peek(playerId) { return playerState.get(playerId) ?? null; },
    players() { return playerState.keys(); },
    deletePlayer(playerId) { playerState.delete(playerId); },
    global(namespace = "default") {
        let state = globalState.get(namespace);
        if (!state) { state = {}; globalState.set(namespace, state); }
        return state;
    },
    clear() { playerState.clear(); globalState.clear(); },
};
