// ClaudeRPG Logger — centralized diagnostic output.
const PREFIX = "[ClaudeRPG]";

export const Logger = {
    info(message, ...args) { console.log(`${PREFIX} ${message}`, ...args); },
    warn(message, ...args) { console.warn(`${PREFIX} ${message}`, ...args); },
    error(message, error = null, ...args) {
        if (error) console.error(`${PREFIX} ${message}:`, error, ...args);
        else console.error(`${PREFIX} ${message}`, ...args);
    },
    guard(label, fn, fallback = undefined) {
        try { return fn(); }
        catch (error) { this.error(label, error); return fallback; }
    },
};
