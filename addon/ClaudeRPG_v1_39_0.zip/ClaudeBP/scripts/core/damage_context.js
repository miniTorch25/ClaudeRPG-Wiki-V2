// ClaudeRPG DamageContext — immutable identity + mutable calculation state for one hit.
// Every damage resolution should travel through this object.
let nextId = 0;

export class DamageContext {
    constructor(attacker, victim, baseDamage) {
        this.id = `dmg_${++nextId}`;
        this.attacker = attacker ?? null;
        this.victim = victim ?? null;
        this.source = null;
        this.cause = "unknown";
        this.originalEvent = null;

        this.baseDamage = Number.isFinite(baseDamage) ? Math.max(0, baseDamage) : 0;
        this.flatBonus = 0;
        this.multipliers = [];
        this.finalDamage = 0;

        this.cancelled = false;
        this.resolved = false;
        this.phase = "created";
        this.flags = new Set();
        this.meta = Object.create(null);
    }

    addFlat(amount) {
        if (Number.isFinite(amount)) this.flatBonus += amount;
        return this;
    }

    addMultiplier(percent) {
        if (Number.isFinite(percent)) this.multipliers.push(percent);
        return this;
    }

    cancel(reason = "cancelled") {
        this.cancelled = true;
        this.phase = "cancelled";
        this.meta.cancelReason = reason;
        return this;
    }
}
