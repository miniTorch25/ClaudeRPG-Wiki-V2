// ClaudeRPG Scheduler — single owner for recurring and deferred engine jobs.
import { system } from "@minecraft/server";
import { Logger } from "./logger.js";

const intervals = new Map();
const timeouts = new Map();

export const Scheduler = {
    every(name, interval, callback) {
        if (intervals.has(name)) return intervals.get(name);
        const id = system.runInterval(() => Logger.guard(`scheduler:${name}`, callback), interval);
        intervals.set(name, id);
        return id;
    },
    after(name, delay, callback) {
        if (timeouts.has(name)) return timeouts.get(name);
        const id = system.runTimeout(() => {
            timeouts.delete(name);
            Logger.guard(`scheduler:${name}`, callback);
        }, delay);
        timeouts.set(name, id);
        return id;
    },
    cancel(name) {
        if (intervals.has(name)) {
            system.clearRun(intervals.get(name));
            intervals.delete(name);
            return true;
        }
        if (timeouts.has(name)) {
            system.clearRun(timeouts.get(name));
            timeouts.delete(name);
            return true;
        }
        return false;
    },
    has(name) { return intervals.has(name) || timeouts.has(name); },
    clearAll() {
        for (const id of intervals.values()) system.clearRun(id);
        for (const id of timeouts.values()) system.clearRun(id);
        intervals.clear();
        timeouts.clear();
    },
};
