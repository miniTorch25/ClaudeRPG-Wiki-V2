// rune_fx.js — resolves a rune's effect list at a given level. Pure functions (no game imports),
// shared by the effect engine (rune_effects.js) and the Lore builder (rune_lore.js).

import { RUNE_BY_ID, LEVEL_PENALTY } from "../config/rune_catalog.js";
import { RUNE_LEVEL_MULT, clampLevel } from "../config/level_config.js";

// Stats where a LOWER number is better. For these a good effect lowers the stat, a bad one raises it.
const LOWER_BETTER = new Set(["dura", "hunger", "manaCost", "taken"]);

const round = (n) => Math.round(n * 100) / 100;

// Returns [{ fx, v, side: "good" | "bad", off, when, ...params }]. `off` = the penalty has fully worn off at this level.
// itemIsTool picks the tool version of a curse. Curses are never scaled.
export function resolveFx(runeId, level, effectPct = 0, itemIsTool = false) {
    const def = RUNE_BY_ID[runeId];
    if (!def) return [];
    const lv = clampLevel(level);
    const curse = def.pool === "curse";
    const goodMult = curse ? 1 : (RUNE_LEVEL_MULT[lv] ?? 1) * (1 + effectPct / 100);
    const badMult = curse ? 1 : (LEVEL_PENALTY[lv] ?? 1);
    const out = [];
    for (const e of def.good) {
        let v = e.v * goodMult;
        if (typeof e.max === "number") v = Math.min(e.max, v);
        out.push({ ...e, v: round(v), side: "good", off: false });
    }
    const badList = curse && itemIsTool && def.badTool ? def.badTool : def.bad;
    for (const e of badList) {
        const v = e.v * badMult;
        out.push({ ...e, v: round(v), side: "bad", off: e.fx !== "note" && v <= 0 });
    }
    return out;
}

// Signed change of a stat caused by one effect: +10 = the stat goes up by 10%.
export function deltaOf(e) {
    if (e.off) return 0;
    const up = !LOWER_BETTER.has(e.fx);
    return ((e.side === "good") === up ? 1 : -1) * e.v;
}

// The Rune's pool label for names and Lore ("Sword", "All-Weapon", "Curse" ...).
export { RUNE_BY_ID };
