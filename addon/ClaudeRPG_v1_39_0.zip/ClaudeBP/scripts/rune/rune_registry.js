// rune_registry.js — Rune metadata, built from config/rune_catalog.js (115 runes).
//
// kind:      "positive" (good + bad side) | "curse" (penalty only)
// category:  the rune's POOL: sword | bow | spear | trident | mace | magic | all_weapon | pickaxe | axe | shovel | hoe | all_tool | curse
// tier:      1-7 = grade (Gamma T1 ... Omega T7). Used by Rune Mastery unlocks and the Rune items.
// arch:      "TRIGGER" for every rune (a Rune effect fires on hit / kill / block / tick)

import { RUNES, POOLS } from "../config/rune_catalog.js";
import { getItemKind, KIND_RUNE_POOLS } from "../config/item_category_config.js";

export const RUNE_PROP_KEY = "crpg:rune_id";
// Written next to RUNE_PROP_KEY by the v6 Rune system. A stored rune without it belongs to the old 80-rune roster
// (some old ids, like "cleave" or "greed", were reused by new runes with a different effect).
export const RUNE_VER_KEY = "crpg:rune_ver";
export const RUNE_VER = 2;
// Set by Rune Creative when a rune of the wrong type is forced onto an item. Such a rune stays on the item but never works.
export const RUNE_FORCED_KEY = "crpg:rune_forced";

export const RUNE_REGISTRY = {};
for (const r of RUNES) {
    RUNE_REGISTRY[r.id] = {
        name: r.name, category: r.pool, tier: r.tier, kind: r.pool === "curse" ? "curse" : "positive",
        arch: "TRIGGER", exclusive: [], elements: r.elements,
    };
}

export const LEGACY_RUNE_IDS = {};   // v6 has no 1:1 renames; old ids go through migrateLegacyRune()

// Old (80-rune roster) id -> new rune candidates, by preference.
const OLD_TO_NEW = {
 "relentless": [
  "frenzy",
  "riposte"
 ],
 "cleave": [
  "cleave"
 ],
 "executioner": [
  "finisher"
 ],
 "iron_will": [
  "guardian"
 ],
 "berserker": [
  "berserk"
 ],
 "phantom_strike": [
  "backstab",
  "silent_edge"
 ],
 "wardens_echo": [
  "shockwave"
 ],
 "shockwave": [
  "shockwave"
 ],
 "bloodshed": [
  "soul_harvest"
 ],
 "stormcall": [
  "lightning_strike"
 ],
 "soulbound_fury": [
  "soul_harvest",
  "vampiric_surge"
 ],
 "dooms_edge": [
  "brutal"
 ],
 "berserking_heart": [
  "berserk"
 ],
 "ravenous_beast": [
  "frenzy"
 ],
 "glass_cannon": [
  "sharpened"
 ],
 "twin_edges": [
  "twin_cast",
  "duelist"
 ],
 "volatile_power": [
  "brutal"
 ],
 "deadeye": [
  "eagle_eye"
 ],
 "hunters_mark": [
  "marked_prey",
  "precision"
 ],
 "piercing_shot": [
  "piercing_shot"
 ],
 "explosive_arrow": [
  "overkill"
 ],
 "multishot": [
  "ricochet"
 ],
 "ricochet": [
  "ricochet"
 ],
 "overcharge": [
  "quickdraw"
 ],
 "voidshot": [
  "piercing_shot"
 ],
 "skyfall": [
  "eagle_eye"
 ],
 "hailstorm": [
  "frostbite"
 ],
 "eclipse": [
  "windrider"
 ],
 "cataclysm": [
  "overkill"
 ],
 "snipers_patience": [
  "steady_aim"
 ],
 "gambit": [
  "gambler"
 ],
 "hairtrigger": [
  "quickdraw"
 ],
 "reckless_volley": [
  "brutal"
 ],
 "stormcallers_burden": [
  "lightning_strike"
 ],
 "opening_strike": [
  "opening_salvo"
 ],
 "venom": [
  "venom"
 ],
 "lifedrain": [
  "lifesteal"
 ],
 "tempest": [
  "lightning_strike"
 ],
 "colossus_bane": [
  "giant_slayer"
 ],
 "scholars_mark": [
  "scholar"
 ],
 "vital_strike": [
  "precision"
 ],
 "soul_reaper": [
  "soul_harvest"
 ],
 "mana_siphon": [
  "vampiric_surge"
 ],
 "undying_rune": [
  "second_wind"
 ],
 "resonance": [
  "chorus_link"
 ],
 "ascendant": [
  "berserk"
 ],
 "windfall": [
  "fortunes_edge"
 ],
 "the_gambler": [
  "gambler"
 ],
 "vampires_pact": [
  "vampiric_surge"
 ],
 "overdrive": [
  "berserk"
 ],
 "chaos_echo": [
  "gambler"
 ],
 "lucky_strike": [
  "lucky_find"
 ],
 "smelters_touch": [
  "smelter"
 ],
 "tireless": [
  "durable"
 ],
 "magnetize": [
  "tool_magnet"
 ],
 "momentum": [
  "tool_haste"
 ],
 "mending_touch": [
  "tool_mender"
 ],
 "earthsplitter": [
  "vein_boost"
 ],
 "prospector": [
  "gem_sense"
 ],
 "greed": [
  "fortune_touch"
 ],
 "void_siphon": [
  "tool_scholar"
 ],
 "fortunes_harvest": [
  "fortune_touch"
 ],
 "excavator": [
  "excavator"
 ],
 "reckless_haste": [
  "tool_haste"
 ],
 "the_wanderer": [
  "light_step"
 ],
 "surge": [
  "efficiency"
 ],
 "cave_dweller": [
  "tool_night_eye"
 ],
 "the_sacrifice": [
  "stamina_saver"
 ],
 "bloodprice": [
  "fatigue"
 ],
 "brittle_fate": [
  "greed"
 ],
 "provoked_wrath": [
  "hex"
 ],
 "wild_aim": [
  "fatigue"
 ],
 "leaky_quiver": [
  "greed"
 ],
 "returning_doom": [
  "hex"
 ],
 "hollow_vessel": [
  "fatigue"
 ],
 "mounting_dread": [
  "greed"
 ],
 "toll_of_the_fallen": [
  "hex"
 ],
 "rusted_edge": [
  "fatigue"
 ],
 "famished_labor": [
  "greed"
 ],
 "unstable_ground": [
  "hex"
 ]
};
// Even older ids -> an id of the 80-rune roster.
const OLDER_TO_OLD = {
 "seeker": "skyfall",
 "severance": "executioner",
 "ruination": "relentless",
 "wrath_of_giants": "bloodshed",
 "crimson_surge": "lifedrain",
 "predator": "deadeye",
 "shattershot": "explosive_arrow",
 "phantom_volley": "multishot",
 "frenzy": "soul_reaper",
 "mana_surge": "mana_siphon",
 "resilience": "resonance",
 "fortunes_favor": "windfall",
 "bloodlust": "vampires_pact",
 "nightstalker": "cave_dweller",
 "decay": "hollow_vessel",
 "forsaken": "hollow_vessel",
 "numbness": "hollow_vessel",
 "dread": "mounting_dread",
 "fragility": "mounting_dread",
 "the_fallen": "toll_of_the_fallen",
 "cursed_edge": "brittle_fate",
 "backfire": "returning_doom",
 "exhaustion": "famished_labor",
 "clumsiness": "wild_aim"
};
const OLD_TIER = {"relentless": 1, "cleave": 2, "executioner": 3, "iron_will": 3, "berserker": 4, "phantom_strike": 4, "wardens_echo": 4, "shockwave": 5, "bloodshed": 5, "stormcall": 6, "soulbound_fury": 6, "dooms_edge": 7, "berserking_heart": 2, "ravenous_beast": 3, "glass_cannon": 4, "twin_edges": 5, "volatile_power": 6, "bloodprice": 2, "brittle_fate": 4, "provoked_wrath": 6, "deadeye": 1, "hunters_mark": 2, "piercing_shot": 3, "explosive_arrow": 3, "multishot": 4, "ricochet": 4, "overcharge": 4, "voidshot": 5, "skyfall": 5, "hailstorm": 6, "eclipse": 7, "cataclysm": 7, "snipers_patience": 2, "gambit": 3, "hairtrigger": 4, "reckless_volley": 5, "stormcallers_burden": 6, "wild_aim": 2, "leaky_quiver": 4, "returning_doom": 6, "opening_strike": 1, "venom": 2, "lifedrain": 2, "tempest": 3, "colossus_bane": 3, "scholars_mark": 3, "vital_strike": 4, "soul_reaper": 4, "mana_siphon": 5, "undying_rune": 5, "resonance": 6, "ascendant": 7, "windfall": 2, "the_gambler": 3, "vampires_pact": 4, "overdrive": 5, "chaos_echo": 6, "hollow_vessel": 2, "mounting_dread": 4, "toll_of_the_fallen": 6, "lucky_strike": 1, "smelters_touch": 2, "tireless": 2, "magnetize": 3, "momentum": 3, "mending_touch": 4, "earthsplitter": 4, "prospector": 5, "greed": 5, "void_siphon": 6, "fortunes_harvest": 6, "excavator": 7, "reckless_haste": 1, "the_wanderer": 2, "surge": 3, "cave_dweller": 4, "the_sacrifice": 5, "rusted_edge": 2, "famished_labor": 4, "unstable_ground": 6};

export function poolsForItem(itemTypeId) {
    const k = getItemKind(itemTypeId);
    return k ? (KIND_RUNE_POOLS[k.kind] ?? []) : [];
}

// Does this rune fit this weapon / tool? Curses fit every weapon and tool.
export function runeFitsItem(runeId, itemTypeId) {
    const meta = RUNE_REGISTRY[runeId];
    if (!meta) return false;
    const k = getItemKind(itemTypeId);
    if (!k || (k.group !== "weapon" && k.group !== "tool")) return false;
    if (meta.category === "curse") return k.kind !== "shears";
    return poolsForItem(itemTypeId).includes(meta.category);
}

// Kept for callers that still pass a legacy weapon type ("melee" | "ranged" | "tool").
export function categoryFits(category, weaponType) {
    return category === "curse" || weaponType === category;
}

// Old roster id -> a v6 rune that fits `itemTypeId` (same tier when nothing maps). Returns null when no rune fits.
export function migrateLegacyRune(storedId, itemTypeId) {
    let oid = OLDER_TO_OLD[storedId] ?? storedId;
    for (const cand of OLD_TO_NEW[oid] ?? []) if (runeFitsItem(cand, itemTypeId)) return cand;
    const tier = OLD_TIER[oid] ?? 1;
    const pool = Object.keys(RUNE_REGISTRY).filter((id) => RUNE_REGISTRY[id].category !== "curse" && runeFitsItem(id, itemTypeId));
    for (let t = tier; t >= 1; t--) {
        const same = pool.filter((id) => RUNE_REGISTRY[id].tier === t);
        if (same.length) return same[Math.floor(Math.random() * same.length)];
    }
    return null;
}

// What should the stored rune on item `itemTypeId` become? `ver` = the item's RUNE_VER_KEY.
// Returns { id: string | null, changed: boolean }. id null = remove the rune.
export function migrateStoredRune(storedId, itemTypeId, ver = 0) {
    if (!storedId) return { id: null, changed: false };
    if (ver >= RUNE_VER) {
        if (RUNE_REGISTRY[storedId] && runeFitsItem(storedId, itemTypeId)) return { id: storedId, changed: false };
        return { id: null, changed: true };
    }
    const id = migrateLegacyRune(storedId, itemTypeId);
    return { id, changed: true, markVer: true };
}

// "positive" | "curse" -- curses are never scaled by level, Mastery or Synergy
export function getRuneKind(runeId) {
    return RUNE_REGISTRY[runeId]?.kind ?? "positive";
}

// Returns the registry entry for a rune, or null if unknown
export function getRuneMeta(runeId) {
    return RUNE_REGISTRY[runeId] ?? null;
}

export function areExclusive() { return false; }

export const RUNE_POOL_LABELS = Object.fromEntries(Object.entries(POOLS).map(([k, v]) => [k, v.label]));
