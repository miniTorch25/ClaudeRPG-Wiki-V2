// rune_item.js — Rune ITEMS: a stackless item (crpg:rune_<grade>) that holds one random rune.
//
//   Uncarved Rune (mainhand) + Engraver (offhand), click  ->  random Rune item
//   A Rune item that has no rune yet (creative menu, /give, loot) is rolled automatically
//   the first time a scan sees it in a player's inventory.
//
// Stored on the item: crpg:rune_id (RUNE_PROP_KEY) and crpg:rune_level (RUNE_LEVEL_PROP_KEY).

import { world, system, ItemStack, EntityComponentTypes } from "@minecraft/server";
import { RUNE_PROP_KEY, RUNE_REGISTRY } from "./rune_registry.js";
import { buildRuneLoreLines, describeEffects } from "./rune_lore.js";
import { RUNE_LEVEL_PROP_KEY, DEFAULT_LEVEL, clampLevel } from "../config/level_config.js";
import { RUNE_GRADES, RUNE_TYPE_LABELS, UNCARVED_RUNE_ID, RUNE_CARVE_BATCH } from "../config/rune_item_config.js";
import { DISABLED_POOLS } from "../config/rune_catalog.js";

const GRADE_BY_ID = Object.fromEntries(RUNE_GRADES.map((g) => [g.id, g]));

export function getGradeOfTypeId(typeId) {
    if (typeof typeId !== "string" || !typeId.startsWith("crpg:rune_")) return null;
    return GRADE_BY_ID[typeId.slice("crpg:rune_".length)] ?? null;
}

export function isRuneItemId(typeId) { return !!getGradeOfTypeId(typeId); }

export function rollGrade() {
    const total = RUNE_GRADES.reduce((a, g) => a + g.weight, 0);
    let r = Math.random() * total;
    for (const g of RUNE_GRADES) { r -= g.weight; if (r < 0) return g; }
    return RUNE_GRADES[0];
}

// Random rune of exactly this tier (any category). Falls back to the nearest lower tier that has runes.
export function rollRuneOfTier(tier) {
    for (let t = tier; t >= 1; t--) {
        const ids = Object.keys(RUNE_REGISTRY).filter((id) => RUNE_REGISTRY[id].tier === t && !DISABLED_POOLS.includes(RUNE_REGISTRY[id].category));
        if (ids.length) return ids[Math.floor(Math.random() * ids.length)];
    }
    return null;
}

export function getRuneTypeLabel(runeId) {
    return RUNE_TYPE_LABELS[RUNE_REGISTRY[runeId]?.category] ?? "Unknown";
}

// "Gamma Rune (Melee T1)"
export function buildRuneItemName(grade, runeId) {
    return `§r${grade.color}${grade.label} Rune §8(${getRuneTypeLabel(runeId)} T${grade.tier})`;
}

// Same Lore layout as weapons/tools (rune block) + a Type line at the very bottom.
export function buildRuneItemLore(runeId, level = DEFAULT_LEVEL) {
    const lines = buildRuneLoreLines(runeId, null, level, 0);
    if (lines[0] === "") lines.shift();   // standalone item: no blank line above the rune block
    if (RUNE_REGISTRY[runeId]?.category === "curse") {
        // A curse hurts tools differently from weapons: show both.
        const tool = describeEffects(runeId, level, 0, true).bad;
        if (tool.length) lines.push(`§r§8On tools: §c${tool.join(", ")}`);
    }
    return [
        ...lines,
        "",
        `§r§7Type: §f${getRuneTypeLabel(runeId)}`,
    ];
}

// Writes rune + level + name + lore onto a rune ItemStack. Returns the same stack.
export function applyRuneToItem(stack, runeId, level = DEFAULT_LEVEL) {
    const grade = getGradeOfTypeId(stack.typeId);
    if (!grade || !RUNE_REGISTRY[runeId]) return stack;
    const lv = clampLevel(level);
    stack.setDynamicProperty(RUNE_PROP_KEY, runeId);
    stack.setDynamicProperty(RUNE_LEVEL_PROP_KEY, lv);
    stack.nameTag = buildRuneItemName(grade, runeId);
    stack.setLore(buildRuneItemLore(runeId, lv));
    return stack;
}

// A brand-new Rune item of `grade` ({id,...}) with a random rune of its tier inside.
export function createRuneItem(grade = rollGrade()) {
    const runeId = rollRuneOfTier(grade.tier);
    const stack = new ItemStack(`crpg:rune_${grade.id}`, 1);
    if (runeId) applyRuneToItem(stack, runeId, DEFAULT_LEVEL);
    return stack;
}

// Gives a rune item to the player (drops it at their feet when the inventory is full).
export function giveRuneItem(player, stack) {
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const left = inv ? inv.addItem(stack) : stack;
    if (left) player.dimension.spawnItem(left, player.location);
}

// Rolls the inside of any rune item that does not hold a rune yet (or holds an unknown one).
function scanPlayer(player) {
    const inv = player.getComponent(EntityComponentTypes.Inventory)?.container;
    if (!inv) return;
    for (let i = 0; i < inv.size; i++) {
        const it = inv.getItem(i);
        if (!it || !isRuneItemId(it.typeId)) continue;
        const stored = it.getDynamicProperty(RUNE_PROP_KEY);
        if (typeof stored === "string" && RUNE_REGISTRY[stored]) continue;
        const grade = getGradeOfTypeId(it.typeId);
        const runeId = rollRuneOfTier(grade.tier);
        if (!runeId) continue;
        // A stack of several unrolled items: roll each one separately so every rune is its own random pick.
        if (it.amount > 1) {
            const extra = it.amount - 1;
            it.amount = 1;
            applyRuneToItem(it, runeId, DEFAULT_LEVEL);
            inv.setItem(i, it);
            for (let n = 0; n < extra; n++) giveRuneItem(player, createRuneItem(grade));
        } else {
            applyRuneToItem(it, runeId, DEFAULT_LEVEL);
            inv.setItem(i, it);
        }
    }
}

export function startRuneItemScanner() {
    system.runInterval(() => {
        for (const p of world.getAllPlayers()) {
            try { scanPlayer(p); } catch (_) { /* inventory not ready */ }
        }
    }, 20);
}

// Carves Uncarved Runes from the mainhand (Engraver in offhand is checked by the caller).
// batch = true carves up to RUNE_CARVE_BATCH at once (Shift-click). Returns the grades carved, or null.
export function carveUncarvedRunes(player, batch = false) {
    const slot = player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot("Mainhand");
    if (!slot?.hasItem() || slot.typeId !== UNCARVED_RUNE_ID) return null;
    const held = slot.getItem();
    const count = batch ? Math.min(RUNE_CARVE_BATCH, held.amount) : 1;
    if (held.amount > count) { held.amount -= count; slot.setItem(held); } else { slot.setItem(undefined); }

    const result = [];
    for (let i = 0; i < count; i++) {
        const stack = createRuneItem(rollGrade());
        result.push(getGradeOfTypeId(stack.typeId));
        giveRuneItem(player, stack);
    }
    return result;
}
