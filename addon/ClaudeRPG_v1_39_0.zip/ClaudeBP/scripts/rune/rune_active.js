// rune_active.js — v6 has no Sneak-activated runes. Kept so older imports resolve.
export function onActivate() { /* nothing to activate */ }
