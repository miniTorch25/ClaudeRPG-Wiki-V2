// rune_effects.js — runs the 115 runes of config/rune_catalog.js.
//
// One generic engine instead of one hand-written handler per rune. Each rune is a list of effects
// (fx) resolved for the held item's level by rune_fx.js; this file implements every fx.
//
// Hooks (all wired in startRuneEngine / rune_manager):
//   EventBus "damage:before"  dealt + taken damage modifiers (ctx.multipliers), dodge, barrier
//   EventBus "damage:after"   procs, lifesteal, splash, echo, waves, thorns, knockback tweaks, durability
//   onKill                    heals, buffs, stacks, repairs, drop changes, cleanse
//   onBlockBreak              tool effects: durability, drops, smelt, 3x3, harvest, bonus loot
//   tick (every 10 ticks)     Haste / Night Vision, hunger rate, magnet, glow, barrier, second wind, gravity well
//   getters                   speed / HP / XP / Mana / heal modifiers read by the Managers
//
// Approximations (Bedrock cannot do these exactly): attack / cast / charge speed is applied as the equivalent
// damage; mining speed uses Haste (bonus) and short Mining Fatigue bursts (penalty); reach is a damage bonus.

import { world, system, EntityComponentTypes, EquipmentSlot, ItemStack } from "@minecraft/server";
import { EventBus } from "../core/event_bus.js";
import { HPManager } from "../managers/hp_manager.js";
import { ManaManager } from "../managers/mana_manager.js";
import { fireSuppressedDamage, isSplashTarget } from "../managers/damage_manager.js";
import { isBoss, isUndead } from "../config/mob_config.js";
import { MASTERY } from "../config/mastery_config.js";
import { Synergy } from "../systems/synergy.js";
import { onRuneDispatch } from "../systems/achievement_hooks.js";
import { RUNE_PROP_KEY, RUNE_VER_KEY, RUNE_VER, RUNE_REGISTRY, runeFitsItem } from "./rune_registry.js";
import { useRuneLevelOf, getRuneLevelContext, getRuneEffectPctContext } from "../config/rune_config.js";
import { getItemKind } from "../config/item_category_config.js";
import { resolveFx, deltaOf } from "./rune_fx.js";
import { RuneState } from "./rune_state.js";

const isPlayer = (e) => e?.typeId === "minecraft:player";
const now = () => system.currentTick;
const rnd = () => Math.random() * 100;

// ─── Resolve the rune on the held item ───────────────────────────────────────

const cache = new Map();   // playerId -> { tick, res }

function mainhandSlot(player) {
    return player.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);
}

function compute(player) {
    const slot = mainhandSlot(player);
    if (!slot?.hasItem()) return null;
    const item = slot.getItem();
    const runeId = item.getDynamicProperty(RUNE_PROP_KEY);
    if (typeof runeId !== "string" || !RUNE_REGISTRY[runeId]) return null;
    if ((item.getDynamicProperty(RUNE_VER_KEY) ?? 0) < RUNE_VER) return null;   // legacy rune: migrated by the Lore refresh first
    if (!runeFitsItem(runeId, item.typeId)) return null;
    useRuneLevelOf(player);
    const tool = getItemKind(item.typeId)?.group === "tool";
    return { runeId, level: getRuneLevelContext(), fx: resolveFx(runeId, getRuneLevelContext(), getRuneEffectPctContext(), tool), itemTypeId: item.typeId, tool };
}

export function resolvePlayer(player) {
    try {
        const t = now();
        const c = cache.get(player.id);
        if (c && c.tick === t) return c.res;
        const res = compute(player);
        cache.set(player.id, { tick: t, res });
        return res;
    } catch (_) { return null; }
}

// Per-player runtime state (reset on respawn / leave by RuneState.clearPlayer).
function stateOf(player, res) {
    const r = RuneState.get(player.id);
    r.fx ??= {};
    const s = r.fx;
    if (res && s.runeId !== res.runeId) {   // a different rune: start clean
        Object.assign(s, { runeId: res.runeId, stacks: 0, hitN: 0, shockN: 0, kills: 0, blocks: 0, lastHit: 0 });
    }
    s.hits ??= new Map();       // victimId -> last tick this player hit it
    s.marks ??= new Map();      // victimId -> mark expiry tick
    s.poison ??= new Map();     // victimId -> poison stacks
    s.stacks ??= 0; s.hitN ??= 0; s.shockN ??= 0; s.kills ??= 0; s.blocks ??= 0;
    s.barrierHp ??= 0; s.barrierNext ??= 0; s.swCd ??= 0; s.gwNext ??= 0; s.absorbCd ??= 0; s.pullCd ??= 0;
    s.fallenUntil ??= 0; s.noRegenUntil ??= 0; s.riposteUntil ??= 0; s.lastAttack ??= -9999; s.slowPct ??= 0;
    return s;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const hpFrac = (e) => {
    try { const h = e.getComponent("minecraft:health"); return h && h.effectiveMax > 0 ? h.currentValue / h.effectiveMax : 1; } catch (_) { return 1; }
};
const maxHp = (e) => { try { return e.getComponent("minecraft:health")?.effectiveMax ?? 20; } catch (_) { return 20; } };
const dist = (a, b) => Math.hypot(a.location.x - b.location.x, a.location.y - b.location.y, a.location.z - b.location.z);
const speedXZ = (p) => { try { const v = p.getVelocity(); return Math.hypot(v.x, v.z); } catch (_) { return 0; } };
const playerHpFrac = (p) => { const m = HPManager.getMaxHP(p); return m > 0 ? HPManager.getHP(p) / m : 1; };
const FIRE_MOBS = new Set(["minecraft:blaze", "minecraft:magma_cube", "minecraft:wither_skeleton", "minecraft:ghast", "minecraft:strider", "minecraft:zombified_piglin", "minecraft:wither"]);

function nearbyEnemies(center, dim, radius, exclude = []) {
    try {
        return dim.getEntities({ location: center, maxDistance: radius, excludeTypes: ["minecraft:player", "minecraft:item"] })
            .filter((e) => !exclude.includes(e.id) && isSplashTarget(e));
    } catch (_) { return []; }
}

function armorOf(e) {
    try {
        const eq = e.getComponent(EntityComponentTypes.Equippable);
        if (!eq) return false;
        return ["Head", "Chest", "Legs", "Feet"].some((s) => { try { return !!eq.getEquipment(s); } catch (_) { return false; } });
    } catch (_) { return false; }
}

// ─── Conditions ──────────────────────────────────────────────────────────────

const near = (e) => (e._near ??= nearbyEnemies(e.victim.location, e.victim.dimension, 5, [e.victim.id, e.player.id]).length);
const facing = (e) => {
    try {
        const v = e.victim.getViewDirection();
        const dx = e.player.location.x - e.victim.location.x, dz = e.player.location.z - e.victim.location.z;
        const len = Math.hypot(dx, dz) || 1, vl = Math.hypot(v.x, v.z) || 1;
        return (v.x * dx + v.z * dz) / (len * vl);   // +1: attacker in front of the victim, -1: behind
    } catch (_) { return 0; }
};
const projSpeed = (e) => { try { const v = e.proj.getVelocity(); return Math.hypot(v.x, v.y, v.z); } catch (_) { return 0; } };

const COND = {
    alone: (e) => !!e.victim && near(e) === 0,
    crowd: (e) => !!e.victim && near(e) >= 2,
    first: (e) => !!e.first, later: (e) => e.first === false,
    hpLow: (e) => !!e.victim && hpFrac(e.victim) < 0.25,
    hpFull: (e) => !!e.victim && hpFrac(e.victim) >= 0.95,
    boss: (e) => !!e.victim && isBoss(e.victim.typeId), nonBoss: (e) => !!e.victim && !isBoss(e.victim.typeId),
    undead: (e) => !!e.victim && isUndead(e.victim.typeId), living: (e) => !!e.victim && !isUndead(e.victim.typeId),
    big: (e) => !!e.victim && maxHp(e.victim) >= 40, small: (e) => !!e.victim && maxHp(e.victim) <= 20,
    behind: (e) => !!e.victim && facing(e) < -0.3, front: (e) => !!e.victim && facing(e) > 0.3,
    noCrit: (e) => !e.ctx?.meta?.crit,
    still: (e) => speedXZ(e.player) < 0.03, moving: (e) => speedXZ(e.player) >= 0.03,
    run: (e) => !!e.player.isSprinting || speedXZ(e.player) > 0.2,
    far: (e) => !!e.victim && dist(e.player, e.victim) > 3, close: (e) => !!e.victim && dist(e.player, e.victim) < 6,
    fullCharge: (e) => !!e.proj && projSpeed(e) >= 2.4, notFull: (e) => !!e.proj && projSpeed(e) < 2.4,
    ranged: (e) => !!e.proj, melee: (e) => !e.proj,
    armored: (e) => !!e.victim && armorOf(e.victim), unarmored: (e) => !!e.victim && !armorOf(e.victim),
    unmarked: (e) => !!e.victim && !((e.st.marks.get(e.victim.id) ?? 0) > now()),
    fireMob: (e) => !!e.victim && FIRE_MOBS.has(e.victim.typeId),
    offBeat: (e) => (e.st.hitN % (e.waveN || 4)) !== ((e.waveN || 4) - 1),
    selfLow: (e) => playerHpFrac(e.player) < 0.5, selfFull: (e) => playerHpFrac(e.player) >= 0.95, selfHigh: (e) => playerHpFrac(e.player) >= 0.5,
    stacksFull: (e) => e.st.stacks >= (e.stackMax || 5),
    fallenWindow: (e) => now() < e.st.fallenUntil,
    day: () => { const t = world.getTimeOfDay(); return t < 12500 || t > 23500; },
    chorus: (e) => Synergy.runeLevelBonus(e.player, e.res.runeId) > 0, noChorus: (e) => !(Synergy.runeLevelBonus(e.player, e.res.runeId) > 0),
    onCooldown: (e) => e.st.swCd > now(),
    noBarrier: (e) => e.st.barrierHp <= 0,
    attack: (e) => now() - e.st.lastAttack < 40,
    noSneak: (e) => !e.player.isSneaking, firstSneak: (e) => !!e.player.isSneaking && !!e.first,
    ore: (e) => !!e.ore,
};

const ok = (e, env) => !e.when || (COND[e.when]?.(env) ?? false);

function envFor(player, res, st, extra = {}) {
    const stackFx = res.fx.find((f) => f.fx === "stack");
    const waveFx = res.fx.find((f) => f.fx === "wave");
    return { player, res, st, stackMax: stackFx?.max, waveN: waveFx?.n, ...extra };
}

function sumStat(res, stat, env) {
    let t = 0;
    for (const e of res.fx) if (e.fx === stat && !e.off && ok(e, env)) t += deltaOf(e);
    return t;
}

// ─── Damage before ───────────────────────────────────────────────────────────

function dealBefore(ctx, player, victim) {
    const res = resolvePlayer(player);
    if (!res || res.tool) { if (!res || !res.fx.length) return; }
    if (!victim || victim.id === player.id) return;
    const st = stateOf(player, res);
    const proj = ctx.source?.damagingProjectile ?? null;
    if (!proj && ctx.cause !== "entity_attack" && ctx.cause !== "mace_smash") return;
    const first = !((st.hits.get(victim.id) ?? -9999) > now() - 200);
    const env = envFor(player, res, st, { victim, ctx, proj, first });

    // Crit rolls first so Crit Damage effects see them.
    for (const e of res.fx) {
        if (e.fx !== "crit" || e.off) continue;
        if (e.side === "good") {
            if (!ctx.meta.crit && rnd() < e.v) { ctx.meta.crit = true; ctx.addMultiplier(MASTERY.CRIT_BASE_BONUS); }
        } else ctx.addMultiplier(-e.v * 0.5);   // crit chance penalty ~ half its value in average damage
    }
    for (const e of res.fx) {
        if (e.off) continue;
        switch (e.fx) {
            case "dmg": case "atkSpeed": if (ok(e, env)) ctx.addMultiplier(deltaOf(e)); break;
            case "critDmg": if (ctx.meta.crit) ctx.addMultiplier(deltaOf(e)); break;
            case "dmgRange": if (proj) ctx.addMultiplier(e.v * Math.min(1, dist(player, victim) / 30)); break;
            case "riposte": if (e.side === "good" && st.riposteUntil > now()) { ctx.addMultiplier(e.v); ctx.meta.riposteUsed = true; } break;
            case "stack": if (e.side === "good" && st.stacks > 0) ctx.addMultiplier(st.stacks * e.v); break;
            case "gamble": ctx.addMultiplier(e.lo + Math.random() * (e.hi - e.lo) - 100); break;
            case "mark": if (e.side === "good" && (st.marks.get(victim.id) ?? 0) > now()) ctx.addMultiplier(e.v); break;
            default: break;
        }
    }
    ctx.meta.runeDealt = true;
}

function takeBefore(ctx, player, attacker) {
    const res = resolvePlayer(player);
    if (!res) return;
    const st = stateOf(player, res);
    const env = envFor(player, res, st, { attacker });
    for (const e of res.fx) {
        if (e.off) continue;
        if (e.fx === "taken" && ok(e, env)) ctx.addMultiplier(deltaOf(e));
        else if (e.fx === "dodge" && e.side === "good" && attacker && rnd() < e.v) {
            ctx.cancel("dodge");
            try { player.onScreenDisplay.setActionBar("§b[Evasion] Dodged!"); } catch (_) {}
            return;
        }
    }
    // Barrier / shield: soaks damage before it reaches HP.
    if (st.barrierHp > 0 && ctx.baseDamage > 0) {
        const absorbed = Math.min(st.barrierHp, ctx.baseDamage);
        ctx.addFlat(-absorbed);
        st.barrierHp -= absorbed;
    }
}

function onDamageBefore(ctx) {
    try {
        if (isPlayer(ctx.attacker)) dealBefore(ctx, ctx.attacker, ctx.victim);
        if (isPlayer(ctx.victim) && !ctx.cancelled) takeBefore(ctx, ctx.victim, ctx.attacker);
    } catch (e) { console.warn(`[RuneFx] before: ${e}`); }
}

// ─── Damage after ────────────────────────────────────────────────────────────

function dot(victim, attacker, dmg, sec, perSec) {
    for (let i = 1; i <= sec; i++) {
        system.runTimeout(() => { try { if (victim.isValid) fireSuppressedDamage(victim, attacker, perSec); } catch (_) {} }, i * 20);
    }
}

function applyProc(e, player, victim, dmg, st) {
    switch (e.kind) {
        case "bleed": dot(victim, player, dmg, e.sec, Math.max(1, Math.round(dmg * 0.2))); break;
        case "slow": victim.addEffect("slowness", e.sec * 20, { amplifier: 1, showParticles: true }); break;
        case "ignite": victim.setOnFire(e.sec, true); break;
        case "poison": {
            const n = Math.min(3, (st.poison.get(victim.id) ?? 0) + 1);
            st.poison.set(victim.id, n);
            victim.addEffect("poison", e.sec * 20, { amplifier: n - 1, showParticles: true });
            break;
        }
        case "stun": victim.addEffect("slowness", Math.max(5, Math.round(e.sec * 20)), { amplifier: 6, showParticles: false }); break;
        case "lightning":
            victim.dimension.spawnEntity("minecraft:lightning_bolt", victim.location);
            fireSuppressedDamage(victim, player, Math.max(1, Math.round(dmg * 0.6)));
            break;
        default: break;
    }
}

function pushAway(from, target, strength, up = 0.3) {
    try {
        const dx = target.location.x - from.location.x, dz = target.location.z - from.location.z;
        const l = Math.hypot(dx, dz) || 1;
        target.applyKnockback({ x: (dx / l) * strength, z: (dz / l) * strength }, up);
    } catch (_) { /* not knockable */ }
}

function changeDurability(player, delta) {
    try {
        const slot = mainhandSlot(player);
        const item = slot?.hasItem() ? slot.getItem() : null;
        const dur = item?.getComponent("minecraft:durability");
        if (!dur) return;
        dur.damage = Math.max(0, Math.min(dur.maxDurability - 1, dur.damage + delta));
        slot.setItem(item);
    } catch (_) { /* no durability */ }
}

// Durability use +/-: a chance of an extra point of damage (or a repaired point).
function applyDurability(player, res, env) {
    const pct = sumStat(res, "dura", env);
    if (pct > 0) { let n = Math.floor(pct / 100); if (rnd() < pct % 100) n++; if (n > 0) changeDurability(player, n); }
    else if (pct < 0 && rnd() < -pct) changeDurability(player, -1);
}

function dealAfter(ctx, player, victim) {
    const res = resolvePlayer(player);
    if (!res || !victim) return;
    const st = stateOf(player, res);
    const dmg = ctx.meta?.appliedDamage ?? ctx.finalDamage;
    if (!(dmg > 0) || !ctx.meta.runeDealt) return;
    const proj = ctx.source?.damagingProjectile ?? null;
    const first = !((st.hits.get(victim.id) ?? -9999) > now() - 200);
    const env = envFor(player, res, st, { victim, ctx, proj, first });
    st.lastAttack = now();
    st.hitN++;
    st.hits.set(victim.id, now());
    if (ctx.meta.riposteUsed) st.riposteUntil = 0;
    let fired = false;

    for (const e of res.fx) {
        if (e.off || e.side !== "good" && !["recoil", "selfHurt"].includes(e.fx)) continue;
        try {
            switch (e.fx) {
                case "lifesteal": HPManager.heal(player, dmg * e.v / 100); break;
                case "proc":
                    if (e.v >= 100 || rnd() < e.v) { applyProc(e, player, victim, dmg, st); fired = true; }
                    break;
                case "splash": {
                    const others = nearbyEnemies(victim.location, victim.dimension, e.radius ?? 3, [victim.id, player.id]);
                    if (!others.length) break;
                    let pool = others;
                    if (e.line) {
                        const v = player.getViewDirection();
                        pool = others.filter((o) => ((o.location.x - victim.location.x) * v.x + (o.location.z - victim.location.z) * v.z) > 0);
                    }
                    pool.sort((a, b) => dist(a, victim) - dist(b, victim));
                    for (const t of pool.slice(0, e.n)) fireSuppressedDamage(t, player, Math.max(1, Math.round(dmg * e.v / 100)));
                    fired = true; break;
                }
                case "overkill":
                    if (!victim.isValid || hpFrac(victim) <= 0) {
                        const t = nearbyEnemies(victim.location, victim.dimension, e.radius ?? 4, [victim.id, player.id])[0];
                        if (t) { fireSuppressedDamage(t, player, Math.max(1, Math.round(dmg * 0.35 * e.v / 100))); fired = true; }
                    }
                    break;
                case "echo":
                    if (ok(e, env)) {
                        system.runTimeout(() => { try { if (victim.isValid) fireSuppressedDamage(victim, player, Math.max(1, Math.round(dmg * e.v / 100))); } catch (_) {} }, 6);
                        fired = true;
                    }
                    break;
                case "wave":
                    if (st.hitN % e.n === 0) {
                        const v = player.getViewDirection();
                        const hit = nearbyEnemies(player.location, player.dimension, e.len, [player.id])
                            .filter((o) => ((o.location.x - player.location.x) * v.x + (o.location.z - player.location.z) * v.z) > 0.5 * dist(o, player))
                            .slice(0, 5);
                        for (const t of hit) fireSuppressedDamage(t, player, Math.max(1, Math.round(dmg * e.v / 100)));
                        fired = true;
                    }
                    break;
                case "shock":
                    st.shockN++;
                    if (st.shockN % e.n === 0) {
                        for (const t of nearbyEnemies(player.location, player.dimension, e.radius, [player.id]).slice(0, 6)) {
                            fireSuppressedDamage(t, player, Math.max(1, Math.round(dmg * e.v / 100)));
                            pushAway(player, t, 0.9);
                        }
                        fired = true;
                    }
                    break;
                case "knock": pushAway(player, victim, 0.7, 0.25); break;
                case "absorbHit":
                    if (st.absorbCd <= now()) {
                        st.barrierHp += e.v * HPManager.getMaxHP(player) / 20;
                        st.absorbCd = now() + e.cd * 20;
                        system.runTimeout(() => { st.barrierHp = Math.max(0, st.barrierHp - e.v * HPManager.getMaxHP(player) / 20); }, e.sec * 20);
                    }
                    break;
                case "pull":
                    if (st.pullCd <= now() && victim.isValid) {
                        const dx = player.location.x - victim.location.x, dz = player.location.z - victim.location.z, l = Math.hypot(dx, dz) || 1;
                        victim.applyKnockback({ x: (dx / l) * 0.9 * e.v, z: (dz / l) * 0.9 * e.v }, 0.2);
                        st.pullCd = now() + e.cd * 20; fired = true;
                    }
                    break;
                case "mark": st.marks.set(victim.id, now() + e.sec * 20); break;
                case "stack": if (e.per === "hit") st.stacks = Math.min(e.max, st.stacks + 1); break;
                case "manaOnHit": ManaManager.setMana(player, Math.min(ManaManager.getMaxMana(player), ManaManager.getMana(player) + ManaManager.getMaxMana(player) * e.v / 100)); break;
                default: break;
            }
        } catch (_) { /* target gone */ }
    }
    // Bad-side effects that act on the wielder
    for (const e of res.fx) {
        if (e.off || e.side !== "bad") continue;
        if (e.fx === "recoil") { const cur = HPManager.getHP(player); if (cur > 1) HPManager.setHP(player, Math.max(1, cur - dmg * e.v / 100)); }
        else if (e.fx === "selfHurt" && rnd() < e.v) { const cur = HPManager.getHP(player); if (cur > 1) HPManager.setHP(player, Math.max(1, cur - HPManager.getMaxHP(player) * 0.02)); }
    }
    applyDurability(player, res, env);
    if (fired) { try { onRuneDispatch(player, res.runeId); } catch (_) {} }
}

function takeAfter(ctx, player, attacker) {
    const res = resolvePlayer(player);
    if (!res) return;
    const st = stateOf(player, res);
    const env = envFor(player, res, st, { attacker });
    const dmg = ctx.finalDamage;
    if (res.fx.some((f) => f.fx === "stack" && f.resetOnHurt)) st.stacks = 0;
    for (const e of res.fx) {
        if (e.off) continue;
        if (e.fx === "riposte" && e.side === "good") st.riposteUntil = now() + 100;
        else if (e.fx === "thorns" && e.side === "good" && attacker && !isPlayer(attacker) && dmg > 0) {
            try { fireSuppressedDamage(attacker, player, Math.max(1, Math.round(dmg * e.v / 100))); } catch (_) {}
        } else if (e.fx === "knockRes" && e.side === "good" && ok(e, env) && rnd() < e.v) {
            for (const t of [1, 2, 3]) system.runTimeout(() => { try { player.clearVelocity(); } catch (_) {} }, t);
        } else if (e.fx === "knockTaken" && e.side === "bad" && attacker && ok(e, env)) {
            system.runTimeout(() => pushAway(attacker, player, 0.5 * e.v / 100, 0.05), 1);
        }
    }
}

function onDamageAfter(ctx) {
    try {
        if (isPlayer(ctx.attacker) && !isPlayer(ctx.victim)) dealAfter(ctx, ctx.attacker, ctx.victim);
        else if (isPlayer(ctx.attacker)) dealAfter(ctx, ctx.attacker, ctx.victim);
        if (isPlayer(ctx.victim)) takeAfter(ctx, ctx.victim, ctx.attacker);
    } catch (e) { console.warn(`[RuneFx] after: ${e}`); }
}

// ─── Drops ───────────────────────────────────────────────────────────────────

const COMMON = new Set([
    "minecraft:rotten_flesh", "minecraft:bone", "minecraft:string", "minecraft:spider_eye", "minecraft:gunpowder", "minecraft:arrow",
    "minecraft:stick", "minecraft:cobblestone", "minecraft:dirt", "minecraft:gravel", "minecraft:sand", "minecraft:cobbled_deepslate",
    "minecraft:flint", "minecraft:feather", "minecraft:leather", "minecraft:egg", "minecraft:coal", "minecraft:oak_log", "minecraft:wheat_seeds",
]);
const SMELT = {
    "minecraft:raw_iron": "minecraft:iron_ingot", "minecraft:raw_gold": "minecraft:gold_ingot", "minecraft:raw_copper": "minecraft:copper_ingot",
    "minecraft:ancient_debris": "minecraft:netherite_scrap", "minecraft:iron_ore": "minecraft:iron_ingot", "minecraft:gold_ore": "minecraft:gold_ingot",
    "minecraft:copper_ore": "minecraft:copper_ingot", "minecraft:nether_gold_ore": "minecraft:gold_ingot",
};
const itemKindMatch = (id, kind) => {
    switch (kind) {
        case "ore": return /^minecraft:(raw_|.*_ingot$|diamond$|emerald$|lapis_lazuli$|redstone$|quartz$|amethyst_shard$|netherite_scrap$|coal$)/.test(id) || id.endsWith("_ore");
        case "wood": return /_log$|_planks$|_wood$|_stem$|^minecraft:stick$/.test(id);
        case "dirt": return /^minecraft:(dirt|gravel|sand|red_sand|clay_ball|flint|soul_sand|mud)$/.test(id);
        case "crop": return /^minecraft:(wheat|carrot|potato|beetroot|melon_slice|pumpkin|nether_wart|sweet_berries)$/.test(id);
        case "seed": return id.endsWith("_seeds");
        case "common": return COMMON.has(id);
        case "rare": return !COMMON.has(id);
        default: return true;
    }
};

// One pass over the item entities a break / kill just dropped near `loc`.
function processDrops(player, res, st, dim, loc, radius, env) {
    system.runTimeout(() => {
        try {
            let items = dim.getEntities({ type: "minecraft:item", location: loc, maxDistance: radius }).filter((i) => i.isValid);
            if (!items.length) return;
            const stackOf = (i) => i.getComponent("minecraft:item")?.itemStack;
            for (const e of res.fx) {
                if (e.off) continue;
                if (e.fx === "smelt") {
                    for (const i of items) {
                        const s = stackOf(i); const out = s && SMELT[s.typeId];
                        if (out) { const a = s.amount; i.remove(); dim.spawnItem(new ItemStack(out, a), i.location); }
                    }
                    items = dim.getEntities({ type: "minecraft:item", location: loc, maxDistance: radius }).filter((i) => i.isValid);
                } else if ((e.fx === "drops" && e.side === "good") || (e.fx === "dropsLose" && e.side === "bad") || (e.fx === "drops" && e.side === "bad")) {
                    const pool = items.filter((i) => { const s = stackOf(i); return s && itemKindMatch(s.typeId, e.kind ?? "any"); });
                    if (!pool.length || rnd() >= e.v) continue;
                    const it = pool[Math.floor(Math.random() * pool.length)];
                    if (e.fx === "drops" && e.side === "good") { const s = stackOf(it); if (s) dim.spawnItem(s.clone(), it.location); }
                    else it.remove();
                }
            }
        } catch (_) { /* chunk unloaded */ }
    }, 2);
}

const SAPLINGS = { oak: "oak_sapling", spruce: "spruce_sapling", birch: "birch_sapling", jungle: "jungle_sapling", acacia: "acacia_sapling", dark_oak: "dark_oak_sapling", cherry: "cherry_sapling", mangrove: "mangrove_propagule" };
const LUCKY = [["minecraft:gold_nugget", 3, 50], ["minecraft:iron_ingot", 1, 30], ["minecraft:emerald", 1, 15], ["minecraft:diamond", 1, 5]];
const DIG = [["minecraft:gold_nugget", 2, 40], ["minecraft:iron_nugget", 3, 30], ["minecraft:clay_ball", 4, 20], ["minecraft:emerald", 1, 7], ["minecraft:diamond", 1, 3]];
const pickWeighted = (list) => { let r = Math.random() * 100; for (const [id, n, w] of list) { r -= w; if (r < 0) return [id, n]; } return list[0].slice(0, 2); };

// ─── Block break (tools) ─────────────────────────────────────────────────────

const PROTECTED = new Set(["minecraft:bedrock", "minecraft:barrier", "minecraft:obsidian", "minecraft:crying_obsidian", "minecraft:reinforced_deepslate",
    "minecraft:end_portal_frame", "minecraft:air", "minecraft:water", "minecraft:lava", "minecraft:command_block", "minecraft:chest", "minecraft:trapped_chest",
    "minecraft:barrel", "minecraft:furnace", "minecraft:spawner", "minecraft:ender_chest"]);
const isOre = (id) => id.endsWith("_ore") || id === "minecraft:ancient_debris";
const isCrop = (id) => /^minecraft:(wheat|carrots|potatoes|beetroot|nether_wart)$/.test(id);
const isStoneish = (id) => /stone|deepslate|andesite|diorite|granite|tuff|netherrack|basalt|blackstone|sandstone|calcite/.test(id) || isOre(id);
const isRipe = (perm) => {
    try { const g = perm.getState("growth"); if (typeof g === "number") return g >= 7; const a = perm.getState("age"); if (typeof a === "number") return a >= 3; } catch (_) {}
    return true;
};

function destroyAt(dim, x, y, z) { try { dim.runCommand(`setblock ${x} ${y} ${z} air destroy`); } catch (_) {} }

function onBlockBreak(event) {
    const player = event.player;
    const res = resolvePlayer(player);
    if (!res || !res.tool) return;
    const st = stateOf(player, res);
    const typeId = event.brokenBlockPermutation.type.id;
    const dim = event.block.dimension, loc = event.block.location;
    const center = { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 };
    const env = envFor(player, res, st, { ore: isOre(typeId), block: event.block });
    st.blocks++;
    let fired = false;

    // Careful Hands: an unripe crop is put back instead of being wasted.
    if (res.fx.some((f) => f.fx === "careful" && !f.off) && isCrop(typeId) && !isRipe(event.brokenBlockPermutation) && player.getGameMode() !== "Creative") {
        system.runTimeout(() => {
            try { dim.getBlock(loc).setPermutation(event.brokenBlockPermutation); dim.getEntities({ type: "minecraft:item", location: center, maxDistance: 1.6 }).forEach((i) => i.remove()); } catch (_) {}
        }, 1);
        return;
    }

    applyDurability(player, res, env);
    for (const e of res.fx) {
        if (e.off) continue;
        if (e.fx === "duraBurst" && rnd() < e.v) changeDurability(player, e.burst ?? 10);
        else if (e.fx === "mine" && e.side === "bad" && !e.when) { /* handled below */ }
    }
    // Mining slowdown: short Mining Fatigue bursts on average ~ the slowdown %.
    if (st.slowPct > 0 && rnd() < st.slowPct * 0.0129) { try { player.addEffect("mining_fatigue", 5, { amplifier: 0, showParticles: false }); } catch (_) {} }

    processDrops(player, res, st, dim, center, 2, env);

    for (const e of res.fx) {
        if (e.off || e.side !== "good") continue;
        try {
            switch (e.fx) {
                case "bonusDrop": {
                    if (rnd() >= e.v) break;
                    let out = null;
                    if (e.kind === "sap" && /_log$/.test(typeId)) { const w = typeId.replace("minecraft:", "").replace(/^stripped_/, "").replace(/_log$/, ""); out = [`minecraft:${SAPLINGS[w] ?? "stick"}`, 1]; }
                    else if (e.kind === "dig" && /^minecraft:(dirt|gravel|sand|red_sand|soul_sand|mud|clay)$/.test(typeId)) out = pickWeighted(DIG);
                    else if (e.kind === "lucky") out = pickWeighted(LUCKY);
                    else if (e.kind === "bonemeal" && isCrop(typeId)) out = ["minecraft:bone_meal", 1];
                    if (out) { dim.spawnItem(new ItemStack(out[0], out[1]), center); fired = true; }
                    break;
                }
                case "aoe":
                    if (rnd() < e.v && isStoneish(typeId)) {
                        const v = player.getViewDirection();
                        const ax = Math.abs(v.x) > Math.abs(v.y) && Math.abs(v.x) > Math.abs(v.z) ? "x" : Math.abs(v.y) > Math.abs(v.z) ? "y" : "z";
                        for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
                            if (!a && !b) continue;
                            const p = { x: loc.x, y: loc.y, z: loc.z };
                            if (ax === "x") { p.y += a; p.z += b; } else if (ax === "y") { p.x += a; p.z += b; } else { p.x += a; p.y += b; }
                            const bl = dim.getBlock(p);
                            if (bl && !PROTECTED.has(bl.typeId) && isStoneish(bl.typeId)) destroyAt(dim, p.x, p.y, p.z);
                        }
                        fired = true;
                    }
                    break;
                case "harvest":
                    if (isCrop(typeId)) {
                        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
                            if (!dx && !dz) continue;
                            const bl = dim.getBlock({ x: loc.x + dx, y: loc.y, z: loc.z + dz });
                            if (bl && isCrop(bl.typeId) && isRipe(bl.permutation)) destroyAt(dim, bl.location.x, bl.location.y, bl.location.z);
                        }
                        fired = true;
                    }
                    break;
                case "repairBlocks": if (st.blocks % Math.max(1, Math.round(100 / Math.max(1, e.v))) === 0) changeDurability(player, -1); break;
                default: break;
            }
        } catch (_) { /* block unloaded */ }
    }
    if (fired) { try { onRuneDispatch(player, res.runeId); } catch (_) {} }
}

// ─── Kill ────────────────────────────────────────────────────────────────────

const BAD_EFFECTS = ["poison", "wither", "slowness", "weakness", "mining_fatigue", "blindness", "hunger", "nausea", "darkness"];

function onKill(killEvent) {
    const player = killEvent.killer;
    if (!isPlayer(player)) return;
    const res = resolvePlayer(player);
    if (!res || res.tool) return;
    const st = stateOf(player, res);
    let loc = null, dim = null;
    try { loc = killEvent.victim.location; dim = killEvent.victim.dimension; } catch (_) {}
    st.kills++;
    let fired = false;
    for (const e of res.fx) {
        if (e.off || e.side !== "good") continue;
        try {
            switch (e.fx) {
                case "killHeal": HPManager.heal(player, HPManager.getMaxHP(player) * e.v / 100); fired = true; break;
                case "killFood": player.addEffect("saturation", 20, { amplifier: Math.max(0, Math.round(e.v) - 1), showParticles: false }); break;
                case "killSpeed": player.addEffect("speed", e.sec * 20, { amplifier: 0, showParticles: false }); st.fallenUntil = now() + e.sec * 20; fired = true; break;
                case "killRegen":
                    for (let i = 1; i <= e.sec; i++) system.runTimeout(() => { try { HPManager.heal(player, HPManager.getMaxHP(player) * 0.015); } catch (_) {} }, i * 20);
                    fired = true; break;
                case "repairKills": if (st.kills % Math.max(1, Math.round(100 / Math.max(1, e.v))) === 0) changeDurability(player, -1); break;
                case "stack": if (e.per === "kill") st.stacks = Math.min(e.max, st.stacks + 1); break;
                case "cleanse":
                    for (const id of BAD_EFFECTS) { if (player.getEffect(id)) { player.removeEffect(id); fired = true; break; } }
                    break;
                default: break;
            }
        } catch (_) { /* player gone */ }
    }
    for (const e of res.fx) if (e.fx === "regenPause" && !e.off) st.noRegenUntil = now() + e.sec * 20;
    if (loc && dim) processDrops(player, res, st, dim, loc, 3, envFor(player, res, st));
    if (fired) { try { onRuneDispatch(player, res.runeId); } catch (_) {} }
}

// ─── Tick (every 10 ticks) ───────────────────────────────────────────────────

function tick(player) {
    const res = resolvePlayer(player);
    const st = stateOf(player, res);
    if (!res) { st.exLast = undefined; st.slowPct = 0; return; }
    const env = envFor(player, res, st);
    const t = now();

    // Forget old per-target data so the maps stay small.
    if (t % 200 < 10) {
        for (const [id, at] of st.hits) if (t - at > 600) st.hits.delete(id);
        for (const [id, until] of st.marks) if (until < t) st.marks.delete(id);
        if (st.poison.size > 40) st.poison.clear();
    }

    // Frenzy-style stacks fade when you stop hitting.
    const decayFx = res.fx.find((f) => f.fx === "stack" && f.decay && !f.off);
    if (decayFx && st.stacks > 0 && t - st.lastAttack > decayFx.decay * 20) st.stacks = 0;

    // Hunger rate: scale the exhaustion gained since the last pass.
    const hungerPct = sumStat(res, "hunger", env);
    try {
        const ex = player.getComponent("minecraft:player.exhaustion");
        if (ex) {
            const cur = ex.currentValue;
            let next = cur;
            if (hungerPct !== 0 && st.exLast !== undefined && cur > st.exLast) {
                next = Math.max(st.exLast, cur + (cur - st.exLast) * (hungerPct / 100));
                if (next !== cur) ex.setCurrentValue(next);
            }
            st.exLast = next;
        }
    } catch (_) { /* component unavailable */ }

    // Mining speed: net bonus -> Haste, net penalty -> Mining Fatigue bursts on break.
    if (res.tool) {
        const net = sumStat(res, "mine", env);
        st.slowPct = net < 0 ? -net : 0;
        if (net >= 10) { try { player.addEffect("haste", 40, { amplifier: Math.min(4, Math.floor((net + 10) / 20) - 1), showParticles: false }); } catch (_) {} }
    }

    for (const e of res.fx) {
        if (e.off || e.side !== "good" && e.fx !== "regenPause") continue;
        try {
            switch (e.fx) {
                case "effect":
                    if (e.eff === "haste") player.addEffect("haste", 40, { amplifier: 0, showParticles: false });
                    else player.addEffect("night_vision", 260, { amplifier: 0, showParticles: false });
                    break;
                case "glow":
                    for (const m of player.dimension.getEntities({ location: player.location, maxDistance: Math.min(16, e.v), families: ["monster"] })) { try { m.addEffect("glowing", 30, { amplifier: 0, showParticles: false }); } catch (_) {} }
                    break;
                case "magnet":
                    for (const i of player.dimension.getEntities({ type: "minecraft:item", location: player.location, maxDistance: e.v })) {
                        if (dist(i, player) > 1.5) i.teleport(player.location);
                    }
                    break;
                case "barrier":
                    if (t >= st.barrierNext) { st.barrierHp = e.v * HPManager.getMaxHP(player) / 20; st.barrierNext = t + e.cd * 20; }
                    break;
                case "secondWind":
                    if (st.swCd <= t && playerHpFrac(player) * 100 < e.hp && HPManager.getHP(player) > 0) {
                        HPManager.heal(player, HPManager.getMaxHP(player) * e.v / 100);
                        st.swCd = t + e.cd * 20;
                        player.onScreenDisplay.setActionBar("§a[Second Wind] Healed!");
                    }
                    break;
                case "pullAll":
                    if (t >= st.gwNext) {
                        st.gwNext = t + e.v * 20;
                        for (const m of nearbyEnemies(player.location, player.dimension, e.radius, [player.id])) {
                            const dx = player.location.x - m.location.x, dz = player.location.z - m.location.z, l = Math.hypot(dx, dz) || 1;
                            if (l > 2) m.applyImpulse({ x: (dx / l) * 0.6, y: 0.2, z: (dz / l) * 0.6 });
                        }
                    }
                    break;
                default: break;
            }
        } catch (_) { /* target / chunk unavailable */ }
    }
}

// ─── Projectile spawn (ammo saving) ──────────────────────────────────────────

function onProjectileSpawn(event) {
    try {
        const proj = event.entity;
        if (proj?.typeId !== "minecraft:arrow") return;
        const owner = proj.getComponent("minecraft:projectile")?.owner;
        if (!isPlayer(owner) || owner.getGameMode() === "Creative") return;
        const res = resolvePlayer(owner);
        const e = res?.fx.find((f) => f.fx === "ammoSave" && !f.off);
        if (e && rnd() < e.v) owner.getComponent(EntityComponentTypes.Inventory)?.container?.addItem(new ItemStack("minecraft:arrow", 1));
    } catch (_) { /* owner gone */ }
}

// ─── Getters used by the Managers ────────────────────────────────────────────

const quick = (player, stat) => {
    const res = resolvePlayer(player);
    if (!res) return 0;
    const st = stateOf(player, res);
    return sumStat(res, stat, envFor(player, res, st));
};
export const getRuneSpeedPercent = (p) => quick(p, "speed");
export const getRuneHpPercent = (p) => quick(p, "hp");
export const getRuneXpPercent = (p) => quick(p, "xp");
export const getRuneManaCostPercent = (p) => quick(p, "manaCost");
export const getRuneManaRegenPercent = (p) => quick(p, "manaRegen");
export const getRuneHealMultiplier = (p) => Math.max(0, 1 + quick(p, "healRecv") / 100);
// Value of a GOOD effect of the held rune (0 when none / worn off). Used by systems that gate on one effect.
export function runeFxValue(p, fx) {
    const res = resolvePlayer(p);
    const e = res?.fx.find((f) => f.fx === fx && f.side === "good" && !f.off);
    return e ? e.v : 0;
}
export function getRuneVeinBonus(p) { return Math.max(0, Math.round(quick(p, "vein"))); }
export function isRegenBlocked(p) {
    const res = resolvePlayer(p);
    return !!res && stateOf(p, res).noRegenUntil > now();
}

export const RuneFx = { onKill, onBlockBreak, tick, onProjectileSpawn };

let started = false;
export function startRuneEngine() {
    if (started) return;
    started = true;
    EventBus.on("damage:before", onDamageBefore);
    EventBus.on("damage:after", onDamageAfter);
}
