// RuneState — central owner for temporary Rune combat state.
// Persistent Rune state belongs on ItemStack/player dynamic properties.
// This module only stores ephemeral counters that may safely reset on reload.
import { RuntimeState } from "../core/runtime_state.js";

function state(playerId) {
    const root = RuntimeState.player(playerId);
    root.rune ??= {};
    root.rune.hitTracking ??= {};
    return root.rune;
}

export const RuneState = {
    get(playerId) {
        return state(playerId);
    },

    getMap(playerId, key) {
        const rune = state(playerId);
        rune.hitTracking[key] ??= new Map();
        return rune.hitTracking[key];
    },

    getSet(playerId, key) {
        const rune = state(playerId);
        rune.hitTracking[key] ??= new Set();
        return rune.hitTracking[key];
    },

    clearVictim(victimId) {
        for (const playerId of RuntimeState.players()) {
            const root = RuntimeState.peek(playerId);
            const hitTracking = root?.rune?.hitTracking;
            if (!hitTracking) continue;
            for (const value of Object.values(hitTracking)) {
                if (value instanceof Map) value.delete(victimId);
                else if (value instanceof Set) value.delete(victimId);
            }
        }
    },

    clearPlayer(playerId) {
        const root = RuntimeState.peek(playerId);
        if (root) root.rune = {};
    },
};
