// rune_manager.js — Central Rune event dispatcher.
//
// Single owner of the Rune hooks called by core/event_router.js. All Rune behavior lives in rune_effects.js
// (data: config/rune_catalog.js); this file only routes events, installs and removes runes.

import { EquipmentSlot } from "@minecraft/server";
import { RUNE_PROP_KEY, RUNE_VER_KEY, RUNE_VER, RUNE_FORCED_KEY, RUNE_REGISTRY, runeFitsItem, getRuneMeta } from "./rune_registry.js";
import { KillManager } from "../managers/kill_manager.js";
import { RUNE_LEVEL_PROP_KEY, DEFAULT_LEVEL, clampLevel } from "../config/level_config.js";
import { ItemRestrictionManager } from "../systems/item_restriction.js";
import { EquipmentManager } from "../managers/equipment_manager.js";
import { RuneState } from "./rune_state.js";
import { Logger } from "../core/logger.js";
import { RuneFx } from "./rune_effects.js";

export function isActiveRune() { return false; }   // v6 has no Sneak-activated runes

export function isRuneKnown(runeId) {
    return !!getRuneMeta(runeId);
}

export function getRuneCategory(runeId) {
    return getRuneMeta(runeId)?.category ?? null;
}

// Returns the rune ID installed on the player's mainhand weapon, or null.
// A rune stored without the v6 version marker is an old-roster rune: it is migrated by the Lore refresh, not used.
export function getEquippedRuneId(player, slotId = EquipmentSlot.Mainhand) {
    const item = EquipmentManager.getItem(player, slotId);
    if (!item) return null;
    const stored = item.getDynamicProperty(RUNE_PROP_KEY) ?? null;
    if (!stored || (item.getDynamicProperty(RUNE_VER_KEY) ?? 0) < RUNE_VER) return null;
    return isRuneKnown(stored) ? stored : null;
}

// Returns true if the weapon / tool accepts this rune (pool + item kind match; curses fit every weapon and tool)
export function isRuneCompatible(runeId, itemTypeId) {
    return runeFitsItem(runeId, itemTypeId);
}

// Validates whether a rune can be equipped given current runes on other weapons.
// Returns { ok: bool, conflict: string | null }
export function checkExclusive(player, runeId) {
    for (const slotId of [EquipmentSlot.Mainhand, EquipmentSlot.Offhand]) {
        const existing = getEquippedRuneId(player, slotId);
        if (existing && areExclusive(runeId, existing)) {
            return { ok: false, conflict: existing };
        }
    }
    return { ok: true, conflict: null };
}

// Installs a rune onto the item currently in the player's mainhand.
// Returns { ok: bool, reason: string }
export function installRune(player, runeId, level = DEFAULT_LEVEL) {
    const mainhandSlot = EquipmentManager.getSlot(player, EquipmentSlot.Mainhand);
    if (!mainhandSlot?.hasItem()) return { ok: false, reason: "no_item" };

    const item = mainhandSlot.getItem();

    if (!isRuneCompatible(runeId, item.typeId))
        return { ok: false, reason: "incompatible" };

    if (item.getDynamicProperty(RUNE_PROP_KEY))
        return { ok: false, reason: "already_has_rune" };

    const exclusive = checkExclusive(player, runeId);
    if (!exclusive.ok)
        return { ok: false, reason: `exclusive:${exclusive.conflict}` };

    item.setDynamicProperty(RUNE_PROP_KEY, runeId);
    item.setDynamicProperty(RUNE_VER_KEY, RUNE_VER);
    item.setDynamicProperty(RUNE_LEVEL_PROP_KEY, clampLevel(level));   // a Rune item keeps its own Lv
    mainhandSlot.setItem(item);
    // Refresh lore so Rune block appears immediately
    ItemRestrictionManager.updateSlotLore(mainhandSlot, player ?? null);
    return { ok: true, reason: "" };
}

// Force-installs a rune onto the player's mainhand item, bypassing cost,
// the "already has a rune" check and exclusivity rules.
// Creative-Mode debug tool only — see rune_creative_gui.js.
// Returns { ok: bool, reason: string }
export function forceInstallRune(player, runeId, level = DEFAULT_LEVEL) {
    const mainhandSlot = EquipmentManager.getSlot(player, EquipmentSlot.Mainhand);
    if (!mainhandSlot?.hasItem()) return { ok: false, reason: "no_item" };

    const item = mainhandSlot.getItem();
    item.setDynamicProperty(RUNE_PROP_KEY, runeId);
    item.setDynamicProperty(RUNE_VER_KEY, RUNE_VER);
    item.setDynamicProperty(RUNE_LEVEL_PROP_KEY, clampLevel(level));
    mainhandSlot.setItem(item);
    // Refresh lore so Rune block appears immediately
    ItemRestrictionManager.updateSlotLore(mainhandSlot, player ?? null);
    return { ok: true, reason: "" };
}

// Removes the rune from the player's mainhand item.
// Returns the removed rune ID, or null if none was installed.
export function removeRune(player) {
    const mainhandSlot = EquipmentManager.getSlot(player, EquipmentSlot.Mainhand);
    if (!mainhandSlot?.hasItem()) return null;

    const item   = mainhandSlot.getItem();
    const runeId = item.getDynamicProperty(RUNE_PROP_KEY);
    if (!runeId) return null;

    item.setDynamicProperty(RUNE_PROP_KEY, undefined);
    item.setDynamicProperty(RUNE_VER_KEY, undefined);
    item.setDynamicProperty(RUNE_FORCED_KEY, undefined);
    item.setDynamicProperty(RUNE_LEVEL_PROP_KEY, undefined);
    mainhandSlot.setItem(item);
    // Refresh lore to remove the Rune block
    ItemRestrictionManager.updateSlotLore(mainhandSlot, player ?? null);
    return runeId;
}

export class RuneManager {
    // Event handlers are called by core/event_router.js. Damage hooks run on the EventBus
    // ("damage:before" / "damage:after", see rune_effects.js startRuneEngine).
    static handleHurtBefore() { /* handled on the EventBus */ }
    static handleHurtAfter() { /* handled on the EventBus */ }

    static handleBlockBreak(event) {
        try { RuneFx.onBlockBreak(event); }
        catch (e) { Logger.error("Rune block-break error", e); }
    }

    static registerKillHooks() {
        KillManager.addListener((killEvent) => {
            if (!killEvent.isPlayerKill) return;
            try { RuneFx.onKill(killEvent); } catch (e) { Logger.error("Rune kill hook error", e); }
        });
    }

    static onPlayerRespawn(player) {
        if (!player) return;
        RuneState.clearPlayer(player.id);
    }

    static onPlayerLeave(playerId) {
        RuneState.clearPlayer(playerId);
    }

    static clearVictimState(victimId) {
        RuneState.clearVictim(victimId);
    }

    static getActiveRuneIds() { return []; }

    static tickPassive(player) {
        if (!player) return;
        try { RuneFx.tick(player); } catch (_) { /* player not ready */ }
    }

    // Backward-compatible bootstrap for older callers.
    static register() { this.registerKillHooks(); }
}
