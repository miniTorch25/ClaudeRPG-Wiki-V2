// rune_curseneutral.js — stat getters read by the Managers (HP, Mana, XP, speed, healing).
//
// Kept under its old name because hp_manager / mana_manager / xp_manager / stats_manager / augment / gui_manager
// import it. The values now come from the rune effect engine (rune_effects.js). Damage dealt / taken is applied
// directly in the combat pipeline (EventBus), so those two getters return 0 to avoid counting them twice.

import {
    getRuneSpeedPercent, getRuneHpPercent, getRuneXpPercent, getRuneManaCostPercent,
    getRuneManaRegenPercent, getRuneHealMultiplier, isRegenBlocked,
} from "./rune_effects.js";

export const getHpModPercent = (player) => getRuneHpPercent(player);
export const getManaModPercent = () => 0;
export const getSpeedModPercent = (player) => getRuneSpeedPercent(player);
export const getManaRegenModPercent = (player) => getRuneManaRegenPercent(player);
export const getXpModPercent = (player) => getRuneXpPercent(player);
export const getHealReceivedMultiplier = (player) => getRuneHealMultiplier(player);
export const getManaCostModPercent = (player) => getRuneManaCostPercent(player);
export const shouldDisableRegen = (player) => isRegenBlocked(player);
export const getDamageDealtPercent = () => 0;
export const getDamageTakenPercent = () => 0;

export function onPlayerHurt() { /* handled in rune_effects.js */ }
export function clearHurtState() { /* no per-hurt state */ }
export function tickCurseEffects() { /* ticked by RuneManager.tickPassive */ }
export function rollChaosEchoOnRespawn() { /* Chaos Echo no longer exists */ }
