// rune_lore.js — Rune Lore text, generated from the effect list in config/rune_catalog.js.
//
//   Rune: <Name> Lv N T<tier> [Trigger]
//   <good effects, one line each (§a)>
//   <bad effects, one line each (§c)>
//   Chorus Synergy: ...

import { Synergy } from "../systems/synergy.js";
import { LEVEL_LABEL, clampLevel } from "../config/level_config.js";
import { wrapLoreLines } from "../config/lore_wrap.js";
import { RUNE_REGISTRY } from "./rune_registry.js";
import { resolveFx } from "./rune_fx.js";
import { getItemKind } from "../config/item_category_config.js";

// Rune name color by tier (T1-T7) — matches Gem rarity color scale
const TIER_COLOR = { 1: "§f", 2: "§e", 3: "§a", 4: "§3", 5: "§9", 6: "§u", 7: "§4" };

const COND_TXT = {
    alone: "vs a lone target", crowd: "with 3+ enemies near", first: "on the first hit on a target", later: "on later hits",
    hpLow: "vs targets below 25% HP", hpFull: "vs full-HP targets", boss: "vs bosses", nonBoss: "vs non-bosses",
    undead: "vs undead", living: "vs living targets", big: "vs high-HP targets", small: "vs low-HP targets",
    behind: "from behind", front: "from the front", noCrit: "on non-crit hits", still: "while standing still",
    moving: "while moving", run: "while sprinting", far: "at long reach", close: "at close range",
    fullCharge: "with full-charge shots", notFull: "without a full charge", ranged: "on ranged hits", melee: "on melee hits",
    armored: "vs armored targets", unarmored: "vs unarmored targets", unmarked: "vs unmarked targets",
    fireMob: "vs fire-immune mobs", offBeat: "on hits 1-3 of 4", selfLow: "below 50% HP", selfFull: "at full HP",
    selfHigh: "above 50% HP", stacksFull: "at full stacks", fallenWindow: "right after a kill", day: "in daylight",
    chorus: "with a matching Chorus set", noChorus: "without a matching Chorus set", onCooldown: "while on cooldown",
    noBarrier: "with no Barrier", attack: "while attacking", noSneak: "when not sneaking",
    firstSneak: "on a sneaking first hit", ore: "on ores",
};

const n = (v) => (v >= 10 ? String(Math.round(v)) : String(Math.round(v * 10) / 10));
const sg = (e) => (e.side === "good" ? "+" : "-");
const cond = (e) => (e.when && COND_TXT[e.when] ? ` ${COND_TXT[e.when]}` : "");
// For "lower is better" stats the sign flips with the side.
const sgLow = (e) => (e.side === "good" ? "-" : "+");

const PROC_TXT = {
    bleed:     (e) => `Bleed the target for ${e.sec}s`,
    stun:      (e) => `${n(e.v)}% chance to stun for ${e.sec}s`,
    lightning: (e) => `${n(e.v)}% chance to call lightning`,
    slow:      (e) => `Slow the target for ${e.sec}s`,
    ignite:    (e) => `Ignite the target for ${e.sec}s`,
    poison:    (e) => `Poison stacks up to level III (${e.sec}s)`,
};

const FX_TXT = {
    dmg:        (e) => `${sg(e)}${n(e.v)}% damage${cond(e)}`,
    atkSpeed:   (e) => `${sg(e)}${n(e.v)}% attack speed`,
    crit:       (e) => `${sg(e)}${n(e.v)}% crit chance`,
    critDmg:    (e) => `${sg(e)}${n(e.v)}% crit damage`,
    dmgRange:   (e) => `Damage grows with distance (up to +${n(e.v)}%)`,
    lifesteal:  (e) => `Heal ${n(e.v)}% of damage dealt`,
    splash:     (e) => e.line ? `Hits the target behind for ${n(e.v)}% damage` : `Hits ${e.n} extra target${e.n > 1 ? "s" : ""} for ${n(e.v)}% damage`,
    riposte:    (e) => `After being hit, your next attack deals +${n(e.v)}%`,
    wave:       (e) => `Every ${e.n}th hit sends a slash wave (${n(e.v)}% damage)`,
    proc:       (e) => (PROC_TXT[e.kind] ?? (() => "Proc"))(e),
    echo:       (e) => `${e.when === "ranged" ? "Ranged hits" : e.when === "melee" ? "Melee hits" : "Hits"} strike again for ${n(e.v)}% damage`,
    knock:      () => "Stronger knockback",
    recoil:     (e) => `Take ${n(e.v)}% of damage dealt as recoil`,
    absorbHit:  (e) => `Hits grant a shield of ${n(e.v)} hearts (${e.cd}s cooldown)`,
    stack:      (e) => e.per === "kill" ? `+${n(e.v)}% damage per kill, up to ${e.max}%` : `+${n(e.v)}% damage per hit, up to ${e.max} stacks${e.resetOnHurt ? " (reset when hit)" : ""}`,
    shock:      (e) => `Every ${e.n}th hit shocks nearby enemies (${n(e.v)}% damage)`,
    gamble:     (e) => `Damage varies between ${e.lo}% and ${e.hi}%`,
    killHeal:   (e) => `Heal ${n(e.v)}% max HP on kill`,
    killFood:   (e) => `Restore ${Math.max(1, Math.round(e.v))} hunger on kill`,
    killSpeed:  (e) => `Speed boost for ${e.sec}s after a kill`,
    killRegen:  (e) => `Regenerate for ${e.sec}s after a kill`,
    regenPause: (e) => `Natural regeneration stops for ${e.sec}s after a kill`,
    repairKills:(e) => `Repair 1 durability every ${Math.max(1, Math.round(100 / Math.max(1, e.v)))} kills`,
    repairBlocks:(e) => `Repair 1 durability every ${Math.max(1, Math.round(100 / Math.max(1, e.v)))} blocks`,
    xp:         (e) => `${sg(e)}${n(e.v)}% XP`,
    drops:      (e) => e.side === "good" ? `${n(e.v)}% chance for a bonus ${e.kind === "any" || !e.kind ? "" : e.kind + " "}drop` : `-${n(e.v)}% drops`,
    dropsLose:  (e) => `${n(e.v)}% chance to lose ${e.kind && e.kind !== "any" ? e.kind + " " : ""}drops`,
    bonusDrop:  (e) => `${n(e.v)}% chance for a bonus ${e.kind === "sap" ? "sapling or stick" : e.kind === "dig" ? "buried treasure" : e.kind === "lucky" ? "rare find" : e.kind === "bonemeal" ? "bone meal" : "item"}`,
    magnet:     (e) => `Drops fly to you (${n(e.v)} blocks)`,
    speed:      (e) => `${sg(e)}${n(e.v)}% walk speed`,
    knockRes:   (e) => `${e.when === "attack" ? "Resist knockback while attacking" : e.when === "selfLow" ? "Resist knockback below 50% HP" : "Resist knockback"}${e.v < 100 ? ` (${n(e.v)}%)` : ""}`,
    knockTaken: (e) => `${sgLow(e) === "-" ? "-" : "+"}${n(e.v)}% knockback taken${cond(e)}`,
    taken:      (e) => `${sgLow(e)}${n(e.v)}% damage taken${cond(e)}`,
    dodge:      (e) => `${n(e.v)}% chance to dodge a hit`,
    thorns:     (e) => `Reflect ${n(e.v)}% of damage taken`,
    secondWind: (e) => `Below ${e.hp}% HP, heal ${n(e.v)}% max HP (${e.cd}s cooldown)`,
    healRecv:   (e) => `${sg(e)}${n(e.v)}% healing received${cond(e)}`,
    barrier:    (e) => `Gain a ${n(e.v)}-heart barrier every ${e.cd}s`,
    cleanse:    () => "Remove a bad effect on kill",
    hp:         (e) => `${sg(e)}${n(e.v)}% max HP`,
    hunger:     (e) => `${sgLow(e)}${n(e.v)}% hunger rate`,
    dura:       (e) => `${sgLow(e)}${n(e.v)}% durability use${cond(e)}`,
    manaCost:   (e) => `${sgLow(e)}${n(e.v)}% Mana cost`,
    manaRegen:  (e) => `${sg(e)}${n(e.v)}% Mana regen`,
    manaOnHit:  (e) => `Restore ${n(e.v)}% Mana per hit`,
    glow:       (e) => `Enemies within ${e.v >= 16 ? 16 : n(e.v)} blocks glow`,
    pullAll:    (e) => `Every ${n(e.v)}s pull enemies toward you`,
    pull:       (e) => `Pull the target ${n(e.v)} block closer (${e.cd}s cooldown)`,
    mark:       (e) => `First hit marks the target: +${n(e.v)}% damage for ${e.sec}s`,
    overkill:   () => "Overkill damage spills onto nearby enemies",
    ammoSave:   (e) => `${n(e.v)}% chance not to use ammo`,
    effect:     (e) => e.eff === "haste" ? "Haste while held" : "Night vision while held",
    mine:       (e) => `${sg(e)}${n(e.v)}% mining speed${cond(e)}`,
    aoe:        (e) => `${n(e.v)}% chance to mine a 3x3 area`,
    harvest:    () => "Harvest ripe crops in a 3x3 area",
    replant:    (e) => `${n(e.v)}% chance to replant a harvested ripe crop (uses a dropped seed)`,
    careful:    () => "Unripe crops and missed ores are not wasted",
    smelt:      () => "Ores drop smelted",
    vein:       (e) => `+${Math.round(e.v)} blocks of Vein reach`,
    selfHurt:   (e) => `${n(e.v)}% chance per attack to lose a little HP`,
    duraBurst:  (e) => `${n(e.v)}% chance per block to lose 10 durability`,
    note:       (e) => e.txt,
};

function effectLine(e) {
    const f = FX_TXT[e.fx];
    return f ? f(e) : null;
}

// Plain list of effect lines, for the Knowledge Book encyclopedia and the Rune item Lore.
export function describeEffects(runeId, level = 4, effectPct = 0, itemIsTool = false) {
    const fx = resolveFx(runeId, level, effectPct, itemIsTool);
    const good = [], bad = [];
    for (const e of fx) {
        if (e.off) continue;
        const t = effectLine(e);
        if (t) (e.side === "good" ? good : bad).push(t);
    }
    const wornOff = fx.some((e) => e.side === "bad" && e.off) && bad.length === 0;
    return { good, bad, wornOff };
}

export function buildRuneLoreLines(runeId, player = null, level = 1, bonus = 0, itemTypeId = null) {
    if (!runeId) return [];
    const meta = RUNE_REGISTRY[runeId];
    if (!meta) return [];
    const baseLevel = clampLevel(level);
    level = clampLevel(baseLevel + (meta.kind === "curse" ? 0 : bonus));   // curses never gain levels from Mastery
    const nameColor = meta.kind === "curse" ? "§c" : (TIER_COLOR[meta.tier] ?? "§f");
    const isTool = itemTypeId ? getItemKind(itemTypeId)?.group === "tool" : false;
    const { good, bad, wornOff } = describeEffects(runeId, level, 0, isTool);

    const body = [
        ...good.map((t) => `§r§a${t}`),
        ...bad.map((t) => `§r§c${t}`),
        ...(wornOff ? ["§r§8Drawback worn off"] : []),
    ];
    const aff = Synergy.affinityLine("rune", runeId);
    return [
        "",
        `§r§7Rune: ${nameColor}${formatRuneName(runeId)} §b${LEVEL_LABEL[level]}${level > baseLevel ? ` §d(+${level - baseLevel})` : ""} §8T${meta.tier} §8[${meta.kind === "curse" ? "Curse" : "Trigger"}]`,
        ...wrapLoreLines(body),
        ...(aff ? [aff] : []),
    ];
}

export function formatRuneName(runeId) {
    return RUNE_REGISTRY[runeId]?.name
        ?? String(runeId).split("_").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}
