// rune_projectile.js — projectile hooks called by core/event_router.js.
// Arrow damage runs through the normal combat pipeline (rune_effects.js); only the spawn hook is needed (ammo saving).
import { RuneFx } from "./rune_effects.js";

export function handleProjectileSpawn(event) { RuneFx.onProjectileSpawn(event); }
export function handleProjectileHitEntity() { /* damage pipeline handles the hit */ }
export function handleProjectileHitBlock() { /* nothing to do */ }
export function tickProjectileSystem() { /* no tracked projectiles */ }
export function registerProjectileHooks() {}
