// gem_ability_config.js — Balance values for every Gem skill (84 abilities, 7 tiers x 12).
// All Gem ability logic reads from here — never hardcodes values in logic files.
// Mirrors the pattern used by rune_config.js for Runes.
//
// Tiers 1-3 STACK: the same ability on several armor pieces adds up (count x value) up to the global caps below.
// Tiers 4-7 are bound to one armor category, so they never stack.

// Global caps on everything Gems give (all sources together). Max HP / Max Mana / regen are uncapped.
export const GEM_CAPS = {
    dmgReduction: 50,   // % damage taken reduction, all Gem sources
    dodge:        15,   // % dodge from Gems (separate from the Chorus cap)
    meleeBonus:   60,   // % melee-specific damage bonus, all Gem sources
    speed:        50,   // % movement speed from Gems
};

// How Gem Enchanting picks the ability: "random" = roll among the abilities the armor category can carry
// (default, per design); "choose" = the player picks from that list.
export const GEM_ENCHANT_MODE = "random";

const GEM_ABILITY_CONFIG_BASE = {

    // ===== Tier 1 · Common =====
    vitality:     { maxHpBonus: 15 },
    swiftness:    { speedPct: 5 },
    toughness:    { dmgReduction: 3 },
    recovery:     { regenBonus: 0.3 },
    keen_eyes:    {},
    marksman:     { rangedBonus: 5 },
    focus:        { maxMana: 20 },
    mana_trickle: { manaRegen: 0.4 },
    padded_plate: { projReduction: 5 },
    brawler:      { meleeBonus: 4 },
    sure_step:    { knockbackReduction: 20 },
    soft_landing: { fallReduction: 30 },

    // ===== Tier 2 · Uncommon =====
    hearty:       { maxHpBonus: 30 },
    vigor:        { regenBonus: 0.8 },
    tenacity:     { dmgReduction: 15, hpThresholdPct: 50 },
    intuition:    { dodge: 4 },
    spell_ward:   { magicReduction: 12 },
    clear_mind:   { manaRegen: 0.8 },
    eagle_eye:    { rangedBonus: 8 },
    aqua_lung:    {},
    stoneskin:    { meleeReduction: 10 },
    brute_force:  { meleeBonus: 8 },
    thorns:       { damage: 3 },
    marathon:     { hungerReduction: 35 },

    // ===== Tier 3 · Rare =====
    fortitude:        { maxHpBonus: 45 },
    adrenaline:       { meleeBonus: 20, hpThresholdPct: 40 },
    resolve:          { dmgReduction: 8 },
    swift_strides:    { speedPct: 10 },
    assassination:    { sneakBonus: 30 },
    arcane_reservoir: { maxMana: 80, manaRegen: 1.0 },
    spellbreaker:     { magicFireReduction: 20 },
    reflexes:         { dodge: 6 },
    sanctuary:        { dmgReduction: 25, healPerSec: 2 },
    plate_wall:       { projReduction: 20 },
    cats_grace:       { safeFallBlocks: 10 },
    killers_rush:     { speedSeconds: 3, speedAmplifier: 1 },

    // ===== Tier 4 · Unique =====
    arcane_surge:       { maxMana: 120, manaRegen: 2 },
    clairvoyance:       { radius: 20 },
    spell_mirror:       { chance: 25 },
    reflection:         { chance: 20, shieldChance: 40 },
    second_wind:        { hpThresholdPct: 20, healAmount: 25, cooldownSec: 60 },
    glacial_presence:   { radius: 5 },
    cinderveil:         { radius: 5 },
    warpath:            { windowSec: 5, perStack: 4, maxStacks: 5 },
    executioners_gait:  { dmgBonus: 20, hpThresholdPct: 35 },
    wind_walker:        { speedPct: 15, safeFallBlocks: 15 },
    frost_walker:       {},
    evasion:            { dodge: 8, speedSeconds: 2, speedAmplifier: 1 },

    // ===== Tier 5 · Legend =====
    immunity:           { cooldownSec: 30 },
    lucid_mind:         { cooldownReduction: 15 },
    soulward:           { magicReduction: 30 },
    guardian_shield:    { chargeSec: 60, maxStacks: 3, absorb: 8 },
    bulletproof:        { dmgReduction: 30 },
    unyielding:         { maxHitPct: 35 },
    bloodthirst:        { lifestealPct: 8 },
    overpower:          { meleeBonus: 20, armorPenPct: 10 },
    momentum_strike:    { perSec: 3, maxBonus: 15, lingerSec: 3 },
    void_escape:        { voidY: -64 },
    skystep:            {},
    quicksilver:        { speedPct: 25, seconds: 4 },

    // ===== Tier 6 · Epic =====
    archmages_crown:    { maxMana: 250, manaRegen: 3 },
    premonition:        { intervalSec: 15 },
    dragons_gaze:       { rangedBonus: 30, armorPenPct: 20 },
    frostflare:         { radius: 5 },
    static_field:       { damage: 5, radius: 5, intervalSec: 2 },
    titan_heart:        { maxHpBonus: 100, regenBonus: 1.5 },
    vampirism:          { lifestealPct: 15 },
    rampage:            { perKill: 10, seconds: 8, maxStacks: 5 },
    thunder_stride:     { damage: 8, radius: 4, cooldownSec: 4 },
    flight:             { manaPerSec: 50 },
    phase_step:         { chance: 15, distance: 4, cooldownSec: 8 },
    earthshaker:        { minHeight: 6, damage: 10, radius: 5 },

    // ===== Tier 7 · Mythical =====
    ascended_mind:      { maxMana: 400, manaRegen: 5, manaCostReduction: 30 },
    mind_over_matter:   { absorbPct: 60 },
    third_eye:          { radius: 32, extraDamagePct: 15 },
    undying:            { cooldownSec: 120 },
    colossus:           { maxHpBonus: 120, dmgReduction: 15 },
    domain:             { damage: 20, radius: 6, cooldownSec: 15 },
    berserker:          { hpThresholdPct: 25, dmgBonus: 40, dmgReduction: 30 },
    warlords_might:     { meleeBonus: 25, stunEvery: 5, stunSec: 1 },
    reapers_due:        { healPct: 10 },
    godspeed:           { speedPct: 50 },
    voidstep:           { distance: 10, cooldownSec: 10 },
    earthbound:         {},
};

// --- Gem Potency -------------------------------------------------------------
// Gems have no levels. GEM_ABILITY_CONFIG[skill] holds the fixed values for the skill.
// Gem Mastery adds "Gem Potency" (a % boost, up to GEM_POTENCY_MAX; the Resonance rune adds more, total
// capped at GEM_POTENCY_CAP): it raises ONLY the power
// numbers listed in GEM_POTENCY_KEYS (heal / damage / reduction / bonus values). Cooldowns,
// costs, radii, durations and the global caps never change.
// Runtime logic reads getScaledGemConfig(skill, potencyPct) -- gem_ability.js passes the
// player's Potency (MasteryManager.getGemPotency).
import { scaleEntry } from "./level_config.js";

export const GEM_POTENCY_MAX = 20;   // % from Gem Mastery (matches the Gem Mastery effect max)
export const GEM_POTENCY_CAP = 40;   // % absolute ceiling: Gem Mastery + the Resonance rune together

export const GEM_POTENCY_KEYS = {
    // power numbers only; cooldowns, durations, radii, thresholds and the global caps never scale
    vitality: ["maxHpBonus"], swiftness: ["speedPct"], toughness: ["dmgReduction"], recovery: ["regenBonus"],
    marksman: ["rangedBonus"], focus: ["maxMana"], mana_trickle: ["manaRegen"], padded_plate: ["projReduction"],
    brawler: ["meleeBonus"], sure_step: ["knockbackReduction"], soft_landing: ["fallReduction"],
    hearty: ["maxHpBonus"], vigor: ["regenBonus"], tenacity: ["dmgReduction"], intuition: ["dodge"],
    spell_ward: ["magicReduction"], clear_mind: ["manaRegen"], eagle_eye: ["rangedBonus"],
    stoneskin: ["meleeReduction"], brute_force: ["meleeBonus"], thorns: ["damage"], marathon: ["hungerReduction"],
    fortitude: ["maxHpBonus"], adrenaline: ["meleeBonus"], resolve: ["dmgReduction"], swift_strides: ["speedPct"],
    assassination: ["sneakBonus"], arcane_reservoir: ["maxMana", "manaRegen"], spellbreaker: ["magicFireReduction"],
    reflexes: ["dodge"], sanctuary: ["dmgReduction", "healPerSec"], plate_wall: ["projReduction"],
    arcane_surge: ["maxMana", "manaRegen"], spell_mirror: ["chance"], reflection: ["chance", "shieldChance"],
    second_wind: ["healAmount"], executioners_gait: ["dmgBonus"], wind_walker: ["speedPct"], evasion: ["dodge"],
    lucid_mind: ["cooldownReduction"], soulward: ["magicReduction"], guardian_shield: ["absorb"],
    bulletproof: ["dmgReduction"], bloodthirst: ["lifestealPct"], overpower: ["meleeBonus"],
    quicksilver: ["speedPct"], archmages_crown: ["maxMana", "manaRegen"], dragons_gaze: ["rangedBonus"],
    static_field: ["damage"], titan_heart: ["maxHpBonus", "regenBonus"], vampirism: ["lifestealPct"],
    thunder_stride: ["damage"], phase_step: ["chance"], earthshaker: ["damage"],
    ascended_mind: ["maxMana", "manaRegen"], third_eye: ["extraDamagePct"], colossus: ["maxHpBonus", "dmgReduction"],
    domain: ["damage"], berserker: ["dmgBonus", "dmgReduction"], warlords_might: ["meleeBonus"],
    reapers_due: ["healPct"], godspeed: ["speedPct"],
};

export const GEM_ABILITY_CONFIG = GEM_ABILITY_CONFIG_BASE;

const _gemCache = new Map();
export function getScaledGemConfig(skill, potencyPct = 0) {
    const pct = Math.min(GEM_POTENCY_CAP, Math.max(0, Math.round(Number(potencyPct) || 0)));
    const key = `${skill}:${pct}`;
    let hit = _gemCache.get(key);
    if (!hit) {
        hit = pct === 0 ? GEM_ABILITY_CONFIG_BASE[skill]
                        : scaleEntry(GEM_ABILITY_CONFIG_BASE[skill], GEM_POTENCY_KEYS[skill], 1 + pct / 100);
        _gemCache.set(key, hit);
    }
    return hit;
}
