// achievement_config.js -- Achievement system settings (editable from the Admin Config Editor in phase B2).
export const ACHIEVEMENT = {
    ENABLED: 1,                     // master switch, 1 = on / 0 = off (Admin Config Editor)
    FLUSH_INTERVAL_TICKS: 100,      // dirty player data is written about every 5 seconds
    PROPERTY: "crpg:ach",           // one dynamic property per player (never touched by Prestige / Reset All / Delete All)
    SCHEMA: 1,
    COUNT_GAMEMODES: ["survival", "adventure"],   // Creative / Spectator never count
    ITEMS_PER_PAGE: 10,
    NOTIFY: {
        SOUND: "random.levelup",
        CHAT: 1,                    // 1 = chat line + quip
        ACTIONBAR: 1,                // 1 = action bar text
        MAX_PER_TICK: 4,            // safety: more than this at once are queued to the next flush
    },
};
