// mob_config.js — central mob metadata used by KillManager, Rune system, and future systems.
//
// tags:       string[]  — "undead" | "giant" | "boss" | "homing" (Skyfall Rune)
// soulValue:  number    — soul points granted to Soul Reaper Rune on kill
// homing:     bool      — Skyfall Rune can target this mob (default false)
//
// Mobs not listed here have no special tags (soulValue: 1 by default from KillManager).

export const MOB_CONFIG = {
    // --- Undead ---
    "minecraft:zombie":          { tags: ["undead"],         soulValue: 1  },
    "minecraft:husk":            { tags: ["undead"],         soulValue: 1  },
    "minecraft:drowned":         { tags: ["undead"],         soulValue: 1  },
    "minecraft:skeleton":        { tags: ["undead"],         soulValue: 1  },
    "minecraft:stray":           { tags: ["undead"],         soulValue: 1  },
    "minecraft:bogged":          { tags: ["undead"],         soulValue: 1  },
    "minecraft:wither_skeleton": { tags: ["undead"],         soulValue: 2  },
    "minecraft:phantom":         { tags: ["undead"],         soulValue: 1  },
    "minecraft:zombified_piglin":{ tags: ["undead"],         soulValue: 1  },
    "minecraft:zoglin":          { tags: ["undead"],         soulValue: 2  },

    // --- Giant ---
    "minecraft:iron_golem":      { tags: ["giant"],          soulValue: 5,  homing: false },
    "minecraft:ravager":         { tags: ["giant"],          soulValue: 5,  homing: false },
    "minecraft:elder_guardian":  { tags: ["giant", "boss"],  soulValue: 10, homing: false },

    // --- Boss ---
    "minecraft:warden":          { tags: ["boss"],           soulValue: 10, homing: false },
    "minecraft:ender_dragon":    { tags: ["boss"],           soulValue: 10, homing: false },
    "minecraft:wither":          { tags: ["boss"],           soulValue: 10, homing: false },

    // --- Standard hostile (homing targets) ---
    "minecraft:creeper":         { tags: [],  soulValue: 2, homing: true  },
    "minecraft:spider":          { tags: [],  soulValue: 1, homing: true  },
    "minecraft:cave_spider":     { tags: [],  soulValue: 1, homing: true  },
    "minecraft:pillager":        { tags: [],  soulValue: 1, homing: true  },
    "minecraft:vindicator":      { tags: [],  soulValue: 2, homing: true  },
    "minecraft:evoker":          { tags: [],  soulValue: 3, homing: true  },
    "minecraft:blaze":           { tags: [],  soulValue: 3, homing: true  },
    "minecraft:enderman":        { tags: [],  soulValue: 3, homing: true  },
    "minecraft:witch":           { tags: [],  soulValue: 2, homing: true  },
    "minecraft:shulker":         { tags: [],  soulValue: 3, homing: true  },
    "minecraft:guardian":        { tags: [],  soulValue: 2, homing: true  },
    "minecraft:ghast":           { tags: [],  soulValue: 2, homing: true  },
    "minecraft:breeze":          { tags: [],  soulValue: 3, homing: true  },
    "minecraft:piglin_brute":    { tags: [],  soulValue: 3, homing: true  },
};

// Default soul value for mobs not listed above
const DEFAULT_SOUL_VALUE = 1;

// --- Helper functions ---

export function getMobMeta(typeId) {
    return MOB_CONFIG[typeId] ?? null;
}

export function hasTag(typeId, tag) {
    return MOB_CONFIG[typeId]?.tags?.includes(tag) ?? false;
}

export function isUndead(typeId) { return hasTag(typeId, "undead"); }
export function isGiant(typeId)  { return hasTag(typeId, "giant");  }
export function isBoss(typeId)   { return hasTag(typeId, "boss");   }
export function isHoming(typeId) { return MOB_CONFIG[typeId]?.homing ?? false; }

export function getSoulValue(typeId) {
    return MOB_CONFIG[typeId]?.soulValue ?? DEFAULT_SOUL_VALUE;
}
