// damage_indicator_config.js -- floating damage numbers (Admin Config Editor, group "Damage Indicator").
// Each hit a player lands on a mob or boss spawns a short-lived invisible entity ("crpg:damage_indicator")
// named with the damage. The 2 second lifetime is defined in the entity file itself (timer), not here.
export const DAMAGE_INDICATOR = {
    ENABLED: 1,                 // 1 = on, 0 = off
    MAX_PER_PLAYER: 8,          // numbers alive at once per attacking player (stops spam from fast or area hits)
    MERGE_TICKS: 10,            // hits from one player on the same mob within this time (10 = 0.5 s) merge into ONE number
    VIEW_RADIUS: 24,            // blocks between attacker and mob; farther hits show no number
    LIFETIME_TICKS: 40,         // must match the entity's timer (2 s); only used to count live numbers
    RADIUS_MIN: 0.6,            // blocks from the mob's centre
    RADIUS_MAX: 1.4,
    HEIGHT_MIN: -0.2,           // height relative to the mob's head
    HEIGHT_MAX: 0.6,
    COLOR_NORMAL: "§f",         // white
    COLOR_CRIT: "§6",           // orange (gold) for critical hits
    ENTITY_ID: "crpg:damage_indicator",
};
