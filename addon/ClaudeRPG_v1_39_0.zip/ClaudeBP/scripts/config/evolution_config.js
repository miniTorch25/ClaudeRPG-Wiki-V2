// evolution_config.js -- Mob Evolution (Evolution Pool). Tiers are THEMES unlocked by
// Ascension, not a power ladder. Each new hostile mob rolls at most one tier from the
// pool that is unlocked at the current Ascension.

import { SPECIAL_AWAKEN_TYPES } from "./special_config.js";

export const EVOLUTION = {
    // Chance that a newly spawned eligible mob evolves: BASE + PER_ASC * Ascension (max MAX)
    CHANCE_BASE: 0.10,
    CHANCE_PER_ASC: 0.04,
    CHANCE_MAX: 0.40,

    // Evolved mobs (any tier) also hit harder as Ascension rises: x(1 + PER_ASC * Ascension), max CAP.
    ASC_DAMAGE: { PER_ASC: 0.04, CAP: 1.5 },

    // Performance cap: evolved mobs already alive within AREA_RADIUS of the spawn point
    AREA_CAP: 10,
    AREA_RADIUS: 48,

    // Ability scan (only mobs within SCAN_RADIUS of a player are processed)
    SCAN_INTERVAL_TICKS: 20,
    SCAN_RADIUS: 48,

    // Hostile mobs that never evolve (splitters, summons, swarm mobs)
    EXCLUDE: [
        "minecraft:vex", "minecraft:silverfish", "minecraft:endermite",
        "minecraft:slime", "minecraft:magma_cube",
    ],

    TIERS: {
        tough: {
            name: "Tough", color: "§a", unlockAsc: 1, weight: 1,
            hp: 1.5, damage: 1.25, xp: 1.5,
            particle: "minecraft:villager_happy",
        },
        elite: {
            name: "Elite", color: "§c", unlockAsc: 2, weight: 1,
            hp: 2.0, damage: 1.5, xp: 2.0,
            particle: "minecraft:villager_angry",
            enrageBelow: 0.35,         // HP fraction: gains Speed
            enrageSpeedAmp: 1,
            callBelow: 0.5,            // HP fraction: calls allies once
            callCount: 2,
            callTypes: [
                "minecraft:zombie", "minecraft:husk", "minecraft:skeleton",
                "minecraft:stray", "minecraft:pillager", "minecraft:vindicator",
            ],
        },
        sculk: {
            name: "Sculk", color: "§3", unlockAsc: 3, weight: 1,
            hp: 1.25, damage: 1.1, xp: 1.5,
            particle: "minecraft:soul_particle",
            senseRange: 24,            // senses the nearest player through walls
            senseRangeNoisy: 40,       // ...farther when that player is noisy
            hotDamageBonus: 0.30,      // extra damage while a nearby player is noisy
            hotSpeedAmp: 0,
            nudge: 0.22,               // horizontal impulse toward the sensed player
            shardMin: 1, shardMax: 3,  // guaranteed Echo Shards on a player kill (also used for the Warden)
        },
        geode: {
            name: "Geode", color: "§d", unlockAsc: 4, weight: 1,
            hp: 1.5, damage: 1.0, xp: 1.5,
            particle: "minecraft:totem_particle",
            gemChance: 0.08,           // chance to drop 1 Uncarved Gem when killed by a player
            gemCount: 1,
        },
        inferno: {
            name: "Inferno", color: "§6", unlockAsc: 5, weight: 1,
            hp: 1.25, damage: 1.25, xp: 1.5,
            particle: "minecraft:basic_flame_particle",
            burnChance: 0.25, burnSeconds: 4,   // its attacks may set the player on fire
            // "Power" = this tier's stat bonus above x1. Nether mobs get x3, others none
            // (they still get the burning attack).
            netherPower: 3, otherPower: 0,
        },
        awaken: {
            name: "Awakened", color: "§b", unlockAsc: 7, weight: 0.7,
            hp: 2.0, damage: 1.4, xp: 3.0,
            particle: "minecraft:critical_hit_emitter",
            // Only mobs with a unique ability set can awaken (see AWAKEN_ABILITIES below)
            types: [
                "minecraft:zombie", "minecraft:husk", "minecraft:drowned",
                "minecraft:skeleton", "minecraft:stray", "minecraft:bogged", "minecraft:parched",
                "minecraft:spider", "minecraft:cave_spider",
                ...SPECIAL_AWAKEN_TYPES,   // Creeper, Enderman, Witch, Blaze ... (config/special_config.js)
            ],
            mutations: {
                swift:    { name: "Swift",    speedAmp: 0 },
                brutal:   { name: "Brutal",   damage: 0.30 },
                hardened: { name: "Hardened", hp: 1.30 },
            },
            rareDrops: [
                { id: "crpg:uncarved_gem", chance: 0.06, min: 1, max: 2 },
                { id: "crpg:gem_dust",     chance: 0.20, min: 1, max: 3 },
            ],
        },
        // Core: a stationary, very tanky "loot piñata". Cannot be moved, cannot be one-shot
        // (every hit is capped at hitCapFraction of its max pool), and may drop a Core item.
        core: {
            name: "Core", color: "§m", unlockAsc: 1, weight: 0.5,
            hp: 20, damage: 1.0, xp: 6.0,
            particle: "minecraft:totem_particle",
            noForce: true,                 // not offered by Stellar Core force-evolve
            hitCapFraction: 0.10,          // one hit never removes more than this fraction of max HP
            burstTicks: 5,                 // ...and ALL damage landing within this many ticks counts as ONE hit (chain, rune bonus, Chorus blasts)
            immobileAmp: 255,              // Slowness level that pins it in place
            anchorSnap: 0.5,               // teleported back when pushed farther than this (blocks)
            dropChance: 0.25,              // chance to drop exactly ONE of dropItems on a player kill
            dropItems: ["crpg:augment_core", "crpg:stellar_core"],
            exclude: [                     // mobs that make no sense as a stationary Core
                "minecraft:creeper", "minecraft:enderman", "minecraft:phantom", "minecraft:ghast",
            ],
        },
        // Event tier: never rolled on spawn, only created by the Nightmare event.
        nightmare: {
            name: "Nightmare", color: "§5", unlockAsc: 6, weight: 0, event: true,
            hp: 2.0, damage: 1.5, xp: 3.0,
            particle: "minecraft:basic_smoke_particle",
            blindChance: 0.35, blindTicks: 60,  // its hits may blind the player
        },
    },
};

// Enchanted: a modifier (NOT a tier) that can sit on top of any tier except Core.
// Rolled independently of the Evolution roll, so it can appear even at Ascension 0.
export const ENCHANTED = {
    name: "Enchanted", color: "§t",
    CHANCE_BASE: 0.005,          // 0.5% per eligible spawn at Ascension 0
    CHANCE_PER_ASC: 0.0025,      // +0.25% per Ascension
    CHANCE_MAX: 0.05,
    xp: 1.5,                     // EXP multiplier
    damage: 1.2,                 // damage multiplier of an Enchanted mob
    shieldIntervalMs: 10000,     // a broken shield comes back after this long
    essenceMin: 1, essenceMax: 5,   // Enchant Essence always dropped on a player kill
    crystalMin: 1, crystalMax: 5,   // Augment Crystal also always dropped on a player kill
    particle: "minecraft:enchanting_table_particle",
    shieldParticle: "minecraft:blue_flame_particle",
};

// Stellar Core: right-click a mob to force-evolve it (costs this many Stellar Cores).
export const STELLAR_FORCE = { COST: 1 };

// Unique abilities of Awakened mobs (cooldowns in ms, ranges in blocks)
export const AWAKEN_ABILITIES = {
    zombie: {
        types: ["minecraft:zombie", "minecraft:husk", "minecraft:drowned"],
        dash:    { cooldownMs: 8000, minDist: 5, maxDist: 16, push: 0.9, lift: 0.25 },
        berserk: { below: 0.4, speedAmp: 1, damageBonus: 0.5 },
        call:    { below: 0.6, count: 2 },
    },
    skeleton: {
        types: ["minecraft:skeleton", "minecraft:stray", "minecraft:bogged", "minecraft:parched"],
        volley:  { cooldownMs: 6000, minDist: 6, maxDist: 24, spread: 0.15, speed: 2.4 },   // 2 extra arrows
    },
    spider: {
        types: ["minecraft:spider", "minecraft:cave_spider"],
        web:     { cooldownMs: 12000, maxDist: 10, lifeTicks: 120 },
        leap:    { cooldownMs: 5000, minDist: 3, maxDist: 12, push: 0.75, lift: 0.5 },
    },
};

// Nightmare event: days without sleeping (world days) -> chance per check, wave size
export const NIGHTMARE = {
    MIN_ASCENSION: 6,
    CHECK_EVERY_TICKS: 200,
    NIGHT_FROM: 13000, NIGHT_TO: 23000,
    LEVELS: [                           // sorted high to low
        { days: 5, chance: 0.25, wave: [2, 3], close: true,  message: "§4[Nightmare] They found you." },
        { days: 4, chance: 0.10, wave: [1, 2], close: false, message: "§5[Nightmare] Something moves in the dark..." },
        { days: 3, chance: 0.04, wave: [1, 1], close: false, message: "§5[Nightmare] You feel watched. You should sleep." },
    ],
    MAX_ALIVE_NEAR: 4,                  // Nightmare mobs alive within 64 blocks of the player
    FAR_MIN: 14, FAR_MAX: 24,           // spawn distance below the "close" level
    CLOSE_MIN: 3, CLOSE_MAX: 7,         // "close" level: appears right next to you, even indoors
    TYPES: ["minecraft:zombie", "minecraft:skeleton", "minecraft:spider"],
};
