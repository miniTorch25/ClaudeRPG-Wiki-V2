// "type" distinguishes the XP source:
//   "mob"     : killing this entity grants XP
//   "block"   : breaking this block grants XP; also specifies drop/dropCount for Vein & Luck
//   "consume" : eating/drinking this item grants XP
export const XP_CONFIG = {
    // Mobs
    "minecraft:zombie":          { type: "mob", xp: 5 },
    "minecraft:husk":            { type: "mob", xp: 5 },
    "minecraft:drowned":         { type: "mob", xp: 5 },
    "minecraft:pillager":        { type: "mob", xp: 5 },
    "minecraft:vindicator":      { type: "mob", xp: 6 },
    "minecraft:evoker":          { type: "mob", xp: 6 },
    "minecraft:vex":             { type: "mob", xp: 2 },
    "minecraft:ravager":         { type: "mob", xp: 30 },
    "minecraft:skeleton":        { type: "mob", xp: 5 },
    "minecraft:stray":           { type: "mob", xp: 6 },
    "minecraft:bogged":          { type: "mob", xp: 6 },
    "minecraft:parched":         { type: "mob", xp: 6 },
    "minecraft:wither_skeleton": { type: "mob", xp: 12 },
    "minecraft:spider":          { type: "mob", xp: 4 },
    "minecraft:cave_spider":     { type: "mob", xp: 6 },
    "minecraft:creeper":         { type: "mob", xp: 8 },
    "minecraft:witch":           { type: "mob", xp: 12 },
    "minecraft:phantom":         { type: "mob", xp: 8 },
    "minecraft:guardian":        { type: "mob", xp: 6 },
    "minecraft:ghast":           { type: "mob", xp: 4 },
    "minecraft:slime":           { type: "mob", xp: 1 },
    "minecraft:magma_cube":      { type: "mob", xp: 1 },
    "minecraft:piglin":          { type: "mob", xp: 5 },
    "minecraft:piglin_brute":    { type: "mob", xp: 20 },
    "minecraft:zombified_piglin":{ type: "mob", xp: 7 },
    "minecraft:hoglin":          { type: "mob", xp: 4 },
    "minecraft:zoglin":          { type: "mob", xp: 6 },
    "minecraft:breeze":          { type: "mob", xp: 10 },
    "minecraft:blaze":           { type: "mob", xp: 15 },
    "minecraft:silverfish":      { type: "mob", xp: 3 },
    "minecraft:enderman":        { type: "mob", xp: 15 },
    "minecraft:endermite":       { type: "mob", xp: 5 },
    "minecraft:shulker":         { type: "mob", xp: 20 },
    "minecraft:iron_golem":      { type: "mob", xp: 30 },
    "minecraft:elder_guardian":  { type: "mob", xp: 50 },
    "minecraft:warden":          { type: "mob", xp: 100 },
    "minecraft:wither":          { type: "mob", xp: 300 },
    "minecraft:ender_dragon":    { type: "mob", xp: 500 },

    // Blocks
    "minecraft:coal_ore":                { type: "block", xp: 1,  drop: "minecraft:coal",          dropCount: 1 },
    "minecraft:deepslate_coal_ore":      { type: "block", xp: 1,  drop: "minecraft:coal",          dropCount: 1 },
    "minecraft:iron_ore":                { type: "block", xp: 3,  drop: "minecraft:raw_iron",       dropCount: 1 },
    "minecraft:deepslate_iron_ore":      { type: "block", xp: 3,  drop: "minecraft:raw_iron",       dropCount: 1 },
    "minecraft:copper_ore":              { type: "block", xp: 2,  drop: "minecraft:raw_copper",     dropCount: 2 },
    "minecraft:deepslate_copper_ore":    { type: "block", xp: 2,  drop: "minecraft:raw_copper",     dropCount: 2 },
    "minecraft:gold_ore":                { type: "block", xp: 5,  drop: "minecraft:raw_gold",       dropCount: 1 },
    "minecraft:deepslate_gold_ore":      { type: "block", xp: 5,  drop: "minecraft:raw_gold",       dropCount: 1 },
    "minecraft:redstone_ore":            { type: "block", xp: 3,  drop: "minecraft:redstone",       dropCount: 4 },
    "minecraft:deepslate_redstone_ore":  { type: "block", xp: 3,  drop: "minecraft:redstone",       dropCount: 4 },
    "minecraft:lapis_ore":               { type: "block", xp: 4,  drop: "minecraft:lapis_lazuli",   dropCount: 6 },
    "minecraft:deepslate_lapis_ore":     { type: "block", xp: 4,  drop: "minecraft:lapis_lazuli",   dropCount: 6 },
    "minecraft:diamond_ore":             { type: "block", xp: 10, drop: "minecraft:diamond",        dropCount: 1 },
    "minecraft:deepslate_diamond_ore":   { type: "block", xp: 10, drop: "minecraft:diamond",        dropCount: 1 },
    "minecraft:emerald_ore":             { type: "block", xp: 12, drop: "minecraft:emerald",        dropCount: 1 },
    "minecraft:deepslate_emerald_ore":   { type: "block", xp: 12, drop: "minecraft:emerald",        dropCount: 1 },
    "minecraft:ancient_debris":          { type: "block", xp: 20, drop: "minecraft:netherite_scrap",dropCount: 1 },
    "minecraft:nether_gold_ore":         { type: "block", xp: 3,  drop: "minecraft:gold_nugget",    dropCount: 4 },
    "minecraft:nether_quartz_ore":       { type: "block", xp: 2,  drop: "minecraft:quartz",         dropCount: 1 },

    // Consumables
    "minecraft:apple":                   { type: "consume", xp: 1 },
    "minecraft:bread":                   { type: "consume", xp: 1 },
    "minecraft:cooked_beef":             { type: "consume", xp: 2 },
    "minecraft:cooked_porkchop":         { type: "consume", xp: 2 },
    "minecraft:cooked_chicken":          { type: "consume", xp: 2 },
    "minecraft:cooked_mutton":           { type: "consume", xp: 2 },
    "minecraft:cooked_rabbit":           { type: "consume", xp: 2 },
    "minecraft:cooked_cod":              { type: "consume", xp: 2 },
    "minecraft:cooked_salmon":           { type: "consume", xp: 2 },
    "minecraft:baked_potato":            { type: "consume", xp: 2 },
    "minecraft:pumpkin_pie":             { type: "consume", xp: 2 },
    "minecraft:cookie":                  { type: "consume", xp: 1 },
    "minecraft:mushroom_stew":           { type: "consume", xp: 2 },
    "minecraft:rabbit_stew":             { type: "consume", xp: 3 },
    "minecraft:beetroot_soup":           { type: "consume", xp: 2 },
    "minecraft:suspicious_stew":         { type: "consume", xp: 2 },
    "minecraft:honey_bottle":            { type: "consume", xp: 2 },
    "minecraft:golden_carrot":           { type: "consume", xp: 3 },
    "minecraft:golden_apple":            { type: "consume", xp: 5 },
    "minecraft:enchanted_golden_apple":  { type: "consume", xp: 20 },
    "minecraft:potion":                  { type: "consume", xp: 2 },
};

// ── Fishing Xp ───────────────────────────────────────────────────────────────
// Xp granted per item caught while fishing. Kept separate from XP_CONFIG because
// item ids overlap with "consume" entries (e.g. minecraft:potion = Water Bottle junk).
// Based on the vanilla Bedrock fishing loot table (fish 85% / junk 10% / treasure 5%).
//   category   : "fish" | "junk" | "treasure"  (informational, used for the message colour)
//   xp         : Xp for the normal item
//   enchantedXp: Xp when the caught item is enchanted (treasure Bow / Fishing Rod;
//                the unenchanted version of these ids comes from the junk pool)
export const FISHING_XP_CONFIG = {
    // Fish
    "minecraft:cod":               { category: "fish",     xp: 2 },
    "minecraft:salmon":            { category: "fish",     xp: 3 },
    "minecraft:pufferfish":        { category: "fish",     xp: 4 },
    "minecraft:tropical_fish":     { category: "fish",     xp: 6 },

    // Junk
    "minecraft:bowl":              { category: "junk",     xp: 1 },
    "minecraft:leather":           { category: "junk",     xp: 1 },
    "minecraft:leather_boots":     { category: "junk",     xp: 1 },
    "minecraft:rotten_flesh":      { category: "junk",     xp: 1 },
    "minecraft:stick":             { category: "junk",     xp: 1 },
    "minecraft:string":            { category: "junk",     xp: 1 },
    "minecraft:potion":            { category: "junk",     xp: 1 },   // Water Bottle
    "minecraft:bone":              { category: "junk",     xp: 1 },
    "minecraft:ink_sac":           { category: "junk",     xp: 1 },
    "minecraft:tripwire_hook":     { category: "junk",     xp: 1 },
    "minecraft:waterlily":         { category: "junk",     xp: 1 },
    "minecraft:lily_pad":          { category: "junk",     xp: 1 },
    "minecraft:bamboo":            { category: "junk",     xp: 1 },   // Jungle biomes
    "minecraft:cocoa_beans":       { category: "junk",     xp: 1 },   // Jungle biomes

    // Junk pool version is 1 Xp; the enchanted version comes from the treasure pool
    "minecraft:fishing_rod":       { category: "junk",     xp: 1,  enchantedXp: 12 },

    // Treasure
    "minecraft:bow":               { category: "junk",     xp: 1,  enchantedXp: 12 },
    "minecraft:enchanted_book":    { category: "treasure", xp: 15 },
    "minecraft:name_tag":          { category: "treasure", xp: 15 },
    "minecraft:saddle":            { category: "treasure", xp: 15 },
    "minecraft:nautilus_shell":    { category: "treasure", xp: 20 },
};
