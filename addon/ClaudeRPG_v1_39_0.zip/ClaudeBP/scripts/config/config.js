export const CONFIG = {
    WELCOME_MESSAGE: "§a[Status System] Addon loaded successfully!",

    BASE_MAX_XP: 50,
    XP_PER_LEVEL_INCREASE: 25,
    // Soft curve: above XP_SOFT_LEVEL each extra level adds only XP_SOFT_FACTOR of the normal
    // increase (keeps late-Prestige levels from exploding). Set factor to 1 for the old line.
    XP_SOFT_LEVEL: 100,
    XP_SOFT_FACTOR: 0.6,
    POINTS_PER_LEVEL: 4,

    STATS_BOOK_ITEM: "crpg:stats_book",
    KNOWLEDGE_BOOK_ITEM: "crpg:knowledge_book",
    SCRIPT_TOOL_ITEM: "crpg:script_tool",

    // Psi requirement increase per enchantment on an item
    PSI_PER_ENCHANT: 5,

    SCOREBOARDS: {
        level:  "Lv",
        exp:    "Exp",
        maxExp: "Max_exp",
        hp:     "rpg_hp",
        maxHp:  "rpg_max_hp"
    },

    // RPG HP Engine — base values before stat scaling
    HP_BASE:           20,     // HP at level 1 before any Augment/Con bonus
    HP_PER_CON:        2,      // flat HP added per point of Con stat
    HP_AUGMENT_MULT:   2,      // HP Augment: +1 stat = this many HP
    HP_DAMAGE_SCALE:   1.0,    // multiplier on all incoming RPG damage (1.0 = normal)

    // Bug fix / safety net: a single hit's computed damage is clamped to this
    // value before being sent to the /damage command. Some combination of
    // stacked bonuses (seen so far with Mace fall-smash + Strength) could
    // produce a non-integer, astronomically large number (e.g. 2.6e+30) that
    // JS renders in scientific notation — which the /damage command's parser
    // rejects outright, silently failing the whole hit (0 damage dealt). This
    // is far above anything legitimate gameplay should ever reach.
    MAX_SINGLE_HIT_DAMAGE: 100000,
    HP_REGEN_PER_SEC:  1,      // flat RPG HP regen per second (0 = off by default)
    HP_REGEN_PER_VIT:  0.5,    // additional HP regen per second, per point of Vit stat

    // Environmental damage scaling (fraction of vanilla damage translated to RPG HP)
    ENV_DAMAGE_FALL:   0.5,
    ENV_DAMAGE_FIRE:   0.3,
    ENV_DAMAGE_VOID:   999,

    // Lava deals a fixed HP/sec instead of scaling raw vanilla damage, so the
    // rate is exact and doesn't drift if vanilla's damage-per-tick changes.
    ENV_DAMAGE_LAVA_PER_SEC: 7,   // flat RPG HP damage per second while standing in lava
    ENV_LAVA_TICK_INTERVAL:  20,  // ticks between lava hits (20 ticks = once per second)

    // Mob melee/ranged damage (Ravager, zombies, etc.) translated to RPG HP —
    // see Bug fix note in damage_manager.js / main.js for why this exists.
    ENV_DAMAGE_MOB_MELEE: 1.0,

    // Bug fix — continuous contact damage (fire/lava/drowning/freeze/suffocation)
    // fires an entityHurt event almost every game tick once the vanilla event is
    // cancelled (see CombatPipeline), because vanilla only sets its own hit-immunity
    // timer as a side effect of damage actually landing on the health component.
    // This throttles those causes to once per this many ticks (20 ticks = 1s),
    // matching vanilla's normal ~0.5s damage-tick rate so players aren't hit 15-20x
    // per second and killed almost instantly (e.g. jumping into lava).
    ENV_DAMAGE_TICK_INTERVAL: 10,
};
