// special_config.js -- Special monsters (Ascension system).
//   1. Awakened special mobs: unique abilities for Creeper, Enderman, Witch, Blaze, Pillager,
//      Vindicator, Piglin Brute, Evoker, Guardian, Breeze. They are Awakened-tier mobs
//      (Ascension 7+), so these abilities come on top of the Awakened mutation.
//   2. Bosses: Wither, Warden, Ender Dragon, Elder Guardian use HP phases. Each phase
//      has its own Ascension unlock, so a boss gets deadlier as the world ascends.
//   3. Tier names: evolved mobs are renamed "<Tier> <Mob>" (e.g. "Tough Zombie").
//   4. Cleanup: evolved mobs and boss minions far from every player are removed (a named
//      mob never despawns by itself).
// Every number is editable (also from the Admin Config Editor, group "Special Mobs & Bosses").
// Cooldowns are in milliseconds, distances in blocks, damage in vanilla-style points (it still
// goes through Ascension damage scaling, armor/Gem reduction and the max-hit cap).

export const SPECIAL = {
    // Awakened special mobs are checked by the Mob Evolution scan (every 10 ticks, 48 blocks).
    // Bosses have their own, slower scan.
    BOSS_SCAN_INTERVAL_TICKS: 20,
    BOSS_SCAN_RADIUS: 64,          // players this close to a boss feel its abilities
    BOSS_MESSAGE_RADIUS: 64,

    // Minions (summoned by bosses) alive within MINION_RADIUS of a boss, max. Stops runaway spawns.
    MINION_CAP: 10,
    MINION_RADIUS: 64,

    // Evolved mobs / boss minions farther than DISTANCE from every player are removed.
    CLEANUP: { ENABLED: true, INTERVAL_TICKS: 100, DISTANCE: 80 },

    // Evolved-mob names. Format: "<bold><tier color><Tier>§r§f <Mob>" or, with an Awakened
    // mutation, "<Tier> <Mutation> <Mob>".
    NAMING: { ENABLED: true },

    // Rage (Vindicator / Piglin Brute): below HP fraction -> faster + extra damage.
    RAGE: {
        types: ["minecraft:vindicator", "minecraft:piglin_brute"],
        below: 0.4, speedAmp: 1, damageBonus: 0.5,
    },
};

// ─── Awakened special mobs ───────────────────────────────────────────────────
export const SPECIAL_ABILITIES = {
    creeper: {
        types: ["minecraft:creeper"],
        // Pounce: a lunge toward the player.
        pounce: { cooldownMs: 8000, minDist: 4, maxDist: 12, push: 0.8, lift: 0.3 },
        // Death blast: when a PLAYER kills it, a small blast follows after a short fuse.
        // Never breaks blocks or starts fires.
        deathBlast: { radius: 2, delayTicks: 20 },
    },
    enderman: {
        types: ["minecraft:enderman"],
        // Blink: when a player looks at it from far enough, it teleports right behind them.
        blink: { cooldownMs: 10000, minDist: 7, maxDist: 24, behind: 2.0, lookDot: 0.9 },
    },
    witch: {
        types: ["minecraft:witch"],
        // Hex: Slowness + Weakness on the nearest player.
        hex: { cooldownMs: 12000, maxDist: 12, slowTicks: 100, slowAmp: 0, weakTicks: 100, weakAmp: 0 },
        // Self-heal once, below this HP fraction.
        heal: { below: 0.4, fraction: 0.35 },
    },
    blaze: {
        types: ["minecraft:blaze"],
        // Fire volley: 3 fireballs fanned toward the player.
        volley: { cooldownMs: 8000, minDist: 5, maxDist: 24, count: 3, spread: 0.12, speed: 1.2, fallbackDamage: 3, fallbackBurnSeconds: 3 },
    },
    pillager: {
        types: ["minecraft:pillager"],
        // Two extra arrows around the aim line.
        volley: { cooldownMs: 7000, minDist: 6, maxDist: 26, spread: 0.15, speed: 2.4 },
    },
    rage: {
        types: ["minecraft:vindicator", "minecraft:piglin_brute"],   // values live in SPECIAL.RAGE
    },
    evoker: {
        types: ["minecraft:evoker"],
        // Fang line: evocation fangs erupt in a line toward the player.
        fangs: { cooldownMs: 10000, minDist: 3, maxDist: 16, count: 6, spacing: 1.6, stepTicks: 3 },
    },
    guardian: {
        types: ["minecraft:guardian"],
        // Tidal pull: drags the player toward it.
        pull: { cooldownMs: 10000, minDist: 5, maxDist: 16, push: 0.9, lift: 0.2, damage: 2 },
    },
    breeze: {
        types: ["minecraft:breeze"],
        // Gust: blasts a close player away.
        gust: { cooldownMs: 8000, maxDist: 8, push: 1.2, lift: 0.5, damage: 2 },
    },
};

// Types an Awakened roll may pick up in addition to the zombie / skeleton / spider families.
export const SPECIAL_AWAKEN_TYPES = Object.values(SPECIAL_ABILITIES).flatMap((g) => g.types)
    .filter((id, i, a) => a.indexOf(id) === i);

// ─── Bosses ──────────────────────────────────────────────────────────────────
// A phase is active while boss HP fraction <= below AND world Ascension >= unlockAsc.
//   aura    : every intervalMs, effects on players within radius
//   tremor  : every intervalMs, players within radius are pushed away, hurt and blinded (Darkness)
//   summon  : once per boss, spawns minions (mode "boss" = around the boss, "players" = around players;
//             water:true = only in water)
//   enrage  : boss moves faster and hits harder while the phase is active
//   message : sent once to nearby players when the phase begins
export const SPECIAL_BOSSES = {
    "minecraft:wither": {
        name: "Wither",
        phases: [
            { id: "aura1", below: 0.75, unlockAsc: 2,
              message: "§5[Wither] §7The air itself begins to rot...",
              aura: { radius: 10, intervalMs: 3000, effects: [{ id: "wither", amp: 0, ticks: 60 }] } },
            { id: "guard", below: 0.5, unlockAsc: 4,
              message: "§5[Wither] §7Skeletal guards rise around it!",
              summon: { type: "minecraft:wither_skeleton", count: 2, radius: 4, mode: "boss" } },
            { id: "aura2", below: 0.25, unlockAsc: 6,
              message: "§4[Wither] §7The rot spreads wide!",
              aura: { radius: 18, intervalMs: 3000, effects: [{ id: "wither", amp: 1, ticks: 80 }] } },
        ],
    },
    "minecraft:warden": {
        name: "Warden",
        phases: [
            { id: "tremor", below: 0.7, unlockAsc: 2,
              message: "§3[Warden] §7The ground trembles beneath it...",
              tremor: { radius: 7, intervalMs: 10000, push: 1.0, lift: 0.4, damage: 6, darknessTicks: 100 } },
            { id: "enrage", below: 0.4, unlockAsc: 4,
              message: "§4[Warden] §7It is enraged!",
              enrage: { speedAmp: 1, damageBonus: 0.3 } },
        ],
    },
    "minecraft:ender_dragon": {
        name: "Ender Dragon",
        phases: [
            { id: "roar", below: 0.75, unlockAsc: 2,
              message: "§5[Ender Dragon] §7Its roar blinds the sky.",
              aura: { radius: 40, intervalMs: 20000, effects: [{ id: "blindness", amp: 0, ticks: 40 }] } },
            { id: "guard1", below: 0.5, unlockAsc: 4,
              message: "§5[Ender Dragon] §7Endermen answer its call!",
              summon: { type: "minecraft:enderman", count: 3, radius: 6, mode: "players" } },
            { id: "guard2", below: 0.25, unlockAsc: 6,
              message: "§4[Ender Dragon] §7More endermen arrive. The air grows heavy.",
              summon: { type: "minecraft:enderman", count: 3, radius: 6, mode: "players" },
              aura: { radius: 64, intervalMs: 6000, effects: [{ id: "slowness", amp: 0, ticks: 100 }] } },
        ],
    },
    "minecraft:elder_guardian": {
        name: "Elder Guardian",
        phases: [
            { id: "curse", below: 1, unlockAsc: 2,
              aura: { radius: 20, intervalMs: 8000, effects: [{ id: "slowness", amp: 0, ticks: 80 }, { id: "weakness", amp: 0, ticks: 80 }] } },
            { id: "guard", below: 0.5, unlockAsc: 4,
              message: "§3[Elder Guardian] §7Guardians gather to defend it!",
              summon: { type: "minecraft:guardian", count: 2, radius: 5, mode: "boss", water: true } },
        ],
    },
};

// ─── Helpers (pure) ──────────────────────────────────────────────────────────
const NAME_OVERRIDES = {};

export function mobDisplayName(typeId) {
    const id = String(typeId ?? "").replace(/^[a-z0-9_.-]+:/, "");
    if (NAME_OVERRIDES[id]) return NAME_OVERRIDES[id];
    return id.split("_").filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join(" ");
}

// tier: EVOLUTION tier config ({ name, color }); mutationName optional (Awakened).
export function evolvedName(tier, typeId, mutationName) {
    const mob = mobDisplayName(typeId);
    const mid = mutationName ? `${mutationName} ` : "";
    return `§l${tier.color}${tier.name}§r§f ${mid}${mob}`;
}
