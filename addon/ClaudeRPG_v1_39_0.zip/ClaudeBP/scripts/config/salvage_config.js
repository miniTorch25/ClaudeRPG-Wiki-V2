// Salvage / Vanilla Enchant shared config.
// Everything here is plain data so it can be tuned later without touching logic.

export const AUGMENT_CRYSTAL_ID = "crpg:augment_crystal";
export const ENCHANT_ESSENCE_ID = "crpg:enchant_essence";

// Salvage rules
export const SALVAGE_HAMMER_DURABILITY = 12;   // per salvage
export const SALVAGE_MATERIAL_RATIO    = 0.5;  // materials returned (rounded down, min 1 per material)
export const SALVAGE_FULL_REFUND_CHANCE = 0.33; // chance to get the materials back in full
export const SALVAGE_DUST_MIN = 1;             // Gem Dust per installed Gem: same 1-10 roll as crushing an Uncarved Gem
export const SALVAGE_DUST_MAX = 10;
export const AUGMENT_CORE_ID = "crpg:augment_core";
export const MAX_AUGMENT_CRYSTALS = 3;         // Crystals gained when salvaging an item with a maxed Augment stat
// Augment Core uses: Max Augment, Perfect Salvage, Gem Fusion (2 Gems).
export const MAX_AUGMENT_CORES = 1;            // Augment Cores needed for "Max Aug."
export const PERFECT_SALVAGE_CORES = 1;        // Augment Cores for a Perfect Salvage (100% materials back)
export const CORE_FUSION_GEMS = 2;             // Gems fused with one Augment Core into 1 Gem one tier higher
export const CORE_FUSION_CORES = 1;
// Augment Crystals are now the Reroll / Lock fee (on top of Hammer durability). Unlock stays crystal-free.
export const AUGMENT_CRYSTAL_COST = { reroll: 1, lock: 2 };
export const AUGMENT_CRYSTALS_PER_STAT = 1;    // Crystals gained per rolled (non-max) Augment

// Enchant Essence value: rarity base + enchant level  (Sharpness V = 0 + 5 = 5)
export const ESSENCE_RARITY_BASE = { common: 0, uncommon: 1, rare: 2, very_rare: 3 };

export const ENCHANT_RARITY = {
    // common
    protection: "common", sharpness: "common", efficiency: "common", power: "common", piercing: "common",
    // uncommon
    fire_protection: "uncommon", feather_falling: "uncommon", projectile_protection: "uncommon",
    smite: "uncommon", bane_of_arthropods: "uncommon", knockback: "uncommon", unbreaking: "uncommon",
    punch: "uncommon", quick_charge: "uncommon", impaling: "uncommon", density: "uncommon", lunge: "uncommon",
    // rare
    blast_protection: "rare", respiration: "rare", aqua_affinity: "rare", depth_strider: "rare",
    fire_aspect: "rare", fortune: "rare", looting: "rare", flame: "rare", riptide: "rare", loyalty: "rare",
    luck_of_the_sea: "rare", lure: "rare", multishot: "rare", breach: "rare", wind_burst: "rare",
    frost_walker: "rare",
    // very rare
    mending: "very_rare", silk_touch: "very_rare", infinity: "very_rare", channeling: "very_rare",
    thorns: "very_rare", soul_speed: "very_rare", swift_sneak: "very_rare",
    binding: "very_rare", vanishing: "very_rare",
};

export function normalizeEnchantId(id) {
    return String(id ?? "").replace("minecraft:", "");
}

export function essenceBase(enchantId) {
    const rarity = ENCHANT_RARITY[normalizeEnchantId(enchantId)] ?? "uncommon";
    return ESSENCE_RARITY_BASE[rarity] ?? 1;
}

// Essence gained when salvaging one enchant.
export function essenceFromEnchant(enchantId, level) {
    return essenceBase(enchantId) + Math.max(0, level);
}

// Vanilla Enchant (Ultench): pay (rarity base + level) x multiplier Essence.
// Multiplier 1 = exactly what Salvage yields for that enchant, so moving an enchant
// from an old item to a new one costs nothing extra. (Vanilla enchanting table: 30 levels + Lapis, random.)
// Levels are capped at the vanilla max.
export const VANILLA_ENCHANT_COST_MULT = 1;

export function essenceCostForLevel(enchantId, level) {
    return Math.max(1, Math.round((essenceBase(enchantId) + level) * VANILLA_ENCHANT_COST_MULT));
}

// Salvage material table: item -> [[materialId, count], ...]
// Counts are the crafting-recipe amounts; Salvage returns half (or full on a lucky roll).
const T = (id, n) => [[id, n]];
const STICK = "minecraft:stick";

function armorSet(prefix, mat) {
    return {
        [`minecraft:${prefix}_helmet`]:     T(mat, 5),
        [`minecraft:${prefix}_chestplate`]: T(mat, 8),
        [`minecraft:${prefix}_leggings`]:   T(mat, 7),
        [`minecraft:${prefix}_boots`]:      T(mat, 4),
    };
}

function toolSet(prefix, mat, netherite = false) {
    const extra = netherite ? [["minecraft:netherite_ingot", 1]] : [];
    const m = netherite ? "minecraft:diamond" : mat;
    return {
        [`minecraft:${prefix}_sword`]:  [[m, 2], [STICK, 1], ...extra],
        [`minecraft:${prefix}_axe`]:    [[m, 3], [STICK, 2], ...extra],
        [`minecraft:${prefix}_pickaxe`]:[[m, 3], [STICK, 2], ...extra],
        [`minecraft:${prefix}_shovel`]: [[m, 1], [STICK, 2], ...extra],
        [`minecraft:${prefix}_hoe`]:    [[m, 2], [STICK, 2], ...extra],
        [`minecraft:${prefix}_spear`]:  [[m, 1], [STICK, 2], ...extra],
    };
}

export const SALVAGE_MATERIALS = {
    ...toolSet("wooden",  "minecraft:oak_planks"),
    ...toolSet("stone",   "minecraft:cobblestone"),
    ...toolSet("golden",  "minecraft:gold_ingot"),
    ...toolSet("copper",  "minecraft:copper_ingot"),
    ...toolSet("iron",    "minecraft:iron_ingot"),
    ...toolSet("diamond", "minecraft:diamond"),
    ...toolSet("netherite", null, true),

    ...armorSet("leather",   "minecraft:leather"),
    ...armorSet("golden",    "minecraft:gold_ingot"),
    ...armorSet("copper",    "minecraft:copper_ingot"),
    ...armorSet("iron",      "minecraft:iron_ingot"),
    ...armorSet("diamond",   "minecraft:diamond"),
    // Netherite armor = diamond armor + ingot (smithing)
    "minecraft:netherite_helmet":     [["minecraft:diamond", 5], ["minecraft:netherite_ingot", 1]],
    "minecraft:netherite_chestplate": [["minecraft:diamond", 8], ["minecraft:netherite_ingot", 1]],
    "minecraft:netherite_leggings":   [["minecraft:diamond", 7], ["minecraft:netherite_ingot", 1]],
    "minecraft:netherite_boots":      [["minecraft:diamond", 4], ["minecraft:netherite_ingot", 1]],
    // Chainmail is not craftable; refund iron
    "minecraft:chainmail_helmet":     T("minecraft:iron_ingot", 2),
    "minecraft:chainmail_chestplate": T("minecraft:iron_ingot", 4),
    "minecraft:chainmail_leggings":   T("minecraft:iron_ingot", 3),
    "minecraft:chainmail_boots":      T("minecraft:iron_ingot", 2),

    "minecraft:turtle_helmet": T("minecraft:turtle_scute", 5),
    "minecraft:shield":        [["minecraft:oak_planks", 6], ["minecraft:iron_ingot", 1]],
    "minecraft:elytra":        T("minecraft:phantom_membrane", 2),

    "minecraft:bow":      [["minecraft:string", 3], [STICK, 3]],
    "minecraft:crossbow": [[STICK, 3], ["minecraft:string", 2], ["minecraft:iron_ingot", 1], ["minecraft:tripwire_hook", 1]],
    "minecraft:trident":  T("minecraft:prismarine_shard", 4),
    "minecraft:mace":     T("minecraft:breeze_rod", 2),
};
