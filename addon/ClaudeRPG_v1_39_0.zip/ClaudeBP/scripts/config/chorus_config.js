// chorus_config.js — Chorus (armor element set-effect system) data.
//
// Chorus is a build-wide "elemental identity" system. Every armor piece (not the
// shield) has 2 element slots → 8 slots for a full set. Matching elements unlock
// set effects at 2 / 4 / 6 / 8 slots. Effects are cumulative (8 slots = 2+4+6+8).
//
// Rules
//   • 1 distinct element              → single set (count = slots using it)
//   • 2 distinct elements, same tier  → hybrid set  (count = min(a, b) × 2)
//   • 3+ distinct elements, or 2 from different tiers
//                                     → no hybrid; each element counts on its own
//   • A piece holds one tier only (Echo / Resonance / Transcend), locked by
//     the first element imprinted on it.
//
// Everything here is data — logic files never hardcode values.

// Safety caps — Chorus never adds more than this to a single hit, however many
// effects stack (final damage is also clamped to >= 1 by the damage pipeline).
export const CHORUS_CAPS = {
    damageReduction: 75,   // max total % damage taken reduction from Chorus
    damageBonus: 100,      // max total % damage dealt bonus from Chorus
    dodge: 25,             // max total % chance to dodge an attack from Chorus (all sets combined)
};

export const CHORUS_SLOTS_PER_ITEM = 2;
export const CHORUS_THRESHOLDS     = [2, 4, 6, 8];
export const CHORUS_MAX_SLOTS      = 8;

export const CHORUS_TIERS = {
    echo:      { label: "Echo",      color: "§a", order: 1 },
    resonance: { label: "Resonance", color: "§b", order: 2 },
    transcend: { label: "Transcend", color: "§d", order: 3 },
    // Fusion tiers: never rolled, no hybrids. Obtained only by Fusion (see CHORUS_FUSION).
    awaken:    { label: "Awaken",    color: "§6", order: 4, fusion: true },
    melodious: { label: "Melodious", color: "§c", order: 5, fusion: true },
    genesis:   { label: "Genesis",   color: "§f", order: 6, fusion: true },
};

// id → { tier, label, color }   (Thai names kept as comments for reference)
export const CHORUS_ELEMENTS = {
    // Echo
    fire:      { tier: "echo",      label: "Fire",      color: "§c" }, // ไฟ
    water:     { tier: "echo",      label: "Water",     color: "§9" }, // น้ำ
    wind:      { tier: "echo",      label: "Wind",      color: "§f" }, // ลม
    earth:     { tier: "echo",      label: "Earth",     color: "§6" }, // ดิน
    // Resonance
    lightning: { tier: "resonance", label: "Lightning", color: "§e" }, // อัศนี
    frost:     { tier: "resonance", label: "Frost",     color: "§b" }, // เหมันต์
    gale:      { tier: "resonance", label: "Gale",      color: "§a" }, // วายุ
    metal:     { tier: "resonance", label: "Metal",     color: "§7" }, // โลหะ
    light:     { tier: "resonance", label: "Light",     color: "§g" }, // แสง
    dark:      { tier: "resonance", label: "Dark",      color: "§8" }, // มืด
    // Transcend
    divine:    { tier: "transcend", label: "Divine",    color: "§6" }, // ศักดิ์สิทธิ์
    demon:     { tier: "transcend", label: "Demon",     color: "§4" }, // มาร
    life:      { tier: "transcend", label: "Life",      color: "§a" }, // ชีวิต
    death:     { tier: "transcend", label: "Death",     color: "§5" }, // ความตาย
    star:      { tier: "transcend", label: "Star",      color: "§3" }, // ดวงดาว
    void:      { tier: "transcend", label: "Void",      color: "§1" }, // ความว่างเปล่า
    dimension: { tier: "transcend", label: "Dimension", color: "§d" }, // มิติ
    time:      { tier: "transcend", label: "Time",      color: "§n" }, // เวลา
    // Awaken (4) — Fusion of two Transcend elements on ONE armor piece
    eclipse:   { tier: "awaken",    label: "Eclipse",   color: "§6" }, // สุริยคราส
    samsara:   { tier: "awaken",    label: "Samsara",   color: "§2" }, // สังสารวัฏ
    cosmos:    { tier: "awaken",    label: "Cosmos",    color: "§9" }, // จักรวาล
    eternity:  { tier: "awaken",    label: "Eternity",  color: "§e" }, // นิรันดร์
    // Melodious (2) — Fusion of two Awaken elements across TWO armor pieces
    destiny:   { tier: "melodious", label: "Destiny",   color: "§c" }, // โชคชะตา
    infinity:  { tier: "melodious", label: "Infinity",  color: "§b" }, // อนันต์
    // Genesis (1) — Fusion of Destiny + Infinity across TWO armor pieces
    genesis:   { tier: "genesis",   label: "Genesis",   color: "§f" }, // กำเนิด
};

// ─── Fusion (Awaken / Melodious / Genesis) ───────────────────────────────────
// result element → { from: [elementA, elementB], pieces }
//   pieces 1: ONE armor piece whose 2 sockets are exactly [A, B] → both sockets become the result.
//   pieces 2: TWO armor pieces, one holding A (both sockets) and one holding B (both sockets)
//             → BOTH pieces become the result.
export const CHORUS_FUSION = {
    eclipse:  { from: ["divine", "demon"],      pieces: 1 },
    samsara:  { from: ["life", "death"],        pieces: 1 },
    cosmos:   { from: ["star", "void"],         pieces: 1 },
    eternity: { from: ["time", "dimension"],    pieces: 1 },
    destiny:  { from: ["eclipse", "samsara"],   pieces: 2 },
    infinity: { from: ["cosmos", "eternity"],   pieces: 2 },
    genesis:  { from: ["destiny", "infinity"],  pieces: 2 },
};

// Cost + unlock per Fusion tier (single material: Stellar Core). All editable in the Admin Config Editor.
// One Fusion = one payment (even when it fuses two armor pieces).
//   Chorus Mastery level  → mastery_config.js (Chorus line unlocks: awaken 15 / melodious 20 / genesis 25)
//   Chorus XP per Fusion  → MASTERY.CHORUS_XP (awaken 2400 / melodious 4800 / genesis 9600)
//   prestige              → minimum Prestige, below.
export const CHORUS_FUSION_COST = {
    awaken:    { stellar: 3,  resonant: 0 },
    melodious: { stellar: 6,  resonant: 0 },
    genesis:   { stellar: 12, resonant: 0 },
};
export const CHORUS_FUSION_UNLOCK = {
    awaken:    { prestige: 3 },
    melodious: { prestige: 6 },
    genesis:   { prestige: 10 },
};
export function isFusionTier(tierId) { return CHORUS_TIERS[tierId]?.fusion === true; }

// Hybrid names — [elementA, elementB, name]. Order of A/B does not matter.
const HYBRID_LIST = [
    // Echo (6)
    ["fire", "water", "Steam"],
    ["fire", "wind", "Wildfire"],
    ["fire", "earth", "Magma"],
    ["water", "wind", "Monsoon"],
    ["water", "earth", "Bog"],
    ["wind", "earth", "Sandstorm"],
    // Resonance (15)
    ["lightning", "frost", "Stormfront"],
    ["lightning", "gale", "Thunderstorm"],
    ["lightning", "metal", "Magnet"],
    ["lightning", "light", "Plasma"],
    ["lightning", "dark", "Nightstorm"],
    ["frost", "gale", "Blizzard"],
    ["frost", "metal", "Coldsteel"],
    ["frost", "light", "Aurora"],
    ["frost", "dark", "Rime"],
    ["gale", "metal", "Razorwind"],
    ["gale", "light", "Zephyr"],
    ["gale", "dark", "Wraith"],
    ["metal", "light", "Lustre"],
    ["metal", "dark", "Obsidian"],
    ["light", "dark", "Twilight"],
    // Transcend (6 + 9)
    ["divine", "demon", "Judgement"],
    ["divine", "life", "Eden"],
    ["divine", "death", "Requiem"],
    ["demon", "life", "Corruption"],
    ["demon", "death", "Damnation"],
    ["life", "death", "Revenant"],
    // Transcend + Star / Void (9)
    ["star", "divine", "Celestial"],
    ["star", "demon", "Meteor"],
    ["star", "life", "Starbloom"],
    ["star", "death", "Supernova"],
    ["void", "divine", "Umbra"],
    ["void", "demon", "Abyss"],
    ["void", "life", "Stasis"],
    ["void", "death", "Oblivion"],
    ["star", "void", "Nebula"],
    // Transcend + Dimension / Time (13)
    ["dimension", "divine", "Sanctum"],
    ["dimension", "demon", "Rift"],
    ["dimension", "life", "Haven"],
    ["dimension", "death", "Limbo"],
    ["dimension", "star", "Wormhole"],
    ["dimension", "void", "Nullspace"],
    ["death", "time", "Entropy"],
    ["demon", "time", "Doomsday"],
    ["life", "time", "Renewal"],
    ["divine", "time", "Providence"],
    ["star", "time", "Orbit"],
    ["time", "void", "Standstill"],
    ["dimension", "time", "Continuum"],
];

export function hybridKey(a, b) {
    return [a, b].sort().join("+");
}

export const CHORUS_HYBRIDS = Object.fromEntries(
    HYBRID_LIST.map(([a, b, name]) => [hybridKey(a, b), { name, elements: [a, b].sort() }])
);

// Cost to imprint (or replace) one element, by tier. Single material: Resonant
// Ink only (paid in bulk). Editable.
// Rolling: the player picks a TIER; the sockets that are not locked get a random element of
// that tier (duplicates allowed). Costs below are for rolling BOTH sockets of a piece.
export const CHORUS_ROLL_COST = {
    echo:      { resonant: 6,  stellar: 0 },
    resonance: { resonant: 16, stellar: 0 },
    transcend: { resonant: 30, stellar: 1 },   // Transcend rolls also burn a Stellar Core
};
// Rolling only one socket (the other is locked) costs this fraction of the full roll, rounded up.
export const CHORUS_ROLL_SETTINGS = { SINGLE_FACTOR: 0.5 };
// Locking one socket (paid by the tier of the piece). Unlocking is free.
export const CHORUS_LOCK_COST = {
    echo:      { resonant: 3,  stellar: 0 },
    resonance: { resonant: 10, stellar: 0 },
    transcend: { resonant: 20, stellar: 0 },
};
export const CHORUS_REMOVE_COST = { resonant: 0, stellar: 0 };

// ─── Effect values (Phase 2) ─────────────────────────────────────────────────
// Numbers used by chorus_effects.js — all editable. Percent values are whole
// numbers (25 = 25%). Cooldowns are in seconds.
export const CHORUS_VALUES = {
    fire: {
        fireResist: 25,           // 2: % less fire/lava/burn damage
        igniteChance: 15,         // 4: % chance to ignite on hit
        igniteSeconds: 4,
        auraRadius: 4,            // 6: blocks
        auraDamage: 1,            //    flat damage per pulse (every 1s)
        auraIgniteSeconds: 2,
        blastRadius: 3.5,         // 8: explosion when an ignited enemy dies
        blastDamage: 4,
        igniteMemorySeconds: 8,   //    how long a kill still counts as "ignited"
    },
    water: {
        waterResist: 25,          // 2: % less drowning + magic (poison) damage
        slowChance: 30,           // 4: % chance to slow on hit
        slowSeconds: 3,
        slowAmplifier: 1,
        regenPercentPerSec: 0.5,  // 6: % of max HP per second
        tidalHpBelow: 35,         // 8: triggers when HP% drops to this or lower
        tidalRadius: 5,
        tidalPush: 1.6,
        tidalCooldown: 45,
    },
    wind: {
        speedAmplifier: 0,        // 2: Speed I
        dashPower: 1.3,           // 4: horizontal dash strength
        dashLift: 0.3,
        dashCooldown: 3,
        arrowBoost: 0.4,          // 6: +30% arrow launch speed
        burstRadius: 4.5,         // 8
        burstPush: 1.8,
        burstLift: 0.6,
        burstCooldown: 15,
        burstDamage: 3,
    },
    earth: {
        physicalResist: 10,       // 2: % less melee/projectile/fall/contact damage
        reflectPercent: 20,       // 4: % of melee damage reflected at the attacker
        shieldAmount: 10,         // 6: Stone Skin absorb pool
        shieldRechargeSeconds: 10,
        quakeRadius: 4.5,         // 8
        quakeSeconds: 2,
        quakeDamage: 4,
        quakeCooldown: 20,
    },

    // ── Echo hybrids (Phase 3) — keyed by hybrid name ──
    steam: {                      // Fire + Water
        resist: 20,               // 2: % less fire/lava/burn + drowning damage
        blindChance: 25, blindSeconds: 3,                    // 4
        auraRadius: 4, weaknessSeconds: 3,                   // 6: Weakness aura
        burstHpBelow: 30, burstRadius: 4.5, burstDamage: 12,  // 8: Steam Burst
        burstBlindSeconds: 4, burstCooldown: 45,
    },
    wildfire: {                   // Fire + Wind
        fireResist: 20, fallResist: 30,                      // 2
        spreadChance: 25, spreadRadius: 3, igniteSeconds: 4, // 4: fire spreads
        sprintRadius: 2.5, sprintIgniteSeconds: 2,           // 6: sprint ignites
        stormRadius: 4.5, stormDamage: 5, stormPush: 1.4,    // 8: Firestorm
        stormIgniteSeconds: 4, stormCooldown: 25,
    },
    magma: {                      // Earth + Fire
        fireResist: 35,                                      // 2
        reflectPercent: 15, reflectIgniteSeconds: 3,         // 4: molten skin
        shieldAmount: 12, shieldRechargeSeconds: 12,         // 6: Magma Armor
        shieldBreakRadius: 3.5, shieldBreakIgniteSeconds: 4,
        eruptRadius: 4.5, eruptDamage: 10, eruptIgniteSeconds: 4, // 8: Eruption
        eruptPush: 1.4, eruptLift: 0.5, eruptCooldown: 30,
    },
    monsoon: {                    // Water + Wind
        fallResist: 50, drownResist: 25,                     // 2
        projSlowChance: 35, slowSeconds: 3,                  // 4: projectiles slow
        regenPercentPerSec: 1,                               // 6: while sprinting/swimming
        typhoonRadius: 5, typhoonPush: 1.6,                  // 8: Typhoon
        typhoonSlowSeconds: 3, typhoonSlowAmplifier: 1, typhoonCooldown: 25,
    },
    bog: {                        // Water + Earth
        magicResist: 30, physicalResist: 5,                  // 2
        poisonChance: 25, poisonSeconds: 4,                  // 4
        auraRadius: 4, auraSlowSeconds: 3,                   // 6: mud aura
        quagRadius: 5, quagSlowSeconds: 4, quagSlowAmplifier: 3, // 8: Quagmire
        quagDamage: 4, quagHealPercent: 5, quagCooldown: 25,
    },
    sandstorm: {                  // Wind + Earth
        fallResist: 30, speedAmplifier: 0,                   // 2
        blindChance: 20, blindSeconds: 2,                    // 4
        dodgeChance: 12,                                     // 6: Dust Veil
        stormRadius: 5, stormBlindSeconds: 4, stormPush: 1.4, // 8: Sandstorm
        stormLift: 0.4, stormDamage: 3, stormCooldown: 25,
    },

    // ── Resonance singles (Phase 4a) ──
    lightning: {
        resist: 25,                                           // 2: lightning + explosion
        chainChance: 15, chainRadius: 4, chainDamage: 3,      // 4
        killSpeedSeconds: 4, killSpeedAmplifier: 1,           // 6
        boltChance: 12, boltRadius: 3, boltDamage: 9, boltCooldown: 9, // 8
    },
    frost: {
        freezeResist: 50,                                     // 2
        rootChance: 20, rootSeconds: 2, rootAmplifier: 3,     // 4
        armorSlowSeconds: 3, armorSlowAmplifier: 1,           // 6
        zeroRadius: 5, zeroSeconds: 3, zeroCooldown: 30, frozenBonus: 30, // 8
    },
    gale: {
        jumpAmplifier: 0, fallResist: 50,                     // 2
        airJumpPower: 0.75, airJumpCooldown: 3,               // 4
        airBonus: 15, airResist: 15,                          // 6
        cycloneRadius: 5, levitationSeconds: 2, slowFallSeconds: 5, cycloneCooldown: 25, // 8
    },
    metal: {
        resist: 20,                                           // 2: projectile + explosion
        spikeDamage: 3,                                       // 4
        fortifiedHpBelow: 50, fortifiedResist: 20,            // 6
        bulwarkResist: 50, bulwarkSeconds: 4, bulwarkCooldown: 30, // 8
    },
    light: {
        undeadBonus: 15,                                      // 2
        killHealPercent: 5,                                   // 4
        auraRadius: 6, auraHealPercent: 1,                    // 6
        novaRadius: 5, novaDamage: 5, novaUndeadDamage: 12,   // 8
        novaBlindSeconds: 3, novaHealPercent: 5, novaCooldown: 25,
    },
    dark: {
        nightBonus: 25,                                       // 2
        witherChance: 30, witherSeconds: 3,                   // 4
        veilRadius: 4, veilBlindSeconds: 2,                   // 6
        stepHpBelow: 30, stepSeconds: 6, stepHealPercent: 12, stepCooldown: 75, // 8
    },
};


// ─── Resonance hybrid kits (Phase 4b) ────────────────────────────────────────
// Data-driven effects for the 15 Resonance hybrids, interpreted by
// chorus_effects.js. A kit has a name plus specs for tiers 2 / 4 / 6 / 8
// (cumulative). A spec may combine any of these keys:
//
//   resist:      [[causeGroups[], pct], ...]   damage taken -pct for those causes
//                groups: fire lightning explosion freeze fall physical magic
//                        projectile drowning
//   lowHpResist: { hpBelow, pct }              damage taken -pct while HP% < hpBelow
//   dodge:       { chance }                    % to negate melee/projectile hits
//   selfEffects: [[effectId, amplifier], ...]  permanent buffs (refreshed)
//   dealBonus:   { pct, cond?, hpBelow? }      damage dealt +pct
//                (cond: night | undead | lowTarget = target HP% below hpBelow)
//   lifesteal:   { pct }                       heal pct% of damage you deal
//   souls:       { max, bonus, seconds }       each kill = 1 soul; +bonus% damage per soul
//   regen:       pct                           % max HP per second
//   regenWhile:  { pct }                       same, only while sprinting/swimming/airborne
//   onHit:       { chance, effects[[id,sec,amp]], igniteSec?, chainDamage?, healPct? }
//   thorns:      { damage, effects[[id,sec,amp]] }   melee attackers
//   killBuff:    { effects[[id,sec,amp]], healPct? }
//   aura:        { radius, effects[[id,sec,amp]]?, damage?, igniteSec?, pull?, healPct?, cleanse? }  every 1s
//   shield:      { amount, recharge, breakRadius, breakEffects[[id,sec,amp]] }
//   burst:       { trigger: "hit" | "lowHp", hpBelow?, radius, damage?, push?, lift?, pull?,
//                  effects[[id,sec,amp]]?, igniteSec?, selfBuffs[[id,sec,amp]]?,
//                  selfWindow{pct,seconds}?, dealWindow{pct,seconds}?, healPct?, healNearbyPct?, cleanse?,
//                  cooldown, msg, sound?,
//                  execute?: { hpBelow }   non-boss / non-Core / non-Enchanted mobs below hpBelow% HP in the blast die,
//                  hold?: seconds }        blasted mobs are pinned in place for that long
//   Awaken+ extras:
//   onHit.chainCount: n                     chain damage hits n nearby mobs (default 1)
//   onHit.mark: { pct, seconds }            Mark: the target takes +pct% damage from YOU for `seconds`
//   blink:       { distance, cooldown }     Sprint + Jump teleport
//   revive:      { hpPct, invulnSeconds, cooldown }   a FATAL hit leaves you at hpPct% HP + short invulnerability.
//                                           One shared cooldown per player (pieces never stack Revives).
const kit = (a, b, name, tiers) => [hybridKey(a, b), { name, ...tiers }];
const single = (id, name, tiers) => [id, { name, ...tiers }];

export const CHORUS_KITS = Object.fromEntries([
    kit("lightning", "frost", "Stormfront", {
        2: { resist: [[["lightning", "explosion", "freeze"], 20]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 2]], chainDamage: 3 } },
        6: { aura: { radius: 4, effects: [["slowness", 2, 0]], damage: 1 } },
        8: { burst: { trigger: "hit", radius: 5, damage: 8, effects: [["slowness", 3, 4]], cooldown: 30,
                      msg: "Cold front and thunder crash down!", sound: "ambient.weather.lightning.impact" } },
    }),
    kit("lightning", "gale", "Thunderstorm", {
        2: { resist: [[["lightning", "fall"], 25]], selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, chainDamage: 5 } },
        6: { killBuff: { effects: [["speed", 4, 1], ["jump_boost", 4, 1]] } },
        8: { burst: { trigger: "hit", radius: 5, damage: 10, push: 1.6, lift: 0.5, cooldown: 25,
                      msg: "A tempest tears through your enemies!", sound: "ambient.weather.lightning.impact" } },
    }),
    kit("lightning", "metal", "Magnet", {
        2: { resist: [[["lightning", "explosion", "projectile"], 20]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 0]], chainDamage: 4 } },
        6: { aura: { radius: 5, pull: 0.35, damage: 1 } },
        8: { burst: { trigger: "hit", radius: 5, damage: 9, pull: 1.5, effects: [["slowness", 2, 10]], cooldown: 25,
                      msg: "Polarity snaps enemies to you!", sound: "random.anvil_land" } },
    }),
    kit("lightning", "light", "Plasma", {
        2: { dealBonus: { pct: 10 } },
        4: { onHit: { chance: 20, effects: [["blindness", 2, 0]], igniteSec: 3 } },
        6: { killBuff: { healPct: 4, effects: [["speed", 3, 0]] } },
        8: { burst: { trigger: "hit", radius: 5, damage: 12, effects: [["blindness", 3, 0]], igniteSec: 3, cooldown: 30,
                      msg: "Plasma erupts!", sound: "random.explode" } },
    }),
    kit("lightning", "dark", "Nightstorm", {
        2: { dealBonus: { pct: 18, cond: "night" } },
        4: { onHit: { chance: 20, effects: [["wither", 3, 0]], chainDamage: 4 } },
        6: { aura: { radius: 4, effects: [["blindness", 2, 0], ["weakness", 2, 0]] } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 5, damage: 8, effects: [["blindness", 4, 0]],
                      selfBuffs: [["invisibility", 6, 0], ["speed", 6, 1]], healPct: 10, cooldown: 90,
                      msg: "You vanish in a flash of dark lightning...", sound: "mob.endermen.portal" } },
    }),
    kit("frost", "gale", "Blizzard", {
        2: { resist: [[["freeze"], 40], [["fall"], 30]] },
        4: { onHit: { chance: 25, effects: [["slowness", 3, 2]] } },
        6: { aura: { radius: 5, effects: [["slowness", 2, 0], ["blindness", 2, 0]] } },
        8: { burst: { trigger: "hit", radius: 6, damage: 5, push: 1.4, lift: 0.4, effects: [["slowness", 4, 4]], cooldown: 30,
                      msg: "A blizzard howls around you!", sound: "random.glass" } },
    }),
    kit("frost", "metal", "Coldsteel", {
        2: { resist: [[["freeze"], 30], [["physical"], 8]] },
        4: { thorns: { damage: 4, effects: [["slowness", 3, 1]] } },
        6: { lowHpResist: { hpBelow: 50, pct: 25 } },
        8: { burst: { trigger: "hit", radius: 4, effects: [["slowness", 2, 3]], selfWindow: { pct: 45, seconds: 4 }, cooldown: 30,
                      msg: "Ice plating hardens your armor!", sound: "random.anvil_land" } },
    }),
    kit("frost", "light", "Aurora", {
        2: { regen: 0.4 },
        4: { onHit: { chance: 20, effects: [["blindness", 2, 0], ["slowness", 2, 1]] } },
        6: { aura: { radius: 6, healPct: 1 } },
        8: { burst: { trigger: "hit", radius: 5, damage: 6, effects: [["slowness", 3, 3], ["blindness", 3, 0]],
                      healNearbyPct: 6, cleanse: true, cooldown: 30,
                      msg: "Aurora light heals allies and dazzles enemies!", sound: "random.levelup" } },
    }),
    kit("frost", "dark", "Rime", {
        2: { resist: [[["freeze", "magic"], 30]] },
        4: { onHit: { chance: 20, effects: [["wither", 3, 0], ["slowness", 2, 1]] } },
        6: { aura: { radius: 4, effects: [["weakness", 2, 0], ["slowness", 2, 0]], damage: 1 } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 5, damage: 7, effects: [["slowness", 3, 10]],
                      selfWindow: { pct: 30, seconds: 4 }, healPct: 8, cooldown: 75,
                      msg: "Dread frost seizes your enemies!", sound: "random.glass" } },
    }),
    kit("gale", "metal", "Razorwind", {
        2: { resist: [[["fall"], 30]], selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, chainDamage: 5 } },
        6: { dodge: { chance: 10 } },
        8: { burst: { trigger: "hit", radius: 5, damage: 9, push: 1.4, lift: 0.3, cooldown: 25,
                      msg: "Razor winds slice through enemies!", sound: "mace.smash_air" } },
    }),
    kit("gale", "light", "Zephyr", {
        2: { resist: [[["fall"], 40]], selfEffects: [["speed", 0], ["jump_boost", 0]] },
        4: { onHit: { chance: 25, healPct: 3 } },
        6: { regenWhile: { pct: 1.2 } },
        8: { burst: { trigger: "hit", radius: 5, push: 1.2, lift: 0.6, effects: [["blindness", 2, 0]],
                      selfBuffs: [["slow_falling", 5, 0], ["speed", 4, 1]], healNearbyPct: 5, cooldown: 30,
                      msg: "A gentle gale lifts and heals!", sound: "mace.smash_air" } },
    }),
    kit("gale", "dark", "Wraith", {
        2: { dodge: { chance: 10 }, resist: [[["fall"], 30]] },
        4: { onHit: { chance: 20, effects: [["wither", 3, 0], ["blindness", 2, 0]] } },
        6: { killBuff: { effects: [["invisibility", 3, 0], ["speed", 3, 1]] } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 5, push: 1.6, effects: [["levitation", 2, 0]],
                      selfBuffs: [["invisibility", 6, 0], ["speed", 6, 2]], healPct: 8, cooldown: 90,
                      msg: "You dissolve into the wind...", sound: "mob.endermen.portal" } },
    }),
    kit("metal", "light", "Lustre", {
        2: { resist: [[["projectile", "explosion"], 15]], dealBonus: { pct: 10, cond: "undead" } },
        4: { thorns: { damage: 3, effects: [["blindness", 2, 0]] } },
        6: { shield: { amount: 12, recharge: 12, breakRadius: 4, breakEffects: [["blindness", 3, 0]] } },
        8: { burst: { trigger: "hit", radius: 5, damage: 8, effects: [["blindness", 3, 0]],
                      selfWindow: { pct: 30, seconds: 4 }, healNearbyPct: 5, cooldown: 30,
                      msg: "Blinding radiance!", sound: "random.levelup" } },
    }),
    kit("metal", "dark", "Obsidian", {
        2: { resist: [[["explosion", "fire"], 25]] },
        4: { thorns: { damage: 4, effects: [["wither", 2, 0]] } },
        6: { lowHpResist: { hpBelow: 50, pct: 25 } },
        8: { burst: { trigger: "hit", radius: 4, damage: 8, effects: [["slowness", 3, 3]],
                      selfWindow: { pct: 50, seconds: 4 }, cooldown: 35,
                      msg: "Obsidian ward shatters outward!", sound: "random.anvil_land" } },
    }),
    kit("light", "dark", "Twilight", {
        2: { dealBonus: { pct: 10 } },
        4: { onHit: { chance: 20, effects: [["blindness", 2, 0], ["wither", 2, 0]] } },
        6: { aura: { radius: 5, effects: [["blindness", 2, 0]], healPct: 1 } },
        8: { burst: { trigger: "hit", radius: 5, damage: 10, effects: [["blindness", 3, 0], ["wither", 3, 0]],
                      healNearbyPct: 6, cooldown: 30, msg: "Twilight falls!", sound: "random.levelup" } },
    }),

    // ── Transcend singles (Phase 5) ──
    single("divine", "Divine", {
        2: { resist: [[["magic", "fire", "lightning", "explosion"], 20]], regen: 0.3 },
        4: { onHit: { chance: 20, effects: [["blindness", 3, 0]], healPct: 3 }, dealBonus: { pct: 25, cond: "undead" } },
        6: { aura: { radius: 6, damage: 2, effects: [["weakness", 2, 0]], healPct: 1.5 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 15, effects: [["blindness", 4, 0], ["weakness", 4, 0]],
                      selfWindow: { pct: 40, seconds: 5 }, healNearbyPct: 10, cleanse: true, cooldown: 40,
                      msg: "Divine wrath descends!", sound: "random.levelup" } },
    }),
    single("demon", "Demon", {
        2: { dealBonus: { pct: 12 }, resist: [[["fire"], 30]] },
        4: { onHit: { chance: 20, effects: [["wither", 3, 0]], igniteSec: 4 }, lifesteal: { pct: 8 } },
        6: { aura: { radius: 4, damage: 2, igniteSec: 2, effects: [["weakness", 2, 0]] } },
        8: { burst: { trigger: "hit", radius: 5, damage: 14, igniteSec: 5, effects: [["wither", 4, 0]],
                      dealWindow: { pct: 25, seconds: 6 }, healPct: 5, cooldown: 40,
                      msg: "Demonic pact sealed!", sound: "mob.ghast.fireball" } },
    }),
    single("life", "Life", {
        2: { regen: 0.8, resist: [[["drowning", "fall", "magic"], 20]] },
        4: { onHit: { chance: 25, healPct: 4 }, killBuff: { healPct: 5 } },
        6: { aura: { radius: 7, healPct: 2, cleanse: true } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 7, healPct: 40, healNearbyPct: 20, cleanse: true,
                      selfWindow: { pct: 40, seconds: 5 }, cooldown: 120,
                      msg: "Life blooms anew!", sound: "random.levelup" } },
    }),
    single("death", "Death", {
        2: { resist: [[["magic", "wither"], 40]], dealBonus: { pct: 10, cond: "lowTarget", hpBelow: 50 } },
        4: { souls: { max: 10, bonus: 2, seconds: 20 }, onHit: { chance: 20, effects: [["wither", 4, 0]] } },
        6: { dealBonus: { pct: 30, cond: "lowTarget", hpBelow: 25 }, killBuff: { healPct: 6, effects: [["speed", 4, 1]] } },
        8: { burst: { trigger: "hit", radius: 6, damage: 12, effects: [["wither", 5, 0], ["slowness", 3, 1]],
                      selfBuffs: [["speed", 5, 1]], dealWindow: { pct: 25, seconds: 6 }, healPct: 6, cooldown: 45,
                      msg: "The Reaper's mark falls!", sound: "mob.wither.spawn" } },
    }),

    // ── Transcend hybrids (Phase 5) ──
    kit("divine", "demon", "Judgement", {
        2: { dealBonus: { pct: 15 }, resist: [[["fire", "magic", "lightning"], 20]] },
        4: { onHit: { chance: 20, effects: [["blindness", 3, 0]], igniteSec: 3, chainDamage: 5 } },
        6: { aura: { radius: 5, damage: 3, igniteSec: 2, effects: [["weakness", 2, 0]], healPct: 1 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, igniteSec: 5, effects: [["blindness", 4, 0], ["weakness", 4, 0]],
                      selfWindow: { pct: 30, seconds: 5 }, healNearbyPct: 8, cooldown: 40,
                      msg: "Judgement is passed!", sound: "random.explode" } },
    }),
    kit("divine", "life", "Eden", {
        2: { regen: 0.8, resist: [[["magic", "drowning", "fall"], 20]] },
        4: { onHit: { chance: 25, healPct: 5 } },
        6: { aura: { radius: 7, healPct: 2, cleanse: true } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 7, healPct: 35, healNearbyPct: 20, cleanse: true,
                      effects: [["weakness", 4, 1]], selfWindow: { pct: 50, seconds: 6 }, cooldown: 120,
                      msg: "Paradise blooms around you!", sound: "random.levelup" } },
    }),
    kit("divine", "death", "Requiem", {
        2: { resist: [[["magic", "wither"], 40]], dealBonus: { pct: 25, cond: "undead" } },
        4: { onHit: { chance: 20, effects: [["wither", 4, 0], ["blindness", 2, 0]] }, lifesteal: { pct: 8 } },
        6: { killBuff: { healPct: 8, effects: [["speed", 4, 1]] } },
        8: { burst: { trigger: "hit", radius: 6, damage: 16, effects: [["wither", 5, 0], ["blindness", 3, 0]],
                      selfWindow: { pct: 35, seconds: 5 }, healPct: 10, cooldown: 45,
                      msg: "A requiem tolls for your enemies.", sound: "mob.wither.spawn" } },
    }),
    kit("demon", "life", "Corruption", {
        2: { regen: 0.5, dealBonus: { pct: 10 } },
        4: { onHit: { chance: 25, effects: [["poison", 5, 1]] }, lifesteal: { pct: 10 } },
        6: { aura: { radius: 5, damage: 2, effects: [["poison", 3, 0]], healPct: 1.5 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 14, effects: [["poison", 6, 1], ["weakness", 4, 0]],
                      healPct: 12, dealWindow: { pct: 20, seconds: 6 }, cooldown: 40,
                      msg: "Corruption spreads!", sound: "mob.ghast.fireball" } },
    }),
    kit("demon", "death", "Damnation", {
        2: { dealBonus: { pct: 12 }, resist: [[["fire", "wither"], 30]] },
        4: { onHit: { chance: 20, effects: [["wither", 4, 0]], igniteSec: 3 }, souls: { max: 10, bonus: 2, seconds: 20 } },
        6: { dealBonus: { pct: 30, cond: "lowTarget", hpBelow: 35 }, aura: { radius: 4, damage: 2, igniteSec: 2 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, igniteSec: 6, effects: [["wither", 6, 0]],
                      dealWindow: { pct: 25, seconds: 6 }, healPct: 8, cooldown: 45,
                      msg: "Damnation falls!", sound: "mob.wither.spawn" } },
    }),
    kit("life", "death", "Revenant", {
        2: { regen: 0.6, resist: [[["wither", "magic"], 30]] },
        4: { killBuff: { healPct: 6 }, souls: { max: 10, bonus: 2, seconds: 20 } },
        6: { aura: { radius: 6, damage: 2, healPct: 1.5 } },
        8: { burst: { trigger: "lowHp", hpBelow: 25, radius: 6, damage: 10, effects: [["wither", 4, 0]],
                      healPct: 50, cleanse: true, selfWindow: { pct: 60, seconds: 6 }, cooldown: 150,
                      msg: "The wheel turns...", sound: "mob.wither.spawn" } },
    }),

    // ── Transcend: Star & Void singles (Phase 7) ──
    single("star", "Star", {
        2: { resist: [[["fall", "explosion"], 25]], selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1]], chainDamage: 6 }, dealBonus: { pct: 6 } },
        6: { aura: { radius: 5, damage: 3, effects: [["slowness", 2, 0]] }, killBuff: { effects: [["speed", 4, 1]] } },
        8: { burst: { trigger: "hit", radius: 6, damage: 20, pull: 1.8, effects: [["slowness", 3, 3]],
                      selfBuffs: [["speed", 5, 1]], cooldown: 40,
                      msg: "Starfall!", sound: "random.explode" } },
    }),
    single("void", "Void", {
        2: { dodge: { chance: 8 }, resist: [[["void", "fall"], 40]] },
        4: { onHit: { chance: 20, effects: [["weakness", 4, 0]] }, lifesteal: { pct: 6 } },
        6: { dodge: { chance: 10 }, aura: { radius: 5, pull: 0.3, effects: [["weakness", 2, 0]] } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 6, damage: 10, pull: 1.6,
                      effects: [["weakness", 5, 1], ["slowness", 3, 3]], selfBuffs: [["invisibility", 5, 0]],
                      selfWindow: { pct: 50, seconds: 5 }, healPct: 15, cooldown: 90,
                      msg: "The void swallows the light...", sound: "mob.endermen.portal" } },
    }),

    // ── Transcend: Star & Void hybrids (Phase 7) ──
    kit("star", "divine", "Celestial", {
        2: { dealBonus: { pct: 12 }, resist: [[["magic", "explosion", "fall"], 20]] },
        4: { onHit: { chance: 20, effects: [["blindness", 2, 0]], chainDamage: 6, healPct: 3 } },
        6: { aura: { radius: 6, damage: 2, effects: [["weakness", 2, 0]], healPct: 1.5 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 16, effects: [["blindness", 3, 0], ["weakness", 3, 0]],
                      selfWindow: { pct: 30, seconds: 5 }, healNearbyPct: 8, cooldown: 40,
                      msg: "The heavens ring!", sound: "random.levelup" } },
    }),
    kit("star", "demon", "Meteor", {
        2: { dealBonus: { pct: 12 }, resist: [[["fire", "explosion"], 30]] },
        4: { onHit: { chance: 25, igniteSec: 4, chainDamage: 6 } },
        6: { aura: { radius: 5, damage: 3, igniteSec: 2 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 20, igniteSec: 6, push: 1.2, lift: 0.6,
                      dealWindow: { pct: 25, seconds: 6 }, cooldown: 45,
                      msg: "Meteor strike!", sound: "random.explode" } },
    }),
    kit("star", "life", "Starbloom", {
        2: { regen: 0.8, selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 25, healPct: 5 }, killBuff: { healPct: 5, effects: [["speed", 3, 1]] } },
        6: { aura: { radius: 7, healPct: 2.5, cleanse: true } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 7, healPct: 40, healNearbyPct: 20, cleanse: true,
                      selfBuffs: [["speed", 5, 1]], cooldown: 100,
                      msg: "A new star blooms!", sound: "random.levelup" } },
    }),
    kit("star", "death", "Supernova", {
        2: { resist: [[["wither", "magic"], 30]], dealBonus: { pct: 10, cond: "lowTarget", hpBelow: 50 } },
        4: { souls: { max: 10, bonus: 2, seconds: 20 }, onHit: { chance: 15, chainDamage: 5 } },
        6: { dealBonus: { pct: 30, cond: "lowTarget", hpBelow: 25 }, killBuff: { healPct: 6, effects: [["speed", 4, 1]] } },
        8: { burst: { trigger: "hit", radius: 7, damage: 20, push: 1.6, lift: 0.5, effects: [["wither", 4, 0]],
                      dealWindow: { pct: 25, seconds: 6 }, healPct: 6, cooldown: 50,
                      msg: "Supernova!", sound: "random.explode" } },
    }),
    kit("void", "divine", "Umbra", {
        2: { resist: [[["magic", "explosion", "wither"], 25]], dodge: { chance: 6 } },
        4: { onHit: { chance: 20, effects: [["blindness", 3, 0], ["weakness", 3, 0]] } },
        6: { aura: { radius: 5, effects: [["blindness", 2, 0], ["weakness", 2, 0]], healPct: 1.5 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 14, effects: [["blindness", 5, 0], ["weakness", 4, 0]],
                      selfWindow: { pct: 40, seconds: 5 }, healNearbyPct: 8, cleanse: true, cooldown: 40,
                      msg: "Umbra darkens the sky!", sound: "mob.endermen.portal" } },
    }),
    kit("void", "demon", "Abyss", {
        2: { dealBonus: { pct: 12 }, dodge: { chance: 6 } },
        4: { onHit: { chance: 25, effects: [["wither", 4, 0], ["weakness", 3, 0]] }, lifesteal: { pct: 8 } },
        6: { aura: { radius: 5, pull: 0.3, damage: 2 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, pull: 1.6, effects: [["wither", 5, 0], ["slowness", 3, 2]],
                      dealWindow: { pct: 25, seconds: 6 }, healPct: 6, cooldown: 45,
                      msg: "The abyss opens!", sound: "mob.wither.spawn" } },
    }),
    kit("void", "life", "Stasis", {
        2: { regen: 0.8, resist: [[["magic", "wither", "drowning"], 25]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 2]], healPct: 5 } },
        6: { aura: { radius: 6, effects: [["slowness", 2, 0]], healPct: 2 } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 6, effects: [["slowness", 4, 10]],
                      healPct: 30, cleanse: true, selfWindow: { pct: 60, seconds: 5 }, cooldown: 100,
                      msg: "Time stills around you.", sound: "random.glass" } },
    }),
    kit("void", "death", "Oblivion", {
        2: { resist: [[["wither", "magic"], 35]], dodge: { chance: 6 } },
        4: { onHit: { chance: 25, effects: [["wither", 4, 0], ["weakness", 3, 0]] } },
        6: { dealBonus: { pct: 25, cond: "lowTarget", hpBelow: 25 }, aura: { radius: 4, damage: 2, effects: [["weakness", 2, 0]] } },
        8: { burst: { trigger: "hit", radius: 6, damage: 16, pull: 1.2, effects: [["wither", 6, 0], ["blindness", 3, 0]],
                      selfWindow: { pct: 30, seconds: 5 }, dealWindow: { pct: 25, seconds: 6 }, healPct: 8, cooldown: 45,
                      msg: "Oblivion consumes all.", sound: "mob.wither.spawn" } },
    }),
    kit("star", "void", "Nebula", {
        2: { dodge: { chance: 6 }, resist: [[["void", "fall"], 40]], selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1], ["weakness", 3, 0]], chainDamage: 6 } },
        6: { dodge: { chance: 6 }, aura: { radius: 6, pull: 0.3, damage: 2 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 20, pull: 2.0, effects: [["slowness", 4, 4], ["weakness", 4, 1]],
                      selfBuffs: [["speed", 5, 2]], selfWindow: { pct: 35, seconds: 5 }, cooldown: 45,
                      msg: "Nebula collapses inward!", sound: "random.explode" } },
    }),

    // ── Transcend: Dimension & Time (Phase 8) ──
    single("dimension", "Dimension", {
        2: { resist: [[["projectile", "fall", "explosion"], 20]], dodge: { chance: 5, blink: 3 } },
        4: { thorns: { damage: 3, effects: [["slowness", 2, 1]] }, onHit: { chance: 15, chainDamage: 7 } },
        6: { blink: { distance: 8, cooldown: 6 }, dodge: { chance: 6, blink: 4 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 12, push: 1.4, lift: 0.5, blink: { distance: 6 },
                  selfWindow: { pct: 25, seconds: 4 }, cooldown: 40,
                  msg: "Space tears open!", sound: "mob.endermen.portal" } },
    }),
    single("time", "Time", {
        2: { selfEffects: [["speed", 0]], resist: [[["magic", "wither"], 30]], dodge: { chance: 4 } },
        4: { onHit: { chance: 30, effects: [["slowness", 2, 2]], cdr: 3 } },
        6: { aura: { radius: 6, damage: 1, effects: [["slowness", 2, 0], ["weakness", 2, 0]] }, killBuff: { effects: [["speed", 4, 1]], cdr: 8 } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 6, damage: 8, effects: [["slowness", 3, 10]], rewind: { seconds: 8, maxPct: 45 },
                  selfBuffs: [["speed", 5, 1]], selfWindow: { pct: 40, seconds: 5 }, cooldown: 90,
                  msg: "Time rewinds!", sound: "beacon.deactivate" } },
    }),
    kit("dimension", "divine", "Sanctum", {
        2: { resist: [[["magic", "explosion", "projectile"], 20]], dodge: { chance: 4, blink: 3 } },
        4: { onHit: { chance: 20, chainDamage: 6, healPct: 3 } },
        6: { aura: { radius: 6, healPct: 2, effects: [["weakness", 2, 0]] } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 6, healPct: 25, healNearbyPct: 20, cleanse: true, blink: { distance: 5 },
                  selfWindow: { pct: 50, seconds: 5 }, cooldown: 100,
                  msg: "Reality shelters you.", sound: "random.levelup" } },
    }),
    kit("dimension", "demon", "Rift", {
        2: { dealBonus: { pct: 12 }, dodge: { chance: 4, blink: 3 } },
        4: { onHit: { chance: 25, effects: [["wither", 3, 0]], chainDamage: 8 } },
        6: { blink: { distance: 8, cooldown: 6 }, aura: { radius: 4, damage: 2, igniteSec: 2 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, igniteSec: 5, push: 1.2, lift: 0.5, blink: { distance: 6 },
                  dealWindow: { pct: 25, seconds: 6 }, cooldown: 45,
                  msg: "The rift tears open!", sound: "mob.wither.spawn" } },
    }),
    kit("dimension", "life", "Haven", {
        2: { regen: 0.7, resist: [[["fall", "drowning", "projectile"], 20]] },
        4: { onHit: { chance: 25, healPct: 4 }, dodge: { chance: 5, blink: 3 } },
        6: { blink: { distance: 6, cooldown: 8 }, aura: { radius: 7, healPct: 2, cleanse: true } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 7, healPct: 35, healNearbyPct: 20, cleanse: true, blink: { distance: 6 },
                  selfBuffs: [["speed", 4, 1]], cooldown: 110,
                  msg: "You slip into a safe pocket.", sound: "random.levelup" } },
    }),
    kit("dimension", "death", "Limbo", {
        2: { resist: [[["wither", "magic"], 30]], dodge: { chance: 5, blink: 3 } },
        4: { souls: { max: 8, bonus: 2, seconds: 20 }, thorns: { damage: 3, effects: [["wither", 3, 0]] } },
        6: { dealBonus: { pct: 25, cond: "lowTarget", hpBelow: 25 }, blink: { distance: 8, cooldown: 7 }, killBuff: { healPct: 6 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 15, pull: 1.4, effects: [["wither", 5, 0]],
                  selfWindow: { pct: 30, seconds: 5 }, healPct: 8, cooldown: 50,
                  msg: "Limbo claims them.", sound: "mob.wither.spawn" } },
    }),
    kit("dimension", "star", "Wormhole", {
        2: { resist: [[["fall", "explosion", "void"], 25]], dodge: { chance: 5, blink: 3 }, selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1]], chainDamage: 7 } },
        6: { blink: { distance: 10, cooldown: 6 }, aura: { radius: 5, damage: 2, pull: 0.3 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 20, pull: 1.8, effects: [["slowness", 3, 3]], blink: { distance: 6 },
                  selfBuffs: [["speed", 5, 1]], cooldown: 45,
                  msg: "The wormhole opens!", sound: "mob.endermen.portal" } },
    }),
    kit("dimension", "void", "Nullspace", {
        2: { resist: [[["void", "fall", "projectile"], 30]], dodge: { chance: 6, blink: 3 } },
        4: { onHit: { chance: 20, effects: [["weakness", 3, 0]] }, lifesteal: { pct: 6 } },
        6: { blink: { distance: 8, cooldown: 6 }, dodge: { chance: 6, blink: 4 } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 6, damage: 10, pull: 1.4, effects: [["weakness", 4, 1]], blink: { distance: 8 },
                  selfBuffs: [["invisibility", 5, 0]], selfWindow: { pct: 50, seconds: 5 }, healPct: 12, cooldown: 90,
                  msg: "You slip between spaces.", sound: "mob.endermen.portal" } },
    }),
    kit("death", "time", "Entropy", {
        2: { resist: [[["wither", "magic"], 30]], dealBonus: { pct: 10, cond: "lowTarget", hpBelow: 50 } },
        4: { onHit: { chance: 25, effects: [["wither", 4, 0], ["slowness", 2, 1]] } },
        6: { dealBonus: { pct: 25, cond: "lowTarget", hpBelow: 25 }, aura: { radius: 4, damage: 2, effects: [["weakness", 2, 0]] }, killBuff: { healPct: 5, cdr: 6 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 18, effects: [["wither", 6, 0], ["slowness", 3, 2]],
                  dealWindow: { pct: 25, seconds: 6 }, healPct: 8, cooldown: 45,
                  msg: "Everything decays.", sound: "mob.wither.spawn" } },
    }),
    kit("demon", "time", "Doomsday", {
        2: { dealBonus: { pct: 12 }, resist: [[["fire", "wither"], 25]] },
        4: { onHit: { chance: 25, igniteSec: 3, effects: [["wither", 3, 0]], cdr: 2 } },
        6: { aura: { radius: 5, damage: 2, igniteSec: 2, effects: [["slowness", 2, 0]] }, killBuff: { effects: [["speed", 4, 1]], cdr: 6 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, igniteSec: 6, effects: [["slowness", 3, 3]],
                  dealWindow: { pct: 30, seconds: 6 }, cooldown: 45,
                  msg: "The final hour strikes!", sound: "mob.wither.spawn" } },
    }),
    kit("life", "time", "Renewal", {
        2: { regen: 0.8, selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 25, healPct: 5, cdr: 2 } },
        6: { aura: { radius: 7, healPct: 2.5, cleanse: true }, killBuff: { healPct: 5, cdr: 5 } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 7, healPct: 30, healNearbyPct: 20, cleanse: true, rewind: { seconds: 8, maxPct: 40 },
                  selfBuffs: [["speed", 5, 1]], cooldown: 120,
                  msg: "Time turns back for you.", sound: "beacon.deactivate" } },
    }),
    kit("divine", "time", "Providence", {
        2: { selfEffects: [["speed", 0]], resist: [[["magic", "wither", "fall"], 20]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1]], healPct: 3, cdr: 2 } },
        6: { aura: { radius: 6, healPct: 1.5, effects: [["slowness", 2, 0]] }, killBuff: { healPct: 4, cdr: 5 } },
        8: { burst: { trigger: "lowHp", hpBelow: 35, radius: 6, healPct: 20, healNearbyPct: 15, cleanse: true, rewind: { seconds: 6, maxPct: 30 },
                  selfWindow: { pct: 40, seconds: 5 }, cooldown: 100,
                  msg: "Fate is rewritten.", sound: "random.levelup" } },
    }),
    kit("star", "time", "Orbit", {
        2: { selfEffects: [["speed", 0]], resist: [[["fall", "explosion"], 20]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1]], chainDamage: 6, cdr: 2 } },
        6: { aura: { radius: 5, damage: 2, effects: [["slowness", 2, 0]] }, killBuff: { effects: [["speed", 4, 1]], cdr: 5 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 18, pull: 1.6, effects: [["slowness", 3, 3]], selfBuffs: [["speed", 5, 2]],
                  dealWindow: { pct: 20, seconds: 6 }, cooldown: 40,
                  msg: "The stars align!", sound: "random.explode" } },
    }),
    kit("time", "void", "Standstill", {
        2: { dodge: { chance: 6 }, resist: [[["void", "magic", "wither"], 25]] },
        4: { onHit: { chance: 30, effects: [["slowness", 2, 2], ["weakness", 3, 0]] } },
        6: { dodge: { chance: 6 }, aura: { radius: 5, damage: 1, effects: [["slowness", 2, 2], ["weakness", 2, 0]] } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 7, damage: 10, effects: [["slowness", 5, 10], ["weakness", 5, 1]],
                  selfWindow: { pct: 60, seconds: 5 }, healPct: 12, cooldown: 90,
                  msg: "Time stands still.", sound: "random.glass" } },
    }),
    kit("dimension", "time", "Continuum", {
        2: { dodge: { chance: 6, blink: 3 }, selfEffects: [["speed", 0]] },
        4: { onHit: { chance: 20, effects: [["slowness", 2, 1]], chainDamage: 6, cdr: 2 } },
        6: { blink: { distance: 8, cooldown: 5 }, killBuff: { effects: [["speed", 4, 1]], cdr: 6 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 16, effects: [["slowness", 3, 3]], blink: { distance: 6 }, rewind: { seconds: 6, maxPct: 25 },
                  selfWindow: { pct: 35, seconds: 5 }, cooldown: 50,
                  msg: "Spacetime folds!", sound: "mob.endermen.portal" } },
    }),
    // ── Awaken (Fusion of two Transcend elements on one piece) ──
    single("eclipse", "Eclipse", {
        2: { dealBonus: { pct: 18 }, resist: [[["fire", "magic", "lightning", "wither"], 25]] },
        4: { onHit: { chance: 25, effects: [["blindness", 3, 0]], igniteSec: 3, chainDamage: 8 }, lifesteal: { pct: 10 } },
        6: { aura: { radius: 6, damage: 4, igniteSec: 2, effects: [["weakness", 2, 0]], healPct: 2 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 30, igniteSec: 5, effects: [["blindness", 5, 0], ["weakness", 4, 0]],
                      selfWindow: { pct: 50, seconds: 6 }, dealWindow: { pct: 30, seconds: 6 }, healNearbyPct: 12, cleanse: true, cooldown: 40,
                      msg: "Totality!", sound: "mob.endermen.portal" } },
    }),
    single("samsara", "Samsara", {
        2: { regen: 1.0, resist: [[["wither", "magic", "drowning", "fall"], 35]] },
        4: { killBuff: { healPct: 8 }, souls: { max: 15, bonus: 2, seconds: 25 }, onHit: { chance: 25, healPct: 5 } },
        6: { aura: { radius: 7, damage: 3, effects: [["wither", 2, 0]], healPct: 2.5, cleanse: true } },
        8: { burst: { trigger: "lowHp", hpBelow: 30, radius: 7, damage: 20, effects: [["wither", 4, 0]], healPct: 60, cleanse: true,
                      selfWindow: { pct: 65, seconds: 7 }, cooldown: 150,
                      msg: "Reincarnation!", sound: "random.totem" },
              revive: { hpPct: 40, invulnSeconds: 3, cooldown: 300 } },
    }),
    single("cosmos", "Cosmos", {
        2: { dodge: { chance: 8 }, resist: [[["fall", "explosion", "void"], 45]], selfEffects: [["speed", 1]] },
        4: { onHit: { chance: 25, effects: [["slowness", 2, 1], ["weakness", 3, 0]], chainDamage: 10, chainCount: 2 }, dealBonus: { pct: 10 } },
        6: { dodge: { chance: 6 }, aura: { radius: 7, pull: 0.3, damage: 4, effects: [["slowness", 2, 0]] } },
        8: { burst: { trigger: "hit", radius: 7, damage: 34, pull: 2.0, effects: [["slowness", 4, 4], ["weakness", 4, 1]], hold: 2,
                      selfBuffs: [["speed", 6, 2]], selfWindow: { pct: 45, seconds: 6 }, cooldown: 45,
                      msg: "Singularity!", sound: "random.explode" } },
    }),
    single("eternity", "Eternity", {
        2: { selfEffects: [["speed", 1]], resist: [[["magic", "wither", "projectile", "fall"], 30]], dodge: { chance: 8, blink: 4 } },
        4: { onHit: { chance: 35, effects: [["slowness", 3, 3]], chainDamage: 10, cdr: 4 } },
        6: { blink: { distance: 12, cooldown: 4 }, aura: { radius: 6, effects: [["slowness", 2, 0], ["weakness", 2, 0]] },
             killBuff: { effects: [["speed", 4, 1]], cdr: 10 } },
        8: { burst: { trigger: "hit", radius: 6, damage: 14, effects: [["slowness", 4, 10]], blink: { distance: 8 }, rewind: { seconds: 10, maxPct: 50 },
                      selfBuffs: [["speed", 6, 2]], selfWindow: { pct: 50, seconds: 6 }, cooldown: 60,
                      msg: "Temporal Collapse!", sound: "beacon.deactivate" } },
    }),

    // ── Melodious (Fusion of two Awaken pieces) ──
    single("destiny", "Destiny", {
        2: { dealBonus: { pct: 22 }, regen: 1.2, resist: [[["fire", "magic", "lightning", "wither"], 35]] },
        4: { onHit: { chance: 30, mark: { pct: 15, seconds: 6 } }, lifesteal: { pct: 12 }, souls: { max: 20, bonus: 2, seconds: 25 } },
        6: { dealBonus: { pct: 40, cond: "lowTarget", hpBelow: 40 }, killBuff: { healPct: 10, cdr: 6 },
             aura: { radius: 7, damage: 5, healPct: 3 } },
        8: { burst: { trigger: "hit", radius: 7, damage: 45, igniteSec: 5, effects: [["wither", 5, 0], ["blindness", 4, 0]], execute: { hpBelow: 15 },
                      selfWindow: { pct: 60, seconds: 7 }, dealWindow: { pct: 40, seconds: 8 }, healNearbyPct: 15, cleanse: true, cooldown: 45,
                      msg: "Fate decreed!", sound: "mob.wither.spawn" },
              revive: { hpPct: 50, invulnSeconds: 4, cooldown: 240 } },
    }),
    single("infinity", "Infinity", {
        2: { dodge: { chance: 10, blink: 5 }, selfEffects: [["speed", 1]], resist: [[["fall", "explosion", "projectile", "void", "magic"], 40]] },
        4: { onHit: { chance: 35, effects: [["slowness", 3, 3], ["weakness", 3, 0]], chainDamage: 12, chainCount: 3, cdr: 6 } },
        6: { blink: { distance: 15, cooldown: 3 }, aura: { radius: 8, pull: 0.3, damage: 5, effects: [["slowness", 2, 0]] }, killBuff: { cdr: 12 } },
        8: { burst: { trigger: "hit", radius: 8, damage: 50, pull: 2.0, effects: [["slowness", 5, 10]], blink: { distance: 10 }, rewind: { seconds: 12, maxPct: 60 },
                      selfBuffs: [["speed", 8, 2]], selfWindow: { pct: 55, seconds: 7 }, cooldown: 70,
                      msg: "Infinite Loop!", sound: "beacon.deactivate" } },
    }),

    // ── Genesis (Fusion of Destiny + Infinity) ──
    single("genesis", "Genesis", {
        2: { dealBonus: { pct: 30 }, regen: 1.5, dodge: { chance: 10 },
             resist: [[["fire", "magic", "wither", "lightning", "explosion", "projectile", "fall", "void"], 30]] },
        4: { onHit: { chance: 35, effects: [["weakness", 3, 0], ["slowness", 3, 1]], mark: { pct: 15, seconds: 6 }, chainDamage: 15, chainCount: 3, cdr: 5 },
             lifesteal: { pct: 15 } },
        6: { aura: { radius: 8, damage: 6, effects: [["slowness", 2, 1], ["weakness", 2, 0]], healPct: 4, cleanse: true },
             blink: { distance: 15, cooldown: 4 }, killBuff: { healPct: 12, cdr: 15 } },
        8: { burst: { trigger: "hit", radius: 8, damage: 70, pull: 1.6, igniteSec: 5, effects: [["wither", 5, 0], ["slowness", 3, 10]],
                      selfWindow: { pct: 70, seconds: 8 }, dealWindow: { pct: 50, seconds: 10 }, healNearbyPct: 20, cleanse: true,
                      rewind: { seconds: 12, maxPct: 60 }, cooldown: 60,
                      msg: "Big Bang!", sound: "random.explode" },
              revive: { hpPct: 60, invulnSeconds: 5, cooldown: 180 } },
    }),
]);

// ─── Set effect descriptions ─────────────────────────────────────────────────
// CHORUS_EFFECTS[setId][threshold] = { desc, ready }
//   setId = element id (single) or "a+b" sorted key (hybrid)
//   ready = false → GUI shows "(Coming Soon)"; flip to true once implemented.
// Anything not listed shows as "???".
const T = (desc) => ({ desc, ready: false });
const R = (desc) => ({ desc, ready: true });

export const CHORUS_EFFECTS = {
    fire: {
        2: R("Fire, lava & burning damage taken -25%."),
        4: R("15% chance to ignite the target on hit."),
        6: R("Every second, burns hostile mobs within 4 blocks (1 damage)."),
        8: R("Enemies you ignited explode on death, hurting nearby hostile mobs (4 damage)."),
    },
    water: {
        2: R("Drowning & magic (poison) damage taken -25%. Swim faster in water."),
        4: R("30% chance to slow the target on hit."),
        6: R("Regenerate 0.5% of max HP every second."),
        8: R("Tidal Wave: at 35% HP or lower, knock back nearby hostile mobs and cleanse debuffs. (45s cooldown)"),
    },
    wind: {
        2: R("Speed I."),
        4: R("Sprint + Jump to dash forward. (3s cooldown)"),
        6: R("Arrows you fire fly 40% faster."),
        8: R("Gale Burst: when hit, launch nearby hostile mobs away (3 damage). (15s cooldown)"),
    },
    earth: {
        2: R("Melee, projectile, fall & contact damage taken -10%."),
        4: R("Reflect 20% of melee damage back at the attacker."),
        6: R("Stone Skin: absorbs 10 damage, recharges after 10s without being hit."),
        8: R("Quake: when hit, stun nearby hostile mobs for 2s. (20s cooldown)"),
    },

    // ── Echo hybrids ──
    "fire+water": {   // Steam
        2: R("Fire, lava, burning & drowning damage taken -20%."),
        4: R("25% chance to blind the target on hit."),
        6: R("Scalding mist: hostile mobs within 4 blocks get Weakness."),
        8: R("Steam Burst: at 30% HP or lower, blast nearby hostile mobs (12 damage + blind). (45s cooldown)"),
    },
    "fire+wind": {    // Wildfire
        2: R("Fire damage taken -20%. Fall damage taken -30%."),
        4: R("25% chance to ignite the target and hostile mobs within 3 blocks of it."),
        6: R("Sprinting ignites hostile mobs you run past."),
        8: R("Firestorm: when hit, ignite, damage & push away nearby hostile mobs. (25s cooldown)"),
    },
    "earth+fire": {   // Magma
        2: R("Fire, lava & burning damage taken -35%."),
        4: R("Molten Skin: reflect 15% of melee damage and ignite the attacker."),
        6: R("Magma Armor: absorbs 12 damage, recharges after 12s. Breaking it scorches nearby hostile mobs."),
        8: R("Eruption: when hit, blast nearby hostile mobs (10 damage + ignite + launch). (30s cooldown)"),
    },
    "water+wind": {   // Monsoon
        2: R("Fall damage taken -50%. Drowning damage taken -25%."),
        4: R("35% chance for your arrows to slow the target."),
        6: R("Regenerate 1% of max HP every second while sprinting or swimming."),
        8: R("Typhoon: when hit, push & slow nearby hostile mobs and cleanse debuffs. (25s cooldown)"),
    },
    "earth+water": {  // Bog
        2: R("Magic (poison) damage taken -30%. Physical damage taken -5%."),
        4: R("25% chance to poison the target on hit."),
        6: R("Mud: hostile mobs within 4 blocks are slowed."),
        8: R("Quagmire: when hit, heavily slow & damage nearby hostile mobs and heal 5% max HP. (25s cooldown)"),
    },
    "earth+wind": {   // Sandstorm
        2: R("Speed I. Fall damage taken -30%."),
        4: R("20% chance to blind the target on hit."),
        6: R("Dust Veil: 12% chance to dodge melee and projectile attacks."),
        8: R("Sandstorm: when hit, blind, damage & push away nearby hostile mobs. (25s cooldown)"),
    },

    // ── Resonance singles ──
    lightning: {
        2: R("Lightning & explosion damage taken -25%."),
        4: R("15% chance for your hits to chain lightning to a nearby hostile mob (3 damage)."),
        6: R("Killing an enemy grants Speed II for 4s."),
        8: R("Thunderstrike: 12% chance on hit to call a bolt on the target (9 damage within 3 blocks). (9s cooldown)"),
    },
    frost: {
        2: R("Freezing damage taken -50%."),
        4: R("20% chance to root the target on hit (Slowness IV, 2s)."),
        6: R("Frost Armor: melee attackers are slowed for 3s."),
        8: R("Absolute Zero: when hit, freeze nearby hostile mobs for 3s. Frozen or rooted enemies take +30% damage from you. (30s cooldown)"),
    },
    gale: {
        2: R("Jump Boost I. Fall damage taken -50%."),
        4: R("Double Jump: jump again in mid-air. (3s cooldown)"),
        6: R("Skybound: while airborne, deal +15% damage and take -15% damage."),
        8: R("Cyclone: when hit, lift nearby hostile mobs into the air (Levitation 2s) and gain Slow Falling for 5s. (25s cooldown)"),
    },
    metal: {
        2: R("Projectile & explosion damage taken -20%."),
        4: R("Spikes: melee attackers take 3 damage."),
        6: R("Fortified: below 50% HP, damage taken -20%."),
        8: R("Bulwark: when hit, damage taken -50% for 4s. (30s cooldown)"),
    },
    light: {
        2: R("Damage dealt to undead +15%."),
        4: R("Blessing: killing an enemy heals 5% of max HP."),
        6: R("Radiant Aura: heal yourself and nearby players 1% max HP every second."),
        8: R("Holy Nova: when hit, blind & damage nearby hostile mobs (5, or 12 vs undead) and heal nearby players 5% max HP. (25s cooldown)"),
    },
    dark: {
        2: R("Damage dealt +25% at night."),
        4: R("30% chance to apply Wither on hit (3s)."),
        6: R("Veil: hostile mobs within 4 blocks are blinded."),
        8: R("Shadow Step: at 30% HP or lower, vanish (Invisibility + Speed II for 6s) and heal 12% max HP. (75s cooldown)"),
    },

    // ── Resonance hybrids ──
    "frost+lightning": {   // Stormfront
        2: R("Lightning, freezing & explosion damage taken -20%."),
        4: R("20% chance to slow the target (Slowness III) and chain 3 damage to a nearby hostile mob."),
        6: R("Frostbitten static: hostile mobs within 4 blocks are slowed and take 1 damage every second."),
        8: R("Stormfront: when hit, blast nearby hostile mobs (8 damage + heavy slow). (30s cooldown)"),
    },
    "gale+lightning": {    // Thunderstorm
        2: R("Lightning & fall damage taken -25%. Speed I."),
        4: R("20% chance to chain 5 damage to a nearby hostile mob."),
        6: R("Killing an enemy grants Speed II and Jump Boost II for 4s."),
        8: R("Tempest: when hit, blast nearby hostile mobs (10 damage) and launch them away. (25s cooldown)"),
    },
    "lightning+metal": {   // Magnet
        2: R("Lightning, explosion & projectile damage taken -20%."),
        4: R("20% chance to slow the target and chain 4 damage to a nearby hostile mob."),
        6: R("Magnetic pull: hostile mobs within 5 blocks are drawn toward you and take 1 damage every second."),
        8: R("Polarity: when hit, yank nearby hostile mobs to you, stun & damage them (9). (25s cooldown)"),
    },
    "light+lightning": {   // Plasma
        2: R("Damage dealt +10%."),
        4: R("20% chance to blind and ignite the target on hit."),
        6: R("Killing an enemy heals 4% of max HP and grants Speed I for 3s."),
        8: R("Plasma Nova: when hit, blast nearby hostile mobs (12 damage + ignite + blind). (30s cooldown)"),
    },
    "dark+lightning": {    // Nightstorm
        2: R("Damage dealt +18% at night."),
        4: R("20% chance to Wither the target and chain 4 damage to a nearby hostile mob."),
        6: R("Storm of dread: hostile mobs within 4 blocks are blinded and weakened."),
        8: R("Night Bolt: at 30% HP or lower, vanish (Invisibility + Speed II 6s), blast nearby mobs (8 damage) and heal 10% max HP. (90s cooldown)"),
    },
    "frost+gale": {        // Blizzard
        2: R("Freezing damage taken -40%. Fall damage taken -30%."),
        4: R("25% chance to slow the target heavily (Slowness III, 3s)."),
        6: R("Whiteout: hostile mobs within 5 blocks are slowed and blinded."),
        8: R("Blizzard: when hit, blast nearby hostile mobs (5 damage), push them away and freeze them. (30s cooldown)"),
    },
    "frost+metal": {       // Coldsteel
        2: R("Freezing damage taken -30%. Physical damage taken -8%."),
        4: R("Melee attackers take 4 damage and are slowed for 3s."),
        6: R("Tempered: below 50% HP, damage taken -25%."),
        8: R("Ice Plating: when hit, slow nearby hostile mobs and take -45% damage for 4s. (30s cooldown)"),
    },
    "frost+light": {       // Aurora
        2: R("Regenerate 0.4% of max HP every second."),
        4: R("20% chance to blind and slow the target on hit."),
        6: R("Aurora Aura: heal yourself and nearby players 1% max HP every second."),
        8: R("Aurora Burst: when hit, dazzle & chill nearby hostile mobs (6 damage), heal nearby players 6% and cleanse debuffs. (30s cooldown)"),
    },
    "dark+frost": {        // Rime
        2: R("Freezing & magic damage taken -30%."),
        4: R("20% chance to Wither and slow the target on hit."),
        6: R("Chilling dread: hostile mobs within 4 blocks are weakened, slowed and take 1 damage every second."),
        8: R("Dread Frost: at 35% HP or lower, freeze nearby mobs (7 damage), take -30% damage for 4s and heal 8% max HP. (75s cooldown)"),
    },
    "gale+metal": {        // Razorwind
        2: R("Fall damage taken -30%. Speed I."),
        4: R("20% chance to chain 5 damage to a nearby hostile mob."),
        6: R("Deflect: 10% chance to dodge melee and projectile attacks."),
        8: R("Blade Storm: when hit, slash nearby hostile mobs (9 damage) and knock them away. (25s cooldown)"),
    },
    "gale+light": {        // Zephyr
        2: R("Fall damage taken -40%. Speed I and Jump Boost I."),
        4: R("25% chance to heal 3% of max HP on hit."),
        6: R("Regenerate 1.2% of max HP every second while sprinting, swimming or airborne."),
        8: R("Gentle Gale: when hit, lift & blind nearby mobs, gain Speed II + Slow Falling and heal nearby players 5%. (30s cooldown)"),
    },
    "dark+gale": {         // Wraith
        2: R("10% chance to dodge melee and projectile attacks. Fall damage taken -30%."),
        4: R("20% chance to Wither and blind the target on hit."),
        6: R("Killing an enemy grants Invisibility and Speed II for 3s."),
        8: R("Dissolve: at 30% HP or lower, vanish (Invisibility + Speed III 6s), lift nearby mobs and heal 8% max HP. (90s cooldown)"),
    },
    "light+metal": {       // Lustre
        2: R("Projectile & explosion damage taken -15%. Damage to undead +10%."),
        4: R("Melee attackers take 3 damage and are blinded for 2s."),
        6: R("Radiant Plate: absorbs 12 damage, recharges after 12s. Breaking it blinds nearby hostile mobs."),
        8: R("Blinding Radiance: when hit, blind & damage nearby hostile mobs (8), take -30% damage for 4s and heal nearby players 5%. (30s cooldown)"),
    },
    "dark+metal": {        // Obsidian
        2: R("Explosion & fire damage taken -25%."),
        4: R("Melee attackers take 4 damage and are withered for 2s."),
        6: R("Hardened: below 50% HP, damage taken -25%."),
        8: R("Obsidian Ward: when hit, blast & slow nearby hostile mobs (8 damage) and take -50% damage for 4s. (35s cooldown)"),
    },
    "dark+light": {        // Twilight
        2: R("Damage dealt +10%."),
        4: R("20% chance to blind and Wither the target on hit."),
        6: R("Dusk Aura: hostile mobs within 5 blocks are blinded; heal yourself and nearby players 1% max HP every second."),
        8: R("Twilight Falls: when hit, blind & wither nearby hostile mobs (10 damage) and heal nearby players 6%. (30s cooldown)"),
    },

    // ── Transcend singles ──
    divine: {
        2: R("Magic, fire, lightning & explosion damage taken -20%. Regenerate 0.3% max HP every second."),
        4: R("20% chance to blind the target and heal 3% max HP on hit. Damage to undead +25%."),
        6: R("Holy Ground: hostile mobs within 6 blocks take 2 damage and are weakened every second; heal yourself and nearby players 1.5% max HP."),
        8: R("Divine Wrath: when hit, blast nearby hostile mobs (15 damage + blind + weaken), take -40% damage for 5s, heal nearby players 10% and cleanse debuffs. (40s cooldown)"),
    },
    demon: {
        2: R("Damage dealt +12%. Fire & lava damage taken -30%."),
        4: R("20% chance to ignite and Wither the target on hit. Heal 8% of damage dealt."),
        6: R("Hellfire: hostile mobs within 4 blocks burn, weaken and take 2 damage every second."),
        8: R("Demonic Pact: when hit, blast nearby hostile mobs (14 damage + ignite + wither), heal 5% max HP and deal +25% damage for 6s. (40s cooldown)"),
    },
    life: {
        2: R("Regenerate 0.8% max HP every second. Drowning, fall & magic damage taken -20%."),
        4: R("25% chance to heal 4% max HP on hit. Killing an enemy heals 5% max HP."),
        6: R("Lifebloom: heal yourself and nearby players 2% max HP every second and cleanse your debuffs."),
        8: R("Rebirth: at 30% HP or lower, heal 40% max HP, heal nearby players 20%, cleanse debuffs and take -40% damage for 5s. (120s cooldown)"),
    },
    death: {
        2: R("Magic & Wither damage taken -40%. Damage dealt +10% to enemies below 50% HP."),
        4: R("Soul Harvest: each kill grants a soul (max 10, lasts 20s) for +2% damage each. 20% chance to Wither the target on hit."),
        6: R("Execute: damage dealt +30% to enemies below 25% HP. Killing an enemy heals 6% max HP and grants Speed II for 4s."),
        8: R("Reaper's Mark: when hit, blast nearby hostile mobs (12 damage + wither + slow), deal +25% damage for 6s and heal 6% max HP. (45s cooldown)"),
    },

    // ── Transcend hybrids ──
    "demon+divine": {      // Judgement
        2: R("Damage dealt +15%. Fire, magic & lightning damage taken -20%."),
        4: R("20% chance to blind and ignite the target and chain 5 damage to a nearby hostile mob."),
        6: R("Purgatory: hostile mobs within 5 blocks burn, weaken and take 3 damage every second; heal yourself and nearby players 1%."),
        8: R("Judgement: when hit, blast nearby hostile mobs (18 damage + ignite + blind + weaken), take -30% damage for 5s and heal nearby players 8%. (40s cooldown)"),
    },
    "divine+life": {       // Eden
        2: R("Regenerate 0.8% max HP every second. Magic, drowning & fall damage taken -20%."),
        4: R("25% chance to heal 5% max HP on hit."),
        6: R("Garden: heal yourself and nearby players 2% max HP every second and cleanse your debuffs."),
        8: R("Paradise: at 35% HP or lower, heal 35% max HP, heal nearby players 20%, cleanse debuffs, weaken nearby mobs and take -50% damage for 6s. (120s cooldown)"),
    },
    "death+divine": {      // Requiem
        2: R("Magic & Wither damage taken -40%. Damage to undead +25%."),
        4: R("20% chance to Wither and blind the target on hit. Heal 8% of damage dealt."),
        6: R("Killing an enemy heals 8% max HP and grants Speed II for 4s."),
        8: R("Requiem: when hit, blast nearby hostile mobs (16 damage + wither + blind), take -35% damage for 5s and heal 10% max HP. (45s cooldown)"),
    },
    "demon+life": {        // Corruption
        2: R("Regenerate 0.5% max HP every second. Damage dealt +10%."),
        4: R("25% chance to poison the target heavily on hit. Heal 10% of damage dealt."),
        6: R("Blight: hostile mobs within 5 blocks are poisoned and take 2 damage every second; heal yourself and nearby players 1.5%."),
        8: R("Corruption: when hit, blast nearby hostile mobs (14 damage + poison + weaken), heal 12% max HP and deal +20% damage for 6s. (40s cooldown)"),
    },
    "death+demon": {       // Damnation
        2: R("Damage dealt +12%. Fire & Wither damage taken -30%."),
        4: R("20% chance to ignite and Wither the target on hit. Soul Harvest: each kill grants a soul (max 10, 20s) for +2% damage each."),
        6: R("Damage dealt +30% to enemies below 35% HP. Hostile mobs within 4 blocks burn and take 2 damage every second."),
        8: R("Damnation: when hit, blast nearby hostile mobs (18 damage + ignite + wither), deal +25% damage for 6s and heal 8% max HP. (45s cooldown)"),
    },
    "death+life": {        // Revenant
        2: R("Regenerate 0.6% max HP every second. Wither & magic damage taken -30%."),
        4: R("Killing an enemy heals 6% max HP. Soul Harvest: each kill grants a soul (max 10, 20s) for +2% damage each."),
        6: R("Soul Tide: hostile mobs within 6 blocks take 2 damage every second; heal yourself and nearby players 1.5% max HP."),
        8: R("Revenant: at 25% HP or lower, heal 50% max HP, blast nearby mobs (10 damage + wither), cleanse debuffs and take -60% damage for 6s. (150s cooldown)"),
    },

    // ── Transcend: Star & Void singles ──
    star: {
        2: R("Fall & explosion damage taken -25%. Permanent Speed I."),
        4: R("20% chance to slow the target and chain 6 damage to a nearby hostile mob on hit. Damage dealt +6%."),
        6: R("Gravity Well: hostile mobs within 5 blocks are slowed and take 3 damage every second. Killing an enemy grants Speed II for 4s."),
        8: R("Starfall: when hit, blast nearby hostile mobs (20 damage + slow), pull them in and gain Speed II for 5s. (40s cooldown)"),
    },
    void: {
        2: R("8% chance to dodge attacks. Void & fall damage taken -40%."),
        4: R("20% chance to weaken the target on hit. Heal 6% of damage dealt."),
        6: R("Dodge chance +10%. Hostile mobs within 5 blocks are pulled in and weakened every second."),
        8: R("Vanish: at 30% HP or lower, blast & pull nearby mobs (10 damage + weaken + slow), turn invisible, heal 15% max HP and take -50% damage for 5s. (90s cooldown)"),
    },

    // ── Transcend: Star & Void hybrids ──
    "divine+star": {       // Celestial
        2: R("Damage dealt +12%. Magic, explosion & fall damage taken -20%."),
        4: R("20% chance to blind the target, chain 6 damage to a nearby hostile mob and heal 3% max HP on hit."),
        6: R("Starlight: hostile mobs within 6 blocks take 2 damage and are weakened every second; heal yourself and nearby players 1.5% max HP."),
        8: R("Heavens Ring: when hit, blast nearby hostile mobs (16 damage + blind + weaken), take -30% damage for 5s and heal nearby players 8%. (40s cooldown)"),
    },
    "demon+star": {        // Meteor
        2: R("Damage dealt +12%. Fire & explosion damage taken -30%."),
        4: R("25% chance to ignite the target and chain 6 damage to a nearby hostile mob on hit."),
        6: R("Falling Embers: hostile mobs within 5 blocks burn and take 3 damage every second."),
        8: R("Meteor Strike: when hit, blast and launch nearby hostile mobs (20 damage + ignite) and deal +25% damage for 6s. (45s cooldown)"),
    },
    "life+star": {         // Starbloom
        2: R("Regenerate 0.8% max HP every second. Permanent Speed I."),
        4: R("25% chance to heal 5% max HP on hit. Killing an enemy heals 5% max HP and grants Speed II for 3s."),
        6: R("Stardust: heal yourself and nearby players 2.5% max HP every second and cleanse your debuffs."),
        8: R("New Star: at 35% HP or lower, heal 40% max HP, heal nearby players 20%, cleanse debuffs and gain Speed II for 5s. (100s cooldown)"),
    },
    "death+star": {        // Supernova
        2: R("Magic & Wither damage taken -30%. Damage dealt +10% to enemies below 50% HP."),
        4: R("Soul Harvest: each kill grants a soul (max 10, 20s) for +2% damage each. 15% chance to chain 5 damage to a nearby hostile mob on hit."),
        6: R("Execute: damage dealt +30% to enemies below 25% HP. Killing an enemy heals 6% max HP and grants Speed II for 4s."),
        8: R("Supernova: when hit, blast and launch nearby hostile mobs (20 damage + wither), deal +25% damage for 6s and heal 6% max HP. (50s cooldown)"),
    },
    "divine+void": {       // Umbra
        2: R("Magic, explosion & Wither damage taken -25%. 6% chance to dodge attacks."),
        4: R("20% chance to blind and weaken the target on hit."),
        6: R("Penumbra: hostile mobs within 5 blocks are blinded and weakened; heal yourself and nearby players 1.5% max HP every second."),
        8: R("Umbra: when hit, blast nearby hostile mobs (14 damage + blind + weaken), take -40% damage for 5s, heal nearby players 8% and cleanse debuffs. (40s cooldown)"),
    },
    "demon+void": {        // Abyss
        2: R("Damage dealt +12%. 6% chance to dodge attacks."),
        4: R("25% chance to Wither and weaken the target on hit. Heal 8% of damage dealt."),
        6: R("Maw: hostile mobs within 5 blocks are pulled in and take 2 damage every second."),
        8: R("Abyss: when hit, blast & pull nearby hostile mobs (18 damage + wither + slow), deal +25% damage for 6s and heal 6% max HP. (45s cooldown)"),
    },
    "life+void": {         // Stasis
        2: R("Regenerate 0.8% max HP every second. Magic, Wither & drowning damage taken -25%."),
        4: R("20% chance to heavily slow the target and heal 5% max HP on hit."),
        6: R("Still Air: hostile mobs within 6 blocks are slowed; heal yourself and nearby players 2% max HP every second."),
        8: R("Time Stills: at 30% HP or lower, freeze nearby mobs in place, heal 30% max HP, cleanse debuffs and take -60% damage for 5s. (100s cooldown)"),
    },
    "death+void": {        // Oblivion
        2: R("Magic & Wither damage taken -35%. 6% chance to dodge attacks."),
        4: R("25% chance to Wither and weaken the target on hit."),
        6: R("Damage dealt +25% to enemies below 25% HP. Hostile mobs within 4 blocks are weakened and take 2 damage every second."),
        8: R("Oblivion: when hit, blast & pull nearby hostile mobs (16 damage + wither + blind), take -30% damage and deal +25% damage for 5-6s, heal 8% max HP. (45s cooldown)"),
    },
    "star+void": {         // Nebula
        2: R("6% chance to dodge attacks. Void & fall damage taken -40%. Permanent Speed I."),
        4: R("20% chance to slow and weaken the target and chain 6 damage to a nearby hostile mob on hit."),
        6: R("Dodge chance +6%. Hostile mobs within 6 blocks are pulled in and take 2 damage every second."),
        8: R("Nebula Burst: when hit, blast & pull nearby hostile mobs (20 damage + slow + weaken), gain Speed III for 5s and take -35% damage for 5s. (45s cooldown)"),
    },

    // ── Transcend: Dimension & Time ──
    dimension: {
        2: R("Projectile, fall & explosion damage taken -20%. 5% chance to dodge attacks and sidestep 3 blocks."),
        4: R("Spatial Mirror: melee attackers take 3 damage and are slowed. 15% chance to chain 7 damage to a nearby hostile mob on hit."),
        6: R("Sprint + Jump to Blink up to 8 blocks forward. (6s cooldown) Dodge chance +6% with a longer 4-block sidestep."),
        8: R("Rupture: when hit, blast and launch nearby hostile mobs (12 damage), blink 6 blocks away from the attacker and take -25% damage for 4s. (40s cooldown)"),
    },
    time: {
        2: R("Permanent Speed I. Magic & Wither damage taken -30%. 4% chance to dodge attacks."),
        4: R("30% chance to heavily slow the target on hit and cut all Chorus burst cooldowns by 3s."),
        6: R("Time Dilation: hostile mobs within 6 blocks are slowed, weakened and take 1 damage every second. Killing an enemy cuts cooldowns by 8s and grants Speed II for 4s."),
        8: R("Rewind: at 35% HP or lower, freeze nearby mobs for 3s (8 damage), recover HP lost in the last 8s (up to 45% max HP), take -40% damage for 5s and gain Speed II for 5s. (90s cooldown)"),
    },
    "dimension+divine": {       // Sanctum
        2: R("Magic, explosion & projectile damage taken -20%. 4% chance to dodge attacks and sidestep 3 blocks."),
        4: R("20% chance to chain 6 damage to a nearby hostile mob and heal 3% max HP on hit."),
        6: R("Sanctum Field: hostile mobs within 6 blocks are weakened; heal yourself and nearby players 2% max HP every second."),
        8: R("Sanctum Ward: at 35% HP or lower, heal 25% max HP, heal nearby players 20%, cleanse debuffs, blink 5 blocks away and take -50% damage for 5s. (100s cooldown)"),
    },
    "demon+dimension": {       // Rift
        2: R("Damage dealt +12%. 4% chance to dodge attacks and sidestep 3 blocks."),
        4: R("25% chance to Wither the target and chain 8 damage to a nearby hostile mob on hit."),
        6: R("Sprint + Jump to Blink up to 8 blocks forward. (6s cooldown) Hostile mobs within 4 blocks burn and take 2 damage every second."),
        8: R("Rift: when hit, blast and launch nearby hostile mobs (18 damage + ignite), blink 6 blocks away and deal +25% damage for 6s. (45s cooldown)"),
    },
    "dimension+life": {       // Haven
        2: R("Regenerate 0.7% max HP every second. Fall, drowning & projectile damage taken -20%."),
        4: R("25% chance to heal 4% max HP on hit. 5% chance to dodge attacks and sidestep 3 blocks."),
        6: R("Sprint + Jump to Blink up to 6 blocks forward. (8s cooldown) Heal yourself and nearby players 2% max HP every second and cleanse your debuffs."),
        8: R("Safe Pocket: at 35% HP or lower, heal 35% max HP, heal nearby players 20%, cleanse debuffs, blink 6 blocks away and gain Speed II for 4s. (110s cooldown)"),
    },
    "death+dimension": {       // Limbo
        2: R("Magic & Wither damage taken -30%. 5% chance to dodge attacks and sidestep 3 blocks."),
        4: R("Soul Harvest: each kill grants a soul (max 8, 20s) for +2% damage each. Melee attackers take 3 damage and are withered."),
        6: R("Damage dealt +25% to enemies below 25% HP. Sprint + Jump to Blink up to 8 blocks forward (7s cooldown). Killing an enemy heals 6% max HP."),
        8: R("Limbo: when hit, pull nearby hostile mobs in and wither them (15 damage), take -30% damage for 5s and heal 8% max HP. (50s cooldown)"),
    },
    "dimension+star": {       // Wormhole
        2: R("Fall, explosion & void damage taken -25%. 5% chance to dodge attacks and sidestep 3 blocks. Permanent Speed I."),
        4: R("20% chance to slow the target and chain 7 damage to a nearby hostile mob on hit."),
        6: R("Sprint + Jump to Blink up to 10 blocks forward. (6s cooldown) Hostile mobs within 5 blocks are pulled in and take 2 damage every second."),
        8: R("Wormhole: when hit, pull and slow nearby hostile mobs (20 damage), blink 6 blocks away and gain Speed II for 5s. (45s cooldown)"),
    },
    "dimension+void": {       // Nullspace
        2: R("Void, fall & projectile damage taken -30%. 6% chance to dodge attacks and sidestep 3 blocks."),
        4: R("20% chance to weaken the target on hit. Heal 6% of damage dealt."),
        6: R("Sprint + Jump to Blink up to 8 blocks forward. (6s cooldown) Dodge chance +6% with a 4-block sidestep."),
        8: R("Slip Away: at 30% HP or lower, pull and weaken nearby hostile mobs (10 damage), blink 8 blocks away, turn invisible, take -50% damage for 5s and heal 12% max HP. (90s cooldown)"),
    },
    "death+time": {       // Entropy
        2: R("Magic & Wither damage taken -30%. Damage dealt +10% to enemies below 50% HP."),
        4: R("25% chance to Wither and slow the target on hit."),
        6: R("Damage dealt +25% to enemies below 25% HP. Hostile mobs within 4 blocks are weakened and take 2 damage every second. Killing an enemy heals 5% max HP and cuts cooldowns by 6s."),
        8: R("Entropy: when hit, blast nearby hostile mobs (18 damage + wither + slow), deal +25% damage for 6s and heal 8% max HP. (45s cooldown)"),
    },
    "demon+time": {       // Doomsday
        2: R("Damage dealt +12%. Fire & Wither damage taken -25%."),
        4: R("25% chance to ignite and Wither the target on hit and cut Chorus burst cooldowns by 2s."),
        6: R("Hostile mobs within 5 blocks burn, are slowed and take 2 damage every second. Killing an enemy cuts cooldowns by 6s and grants Speed II for 4s."),
        8: R("Doomsday: when hit, blast nearby hostile mobs (18 damage + ignite + slow) and deal +30% damage for 6s. (45s cooldown)"),
    },
    "life+time": {       // Renewal
        2: R("Regenerate 0.8% max HP every second. Permanent Speed I."),
        4: R("25% chance to heal 5% max HP on hit and cut Chorus burst cooldowns by 2s."),
        6: R("Heal yourself and nearby players 2.5% max HP every second and cleanse your debuffs. Killing an enemy heals 5% max HP and cuts cooldowns by 5s."),
        8: R("Time Turns Back: at 35% HP or lower, heal 30% max HP, recover HP lost in the last 8s (up to 40% max HP), heal nearby players 20%, cleanse debuffs and gain Speed II for 5s. (120s cooldown)"),
    },
    "divine+time": {       // Providence
        2: R("Permanent Speed I. Magic, Wither & fall damage taken -20%."),
        4: R("20% chance to slow the target and heal 3% max HP on hit and cut Chorus burst cooldowns by 2s."),
        6: R("Hostile mobs within 6 blocks are slowed; heal yourself and nearby players 1.5% max HP every second. Killing an enemy heals 4% max HP and cuts cooldowns by 5s."),
        8: R("Fate Rewritten: at 35% HP or lower, heal 20% max HP, recover HP lost in the last 6s (up to 30% max HP), heal nearby players 15%, cleanse debuffs and take -40% damage for 5s. (100s cooldown)"),
    },
    "star+time": {       // Orbit
        2: R("Permanent Speed I. Fall & explosion damage taken -20%."),
        4: R("20% chance to slow the target, chain 6 damage to a nearby hostile mob and cut Chorus burst cooldowns by 2s."),
        6: R("Hostile mobs within 5 blocks are slowed and take 2 damage every second. Killing an enemy cuts cooldowns by 5s and grants Speed II for 4s."),
        8: R("Orbit: when hit, pull and slow nearby hostile mobs (18 damage), gain Speed III for 5s and deal +20% damage for 6s. (40s cooldown)"),
    },
    "time+void": {       // Standstill
        2: R("6% chance to dodge attacks. Void, magic & Wither damage taken -25%."),
        4: R("30% chance to heavily slow and weaken the target on hit."),
        6: R("Dodge chance +6%. Hostile mobs within 5 blocks are heavily slowed, weakened and take 1 damage every second."),
        8: R("Standstill: at 30% HP or lower, freeze and weaken nearby hostile mobs (10 damage), take -60% damage for 5s and heal 12% max HP. (90s cooldown)"),
    },
    "dimension+time": {       // Continuum
        2: R("6% chance to dodge attacks and sidestep 3 blocks. Permanent Speed I."),
        4: R("20% chance to slow the target, chain 6 damage to a nearby hostile mob and cut Chorus burst cooldowns by 2s."),
        6: R("Sprint + Jump to Blink up to 8 blocks forward. (5s cooldown) Killing an enemy cuts cooldowns by 6s and grants Speed II for 4s."),
        8: R("Spacetime Fold: when hit, slow nearby hostile mobs (16 damage), blink 6 blocks away, recover HP lost in the last 6s (up to 25% max HP) and take -35% damage for 5s. (50s cooldown)"),
    },
    // ── Awaken / Melodious / Genesis (Fusion) ──
    eclipse: {
        2: R("Damage dealt +18%. Fire, magic, lightning & Wither damage taken -25%."),
        4: R("25% chance to ignite and blind the target on hit and chain 8 damage to a nearby hostile mob. Heal 10% of damage dealt."),
        6: R("Corona: hostile mobs within 6 blocks burn, are weakened and take 4 damage every second; heal yourself and nearby players 2% max HP every second."),
        8: R("Totality: when hit, blast nearby hostile mobs (30 damage + ignite + blind + weaken), take -50% damage and deal +30% damage for 6s, heal nearby players 12% and cleanse debuffs. (40s cooldown)"),
    },
    samsara: {
        2: R("Regenerate 1.0% max HP every second. Wither, magic, drowning & fall damage taken -35%."),
        4: R("Killing an enemy heals 8% max HP. Soul Harvest: each kill grants a soul (max 15, 25s) for +2% damage each. 25% chance to heal 5% max HP on hit."),
        6: R("Soul Tide: hostile mobs within 7 blocks are withered and take 3 damage every second; heal yourself and nearby players 2.5% max HP every second and cleanse your debuffs."),
        8: R("Reincarnation: at 30% HP or lower, heal 60% max HP, blast nearby hostile mobs (20 damage + wither), cleanse debuffs and take -65% damage for 7s. (150s cooldown) Revive: a fatal hit instead leaves you at 40% max HP with 3s invulnerability. (300s cooldown)"),
    },
    cosmos: {
        2: R("8% chance to dodge attacks. Fall, explosion & Void damage taken -45%. Permanent Speed II."),
        4: R("25% chance to slow and weaken the target and chain 10 damage to 2 nearby hostile mobs on hit. Damage dealt +10%."),
        6: R("Event Horizon: hostile mobs within 7 blocks are pulled in, slowed and take 4 damage every second. Dodge chance +6%."),
        8: R("Singularity: when hit, blast & pull nearby hostile mobs (34 damage + slow + weaken) and hold them in place for 2s, gain Speed III for 6s and take -45% damage for 6s. (45s cooldown)"),
    },
    eternity: {
        2: R("Permanent Speed II. Magic, Wither, projectile & fall damage taken -30%. 8% chance to dodge attacks and sidestep 4 blocks."),
        4: R("35% chance to heavily slow the target and cut all Chorus burst cooldowns by 4s. Chain 10 damage to a nearby hostile mob on hit."),
        6: R("Chrono Drift: Sprint + Jump to Blink up to 12 blocks forward. (4s cooldown) Hostile mobs within 6 blocks are slowed and weakened. Killing an enemy cuts cooldowns by 10s and grants Speed II for 4s."),
        8: R("Temporal Collapse: when hit, freeze nearby hostile mobs for 4s (14 damage), blink 8 blocks away, recover HP lost in the last 10s (up to 50% max HP), take -50% damage for 6s and gain Speed III. (60s cooldown)"),
    },
    destiny: {
        2: R("Damage dealt +22%. Regenerate 1.2% max HP every second. Fire, magic, lightning & Wither damage taken -35%."),
        4: R("Fate's Mark: 30% chance to mark the target (it takes +15% damage from you for 6s). Heal 12% of damage dealt. Soul Harvest: each kill grants a soul (max 20, 25s) for +2% damage each."),
        6: R("Verdict: damage dealt +40% to enemies below 40% HP. Killing an enemy heals 10% max HP and cuts cooldowns by 6s. Hostile mobs within 7 blocks take 5 damage every second; heal yourself and nearby players 3% max HP every second."),
        8: R("Fate Decreed: when hit, blast nearby hostile mobs (45 damage + ignite + wither + blind), execute non-boss mobs below 15% HP, take -60% damage for 7s, deal +40% damage for 8s, heal nearby players 15% and cleanse debuffs. (45s cooldown) Revive: a fatal hit instead leaves you at 50% max HP with 4s invulnerability. (240s cooldown)"),
    },
    infinity: {
        2: R("10% chance to dodge attacks and sidestep 5 blocks. Permanent Speed II. Fall, explosion, projectile, Void & magic damage taken -40%."),
        4: R("35% chance to heavily slow and weaken the target, chain 12 damage to 3 nearby hostile mobs and cut Chorus burst cooldowns by 6s."),
        6: R("Sprint + Jump to Blink up to 15 blocks forward. (3s cooldown) Hostile mobs within 8 blocks are pulled in, slowed and take 5 damage every second. Killing an enemy cuts cooldowns by 12s."),
        8: R("Infinite Loop: when hit, freeze & pull nearby hostile mobs for 5s (50 damage), blink 10 blocks away, recover HP lost in the last 12s (up to 60% max HP), take -55% damage for 7s and gain Speed III for 8s. (70s cooldown)"),
    },
    genesis: {
        2: R("Damage dealt +30%. Regenerate 1.5% max HP every second. Fire, magic, Wither, lightning, explosion, projectile, fall & Void damage taken -30%. 10% chance to dodge attacks."),
        4: R("Origin Strike: 35% chance to mark, weaken and slow the target, chain 15 damage to 3 nearby hostile mobs and cut Chorus burst cooldowns by 5s. Heal 15% of damage dealt."),
        6: R("Creation: hostile mobs within 8 blocks are slowed, weakened and take 6 damage every second; heal yourself and nearby players 4% max HP every second and cleanse debuffs. Sprint + Jump to Blink up to 15 blocks forward. (4s cooldown) Killing an enemy heals 12% max HP and cuts cooldowns by 15s."),
        8: R("Big Bang: when hit, blast & pull nearby hostile mobs (70 damage + ignite + wither + freeze 3s), take -70% damage for 8s, deal +50% damage for 10s, heal nearby players 20%, cleanse debuffs and recover HP lost in the last 12s (up to 60% max HP). (60s cooldown) Revive: a fatal hit instead leaves you at 60% max HP with 5s invulnerability. (180s cooldown)"),
    },
};

export function getEffect(setId, threshold) {
    const e = CHORUS_EFFECTS[setId]?.[threshold];
    return e ?? { desc: "???", ready: false };
}
