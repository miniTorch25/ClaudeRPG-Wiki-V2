import { RUNES as _RUNES } from "./rune_catalog.js";
// synergy_config.js -- Chorus Synergy (v1_21): Gem skills and Runes grow stronger and gain
// extra effects when the player's armor carries a MATCHING Chorus element.
//
// How it works (all numbers below are editable):
//   1. Every Gem skill / Rune lists the elements it has an "affinity" with.
//   2. The number of armor sockets (0-8) holding any of those elements is the Synergy count.
//   3. LEVEL BONUS (Runes only; Gems have no levels): count 2 / 4 / 8 raises the Rune's effective Level by
//      1 / 2 / 3 (max VIII). A Transcend element as the main match adds TRANSCEND_EXTRA_LEVEL once count >= 4,
//      and 4+ Genesis sockets add GENESIS_EXTRA_LEVEL on top.
//      Fused elements count as their parent elements: Awaken = 2, Melodious = 4, Genesis = all 8 Transcend.
//   4. RIDER: from RIDER_MIN_SLOTS on, the strongest matching element adds a bonus effect:
//        offense ("hit")   -> ELEMENT_HIT   : when you hit an enemy with the Rune / Gem skill
//        defense ("guard") -> ELEMENT_GUARD : when an enemy hits you while the Gem skill is on
//      Chance and numbers grow with RIDER_SCALE (4 / 6 / 8 sockets).
// Hybrid sets count normally: each socket counts for its own element (Steam = Fire + Water).

export const SYNERGY = {
    ENABLED: true,
    CACHE_TICKS: 10,                       // Chorus loadout re-read at most this often
    LEVEL_BONUS: { 2: 1, 4: 2, 8: 3 },     // matching sockets -> extra levels (best step reached)
    TRANSCEND_EXTRA_LEVEL: 1,
    GENESIS_EXTRA_LEVEL: 1,                // extra level when 4+ armor sockets are Genesis (needs count >= 4)
    GENESIS_MIN_SOCKETS: 4,
    RIDER_MIN_SLOTS: 4,
    RIDER_SCALE: { 4: 1, 6: 1.25, 8: 1.5 },
    RIDER_COOLDOWN_TICKS: 20,              // per player, per rider kind
    MAX_BONUS_DAMAGE_PCT: 25,              // total Synergy damage bonus never exceeds this
};

// --- Offense riders: element -> effect on a HIT -----------------------------------------
// chance %, burn (s), target:[effect, ticks, amp], self:[effect, ticks, amp],
// healPct (% of Max HP), bonusPct (% extra damage, always applies)
export const ELEMENT_HIT = {
    fire:      { chance: 35, burn: 3 },
    water:     { chance: 30, target: ["slowness", 40, 0] },
    wind:      { chance: 20, self: ["speed", 60, 0] },
    earth:     { chance: 25, target: ["slowness", 30, 1] },
    lightning: { bonusPct: 8, chance: 20, target: ["slowness", 20, 0] },
    frost:     { chance: 40, target: ["slowness", 60, 1] },
    gale:      { chance: 25, self: ["speed", 60, 1] },
    metal:     { bonusPct: 10 },
    light:     { bonusPct: 6, chance: 20, healPct: 2 },
    dark:      { chance: 25, target: ["blindness", 40, 0] },
    divine:    { bonusPct: 6, chance: 20, healPct: 3 },
    demon:     { bonusPct: 8, chance: 30, burn: 2 },
    life:      { chance: 25, healPct: 2 },
    death:     { chance: 30, target: ["wither", 60, 0] },
    star:      { bonusPct: 10 },
    void:      { bonusPct: 6, chance: 30, target: ["weakness", 60, 0] },
    dimension: { bonusPct: 8, chance: 15, target: ["slowness", 30, 2] },
    time:      { chance: 20, target: ["slowness", 30, 2], self: ["speed", 40, 0] },
};

// --- Defense riders: element -> effect when an enemy HITS YOU --------------------------
// chance %, burnAttacker (s), attacker:[effect, ticks, amp], self:[effect, ticks, amp],
// healPct (% of Max HP)
export const ELEMENT_GUARD = {
    fire:      { chance: 30, burnAttacker: 3 },
    water:     { chance: 25, self: ["regeneration", 60, 0] },
    wind:      { chance: 25, self: ["speed", 60, 0] },
    earth:     { chance: 25, self: ["resistance", 60, 0] },
    lightning: { chance: 30, attacker: ["slowness", 40, 0] },
    frost:     { chance: 35, attacker: ["slowness", 60, 1] },
    gale:      { chance: 25, self: ["speed", 60, 1] },
    metal:     { chance: 25, self: ["resistance", 60, 0] },
    light:     { chance: 25, healPct: 3 },
    dark:      { chance: 25, attacker: ["blindness", 40, 0] },
    divine:    { chance: 25, healPct: 4 },
    demon:     { chance: 30, attacker: ["weakness", 60, 0] },
    life:      { chance: 30, healPct: 3 },
    death:     { chance: 30, attacker: ["wither", 60, 0] },
    star:      { chance: 25, self: ["absorption", 80, 0] },
    void:      { chance: 30, attacker: ["weakness", 60, 0] },
    dimension: { chance: 25, self: ["absorption", 80, 0] },
    time:      { chance: 25, attacker: ["slowness", 30, 2] },
};

// --- Gem skills: skill id -> { kind: "hit" | "guard", elements } ---------------------------
export const GEM_AFFINITY = {
    // offense
    brawler:             { kind: "hit", elements: ["fire", "metal", "earth"] },
    brute_force:         { kind: "hit", elements: ["earth", "metal", "demon"] },
    marksman:            { kind: "hit", elements: ["wind", "light", "star"] },
    eagle_eye:           { kind: "hit", elements: ["wind", "light", "dimension"] },
    assassination:       { kind: "hit", elements: ["dark", "void", "death", "metal"] },
    adrenaline:          { kind: "hit", elements: ["wind", "gale", "lightning", "fire"] },
    killers_rush:        { kind: "hit", elements: ["death", "demon", "gale"] },
    executioners_gait:   { kind: "hit", elements: ["death", "dark", "demon"] },
    warpath:             { kind: "hit", elements: ["fire", "demon", "metal"] },
    overpower:           { kind: "hit", elements: ["metal", "fire", "earth"] },
    momentum_strike:     { kind: "hit", elements: ["wind", "gale", "lightning"] },
    rampage:             { kind: "hit", elements: ["demon", "fire", "death"] },
    thunder_stride:      { kind: "hit", elements: ["lightning", "gale", "metal"] },
    bloodthirst:         { kind: "hit", elements: ["death", "demon", "life"] },
    vampirism:           { kind: "hit", elements: ["death", "dark", "demon", "life"] },
    static_field:        { kind: "hit", elements: ["lightning", "gale", "metal"] },
    berserker:           { kind: "hit", elements: ["fire", "demon", "death"] },
    warlords_might:      { kind: "hit", elements: ["metal", "earth", "demon"] },
    reapers_due:         { kind: "hit", elements: ["death", "dark", "life"] },
    dragons_gaze:        { kind: "hit", elements: ["fire", "star", "light"] },
    third_eye:           { kind: "hit", elements: ["void", "star", "dimension", "light"] },
    frostflare:          { kind: "hit", elements: ["frost", "water", "fire"] },
    cinderveil:          { kind: "hit", elements: ["fire", "demon", "dark"] },
    domain:              { kind: "hit", elements: ["star", "divine", "void", "dimension", "time"] },
    // defense
    vitality:            { kind: "guard", elements: ["life", "earth", "divine"] },
    hearty:              { kind: "guard", elements: ["life", "earth", "water"] },
    fortitude:           { kind: "guard", elements: ["life", "earth", "metal"] },
    toughness:           { kind: "guard", elements: ["metal", "earth"] },
    resolve:             { kind: "guard", elements: ["metal", "divine", "earth"] },
    tenacity:            { kind: "guard", elements: ["earth", "metal", "life"] },
    recovery:            { kind: "guard", elements: ["life", "water", "light"] },
    vigor:               { kind: "guard", elements: ["life", "water", "divine"] },
    swiftness:           { kind: "guard", elements: ["wind", "gale", "lightning"] },
    swift_strides:       { kind: "guard", elements: ["wind", "gale", "time"] },
    intuition:           { kind: "guard", elements: ["light", "star", "wind"] },
    reflexes:            { kind: "guard", elements: ["light", "wind", "time"] },
    keen_eyes:           { kind: "guard", elements: ["light", "star", "dark"] },
    focus:               { kind: "guard", elements: ["water", "star", "divine"] },
    mana_trickle:        { kind: "guard", elements: ["water", "light", "star"] },
    clear_mind:          { kind: "guard", elements: ["water", "light", "divine"] },
    arcane_reservoir:    { kind: "guard", elements: ["star", "divine", "void"] },
    spell_ward:          { kind: "guard", elements: ["divine", "light", "void"] },
    spellbreaker:        { kind: "guard", elements: ["metal", "void", "divine"] },
    padded_plate:        { kind: "guard", elements: ["earth", "metal"] },
    stoneskin:           { kind: "guard", elements: ["earth", "metal"] },
    plate_wall:          { kind: "guard", elements: ["metal", "earth"] },
    sure_step:           { kind: "guard", elements: ["earth", "metal"] },
    soft_landing:        { kind: "guard", elements: ["wind", "gale"] },
    cats_grace:          { kind: "guard", elements: ["wind", "gale", "dimension"] },
    thorns:              { kind: "guard", elements: ["metal", "lightning", "earth"] },
    marathon:            { kind: "guard", elements: ["wind", "life", "water"] },
    aqua_lung:           { kind: "guard", elements: ["water", "frost"] },
    sanctuary:           { kind: "guard", elements: ["earth", "metal", "divine"] },
    arcane_surge:        { kind: "guard", elements: ["star", "void", "dimension"] },
    clairvoyance:        { kind: "guard", elements: ["light", "star", "divine"] },
    spell_mirror:        { kind: "guard", elements: ["void", "dimension", "light"] },
    reflection:          { kind: "guard", elements: ["metal", "lightning", "dark"] },
    second_wind:         { kind: "guard", elements: ["life", "light", "divine"] },
    glacial_presence:    { kind: "guard", elements: ["frost", "water"] },
    wind_walker:         { kind: "guard", elements: ["wind", "gale"] },
    frost_walker:        { kind: "guard", elements: ["frost", "water"] },
    evasion:             { kind: "guard", elements: ["wind", "dark", "time"] },
    immunity:            { kind: "guard", elements: ["divine", "life", "light"] },
    lucid_mind:          { kind: "guard", elements: ["time", "star", "divine"] },
    soulward:            { kind: "guard", elements: ["divine", "death", "light"] },
    guardian_shield:     { kind: "guard", elements: ["divine", "light", "star"] },
    bulletproof:         { kind: "guard", elements: ["metal", "earth"] },
    unyielding:          { kind: "guard", elements: ["earth", "metal", "divine"] },
    void_escape:         { kind: "guard", elements: ["void", "dimension", "time"] },
    skystep:             { kind: "guard", elements: ["wind", "gale", "dimension"] },
    quicksilver:         { kind: "guard", elements: ["metal", "gale", "time"] },
    archmages_crown:     { kind: "guard", elements: ["star", "divine", "void"] },
    premonition:         { kind: "guard", elements: ["time", "star", "light"] },
    titan_heart:         { kind: "guard", elements: ["life", "earth", "divine"] },
    flight:              { kind: "guard", elements: ["wind", "gale", "star"] },
    phase_step:          { kind: "guard", elements: ["void", "dimension", "dark"] },
    earthshaker:         { kind: "guard", elements: ["earth", "lightning", "metal"] },
    ascended_mind:       { kind: "guard", elements: ["star", "divine", "time"] },
    mind_over_matter:    { kind: "guard", elements: ["star", "void", "divine"] },
    undying:             { kind: "guard", elements: ["life", "death", "time"] },
    colossus:            { kind: "guard", elements: ["earth", "divine", "metal"] },
    godspeed:            { kind: "guard", elements: ["gale", "time", "wind"] },
    voidstep:            { kind: "guard", elements: ["void", "dimension", "time"] },
    earthbound:          { kind: "guard", elements: ["earth", "metal"] },
};

// --- Runes: rune id -> elements (all Runes ride ELEMENT_HIT) --------------------------------
// Runes: rune id -> elements (all Runes ride ELEMENT_HIT). Generated from config/rune_catalog.js.
export const RUNE_AFFINITY = Object.fromEntries(_RUNES.map((r) => [r.id, r.elements]));
