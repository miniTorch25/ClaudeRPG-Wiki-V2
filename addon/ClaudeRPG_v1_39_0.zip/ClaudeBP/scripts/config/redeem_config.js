export const REDEEM_CONFIG = {
    "WELCOME2026": {
        message: "§aHappy 2026!",
        items: [
            { item: "minecraft:diamond", amount: 5 },
            { item: "minecraft:golden_apple", amount: 2 }
        ],
        maxUses: 1
    },
    "DAILY": {
        message: "§aHere's your daily bonus!",
        items: [
            { item: "minecraft:emerald", amount: 1 }
        ],
        maxUses: 999
    },
    "REFORGE" : {
        message:  "§aReforging Time! Don't forget the anvil!",
        items: [
            { item: "crpg:reforge_hammer", amount: 1}
        ],
        maxUses: 1
    },
    "CLAUDERPG" : {
        message:  "§aThanks for playing ClaudeRPG!",
        items: [
            { item: "crpg:uncarved_gem", amount: 4}
        ],
        maxUses: 1
    },
    "DIRT" : {
        message: "Dirt",
        items: [
            { item: "minecraft:dirt", amount: 64}
        ],
        maxUses: 32767
    },
    "miniTorch25" : {
        message: "Thank you for still thinking of me, to the point of writing my name in the redeem.",
        items: [
            { item: "crpg:unique_gem", amount: 2},
            { item: "minecraft:emerald_block", amount: 1},
            { item: "minecraft:golden_apple", amount: 12}
        ],
        maxUses: 1
    }
};
