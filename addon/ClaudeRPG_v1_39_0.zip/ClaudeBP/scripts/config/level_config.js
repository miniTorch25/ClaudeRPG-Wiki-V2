// level_config.js -- Level scaling for Runes.
//
// Runes have 8 levels. The values in rune_config.js are the reference (Level IV = 100% of the
// base values); a level multiplies only the *power* keys listed below (damage, heal,
// reduction, proc chance...). Costs, cooldowns, radii, caps and timers stay fixed.
//   Lv1 x0.25 | Lv2 x0.5 | Lv3 x0.75 | Lv4 x1.0 (base) | Lv5 x1.25 | Lv6 x1.5 | Lv7 x2.0 | Lv8 x2.5
//
// How a level scales each kind of rune:
//   positive : every power key x m
//   neutral  : the good side x m, the bad side (RUNE_NEG_KEYS) at half rate: 1 + (m - 1) x 0.5
//   curse    : the penalty x m in full (higher level = harsher), and Mastery / Synergy / perk bonuses
//              never add levels or effect to a curse
//
// Where levels come from: every normal source (Rune Enchanting, tier pick) gives Level I. Rune Mastery
// (up to +4) and Chorus Synergy (up to +3) raise the level of a held positive / neutral rune on top
// of that, so Level VIII needs both at their maximum.
// Gems have NO levels any more: a Gem skill has fixed values, and Gem Mastery adds "Gem Potency"
// (see gem_ability_config.js).

export const MAX_LEVEL     = 8;
export const DEFAULT_LEVEL = 1;
// Rune levels are shown as "Lv 1" ... "Lv 8" (the export keeps its old name so older imports still work).
export const LEVEL_LABEL   = { 1: "Lv 1", 2: "Lv 2", 3: "Lv 3", 4: "Lv 4", 5: "Lv 5", 6: "Lv 6", 7: "Lv 7", 8: "Lv 8" };
export const LEVEL_ROMAN   = LEVEL_LABEL;

export const RUNE_LEVEL_PROP_KEY = "crpg:rune_level";

export const RUNE_LEVEL_MULT = { 1: 0.25, 2: 0.5, 3: 0.75, 4: 1.0, 5: 1.25, 6: 1.5, 7: 2.0, 8: 2.5 };

export function clampLevel(level) {
    const n = Math.floor(Number(level));
    if (!Number.isFinite(n)) return DEFAULT_LEVEL;
    return Math.min(MAX_LEVEL, Math.max(1, n));
}

export const RUNE_SCALED_KEYS = {};   // v6 runes scale in rune_effects.js
export const RUNE_NEG_KEYS = {};

// Multiplier applied to the bad side of a neutral rune: 1 + (m - 1) x 0.5
export function halfRate(m) { return 1 + (m - 1) * 0.5; }

function scaleValue(v, mode, m) {
    if (typeof v !== "number") return v;
    if (mode === "mult") return Math.round((1 + (v - 1) * m) * 100) / 100;
    if (mode === "int")  return Math.max(1, Math.round(v * m));
    const r = v * m;
    return v >= 10 ? Math.round(r) : Math.round(r * 100) / 100;
}

// Scales one Rune entry by level multiplier `levelMult` (+ `effectPct` Rune Effect bonus) following the kind rules above.
// kind: "positive" | "neutral" | "curse". Curses ignore effectPct.
export function scaleRuneEntry(base, runeId, levelMult, effectPct = 0, kind = "positive") {
    if (!base) return base;
    const goodMult = levelMult * (kind === "curse" ? 1 : 1 + effectPct / 100);
    let out = scaleEntry(base, RUNE_SCALED_KEYS[runeId], goodMult);
    if (kind === "neutral" && RUNE_NEG_KEYS[runeId]?.length) out = scaleEntry(out, RUNE_NEG_KEYS[runeId], halfRate(levelMult));
    return out;
}

// Returns a scaled shallow copy of one Rune (level) / Gem (Potency) config entry.
export function scaleEntry(base, keys, mult) {
    if (!base || !keys?.length) return base;
    const out = { ...base };
    for (const spec of keys) {
        const [key, mode] = spec.split(":");
        if (key in out) out[key] = scaleValue(out[key], mode, mult);
    }
    return out;
}
