// lore_wrap.js -- splits long Rune / Gem lore lines into several shorter lines.
// Colour/format codes are carried onto every continuation line so the text keeps its style.

export const LORE_WRAP_WIDTH = 40;   // max visible characters per line (§ codes are not counted)

const FORMAT_CODES = "klmno";

function visibleLength(s) {
    return s.replace(/§./g, "").length;
}

// Applies every § code found in `text` to the running style state.
function applyCodes(state, text) {
    const re = /§(.)/g;
    let m;
    while ((m = re.exec(text)) !== null) {
        const c = m[1].toLowerCase();
        if (c === "r")                    { state.color = ""; state.fmts = ""; }
        else if (FORMAT_CODES.includes(c)) { if (!state.fmts.includes(c)) state.fmts += c; }
        else                               { state.color = c; state.fmts = ""; }
    }
}

function stylePrefix(state) {
    return "§r" + (state.color ? "§" + state.color : "") + [...state.fmts].map((f) => "§" + f).join("");
}

export function wrapLoreLine(line, width = LORE_WRAP_WIDTH) {
    if (typeof line !== "string" || visibleLength(line) <= width) return [line];

    const lead = line.match(/^(?:§.)*/)[0];               // e.g. "§r§8"
    const body = line.slice(lead.length);
    const words = body.split(" ");

    const state = { color: "", fmts: "" };
    applyCodes(state, lead);

    const out = [];
    let current = lead;
    let currentLen = 0;

    for (const word of words) {
        const wLen = visibleLength(word);
        const sep  = currentLen > 0 ? 1 : 0;
        if (currentLen > 0 && currentLen + sep + wLen > width) {
            out.push(current);
            current = stylePrefix(state);
            currentLen = 0;
        }
        current += (currentLen > 0 ? " " : "") + word;
        currentLen += (currentLen > 0 ? 1 : 0) + wLen;
        applyCodes(state, word);
    }
    if (currentLen > 0) out.push(current);
    return out;
}

export function wrapLoreLines(lines, width = LORE_WRAP_WIDTH) {
    return lines.flatMap((l) => wrapLoreLine(l, width));
}
