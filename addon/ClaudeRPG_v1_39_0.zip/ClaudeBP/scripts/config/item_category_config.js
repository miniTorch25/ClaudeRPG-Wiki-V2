// item_category_config.js — Item categories (4 groups, 21 kinds).
//
//   Weapon     : sword | bow | spear | trident | mace | magic
//   Tool       : pickaxe | axe | shovel | hoe | shears
//   Armor      : helmet | chestplate | leggings | boots | shield
//   Consumable : food | drink | ammo | gem | rune
//
// This only ADDS a finer classification on top of ITEM_REQUIREMENTS[typeId].type
// (melee | ranged | armor | tool), which the older systems keep using.
// Rune rule: only Weapon + Tool (shears excluded) can hold a Rune. Armor, Consumable and Shears cannot.

import { ITEM_REQUIREMENTS } from "./req_config.js";
import { getToolCategory } from "./tool_config.js";

export const ITEM_GROUPS = {
    weapon:     { color: "§c", label: { en: "Weapon",     th: "อาวุธ" },       kinds: ["sword", "bow", "spear", "trident", "mace", "magic"] },
    tool:       { color: "§e", label: { en: "Tool",       th: "เครื่องมือ" },  kinds: ["pickaxe", "axe", "shovel", "hoe", "shears"] },
    armor:      { color: "§9", label: { en: "Armor",      th: "เกราะ" },       kinds: ["helmet", "chestplate", "leggings", "boots", "shield"] },
    consumable: { color: "§a", label: { en: "Consumable", th: "ไอเทมใช้งาน" }, kinds: ["food", "drink", "ammo", "gem", "rune"] },
};

export const ITEM_KIND_LABELS = {
    sword:      { en: "Sword",      th: "ดาบ" },
    bow:        { en: "Bow",        th: "ธนู" },
    spear:      { en: "Spear",      th: "หอก" },
    trident:    { en: "Trident",    th: "ตรีศูล" },
    mace:       { en: "Mace",       th: "กระบอง" },
    magic:      { en: "Magic",      th: "เวท" },
    pickaxe:    { en: "Pickaxe",    th: "พิกแอ็กซ์" },
    axe:        { en: "Axe",        th: "ขวาน" },
    shovel:     { en: "Shovel",     th: "พลั่ว" },
    hoe:        { en: "Hoe",        th: "จอบ" },
    shears:     { en: "Shears",     th: "กรรไกร" },
    helmet:     { en: "Helmet",     th: "หมวก" },
    chestplate: { en: "Chestplate", th: "เกราะ" },
    leggings:   { en: "Leggings",   th: "กางเกง" },
    boots:      { en: "Boots",      th: "รองเท้า" },
    shield:     { en: "Shield",     th: "โล่" },
    food:       { en: "Food",       th: "อาหาร" },
    drink:      { en: "Drink",      th: "เครื่องดื่ม" },
    ammo:       { en: "Ammo",       th: "กระสุน" },
    gem:        { en: "Gem",        th: "มณี" },
    rune:       { en: "Rune",       th: "รูน" },
};

// ── Weapon: custom / future items that can't be recognised from the vanilla id ──
// Add "crpg:..." ids here later (Class system weapons: wand, staff, orb ...).
export const MAGIC_WEAPON_IDS = new Set([]);

// ── Consumables that are not vanilla food ────────────────────────────────────
const DRINK_IDS = new Set([
    "minecraft:potion", "minecraft:splash_potion", "minecraft:lingering_potion",
    "minecraft:milk_bucket", "minecraft:honey_bottle", "minecraft:ominous_bottle",
]);
const AMMO_IDS = new Set([
    "minecraft:arrow", "minecraft:spectral_arrow", "minecraft:tipped_arrow", "minecraft:firework_rocket",
]);
const GEM_IDS = new Set([
    "crpg:uncarved_gem", "crpg:gem_dust",
    "crpg:common_gem", "crpg:uncommon_gem", "crpg:rare_gem", "crpg:epic_gem",
    "crpg:legend_gem", "crpg:myth_gem", "crpg:unique_gem",
]);
// Rune ITEMS (added in the Rune update). Matches crpg:rune and any crpg:rune_* id.
const isRuneItemId = (id) => id === "crpg:rune" || id.startsWith("crpg:rune_");
// Vanilla edible items that do not carry the food component in older packs.
const FOOD_FALLBACK_IDS = new Set([
    "minecraft:apple", "minecraft:golden_apple", "minecraft:enchanted_golden_apple", "minecraft:bread",
    "minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:cooked_chicken", "minecraft:cooked_mutton",
    "minecraft:cooked_rabbit", "minecraft:cooked_cod", "minecraft:cooked_salmon", "minecraft:baked_potato",
    "minecraft:carrot", "minecraft:golden_carrot", "minecraft:melon_slice", "minecraft:cookie",
    "minecraft:pumpkin_pie", "minecraft:mushroom_stew", "minecraft:rabbit_stew", "minecraft:beetroot_soup",
    "minecraft:suspicious_stew", "minecraft:dried_kelp", "minecraft:sweet_berries", "minecraft:glow_berries",
    "minecraft:beef", "minecraft:porkchop", "minecraft:chicken", "minecraft:mutton", "minecraft:rabbit",
    "minecraft:cod", "minecraft:salmon", "minecraft:potato", "minecraft:poisonous_potato", "minecraft:beetroot",
    "minecraft:rotten_flesh", "minecraft:spider_eye", "minecraft:chorus_fruit", "minecraft:tropical_fish",
    "minecraft:pufferfish", "minecraft:cake",
]);

// Returns { group, kind } or null. `itemStack` is optional and only used to detect edible custom items.
export function getItemKind(typeId, itemStack = null) {
    if (!typeId || typeof typeId !== "string") return null;
    const sid = typeId.includes(":") ? typeId.split(":", 2)[1] : typeId;

    // Consumables first (custom ids are explicit, so there is no clash with tools/weapons)
    if (isRuneItemId(typeId)) return { group: "consumable", kind: "rune" };
    if (GEM_IDS.has(typeId))  return { group: "consumable", kind: "gem" };

    // Armor
    if (sid === "shield")           return { group: "armor", kind: "shield" };
    if (sid.endsWith("_helmet"))     return { group: "armor", kind: "helmet" };
    if (sid.endsWith("_chestplate")) return { group: "armor", kind: "chestplate" };
    if (sid.endsWith("_leggings"))   return { group: "armor", kind: "leggings" };
    if (sid.endsWith("_boots"))      return { group: "armor", kind: "boots" };

    // Weapons
    if (MAGIC_WEAPON_IDS.has(typeId)) return { group: "weapon", kind: "magic" };
    if (sid.endsWith("_sword"))      return { group: "weapon", kind: "sword" };
    if (sid.endsWith("_spear"))      return { group: "weapon", kind: "spear" };
    if (sid === "bow" || sid === "crossbow") return { group: "weapon", kind: "bow" };
    if (sid === "trident")           return { group: "weapon", kind: "trident" };
    if (sid === "mace")              return { group: "weapon", kind: "mace" };

    // Tools — only items the add-on tracks (keeps crpg:engraver etc. out of the Tool group)
    if (ITEM_REQUIREMENTS[typeId]?.type === "tool") {
        const tc = getToolCategory(typeId);
        if (tc) return { group: "tool", kind: tc };
    }

    // Ammo / drink / food
    if (AMMO_IDS.has(typeId))  return { group: "consumable", kind: "ammo" };
    if (DRINK_IDS.has(typeId)) return { group: "consumable", kind: "drink" };
    if (FOOD_FALLBACK_IDS.has(typeId)) return { group: "consumable", kind: "food" };
    try {
        if (itemStack?.getComponent?.("minecraft:food")) return { group: "consumable", kind: "food" };
    } catch { /* component not available */ }
    return null;
}

// "Weapon · Sword" style label for GUI lines. lang = "en" | "th".
export function getCategoryLabel(typeId, lang = "en", itemStack = null) {
    const k = getItemKind(typeId, itemStack);
    if (!k) return "";
    const g = ITEM_GROUPS[k.group];
    return `${g.label[lang] ?? g.label.en} · ${ITEM_KIND_LABELS[k.kind][lang] ?? ITEM_KIND_LABELS[k.kind].en}`;
}

// Rune rule: Weapon + Tool (not Shears) that the add-on tracks and that is not flagged noRune.
export function canHoldRune(typeId) {
    const req = ITEM_REQUIREMENTS[typeId];
    if (!req || req.noRune) return false;
    const k = getItemKind(typeId);
    if (!k) return false;
    if (k.group === "weapon") return true;
    return k.group === "tool" && k.kind !== "shears";
}

// Which Rune pool(s) a weapon/tool kind draws from (used by the new Rune roster).
// "all" = the rune works on every weapon; "all_tool" = every tool.
export const KIND_RUNE_POOLS = {
    sword:   ["sword",   "all_weapon"],
    bow:     ["bow",     "all_weapon"],
    spear:   ["spear",   "all_weapon"],
    trident: ["trident", "all_weapon"],
    mace:    ["mace",    "all_weapon"],
    magic:   ["magic",   "all_weapon"],
    pickaxe: ["pickaxe", "all_tool"],
    axe:     ["axe",     "all_tool"],
    shovel:  ["shovel",  "all_tool"],
    hoe:     ["hoe",     "all_tool"],
};
