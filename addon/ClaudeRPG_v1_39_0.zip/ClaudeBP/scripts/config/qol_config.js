// qol_config.js -- quality-of-life features (Admin Config Editor, group "Quality of Life").
export const STASH = {
    ENABLED: 1,
    RADIUS: 5,                 // blocks around the player that are searched for containers
    COOLDOWN_SEC: 2,           // per player, stops button spam
    MAX_CONTAINERS: 8,         // nearest containers that are used
    SKIP_LORE: 1,              // 1 = never move items that have lore (runes, gems, augments, reforged gear)
    CONTAINERS: ["minecraft:chest", "minecraft:trapped_chest", "minecraft:barrel"],
};

// Auto-Replant: harvesting a fully grown crop with a Hoe plants it again, using one seed taken from the
// drops on the ground (or from the inventory if nothing suitable dropped). Needs the Re-Crops Rune on the Hoe.
export const REPLANT = {
    ENABLED: 1,
    REQUIRE_HOE: 1,            // 1 = only when the tool is a Hoe
    USE_INVENTORY: 1,          // 1 = fall back to a seed in the inventory when no seed dropped
    DROP_RADIUS: 2,            // blocks around the crop searched for the dropped seed
    DELAY_TICKS: 2,            // wait so the drops exist before looking for them
    // crop block -> { seed item, soil blocks it can grow on }
    CROPS: {
        "minecraft:wheat":       { seed: "minecraft:wheat_seeds",    soil: ["minecraft:farmland"] },
        "minecraft:carrots":     { seed: "minecraft:carrot",         soil: ["minecraft:farmland"] },
        "minecraft:potatoes":    { seed: "minecraft:potato",         soil: ["minecraft:farmland"] },
        "minecraft:beetroot":    { seed: "minecraft:beetroot_seeds", soil: ["minecraft:farmland"] },
        "minecraft:nether_wart": { seed: "minecraft:nether_wart",    soil: ["minecraft:soul_sand"] },
    },
};

// Chorus Aura: cosmetic particles around a player wearing Chorus armor. No stat effect at all.
// The aura shows the player's strongest set (hybrid sets alternate between their two elements).
export const CHORUS_AURA = {
    ENABLED: 1,
    MIN_SLOTS: 2,              // element slots a set needs before the aura appears (2 = first threshold)
    PER_TICK: 2,               // base particles per pulse (every 10 ticks); higher tiers add more
    REFRESH_TICKS: 40,         // how often the worn set is re-read
    RADIUS: 0.8,
    FALLBACK: "minecraft:villager_happy",
    // Best-effort vanilla particle ids; an id the game does not know simply shows nothing.
    PARTICLES: {
        fire: "minecraft:basic_flame_particle",   water: "minecraft:water_splash_particle", wind: "minecraft:basic_smoke_particle", earth: "minecraft:crop_growth_emitter",
        lightning: "minecraft:electric_spark_particle", frost: "minecraft:snowflake_particle", gale: "minecraft:villager_happy", metal: "minecraft:critical_hit_emitter",
        light: "minecraft:endrod", dark: "minecraft:soul_particle",
        divine: "minecraft:totem_particle", demon: "minecraft:blue_flame_particle", life: "minecraft:heart_particle", death: "minecraft:soul_particle",
        star: "minecraft:endrod", void: "minecraft:basic_portal_particle", dimension: "minecraft:dragon_breath_trail", time: "minecraft:note_particle",
        eclipse: "minecraft:totem_particle", samsara: "minecraft:soul_particle", cosmos: "minecraft:basic_portal_particle", eternity: "minecraft:endrod",
        destiny: "minecraft:totem_particle", infinity: "minecraft:dragon_breath_trail", genesis: "minecraft:endrod",
    },
    TIER_BONUS: { echo: 0, resonance: 1, transcend: 2, awaken: 3, melodious: 4, genesis: 5 },   // extra particles per pulse
};
