// Block type IDs that the Ultimate Picker refuses to pick up.
// Add entries such as "minecraft:bedrock" or "crpg:ultimate_enchanter"
// here to protect specific blocks from being picked up.
export const ULTIMATE_PICKER_BLACKLIST = [
    "minecraft:command_block",
    "minecraft:chain_command_block",
    "minecraft:repeating_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:barrier",
    "minecraft:jigsaw_block",
    "minecraft:deny",
    "minecraft:allow",
    "minecraft:border_block",
];
