// Explicit tool-category overrides for items whose typeId doesn't contain the
// category name (custom items, oddly-named items, etc.).
// Anything not listed here falls back to substring matching in getToolCategory().
export const TOOL_CATEGORY_OVERRIDES = {
    "crpg:engraver": "pickaxe"
};

// Returns "pickaxe" | "axe" | "shovel" | "hoe" | "shears" | undefined.
// "pickaxe" is checked before "axe" since "pickaxe" contains the substring "axe".
export function getToolCategory(itemTypeId) {
    if (!itemTypeId) return undefined;
    if (TOOL_CATEGORY_OVERRIDES[itemTypeId]) return TOOL_CATEGORY_OVERRIDES[itemTypeId];

    if (itemTypeId.includes("shears"))  return "shears";
    if (itemTypeId.includes("pickaxe")) return "pickaxe";
    if (itemTypeId.includes("shovel"))  return "shovel";
    if (itemTypeId.includes("hoe"))     return "hoe";
    if (itemTypeId.includes("axe"))     return "axe";
    return undefined;
}
