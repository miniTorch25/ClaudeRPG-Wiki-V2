// rune_catalog.js — the full Rune roster (115 runes) as data. Pure data: no game imports.
//
// Every rune = id, name, pool, tier (1-7 = grade Gamma..Omega), elements (Chorus Synergy) and
// two effect lists: `good` and `bad`. Curses have `bad` only.
//
// Effect = { fx, v, ...params }. `v` is the magnitude AT Lv 4 (x1.0) and is always written as a
// positive number; the side (good/bad) decides the direction:
//   dmg(10)      good: +10% damage          bad: -10% damage
//   dura(20)     good: -20% durability use  bad: +20% durability use     (lower is better)
//   hunger(15)   good: -15% hunger rate     bad: +15% hunger rate
//   taken(6)     good: -6% damage taken     bad: +6% damage taken
//   manaCost(20) good: -20% Mana cost       bad: +20% Mana cost
// Params that are NOT scaled by level: when, n, sec, cd, per, max, radius, kind.
// Level scaling: good = v x level multiplier (x Rune Effect %), bad = v x penalty factor (LEVEL_PENALTY).
// Curses are never scaled.
//
// `when` = condition (see rune_effects.js COND). `impl` notes where a rune differs from the design text.

export const POOLS = {
    sword:      { label: "Sword",      kind: "weapon" },
    bow:        { label: "Bow",        kind: "weapon" },
    spear:      { label: "Spear",      kind: "weapon" },
    trident:    { label: "Trident",    kind: "weapon" },
    mace:       { label: "Mace",       kind: "weapon" },
    magic:      { label: "Magic",      kind: "weapon" },
    all_weapon: { label: "All-Weapon", kind: "weapon" },
    pickaxe:    { label: "Pickaxe",    kind: "tool" },
    axe:        { label: "Axe",        kind: "tool" },
    shovel:     { label: "Shovel",     kind: "tool" },
    hoe:        { label: "Hoe",        kind: "tool" },
    all_tool:   { label: "All-Tool",   kind: "tool" },
    curse:      { label: "Curse",      kind: "curse" },
};

// Pools that cannot roll yet (no item can hold them). Magic returns with the Class system.
export const DISABLED_POOLS = ["magic"];

// Penalty left at each rune level (design table 4.2). Curses ignore it.
export const LEVEL_PENALTY = { 1: 1.0, 2: 0.8, 3: 0.6, 4: 0.4, 5: 0.25, 6: 0.1, 7: 0, 8: 0 };

const g = (fx, v, o = {}) => ({ fx, v, ...o });

export const RUNES = [];
function def(pool, tier, id, name, elements, good, bad) {
    RUNES.push({ id, name, pool, tier, elements, good, bad });
}

// ═══ Sword ═══════════════════════════════════════════════════════════════════
def("sword", 1, "steadfast",    "Steadfast",     ["earth", "metal", "divine"],  [g("knockRes", 100, { when: "attack", max: 100 })], [g("atkSpeed", 8)]);
def("sword", 2, "cleave",       "Cleave",        ["metal", "wind", "earth"],    [g("splash", 70, { n: 1, radius: 3 })], [g("dmg", 10, { when: "alone" })]);
def("sword", 3, "riposte",      "Riposte",       ["metal", "gale", "light"],    [g("riposte", 30)], [g("dmg", 10, { when: "first" })]);
def("sword", 4, "duelist",      "Duelist",       ["metal", "light", "dark"],    [g("dmg", 20, { when: "alone" })], [g("dmg", 15, { when: "crowd" })]);
def("sword", 5, "bloodied_edge","Bloodied Edge", ["demon", "death", "fire"],    [g("lifesteal", 4)], [g("hunger", 20)]);
def("sword", 6, "finisher",     "Finisher",      ["death", "dark", "demon"],    [g("dmg", 35, { when: "hpLow" })], [g("dmg", 10, { when: "hpFull" })]);
def("sword", 7, "wind_slash",   "Wind Slash",    ["wind", "gale", "metal"],     [g("wave", 80, { n: 4, len: 5 })], [g("dmg", 8, { when: "offBeat" })]);

// ═══ Bow ═════════════════════════════════════════════════════════════════════
def("bow", 1, "heavy_quiver",  "Heavy Quiver",  ["metal", "earth", "wind"],    [g("ammoSave", 15, { max: 100 })], [g("speed", 6)]);
def("bow", 2, "quickdraw",     "Quickdraw",     ["lightning", "gale", "time"], [g("atkSpeed", 20)], [g("dmg", 8)]);
def("bow", 3, "steady_aim",    "Steady Aim",    ["light", "star", "time"],     [g("dmg", 12, { when: "still" })], [g("dmg", 8, { when: "moving" })]);
def("bow", 4, "eagle_eye",     "Eagle Eye",     ["light", "star", "wind"],     [g("dmgRange", 30)], [g("dmg", 20, { when: "close" })]);
def("bow", 5, "piercing_shot", "Piercing Shot", ["metal", "light", "wind"],    [g("splash", 70, { n: 1, radius: 4 })], [g("atkSpeed", 10)]);
def("bow", 6, "ricochet",      "Ricochet",      ["metal", "lightning", "dimension"], [g("splash", 60, { n: 1, radius: 6 })], [g("dmg", 10)]);
def("bow", 7, "windrider",     "Windrider",     ["wind", "gale", "star"],      [g("dmg", 15, { when: "fullCharge" })], [g("dmg", 5, { when: "notFull" })]);

// ═══ Spear ═══════════════════════════════════════════════════════════════════
def("spear", 1, "phalanx",  "Phalanx",  ["metal", "earth", "divine"],  [g("taken", 6)], [g("speed", 5)]);
def("spear", 2, "reach",    "Reach",    ["wind", "metal", "light"],    [g("dmg", 7, { when: "far" })], [g("atkSpeed", 8)]);
def("spear", 3, "skewer",   "Skewer",   ["death", "metal", "demon"],   [g("proc", 100, { kind: "bleed", sec: 3, max: 100 })], [g("dmg", 8)]);
def("spear", 4, "vault",    "Vault",    ["gale", "wind", "earth"],     [g("dmg", 25, { when: "run" })], [g("hunger", 15)]);
def("spear", 5, "impale",   "Impale",   ["metal", "earth", "light"],   [g("splash", 120, { n: 1, radius: 3, line: true })], [g("dmg", 6, { when: "crowd" })]);
def("spear", 6, "lancer",   "Lancer",   ["metal", "gale", "divine"],   [g("dmg", 40, { when: "run" })], [g("dmg", 10, { when: "still" })]);
def("spear", 7, "hooked",   "Hooked",   ["metal", "dimension", "void"],[g("pull", 1, { cd: 4 })], [g("note", 0, { txt: "Pull has a 4s cooldown" })]);

// ═══ Trident ═════════════════════════════════════════════════════════════════
def("trident", 1, "silent_edge",   "Silent Edge",   ["dark", "void", "wind"],      [g("dmg", 50, { when: "firstSneak" })], [g("dmg", 8, { when: "noSneak" })]);
def("trident", 2, "harvest",       "Harvest",       ["death", "life", "dark"],     [g("killHeal", 2)], [g("dmg", 10, { when: "boss" })]);
def("trident", 3, "backstab",      "Backstab",      ["dark", "void", "metal"],     [g("dmg", 40, { when: "behind" })], [g("dmg", 10, { when: "front" })]);
def("trident", 4, "marked_prey",   "Marked Prey",   ["dark", "star", "light"],     [g("mark", 15, { sec: 5 })], [g("dmg", 8, { when: "unmarked" })]);
def("trident", 5, "reapers_reach", "Reaper's Reach",["death", "void", "wind"],     [g("dmg", 8, { when: "far" })], [g("atkSpeed", 10)]);
def("trident", 6, "boomerang_arc", "Boomerang Arc", ["metal", "dimension", "gale"],[g("echo", 50, { when: "ranged" })], [g("dmg", 8, { when: "melee" })]);
def("trident", 7, "twin_cast",     "Twin Cast",     ["time", "dimension", "star"], [g("echo", 35, { when: "melee" })], [g("atkSpeed", 12)]);

// ═══ Mace ════════════════════════════════════════════════════════════════════
def("mace", 1, "rebound",       "Rebound",       ["earth", "metal", "gale"],    [g("knock", 100)], [g("recoil", 3)]);
def("mace", 2, "bulwark_crush", "Bulwark Crush", ["earth", "divine", "metal"],  [g("absorbHit", 2, { sec: 6, cd: 6 })], [g("speed", 5)]);
def("mace", 3, "concussion",    "Concussion",    ["earth", "lightning", "dark"],[g("proc", 10, { kind: "stun", sec: 0.5, max: 100 })], [g("atkSpeed", 10)]);
def("mace", 4, "sanctified",    "Sanctified",    ["divine", "light", "life"],   [g("dmg", 25, { when: "undead" })], [g("dmg", 10, { when: "living" })]);
def("mace", 5, "shatter_guard", "Shatter Guard", ["metal", "earth", "demon"],   [g("dmg", 15, { when: "armored" })], [g("dmg", 8, { when: "unarmored" })]);
def("mace", 6, "momentum",      "Momentum",      ["earth", "wind", "gale"],     [g("stack", 3, { per: "hit", max: 5, resetOnHurt: true })], [g("note", 0, { txt: "Stacks reset when you are hit" })]);
def("mace", 7, "shockwave",     "Shockwave",     ["earth", "metal", "lightning"],[g("shock", 40, { n: 6, radius: 4 })], [g("dmg", 8, { when: "alone" })]);

// ═══ Magic (pool disabled until Class weapons exist) ═════════════════════════
def("magic", 1, "quickcast",     "Quickcast",     ["time", "star", "gale"],     [g("atkSpeed", 15)], [g("dmg", 8)]);
def("magic", 2, "piercing_bolt", "Piercing Bolt", ["light", "star", "metal"],   [g("dmg", 10, { when: "armored" })], [g("dmg", 8)]);
def("magic", 3, "focus",         "Focus",         ["star", "light", "time"],    [g("dmg", 20, { when: "still" })], [g("dmg", 15, { when: "moving" })]);
def("magic", 4, "mana_siphon",   "Mana Siphon",   ["star", "water", "void"],    [g("manaOnHit", 3)], [g("manaRegen", 15)]);
def("magic", 5, "overchannel",   "Overchannel",   ["star", "lightning", "fire"],[g("dmg", 25)], [g("manaCost", 20)]);
def("magic", 6, "chain_spark",   "Chain Spark",   ["lightning", "gale", "star"],[g("splash", 60, { n: 1, radius: 5 })], [g("dmg", 10)]);
def("magic", 7, "arcane_echo",   "Arcane Echo",   ["star", "time", "dimension"],[g("echo", 15)], [g("atkSpeed", 8)]);

// ═══ All-Weapon: Offense (10) ════════════════════════════════════════════════
def("all_weapon", 1, "sharpened",    "Sharpened",     ["metal", "earth"],           [g("dmg", 10)], [g("dura", 20)]);
def("all_weapon", 2, "precision",    "Precision",     ["light", "star", "wind"],    [g("crit", 8)], [g("dmg", 5, { when: "noCrit" })]);
def("all_weapon", 3, "culling",      "Culling",       ["death", "metal", "dark"],   [g("dmg", 15, { when: "nonBoss" })], [g("dmg", 15, { when: "boss" })]);
def("all_weapon", 3, "boss_slayer",  "Boss Slayer",   ["star", "metal", "divine"],  [g("dmg", 15, { when: "boss" })], [g("dmg", 10, { when: "nonBoss" })]);
def("all_weapon", 4, "brutal",       "Brutal",        ["fire", "demon", "metal"],   [g("critDmg", 30)], [g("crit", 4)]);
def("all_weapon", 4, "giant_slayer", "Giant Slayer",  ["earth", "metal", "star"],   [g("dmg", 20, { when: "big" })], [g("dmg", 8, { when: "small" })]);
def("all_weapon", 4, "opening_salvo","Opening Salvo", ["wind", "metal", "light"],   [g("dmg", 25, { when: "first" })], [g("dmg", 5, { when: "later" })]);
def("all_weapon", 5, "frenzy",       "Frenzy",        ["fire", "demon", "gale"],    [g("stack", 3, { per: "hit", max: 5, decay: 5 })], [g("taken", 10, { when: "stacksFull" })]);
def("all_weapon", 5, "berserk",      "Berserk",       ["fire", "demon", "life"],    [g("dmg", 20, { when: "selfLow" })], [g("dmg", 8, { when: "selfFull" })]);
def("all_weapon", 6, "overkill",     "Overkill",      ["fire", "earth", "demon"],   [g("overkill", 100, { radius: 4 })], [g("dmg", 5)]);

// ═══ All-Weapon: Utility (10) ════════════════════════════════════════════════
def("all_weapon", 1, "scholar",          "Scholar",          ["star", "light", "divine"],   [g("xp", 10)], [g("dmg", 5)]);
def("all_weapon", 3, "fortunes_edge",    "Fortune's Edge",   ["life", "earth", "divine"],   [g("drops", 8, { max: 100 })], [g("xp", 8)]);
def("all_weapon", 2, "magnet",           "Magnet",           ["metal", "lightning"],        [g("magnet", 8)], [g("dropsLose", 5, { kind: "any" })]);
def("all_weapon", 5, "treasure_hunter",  "Treasure Hunter",  ["earth", "light", "star"],    [g("drops", 15, { kind: "rare", max: 100 })], [g("dropsLose", 10, { kind: "common" })]);
def("all_weapon", 1, "swiftness",        "Swiftness",        ["wind", "gale", "earth"],     [g("speed", 6)], [g("knockTaken", 8)]);
def("all_weapon", 4, "tracker",          "Tracker",          ["dark", "star", "light"],     [g("glow", 16)], [g("taken", 4)]);
def("all_weapon", 2, "mender",           "Mender",           ["life", "earth", "divine"],   [g("repairKills", 10)], [g("dmg", 4)]);
def("all_weapon", 1, "featherweight",    "Featherweight",    ["wind", "gale"],              [g("atkSpeed", 8)], [g("dmg", 5)]);
def("all_weapon", 1, "night_eye",        "Night Eye",        ["dark", "star", "light"],     [g("effect", 0, { eff: "night_vision" })], [g("dmg", 5, { when: "day" })]);
def("all_weapon", 1, "scavenger",        "Scavenger",        ["life", "earth", "death"],    [g("killFood", 1)], [g("healRecv", 10)]);

// ═══ All-Weapon: Defense / Sustain (10) ══════════════════════════════════════
def("all_weapon", 2, "lifesteal",    "Lifesteal",   ["life", "divine", "death"],   [g("lifesteal", 4)], [g("dmg", 5)]);
def("all_weapon", 4, "guardian",     "Guardian",    ["metal", "earth", "divine"],  [g("taken", 6)], [g("dmg", 6)]);
def("all_weapon", 2, "thorns",       "Thorns",      ["earth", "life", "metal"],    [g("thorns", 15)], [g("speed", 4)]);
def("all_weapon", 6, "second_wind",  "Second Wind", ["life", "time", "divine"],    [g("secondWind", 25, { hp: 30, cd: 60 })], [g("healRecv", 20, { when: "onCooldown" })]);
def("all_weapon", 2, "stoneskin",    "Stoneskin",   ["earth", "metal"],            [g("knockRes", 100, { max: 100 })], [g("atkSpeed", 6)]);
def("all_weapon", 5, "barrier",      "Barrier",     ["divine", "light", "metal"],  [g("barrier", 2, { cd: 20 })], [g("taken", 5, { when: "noBarrier" })]);
def("all_weapon", 5, "purify",       "Purify",      ["divine", "life", "light"],   [g("cleanse", 1)], [g("dmg", 4)]);
def("all_weapon", 3, "vigor",        "Vigor",       ["life", "earth", "divine"],   [g("hp", 4)], [g("hunger", 15)]);
def("all_weapon", 3, "evasion",      "Evasion",     ["wind", "gale", "dimension"], [g("dodge", 5, { max: 60 })], [g("taken", 5)]);
def("all_weapon", 6, "resolve",      "Resolve",     ["divine", "earth", "metal"],  [g("knockRes", 100, { when: "selfLow", max: 100 })], [g("knockTaken", 10, { when: "selfHigh" })]);

// ═══ All-Weapon: Special / Trigger (10) ══════════════════════════════════════
def("all_weapon", 6, "lightning_strike","Lightning Strike",["lightning", "gale", "wind"],[g("proc", 8, { kind: "lightning", max: 100 })], [g("dmg", 5)]);
def("all_weapon", 3, "frostbite",       "Frostbite",       ["frost", "water", "gale"],    [g("proc", 100, { kind: "slow", sec: 3, max: 100 })], [g("dmg", 10, { when: "fireMob" })]);
def("all_weapon", 4, "ignite",          "Ignite",          ["fire", "demon", "earth"],    [g("proc", 100, { kind: "ignite", sec: 4, max: 100 })], [g("dura", 10)]);
def("all_weapon", 5, "venom",           "Venom",           ["death", "water", "dark"],    [g("proc", 100, { kind: "poison", sec: 4, max: 100 })], [g("dmg", 8)]);
def("all_weapon", 7, "soul_harvest",    "Soul Harvest",    ["death", "void", "dark"],     [g("stack", 1, { per: "kill", max: 10, persist: true })], [g("note", 0, { txt: "Souls are lost when you die" })]);
def("all_weapon", 7, "gravity_well",    "Gravity Well",    ["void", "dimension", "earth"],[g("pullAll", 8, { radius: 8 })], [g("note", 0, { txt: "Pulled enemies crowd you" })]);
def("all_weapon", 6, "chorus_link",     "Chorus Link",     ["star", "time", "dimension"], [g("dmg", 12, { when: "chorus" })], [g("dmg", 6, { when: "noChorus" })]);
def("all_weapon", 6, "mark_of_the_fallen","Mark of the Fallen",["death", "dark", "demon"],[g("killSpeed", 3, { sec: 3 })], [g("taken", 10, { when: "fallenWindow" })]);
def("all_weapon", 7, "vampiric_surge",  "Vampiric Surge",  ["death", "life", "demon"],    [g("killRegen", 3, { sec: 3 })], [g("regenPause", 3, { sec: 3 })]);
def("all_weapon", 7, "gambler",         "Gambler",         ["time", "star", "dimension"], [g("gamble", 0, { lo: 70, hi: 140 })], [g("note", 0, { txt: "Damage is unstable" })]);

// ═══ Tool-specific (3 per tool) ══════════════════════════════════════════════
def("pickaxe", 2, "tunneler",   "Tunneler",   ["earth", "metal", "fire"],    [g("mine", 20)], [g("dura", 10, { when: "ore" })]);
def("pickaxe", 4, "gem_sense",  "Gem Sense",  ["earth", "light", "star"],    [g("drops", 10, { kind: "ore", max: 100 })], [g("mine", 8)]);
def("pickaxe", 6, "seismic",    "Seismic",    ["earth", "metal", "lightning"],[g("aoe", 6, { max: 100 })], [g("dura", 15)]);
def("axe", 2, "lumberjack",     "Lumberjack", ["earth", "life", "wind"],     [g("mine", 20)], [g("dura", 30)]);
def("axe", 4, "sap_tapper",     "Sap Tapper", ["life", "earth", "water"],    [g("bonusDrop", 15, { kind: "sap", max: 100 })], [g("mine", 8)]);
def("axe", 6, "splitter",       "Splitter",   ["earth", "metal", "wind"],    [g("drops", 10, { kind: "wood", max: 100 })], [g("mine", 8)]);
def("shovel", 2, "excavator",       "Excavator",       ["earth", "metal", "fire"],  [g("mine", 25)], [g("dura", 20)]);
def("shovel", 4, "treasure_digger", "Treasure Digger", ["earth", "light", "star"],  [g("bonusDrop", 3, { kind: "dig", max: 100 })], [g("mine", 8)]);
def("shovel", 6, "sifter",          "Sifter",          ["earth", "water", "wind"],  [g("drops", 12, { kind: "dirt", max: 100 })], [g("dropsLose", 5, { kind: "any" })]);
def("hoe", 2, "green_thumb",    "Green Thumb",   ["life", "earth", "divine"],   [g("drops", 10, { kind: "crop", max: 100 })], [g("mine", 8)]);
def("hoe", 3, "re_crops",       "Re-Crops",      ["life", "earth", "divine"],   [g("replant", 100, { max: 100 })], [g("dura", 10)]);
def("hoe", 4, "quick_harvest",  "Quick Harvest", ["life", "earth", "wind"],     [g("harvest", 100)], [g("dura", 25)]);
def("hoe", 6, "fertile",        "Fertile",       ["life", "water", "earth"],    [g("freeBonemeal", 10, { max: 100 })], [g("dropsLose", 10, { kind: "seed" })]);

// ═══ All-Tool (14) ═══════════════════════════════════════════════════════════
def("all_tool", 1, "tool_haste",       "Haste",          ["gale", "wind", "fire"],    [g("effect", 0, { eff: "haste" })], [g("hunger", 15)]);
def("all_tool", 1, "light_step",       "Light Step",     ["wind", "gale", "earth"],   [g("speed", 5)], [g("knockTaken", 8)]);
def("all_tool", 2, "efficiency",       "Efficiency",     ["gale", "metal", "earth"],  [g("mine", 15)], [g("dura", 10)]);
def("all_tool", 2, "durable",          "Durable",        ["earth", "metal", "life"],  [g("dura", 20)], [g("mine", 5)]);
def("all_tool", 3, "stamina_saver",    "Stamina Saver",  ["life", "earth", "wind"],   [g("hunger", 15)], [g("mine", 6)]);
def("all_tool", 3, "tool_night_eye",   "Night Eye",      ["dark", "star", "light"],   [g("effect", 0, { eff: "night_vision" })], [g("mine", 5, { when: "day" })]);
def("all_tool", 4, "tool_magnet",      "Magnet",         ["metal", "lightning"],      [g("magnet", 8)], [g("dropsLose", 5, { kind: "any" })]);
def("all_tool", 4, "tool_mender",      "Mender",         ["life", "earth", "divine"], [g("repairBlocks", 20)], [g("mine", 4)]);
def("all_tool", 5, "fortune_touch",    "Fortune Touch",  ["life", "earth", "divine"], [g("drops", 8, { max: 100 })], [g("mine", 8)]);
def("all_tool", 5, "careful_hands",    "Careful Hands",  ["life", "light", "earth"],  [g("careful", 100)], [g("mine", 8)]);
def("all_tool", 6, "tool_scholar",     "Scholar",        ["star", "light", "divine"], [g("xp", 10)], [g("mine", 5)]);
def("all_tool", 6, "lucky_find",       "Lucky Find",     ["light", "star", "earth"],  [g("bonusDrop", 2, { kind: "lucky", max: 100 })], [g("dropsLose", 5, { kind: "common" })]);
def("all_tool", 7, "smelter",          "Smelter",        ["fire", "earth"],           [g("smelt", 100)], [g("dropsLose", 8, { kind: "ore" })]);
def("all_tool", 7, "vein_boost",       "Vein Boost",     ["earth", "metal"],          [g("vein", 4)], [g("dura", 10)]);

// ═══ Curses (7, one per tier; weapon and tool versions) ══════════════════════
// Curses are never scaled by level, Mastery or Synergy. `w` = on weapons, `t` = on tools.
export const CURSE_DEFS = {
    rust:    { tier: 1, name: "Rust",    elements: ["metal", "earth", "dark"],     w: [g("dmg", 8)],                                  t: [g("mine", 8)] },
    fatigue: { tier: 2, name: "Fatigue", elements: ["dark", "death", "void"],      w: [g("atkSpeed", 10)],                            t: [g("hunger", 15)] },
    hollow:  { tier: 3, name: "Hollow",  elements: ["void", "dark", "death"],      w: [g("critDmg", 50)],                             t: [g("dropsLose", 10, { kind: "any" })] },
    greed:   { tier: 4, name: "Greed",   elements: ["metal", "divine", "demon"],   w: [g("dura", 50)],                                t: [g("dura", 50)] },
    burden:  { tier: 5, name: "Burden",  elements: ["earth", "metal", "dark"],     w: [g("speed", 8)],                                t: [g("speed", 8)] },
    hex:     { tier: 6, name: "Hex",      elements: ["dark", "death", "demon"],    w: [g("xp", 25)],                                  t: [g("xp", 25)] },
    ruin:    { tier: 7, name: "Ruin",     elements: ["void", "death", "demon"],    w: [g("selfHurt", 3, { per: "attack" })],          t: [g("duraBurst", 2, { burst: 10 })] },
};
for (const [id, c] of Object.entries(CURSE_DEFS)) {
    RUNES.push({ id, name: c.name, pool: "curse", tier: c.tier, elements: c.elements, good: [], bad: c.w, badTool: c.t });
}

export const RUNE_BY_ID = Object.fromEntries(RUNES.map((r) => [r.id, r]));
