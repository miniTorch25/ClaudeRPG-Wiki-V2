// mastery_config.js -- Mastery v2 (permanent skill lines, unlock at Prestige 1, never reset by Prestige).
// Every number is editable.
//
// How values work:
//  * kind "random" (default): `max` is the TOTAL the effect reaches at the line's max level.
//    Each level-up gives a random share (see RANDOM); the shares always add up to exactly `max`
//    at the cap. Rolled shares are stored per player (phase 2), so they never change afterwards.
//  * kind "fixed": `per` is granted every level (no randomness), e.g. Stat Points.
//  * `integer: true` rolls whole numbers only. `toggle: false` = cannot be switched off.
//  * `unlocks`: tier/feature unlocks by level (list of { level, id, name }).
//  * `paths`: exclusive choices; the player picks ONE, effects of the other paths are inactive.
//  * Effect ids are GLOBAL stat ids. Several lines/paths may feed the same id (they add up).

export const MASTERY = {
    // ---- global rules ----
    UNLOCK_PRESTIGE: 1,               // every line needs this Prestige
    PATH_SWITCH_COOLDOWN_SEC: 60,     // free to switch, once per minute
    MOVE_SPEED_FLOOR_PCT: -60,        // total Movement Speed bonus can never go below this
    RANDOM: {
        VARIANCE: 0.6,                // each level's weight = 1 +- VARIANCE (0 = perfectly even)
    },

    // ---- XP sources (tunable) ----
    TRAVEL_XP_PER_BLOCK: 0.4,         // 1 XP / 2.5 blocks
    TRAVEL_NETHER_MULT: 1.5,
    TRAVEL_GLIDE_MULT: 1.5,
    TRAVEL_MAX_STEP: 40,              // blocks per sample; larger jumps (teleport) are ignored
    CRIT_XP: 2,                       // Melee / Ranged XP per critical hit
    CRIT_BASE_BONUS: 50,              // % damage of a chance-triggered crit (like a vanilla falling crit); Crit Damage adds on top
    FISHING_XP_MULT: 6,               // x the Fishing catch XP
    GEM_XP_ENGRAVE: 100,              // per Engrave attempt (success or not)
    GEM_XP_SALVAGE_PER_GEM: 50,
    // Gem XP per gem produced by carving an Uncarved Gem (a Perfect Carved counts both gems).
    // Common gems stop giving carve XP once the Uncommon tier is unlocked.
    GEM_XP_CARVE: { common: 30, uncommon: 60, rare: 100, unique: 160, legend: 240, epic: 340, mythical: 500 },
    CHORUS_XP: { echo: 300, resonance: 600, transcend: 1200, awaken: 2400, melodious: 4800, genesis: 9600 },   // roll: per full roll (both sockets), one socket / a lock = half; Awaken+ = per Fusion
    LEVELING_XP_RATIO: 1,             // Leveling Mastery XP = RPG XP gained x this
    DEFENSE_XP_PER_DAMAGE: 5,         // Defense XP per point of damage taken (after armor)
    MAGIC_XP_PER_MANA: 1,             // Magic XP per mana spent
    GATHER_XP_PER_BLOCK: 3,           // Gathering XP per block mined/harvested (veins count each block)
    // Melee/Ranged/Rune XP = mob XP of kills; Rune only with a rune-enchanted weapon

    // XP to go from level L to L+1 = xp.base + xp.per * L   (per line)
    LINES: {
        leveling: {
            name: "Leveling", icon: "§e", maxLevel: 50, requires: { prestige: 1 },
            xp: { base: 1500, per: 600 },
            gain: "Earn RPG XP (the normal level system); extra Points on every level-up",
            effects: {
                xp_bonus:    { name: "XP Gain",      max: 100, unit: "%" },
                points_per_level: { name: "Bonus Points per Level", max: 4, unit: "", integer: true },
            },
        },

        melee: {
            name: "Melee", icon: "§c", maxLevel: 50, requires: { prestige: 1 },
            xp: { base: 500, per: 150 },
            gain: "Kill mobs in melee, land critical hits",
            paths: {
                heavy: {
                    name: "Heavy", desc: "Slow but crushing",
                    effects: {
                        melee_attack_damage: { name: "Attack Damage", max: 10,  unit: "" },
                        melee_crit_chance:   { name: "Crit Chance",   max: 5,   unit: "%" },
                        melee_crit_damage:   { name: "Crit Damage",   max: 120, unit: "%" },
                        move_speed:          { name: "Movement Speed", max: -80, unit: "%" },
                    },
                },
                light: {
                    name: "Light", desc: "Fast and crit-focused",
                    effects: {
                        melee_attack_damage: { name: "Attack Damage", max: -2,  unit: "" },
                        melee_crit_chance:   { name: "Crit Chance",   max: 50,  unit: "%" },
                        melee_crit_damage:   { name: "Crit Damage",   max: 50,  unit: "%" },
                        move_speed:          { name: "Movement Speed", max: 35, unit: "%" },
                    },
                },
            },
        },

        ranged: {
            name: "Ranged", icon: "§a", maxLevel: 50, requires: { prestige: 1 },
            xp: { base: 500, per: 150 },
            gain: "Kill mobs with bows, crossbows and other projectiles",
            paths: {
                rogue: {
                    name: "Rogue", desc: "Crits and loot",
                    effects: {
                        ranged_crit_chance: { name: "Crit Chance", max: 75, unit: "%" },
                        ranged_crit_damage: { name: "Crit Damage", max: 15, unit: "%" },
                        scavenging:         { name: "Scavenging",  max: 25, unit: "%" },
                    },
                },
                agile: {
                    name: "Agile", desc: "Fast on your feet",
                    effects: {
                        move_speed: { name: "Movement Speed", max: 50, unit: "%" },
                    },
                },
                damage: {
                    name: "Damage", desc: "Rare but devastating crits",
                    effects: {
                        ranged_crit_chance: { name: "Crit Chance", max: 5,   unit: "%" },
                        ranged_crit_damage: { name: "Crit Damage", max: 250, unit: "%" },
                    },
                },
            },
        },

        defense: {
            name: "Defense", icon: "§9", maxLevel: 50, requires: { prestige: 1 },
            xp: { base: 800, per: 250 },
            gain: "Take damage",
            effects: {
                armor:      { name: "Armor",      max: 5,  unit: "" },
                max_health: { name: "Max Health", max: 50, unit: "" },
            },
        },

        magic: {
            name: "Magic", icon: "§b", maxLevel: 25, requires: { prestige: 1 },
            xp: { base: 1000, per: 400 },
            gain: "Spend Mana",
            effects: {
                max_mana:   { name: "Max Mana",   max: 100, unit: "" },
                mana_regen: { name: "Mana Regen", max: 2,   unit: "/s", decimals: 2 },
            },
        },

        gathering: {
            name: "Gathering", icon: "§6", maxLevel: 25, requires: { prestige: 1 },
            xp: { base: 1000, per: 350 },
            gain: "Mine and harvest with any tool",
            effects: {
                vein: { name: "Vein",  max: 10, unit: "", integer: true },
                luck: { name: "Luck",  max: 25, unit: "%" },
            },
        },

        travel: {
            name: "Travel", icon: "§3", maxLevel: 100, requires: { prestige: 1 },
            xp: { base: 500, per: 100 },
            gain: "Walk, run, swim, ride, glide (Nether and Elytra give more)",
            effects: {
                evasion:              { name: "Evasion",                 max: 25, unit: "%" },
                move_speed_overworld: { name: "Movement Speed (Overworld)", max: 25, unit: "%" },
                move_speed_nether:    { name: "Movement Speed (Nether)",    max: 25, unit: "%" },
                move_speed_end:       { name: "Movement Speed (The End)",   max: 25, unit: "%" },
            },
        },

        fishing: {
            name: "Fishing", icon: "§1", maxLevel: 100, requires: { prestige: 1 },
            xp: { base: 500, per: 100 },
            gain: "Catch items while fishing",
            effects: {
                bonus_fish:      { name: "More Loot (extra catch chance)", max: 50, unit: "%" },
                fishing_luck:    { name: "Luck+ (treasure chance)",        max: 30, unit: "%" },
                fishing_xp:      { name: "Fishing XP",                     max: 200, unit: "%" },
            },
        },

        chorus: {
            name: "Chorus", icon: "§d", maxLevel: 25, requires: { prestige: 1 },
            xp: { base: 1000, per: 500 },
            gain: "Roll, lock and fuse Chorus elements",
            // Echo is open from the start.
            unlocks: [
                { level: 5,  id: "resonance", name: "Resonance tier" },
                { level: 10, id: "transcend", name: "Transcend tier" },
                { level: 15, id: "awaken",    name: "Awaken Fusion" },
                { level: 20, id: "melodious", name: "Melodious Fusion" },
                { level: 25, id: "genesis",   name: "Genesis Fusion" },
            ],
            effects: {},
        },

        gem: {
            name: "Gem", icon: "§5", maxLevel: 6, requires: { prestige: 1 },
            xp: { base: 600, per: 400 },
            gain: "Carve gems, engrave sockets, salvage gems",
            // Common gems are open from the start; each level opens the next tier.
            unlocks: [
                { level: 1, id: "uncommon", name: "Uncommon Gem" },
                { level: 2, id: "rare",     name: "Rare Gem" },
                { level: 3, id: "unique",   name: "Unique Gem" },
                { level: 4, id: "legend",   name: "Legend Gem" },
                { level: 5, id: "epic",     name: "Epic Gem" },
                { level: 6, id: "mythical", name: "Mythical Gem" },
            ],
            effects: {
                uncarved_drop: { name: "Uncarved Gem Drop", max: 6, unit: "%" },
                gem_potency:   { name: "Gem Potency",        max: 20, unit: "%", integer: true },
            },
        },

        rune: {
            name: "Rune", icon: "§d", maxLevel: 30, requires: { prestige: 1 },
            xp: { base: 500, per: 200 },
            gain: "Kill mobs with a Rune-enchanted weapon",
            // Tier 1 runes are open from the start (T1-T7 runes).
            unlocks: [
                { level: 5,  id: "t2", name: "Tier 2 Runes" },
                { level: 10, id: "t3", name: "Tier 3 Runes" },
                { level: 15, id: "t4", name: "Tier 4 Runes" },
                { level: 20, id: "t5", name: "Tier 5 Runes" },
                { level: 25, id: "t6", name: "Tier 6 Runes" },
                { level: 30, id: "t7", name: "Tier 7 Runes" },
            ],
            effects: {
                rune_level:     { name: "Rune Level",          max: 4,  unit: "", integer: true },   // positive / neutral runes only (Level I + 4 + Synergy 3 = VIII)
                rune_cooldown:  { name: "Rune Cooldown Reduce", max: 20, unit: "%" },
            },
        },
    },
};

// ---- derived helpers ------------------------------------------------------------------

export const RUNE_LEVEL_CAP = 8;   // held Rune can be raised to at most this level (never below 1); curses never gain levels

// Effects that apply to a line regardless of path / of one path.
export function lineEffects(line, pathId = null) {
    const def = MASTERY.LINES[line];
    if (!def) return {};
    return { ...(def.effects ?? {}), ...((pathId && def.paths?.[pathId]?.effects) || {}) };
}
