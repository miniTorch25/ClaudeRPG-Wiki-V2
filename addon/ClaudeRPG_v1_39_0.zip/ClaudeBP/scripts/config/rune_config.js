// rune_config.js — Rune level context.
//
// The 80 hand-tuned old rune configs are gone: every rune is now data in config/rune_catalog.js and is scaled by
// rune/rune_effects.js (good side x level multiplier, bad side x penalty factor).
// What stays here: the level of the rune on the held item (Lv + Rune Mastery + Chorus Synergy) and the Rune Effect %.

import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import {
    RUNE_LEVEL_PROP_KEY, RUNE_LEVEL_MULT, DEFAULT_LEVEL, clampLevel,
} from "./level_config.js";

import { MasteryManager } from "../managers/mastery_manager.js";
import { ProgressionManager } from "../managers/progression_manager.js";
import { Synergy } from "../systems/synergy.js";
import { AchievementManager } from "../systems/achievement_manager.js";
import { RUNE_PROP_KEY, getRuneKind } from "../rune/rune_registry.js";

let _ctxLevel = DEFAULT_LEVEL;
let _ctxEffectPct = 0;   // Rune Effect % (Mastery + Perk) of the player whose rune logic is running
const _cache = new Map();

export function setRuneLevel(level) { _ctxLevel = clampLevel(level); }
export function getRuneLevelContext() { return _ctxLevel; }

export function getRuneLevelOfItem(item) {
    return clampLevel(item?.getDynamicProperty?.(RUNE_LEVEL_PROP_KEY) ?? DEFAULT_LEVEL);
}

// Reads the level of the rune on the player's mainhand weapon and makes it the active context.
export function useRuneLevelOf(player) {
    try {
        const slot = player?.getComponent?.(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);
        // Rune Mastery and Chorus Synergy add levels on top of the rune on the held weapon, clamped I-VIII.
        // A curse never gains levels or effect from them (its penalty would only get harsher).
        let runeId = null;
        if (slot?.hasItem() && player) {
            const raw = slot.getItem().getDynamicProperty(RUNE_PROP_KEY);
            if (typeof raw === "string") runeId = raw;
        }
        const isCurse = runeId ? getRuneKind(runeId) === "curse" : false;
        const bonusLv = player && !isCurse ? MasteryManager.getItemLevelBonus(player, "rune") : 0;
        const synLv = runeId && !isCurse ? Synergy.runeLevelBonus(player, runeId) : 0;
        _ctxLevel = slot?.hasItem() ? clampLevel(getRuneLevelOfItem(slot.getItem()) + bonusLv + synLv) : DEFAULT_LEVEL;
        _ctxEffectPct = player && !isCurse ? ProgressionManager.getPerkValue(player, "rune_effect") : 0;
        if (player && runeId) AchievementManager.max(player, "rune_level_max", _ctxLevel);
    } catch (_) { /* keep previous context */ }
    return _ctxLevel;
}

export function getRuneEffectPctContext() { return _ctxEffectPct; }

// Old per-rune config objects no longer exist; callers that still read RUNE_CONFIG.<oldRune>?.x get an empty object.
export const RUNE_CONFIG = new Proxy({}, { get: () => ({}) });
