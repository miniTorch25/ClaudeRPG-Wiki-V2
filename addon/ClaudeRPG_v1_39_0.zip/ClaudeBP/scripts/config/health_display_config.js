// health_display_config.js -- HP numbers above mobs and bosses (Admin Config Editor, group "Health Display").
// Idea adapted from "HeartDisplay" by Killer1214 (rewritten for ClaudeRPG: numbers instead of hearts,
// virtual Ascension HP, only mobs near a player, original names are restored when a mob leaves range).
export const HEALTH_DISPLAY = {
    ENABLED: 1,                 // world-wide switch (1 = on, 0 = off; names are restored when switched off)
    SHOW_MOBS: 1,               // regular mobs (players are never shown)
    SHOW_BOSSES: 1,             // Ender Dragon, Wither, Warden, Elder Guardian (everything tagged "boss" in mob_config)
    SCAN_INTERVAL_TICKS: 10,    // read once at startup
    SCAN_RADIUS: 32,            // blocks around each player for regular mobs
    BOSS_RADIUS: 96,            // blocks around each player for bosses
    MAX_PER_SCAN: 80,           // safety cap on how many mobs are rendered per scan
    COMPACT_FROM: 10000,        // numbers at or above this are shortened: 12500 -> 12.5K, 1200000 -> 1.2M
    FLASH_TICKS: 20,            // how long the current HP stays red (damage) or green (healing)

    LABEL: "HP",                // text before the numbers ("" = numbers only)
    COLOR_LABEL: "§c",
    COLOR_NUM: "§f",
    COLOR_SEP: "§7",
    COLOR_DAMAGE: "§4",
    COLOR_HEAL: "§a",
    BOSS_PREFIX: "§l§c",        // label colour + bold for bosses (numbers are bold too)

    EXCLUDE_TYPES: [
        "minecraft:player", "crpg:damage_indicator", "minecraft:item", "minecraft:xp_orb", "minecraft:armor_stand", "minecraft:npc",
        "minecraft:arrow", "minecraft:thrown_trident", "minecraft:snowball", "minecraft:egg", "minecraft:ender_pearl",
        "minecraft:fireball", "minecraft:small_fireball", "minecraft:wither_skull", "minecraft:wither_skull_dangerous",
        "minecraft:shulker_bullet", "minecraft:llama_spit", "minecraft:evocation_fang", "minecraft:fishing_hook",
        "minecraft:tnt", "minecraft:falling_block", "minecraft:lightning_bolt", "minecraft:area_effect_cloud",
        "minecraft:fireworks_rocket", "minecraft:ender_crystal", "minecraft:boat", "minecraft:chest_boat", "minecraft:minecart",
    ],
};
