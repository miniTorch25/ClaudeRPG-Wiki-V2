// toast_config.js -- Toast notifications (pop-up cards at the top right).
// Needs the ClaudeRP resource pack (ui/crpg_toast.json). All values editable in the Admin Config Editor.
export const TOAST = {
    ENABLED: 1,             // 1 = toasts may be used, 0 = everything falls back to chat / action bar
    SPACING_TICKS: 8,       // minimum gap between two toasts for the same player (20 ticks = 1 s)
    MAX_QUEUE: 30,          // per player; extra toasts are dropped
    HEADER_MAX: 28,         // fixed field width in the resource pack - do not change without editing the UI
    BODY_MAX: 22,           // visible characters that fit the card (colour codes do not count)
    DEFAULT_SOUND: "random.toast",
    // Custom toasts (toast:send command / Toast Composer)
    SEND_ENABLED: 1,        // 1 = players may send custom toasts, 0 = only Admin / command blocks
    SEND_COST: 10,          // items paid when a player sends a toast to ANOTHER player (sending to yourself is free)
    SEND_COOLDOWN_SEC: 3,   // minimum seconds between two paid sends by the same player
};
export const TOAST_COST_ITEM = "crpg:common_gem";
export const TOAST_COST_NAME = "Common Gem";
