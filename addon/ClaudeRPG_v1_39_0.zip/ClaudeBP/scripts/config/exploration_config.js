// exploration_config.js -- Waypoint Stone + Discovery Log. Every number is editable (Admin Config Editor, group "Exploration").
//
// Waypoint Stone: a placeable block. The placer must name it; every player saves (up to SAVED_MAX) the stones they want
//   to travel to. Waypoint Stone (Blank) = travel only (no name). Waypoint Orb = item version + SPECIAL_MAX personal points.
//   Cost = Ender Pearls (one material only): ceil(distance / BLOCKS_PER_PEARL), min..max; another dimension = MAX_COST.
//   Orb special points are free but have their own cooldown (SPECIAL_COOLDOWN_SEC).
// Discovery Log: remembers every biome / structure / dimension a player has found.
//   First finds give one-time Travel Mastery XP (only when the Travel line is unlocked, i.e. Prestige 1+).

export const WAYPOINT = {
    ENABLED: 1,                       // 1 = on, 0 = off (existing stones stay, GUI refuses to teleport)
    BLOCK_ID: "crpg:waypoint_stone",
    BLANK_ID: "crpg:waypoint_stone_blank",
    ORB_ID: "crpg:waypoint_orb",
    COST_ITEM: "minecraft:ender_pearl",
    COST_NAME: "Ender Pearl",
    BLOCKS_PER_PEARL: 400,            // same dimension: 1 pearl per 400 blocks (rounded up)
    MIN_COST: 1,
    MAX_COST: 8,                      // also the flat price for crossing dimensions
    COOLDOWN_SEC: 10,                 // per player, between two stone teleports
    PER_PLAYER_MAX: 10,               // named stones one player may own
    WORLD_MAX: 150,                   // named stones in the whole world
    SAVED_MAX: 20,                    // stones one player can save in their list
    SPECIAL_MAX: 5,                   // Orb special points per player (always listed first)
    SPECIAL_COOLDOWN_SEC: 30,         // cooldown after teleporting to a special point (free of cost)
    MIN_SPACING: 6,                   // blocks between two named stones (same dimension) -- stops spam
    NAME_MAX: 24,
};

export const DISCOVERY = {
    ENABLED: 1,
    BIOME_INTERVAL_TICKS: 40,         // biome / dimension check (cheap)
    STRUCTURE_INTERVAL_TICKS: 100,    // block-signature scan (heavier; only runs if the player moved)
    STRUCTURE_MIN_MOVE: 6,            // blocks moved since the last scan before scanning again
    SCAN_RADIUS: 10,                  // horizontal radius of the structure scan
    SCAN_UP: 5,
    SCAN_DOWN: 6,
    SHOW_UNDISCOVERED_NAMES: 0,       // 0 = "???" until found, 1 = show names
    XP_BIOME: 120,                    // one-time Travel Mastery XP per new biome
    XP_STRUCTURE: 350,                // per new structure
    XP_DIMENSION: 800,                // per new dimension (Nether / End)
    XP_OTHER_BIOME: 120,              // a biome that is not in the catalog below
};

// [id without "minecraft:", display name]. Best-effort Bedrock ids. A biome that is not listed here is
// still recorded (shown under "Other biomes"), so a wrong id never loses a discovery.
export const BIOME_CATALOG = {
    overworld: [
        ["plains", "Plains"], ["sunflower_plains", "Sunflower Plains"], ["forest", "Forest"], ["flower_forest", "Flower Forest"],
        ["birch_forest", "Birch Forest"], ["birch_forest_mutated", "Old Growth Birch Forest"], ["roofed_forest", "Dark Forest"],
        ["taiga", "Taiga"], ["cold_taiga", "Snowy Taiga"], ["mega_taiga", "Old Growth Pine Taiga"], ["redwood_taiga_mutated", "Old Growth Spruce Taiga"],
        ["swampland", "Swamp"], ["mangrove_swamp", "Mangrove Swamp"], ["jungle", "Jungle"], ["bamboo_jungle", "Bamboo Jungle"], ["jungle_edge", "Sparse Jungle"],
        ["savanna", "Savanna"], ["savanna_plateau", "Savanna Plateau"], ["desert", "Desert"],
        ["mesa", "Badlands"], ["mesa_plateau", "Wooded Badlands"], ["mesa_bryce", "Eroded Badlands"],
        ["ice_plains", "Snowy Plains"], ["ice_plains_spikes", "Ice Spikes"], ["extreme_hills", "Windswept Hills"],
        ["meadow", "Meadow"], ["cherry_grove", "Cherry Grove"], ["grove", "Grove"], ["snowy_slopes", "Snowy Slopes"],
        ["jagged_peaks", "Jagged Peaks"], ["frozen_peaks", "Frozen Peaks"], ["stony_peaks", "Stony Peaks"],
        ["pale_garden", "Pale Garden"], ["mushroom_island", "Mushroom Fields"],
        ["beach", "Beach"], ["cold_beach", "Snowy Beach"], ["stone_beach", "Stony Shore"], ["river", "River"], ["frozen_river", "Frozen River"],
        ["ocean", "Ocean"], ["deep_ocean", "Deep Ocean"], ["cold_ocean", "Cold Ocean"], ["deep_cold_ocean", "Deep Cold Ocean"],
        ["lukewarm_ocean", "Lukewarm Ocean"], ["deep_lukewarm_ocean", "Deep Lukewarm Ocean"], ["warm_ocean", "Warm Ocean"],
        ["frozen_ocean", "Frozen Ocean"], ["deep_frozen_ocean", "Deep Frozen Ocean"],
        ["lush_caves", "Lush Caves"], ["dripstone_caves", "Dripstone Caves"], ["deep_dark", "Deep Dark"],
    ],
    nether: [
        ["hell", "Nether Wastes"], ["crimson_forest", "Crimson Forest"], ["warped_forest", "Warped Forest"],
        ["soulsand_valley", "Soul Sand Valley"], ["basalt_deltas", "Basalt Deltas"],
    ],
    the_end: [
        ["the_end", "The End"],
    ],
};

// Structures are recognised by signature blocks near the player (no structure API is used).
// A structure counts when at least `min` signature blocks are found inside the scan box.
export const STRUCTURE_CATALOG = [
    { id: "village",       name: "Village",         dim: "overworld", blocks: ["minecraft:bell"],                                   min: 1 },
    { id: "stronghold",    name: "Stronghold",      dim: "overworld", blocks: ["minecraft:end_portal_frame"],                       min: 1 },
    { id: "monument",      name: "Ocean Monument",  dim: "overworld", blocks: ["minecraft:sea_lantern", "minecraft:prismarine_bricks"], min: 4 },
    { id: "ancient_city",  name: "Ancient City",    dim: "overworld", blocks: ["minecraft:reinforced_deepslate"],                   min: 1 },
    { id: "trial_chamber", name: "Trial Chambers",  dim: "overworld", blocks: ["minecraft:trial_spawner", "minecraft:vault"],        min: 1 },
    { id: "ruined_portal", name: "Ruined Portal",   dim: "overworld", blocks: ["minecraft:crying_obsidian"],                        min: 2 },
    { id: "fortress",      name: "Nether Fortress", dim: "nether",    blocks: ["minecraft:nether_brick_fence"],                     min: 4 },
    { id: "bastion",       name: "Bastion Remnant", dim: "nether",    blocks: ["minecraft:gilded_blackstone"],                      min: 2 },
    { id: "end_city",      name: "End City",        dim: "the_end",   blocks: ["minecraft:purpur_pillar"],                          min: 4 },
];

export const DIMENSION_CATALOG = [
    { id: "overworld", name: "Overworld" },
    { id: "nether",    name: "The Nether" },
    { id: "the_end",   name: "The End" },
];
