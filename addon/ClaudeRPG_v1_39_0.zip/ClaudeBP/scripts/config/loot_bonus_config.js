// Vanilla Fortune / Looting support for drops the addon creates by script.
// (Vanilla drops - mob loot, Vein via loot table - already honour the enchants by themselves.)
export const LOOT_BONUS = {
    // Looting: addon drop chances are multiplied by (1 + LOOTING_CHANCE_PER_LEVEL x level) ...
    LOOTING_CHANCE_PER_LEVEL: 0.20,
    // ... but never pushed above this (an already higher base chance is left as is).
    LOOTING_MAX_CHANCE: 0.95,
    // Looting: rolled drop COUNTS gain a random +0..(level x this) (Enchant Essence, Gem count).
    LOOTING_COUNT_PER_LEVEL: 1,

    // Which addon drops react to Looting (1 = yes, 0 = no).
    APPLY_FORTUNES_FAVOR: 1,   // Fortune's Favor rune bonus drop
    APPLY_EVO_GEM: 1,          // Geode / Awaken Uncarved Gem chances
    APPLY_EVO_RARE: 1,         // Awaken rare drops
    APPLY_EVO_CORE: 1,         // Core mob: Augment Core / Stellar Core chance
    APPLY_EVO_SHARD: 1,        // Sculk Evolve / Warden: Echo Shard amount
    APPLY_EVO_ESSENCE: 1,      // Enchanted mob: Enchant Essence amount
};
