// Item usage restrictions by typeId.
// "type"  : melee | ranged | armor | tool
// "slot"  : (armor only) head | chest | legs | feet | offhand
// "lore"  : optional flavour text shown above the Requirements block
// "noRune": true = item can never hold a Rune (Augment/Gem unaffected)
export const ITEM_REQUIREMENTS = {
    // Melee
    // Wooden tier — free to use (no requirement) but still tracked here so
    // players can Augment it and socket Gems/Runes into it.
    "minecraft:wooden_sword": { type: "melee" },
    "minecraft:wooden_spear": { type: "melee" },

    "minecraft:golden_sword":    { type: "melee", str: 8 },
    "minecraft:stone_sword":     { type: "melee", str: 12 },
    "minecraft:copper_sword":    { type: "melee", str: 22 },
    "minecraft:iron_sword":      { type: "melee", str: 26 },
    "minecraft:diamond_sword":   { type: "melee", lore: "A cool shiny sword", str: 35 },
    "minecraft:netherite_sword": { type: "melee", lore: "Endgame Sword", str: 48 },

    "minecraft:golden_spear":    { type: "melee", str: 6, agi: 4 },
    "minecraft:stone_spear":     { type: "melee", str: 8, agi: 7 },
    "minecraft:copper_spear":    { type: "melee", str: 16, agi: 12 },
    "minecraft:iron_spear":      { type: "melee", str: 18, agi: 13 },
    "minecraft:diamond_spear":   { type: "melee", str: 24, agi: 18 },
    "minecraft:netherite_spear": { type: "melee", str: 33, agi: 24 },

    "minecraft:mace": { type: "melee", lore: "SMASH!!!", str: 60, psi: 24 },

    // Ranged
    "minecraft:bow":      { type: "ranged", str: 12, agi: 16 },
    "minecraft:crossbow": { type: "ranged", str: 20, agi: 12 },
    "minecraft:trident":  { type: "ranged", str: 36, agi: 16 },

    // Armor
    "minecraft:shield": { type: "armor", slot: "offhand", lore: "Can't protect your back door", def: 14 },

    // Leather — free to use (no requirement) but still tracked here so
    // players can Augment it and socket Gems/Runes into it.
    "minecraft:leather_helmet":     { type: "armor", slot: "head" },
    "minecraft:leather_chestplate": { type: "armor", slot: "chest" },
    "minecraft:leather_leggings":   { type: "armor", slot: "legs" },
    "minecraft:leather_boots":      { type: "armor", slot: "feet" },

    "minecraft:golden_helmet":    { type: "armor", slot: "head", def: 7 },
    "minecraft:golden_chestplate":{ type: "armor", slot: "chest", def: 10 },
    "minecraft:golden_leggings":  { type: "armor", slot: "legs", def: 9 },
    "minecraft:golden_boots":     { type: "armor", slot: "feet", def: 6 },

    "minecraft:chainmail_helmet":    { type: "armor", slot: "head", def: 11 },
    "minecraft:chainmail_chestplate":{ type: "armor", slot: "chest", def: 16 },
    "minecraft:chainmail_leggings":  { type: "armor", slot: "legs", def: 14 },
    "minecraft:chainmail_boots":     { type: "armor", slot: "feet", def: 10 },

    "minecraft:copper_helmet":    { type: "armor", slot: "head", def: 10 },
    "minecraft:copper_chestplate":{ type: "armor", slot: "chest", def: 14 },
    "minecraft:copper_leggings":  { type: "armor", slot: "legs", def: 13 },
    "minecraft:copper_boots":     { type: "armor", slot: "feet", def: 8 },

    "minecraft:iron_helmet":    { type: "armor", slot: "head", def: 12 },
    "minecraft:iron_chestplate":{ type: "armor", slot: "chest", def: 18 },
    "minecraft:iron_leggings":  { type: "armor", slot: "legs", def: 16 },
    "minecraft:iron_boots":     { type: "armor", slot: "feet", def: 11 },

    "minecraft:diamond_helmet":    { type: "armor", slot: "head", def: 19 },
    "minecraft:diamond_chestplate":{ type: "armor", slot: "chest", def: 27 },
    "minecraft:diamond_leggings":  { type: "armor", slot: "legs", def: 24 },
    "minecraft:diamond_boots":     { type: "armor", slot: "feet", def: 17 },

    "minecraft:netherite_helmet":    { type: "armor", slot: "head", def: 32 },
    "minecraft:netherite_chestplate":{ type: "armor", slot: "chest", def: 45 },
    "minecraft:netherite_leggings":  { type: "armor", slot: "legs", def: 41 },
    "minecraft:netherite_boots":     { type: "armor", slot: "feet", def: 27 },

    "minecraft:turtle_helmet": { type: "armor", slot: "head", def: 12, psi: 12 },
    "minecraft:elytra":        { type: "armor", slot: "chest", agi: 40, psi: 16 },

    // Tools
    // Wooden tier — free to use (no requirement) but still tracked here so
    // players can Augment it and socket Gems/Runes into it.
    "minecraft:wooden_axe":     { type: "tool" },
    "minecraft:wooden_pickaxe": { type: "tool" },
    "minecraft:wooden_shovel":  { type: "tool" },
    "minecraft:wooden_hoe":     { type: "tool" },

    "minecraft:golden_axe":    { type: "tool", exc: 5 },
    "minecraft:stone_axe":     { type: "tool", exc: 8 },
    "minecraft:copper_axe":    { type: "tool", exc: 14 },
    "minecraft:iron_axe":      { type: "tool", exc: 16 },
    "minecraft:diamond_axe":   { type: "tool", exc: 23 },
    "minecraft:netherite_axe": { type: "tool", exc: 32 },

    "minecraft:golden_pickaxe":    { type: "tool", exc: 6 },
    "minecraft:stone_pickaxe":     { type: "tool", exc: 10 },
    "minecraft:copper_pickaxe":    { type: "tool", exc: 18 },
    "minecraft:iron_pickaxe":      { type: "tool", exc: 21 },
    "minecraft:diamond_pickaxe":   { type: "tool", exc: 30 },
    "minecraft:netherite_pickaxe": { type: "tool", exc: 42 },

    "minecraft:golden_shovel":    { type: "tool", exc: 3 },
    "minecraft:stone_shovel":     { type: "tool", exc: 5 },
    "minecraft:copper_shovel":    { type: "tool", exc: 9 },
    "minecraft:iron_shovel":      { type: "tool", exc: 11 },
    "minecraft:diamond_shovel":   { type: "tool", exc: 15 },
    "minecraft:netherite_shovel": { type: "tool", exc: 21 },

    "minecraft:golden_hoe":    { type: "tool", exc: 3 },
    "minecraft:stone_hoe":     { type: "tool", exc: 5 },
    "minecraft:copper_hoe":    { type: "tool", exc: 9 },
    "minecraft:iron_hoe":      { type: "tool", exc: 11 },
    "minecraft:diamond_hoe":   { type: "tool", exc: 15 },
    "minecraft:netherite_hoe": { type: "tool", exc: 21 },

    // Shears — free to use; Augment is limited to Vein only (see augment_registry), no Runes.
    "minecraft:shears": { type: "tool", noRune: true },
};
