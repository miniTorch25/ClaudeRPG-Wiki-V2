// guide_quest_config.js -- Guide Quest settings (all editable in the Admin Config Editor).
export const GUIDE = {
    ENABLED: 1,               // 1 = Guide Quest runs, 0 = switched off for everyone (menus show a notice)
    CHECK_INTERVAL_TICKS: 40, // how often each player's CURRENT step is checked (20 ticks = 1 s)
    NOTIFY_NEXT: 1,           // 1 = after a step, a second toast / chat line names the next step
    WELCOME: 1,               // 1 = new players get one "Guide Quest started" pop-up
    MAX_CATCHUP_STEPS: 60,    // safety limit of steps auto-completed in one check (existing players catching up)
    PROPERTY: "crpg:gq2",     // completed step ids (v1.39 chapter reorder: new key so old ids are never misread; progress catches up by itself), comma separated (never touched by Prestige / Reset All / Delete All)
    FLAG_PROPERTY: "crpg:gqf",// one-time flags (menus opened, socket engraved ...)
};
