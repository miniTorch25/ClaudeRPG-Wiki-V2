// progression_config.js -- central numbers for the Progression System (Phase 1+).
// Every value here is editable; nothing else in the addon hard-codes them.
//
// Feature gates: a player may use a feature when ALL of its requirements pass.
//   level      : Level reached at least once (remembered forever, so a Prestige
//                reset never re-locks a feature)
//   prestige   : player's current Prestige count
//   ascension  : the WORLD's current Ascension (one player presses, everyone shares)

export const PROGRESSION = {
    // Max Level = BASE_MAX_LEVEL + MAX_LEVEL_PER_PRESTIGE * Prestige (P0 = 40, P1 = 60, P2 = 80 ...)
    BASE_MAX_LEVEL: 40,
    MAX_LEVEL_PER_PRESTIGE: 20,

    FEATURES: {
        augment: { name: "Augment", prestige: 1 },
        chorus:  { name: "Chorus",  prestige: 2 },
        gem:     { name: "Gem",     prestige: 4, ascension: 2 },
        rune:    { name: "Rune",    prestige: 6, ascension: 3 },
    },
};

// Dynamic property keys
export const PROG_KEYS = {
    PRESTIGE:  "prog_prestige",   // player, number
    UNLOCKS:   "prog_unlocks",    // player, "augment,chorus,..." (level gates already reached)
    ASCENSION: "prog_ascension",  // world, number
    MIGRATION: "prog_mig_lv40",   // player, 1 once the v1.39 level-cap / points migration ran
};

// ─── Prestige (Phase 2) ──────────────────────────────────────────────────────
export const PRESTIGE = {
    // Stat Limit Break: every stat cap = baseCap * (1 + LIMIT_BREAK_STEP * units)
    // units(P) = sum of factor(i) for i = 1..P
    LIMIT_BREAK_STEP: 0.25,

    // Veteran bonus: every Prestige adds PER % XP gain (max CAP %), because each Prestige
    // replays a longer climb from Level 0.
    XP_BONUS_PER: 3,
    XP_BONUS_CAP: 60,

    // Diminishing returns: Prestige 1..FULL_UNTIL give full strength; after that every
    // Prestige multiplies the strength by DECAY, never below MIN_FACTOR.
    // Applies to Limit Break steps and to Perk power (fixed at the Prestige it was picked).
    FULL_UNTIL: 3,
    DECAY: 0.85,
    MIN_FACTOR: 0.25,

    // Perks: pick 1 per Prestige. minPrestige = first Prestige where it can be picked.
    // value = base power at full strength (unit shown in `unit`).
    PERKS: {
        exp:        { name: "Scholar",        minPrestige: 1, base: 5,   unit: "% EXP",                desc: "+{v}% EXP from all sources" },
        drop_rate:  { name: "Plunderer",      minPrestige: 1, base: 3,   unit: "% Drop Rate",          desc: "+{v}% chance to roll a mob's loot one extra time" },
        max_hp:     { name: "Vigor",          minPrestige: 1, base: 5,   unit: " Max HP",              desc: "+{v} Max HP" },
        gem_chance: { name: "Gemwright",      minPrestige: 2, base: 5,   unit: "% Engrave Chance",     desc: "+{v}% Gem socket Engrave success" },
        move_speed: { name: "Fleetfoot",      minPrestige: 2, base: 3,   unit: "% Move Speed",         desc: "+{v}% Movement Speed" },
        hp_regen:   { name: "Second Wind",    minPrestige: 3, base: 0.5, unit: " HP/sec",              desc: "+{v} HP regen per second" },
        rune_effect:{ name: "Runebound",      minPrestige: 3, base: 5,   unit: "% Rune Effect",       desc: "+{v}% Rune effect strength" },
        max_mana:   { name: "Deep Well",      minPrestige: 3, base: 10,  unit: " Max Mana",            desc: "+{v} Max Mana" },
    },
};

export const PRESTIGE_KEYS = {
    PERKS:   "prog_perks",         // player, "exp@1,max_hp@2"  (perkId@prestigeWhenPicked)
    PENDING: "prog_perk_pending",  // player, number of unspent perk picks
};

// ─── Ascension (Phase 3) ─────────────────────────────────────────────────────
// World difficulty. One player presses, the whole world shares the result. Up only.
export const ASCENSION = {
    MAX: null,   // null = unlimited

    // Prestige the presser needs for the NEXT Ascension level:
    // Asc 1 -> P1, Asc 2 -> P2, Asc 3 and above -> P3
    REQUIRED_PRESTIGE: { 1: 1, 2: 2, DEFAULT: 3 },

    // Scaling (applied to mobs in Phase 5). mult = 1 + Asc * PER_ASC, limited to CAP.
    MOB_HP:    { PER_ASC: 0.5,  CAP: 5 },
    // Mob damage: linear up to SOFT_AFTER, then each extra Ascension adds only SOFT_FACTOR of
    // PER_ASC (smooth late curve), limited to CAP.
    MOB_DAMAGE:{ PER_ASC: 0.25, CAP: 3.5, SOFT_AFTER: 6, SOFT_FACTOR: 0.6 },
    BOSS_HP:   { PER_ASC: 0.8,  CAP: 9 },
    // The harder world pays more: +PER_ASC % XP gain per Ascension (max CAP %) on every XP source
    // and on Melee / Ranged / Rune kill XP.
    XP_BONUS: { PER_ASC: 5, CAP: 100 },

    // Bosses hit harder on top of the Mob Damage multiplier.
    BOSS_DAMAGE: { PER_ASC: 0.08, CAP: 1.8 },
    // Players deal more damage to hostile mobs/bosses as the world rises (offsets the HP pool).
    PLAYER_DAMAGE: { PER_ASC: 0.06, CAP: 1.6 },

    // Mob Evolution themes unlocked at each Ascension (built in Phase 6).
    EVOLUTION_TIERS: {
        1: "Tough", 2: "Elite", 3: "Sculk", 4: "Geode", 5: "Inferno", 6: "Nightmare", 7: "Awaken",
    },

    // Other things an Ascension level opens (shown in the confirm window).
    UNLOCK_NOTES: {
        2: "Bosses start dropping Uncarved Gems; Gem system can be unlocked (with Prestige 2).",
        3: "Rune system can be unlocked (with Prestige 3).",
        4: "Geode mobs can drop Uncarved Gems.",
    },
};

// ─── Mob / Boss scaling (Phase 5) ────────────────────────────────────────────
export const MOB_SCALING = {
    // "pool"   : every scaled mob gets a virtual HP pool (vanilla max HP x multiplier)
    // "reduce" : fallback -- the mob keeps vanilla HP but takes damage / multiplier
    HP_MODE: "pool",

    // A single Ascension-scaled hit can never take more than this fraction of the
    // player's Max HP (only while Ascension > 0).
    MAX_HIT_FRACTION: 0.5,

    // Ceiling for the COMBINED hostile damage multiplier (Ascension x Evolution x Boss).
    TOTAL_DAMAGE_CAP: 6,

    // Hostile mobs that are NOT scaled (allies etc.)
    EXCLUDE: ["minecraft:iron_golem"],

    // Bosses (mob_config tag "boss") use the Boss HP multiplier; everything else in
    // XP_CONFIG (type "mob") uses the Mob HP multiplier.

    // Boss Uncarved Gem drops only from this Ascension upward.
    BOSS_GEM_MIN_ASCENSION: 2,
};

// --- Prestige / Ascension cost items (v1_21) ----------------------------------
// Each action burns ONE item type, paid in bulk (single-material economy).
//   Prestige Sigil  -> Prestige   (crpg:prestige_sigil)
//   Ascension Relic -> Ascension  (crpg:ascension_relic)
// cost = min(CAP, BASE + floor(PER * current))   where current = Prestige you have /
// Ascension the world is at BEFORE the step. Editable in the Admin Config Editor.
export const ACTION_COSTS = {
    PRESTIGE:  { ITEM: "crpg:prestige_sigil",  NAME: "Prestige Sigil",  BASE: 2, PER: 0.75, CAP: 16 },
    ASCENSION: { ITEM: "crpg:ascension_relic", NAME: "Ascension Relic", BASE: 1, PER: 0.5,  CAP: 10 },
};
