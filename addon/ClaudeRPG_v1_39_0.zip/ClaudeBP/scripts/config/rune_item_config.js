// rune_item_config.js — Rune ITEMS (the carved item that holds one random rune).
//
// 7 grades, low -> high. Grade = Tier: Gamma = T1 ... Omega = T7. The rune inside an item
// always has the same tier as the grade (a Phi Rune holds a T5 rune).
//
// Item name:  <Grade> Rune (<Type> T<tier>)      e.g. "Gamma Rune (Melee T1)"
// Item ids:   crpg:rune_gamma ... crpg:rune_omega, crpg:uncarved_rune (the blank, carved with an Engraver)

import { POOLS, DISABLED_POOLS } from "./rune_catalog.js";

export const UNCARVED_RUNE_ID = "crpg:uncarved_rune";

export const RUNE_GRADES = [
    { id: "gamma", label: "Gamma", tier: 1, color: "§f", weight: 40 },
    { id: "delta", label: "Delta", tier: 2, color: "§e", weight: 25 },
    { id: "theta", label: "Theta", tier: 3, color: "§a", weight: 15 },
    { id: "sigma", label: "Sigma", tier: 4, color: "§3", weight: 10 },
    { id: "phi",   label: "Phi",   tier: 5, color: "§9", weight: 6  },
    { id: "psi",   label: "Psi",   tier: 6, color: "§u", weight: 3  },
    { id: "omega", label: "Omega", tier: 7, color: "§4", weight: 1  },
];

// Shown on the Type line (last line of the Lore) and inside the item name: Sword, Bow, All-Weapon, Pickaxe, Curse ...
// Pools come from rune_catalog.js. Pools in DISABLED_POOLS (Magic) never roll.
export const RUNE_TYPE_LABELS = Object.fromEntries(Object.entries(POOLS).map(([k, v]) => [k, v.label]));

// Types the player can pick in Selective reroll (Curse is never a choice).
export const SELECTABLE_TYPES = Object.keys(POOLS).filter((k) => k !== "curse" && !DISABLED_POOLS.includes(k));

// How many Uncarved Runes one Shift-click carves at once.
export const RUNE_CARVE_BATCH = 16;

// Legend Gem -> Uncarved Rune (crafting). The extra ingredient mirrors the Uncarved Gem recipe.
export const UNCARVED_RUNE_RECIPE_EXTRA = "minecraft:amethyst_shard";

// Anvil > Rune page. Costs are paid in Resonant Ink (same material the old Rune Enchanting used).
export const RESONANT_INK_ID = "crpg:resonant_ink";
export const RUNE_ANVIL_COSTS = {
    recarved:      30,   // flat: re-roll the GRADE (Gamma-Omega) and the rune inside
    rerollPerTier: 5,    // x tier of the Rune item: new random effect, same grade
    selectPerTier: 8,    // x tier: new effect of a CHOSEN type, same grade
    insert:        0,
    remove:        0,
};
