// Log/wood blocks a Vein-enabled Axe can chain-chop. These don't grant any
// bonus Xp (Mining Xp only applies to the ore list in xp_config.js) - Vein
// here is purely a "chop the rest of the tree for free" convenience.
export const AXE_VEIN_BLOCKS = {
    "minecraft:oak_log": { drop: "minecraft:oak_log", dropCount: 1 },
    "minecraft:spruce_log": { drop: "minecraft:spruce_log", dropCount: 1 },
    "minecraft:birch_log": { drop: "minecraft:birch_log", dropCount: 1 },
    "minecraft:jungle_log": { drop: "minecraft:jungle_log", dropCount: 1 },
    "minecraft:acacia_log": { drop: "minecraft:acacia_log", dropCount: 1 },
    "minecraft:dark_oak_log": { drop: "minecraft:dark_oak_log", dropCount: 1 },
    "minecraft:mangrove_log": { drop: "minecraft:mangrove_log", dropCount: 1 },
    "minecraft:cherry_log": { drop: "minecraft:cherry_log", dropCount: 1 },
    "minecraft:pale_oak_log": { drop: "minecraft:pale_oak_log", dropCount: 1 },
    "minecraft:poplar_log": { drop: "minecraft:poplar_log", dropCount: 1 },
    "minecraft:crimson_stem": { drop: "minecraft:crimson_stem", dropCount: 1 },
    "minecraft:warped_stem": { drop: "minecraft:warped_stem", dropCount: 1 }
};
