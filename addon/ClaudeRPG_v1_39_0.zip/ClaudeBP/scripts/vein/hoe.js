// Crop blocks a Vein-enabled Hoe can chain-harvest. For crops that grow in
// stages, "growthState" is the block state name and "maxGrowth" is the value
// it reaches when fully ripe - only neighbors at that value get harvested,
// so immature crops are left alone to keep growing. Blocks with
// growthState: null are always ready (e.g. a placed pumpkin/melon block, or leaves).
export const HOE_VEIN_BLOCKS = {
    "minecraft:wheat": { drop: "minecraft:wheat", dropCount: 1, growthState: "growth", maxGrowth: 7 },
    "minecraft:carrots": { drop: "minecraft:carrot", dropCount: 2, growthState: "growth", maxGrowth: 7 },
    "minecraft:potatoes": { drop: "minecraft:potato", dropCount: 2, growthState: "growth", maxGrowth: 7 },
    "minecraft:beetroot": { drop: "minecraft:beetroot", dropCount: 1, growthState: "growth", maxGrowth: 3 },
    "minecraft:nether_wart": { drop: "minecraft:nether_wart", dropCount: 2, growthState: "age", maxGrowth: 3 },
    "minecraft:sweet_berry_bush": { drop: "minecraft:sweet_berries", dropCount: 2, growthState: "growth", maxGrowth: 3 },
    "minecraft:pumpkin": { drop: "minecraft:pumpkin", dropCount: 1, growthState: null },
    "minecraft:melon_block": { drop: "minecraft:melon_slice", dropCount: 4, growthState: null },
    "minecraft:cocoa": { drop: "minecraft:cocoa_beans", dropCount: 2, growthState: "age", maxGrowth: 2 },

    // Every leaf block in the game (always ready; drops the leaf block itself).
    "minecraft:oak_leaves": { drop: "minecraft:oak_leaves", dropCount: 1, growthState: null },
    "minecraft:spruce_leaves": { drop: "minecraft:spruce_leaves", dropCount: 1, growthState: null },
    "minecraft:birch_leaves": { drop: "minecraft:birch_leaves", dropCount: 1, growthState: null },
    "minecraft:jungle_leaves": { drop: "minecraft:jungle_leaves", dropCount: 1, growthState: null },
    "minecraft:acacia_leaves": { drop: "minecraft:acacia_leaves", dropCount: 1, growthState: null },
    "minecraft:dark_oak_leaves": { drop: "minecraft:dark_oak_leaves", dropCount: 1, growthState: null },
    "minecraft:mangrove_leaves": { drop: "minecraft:mangrove_leaves", dropCount: 1, growthState: null },
    "minecraft:cherry_leaves": { drop: "minecraft:cherry_leaves", dropCount: 1, growthState: null },
    "minecraft:pale_oak_leaves": { drop: "minecraft:pale_oak_leaves", dropCount: 1, growthState: null },
    "minecraft:azalea_leaves": { drop: "minecraft:azalea_leaves", dropCount: 1, growthState: null },
    "minecraft:flowering_azalea_leaves": { drop: "minecraft:flowering_azalea_leaves", dropCount: 1, growthState: null },
    "minecraft:red_poplar_leaves": { drop: "minecraft:red_poplar_leaves", dropCount: 1, growthState: null },
    "minecraft:orange_poplar_leaves": { drop: "minecraft:orange_poplar_leaves", dropCount: 1, growthState: null },
    "minecraft:yellow_poplar_leaves": { drop: "minecraft:yellow_poplar_leaves", dropCount: 1, growthState: null }
};
