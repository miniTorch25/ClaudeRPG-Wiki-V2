// Soft/diggable blocks a Vein-enabled Shovel can chain-dig.
export const SHOVEL_VEIN_BLOCKS = {
    "minecraft:dirt": { drop: "minecraft:dirt", dropCount: 1 },
    "minecraft:grass_block": { drop: "minecraft:dirt", dropCount: 1 },
    "minecraft:podzol": { drop: "minecraft:podzol", dropCount: 1 },
    "minecraft:mycelium": { drop: "minecraft:dirt", dropCount: 1 },
    "minecraft:sand": { drop: "minecraft:sand", dropCount: 1 },
    "minecraft:red_sand": { drop: "minecraft:red_sand", dropCount: 1 },
    "minecraft:gravel": { drop: "minecraft:gravel", dropCount: 1 },
    "minecraft:clay": { drop: "minecraft:clay_ball", dropCount: 4 },
    "minecraft:soul_sand": { drop: "minecraft:soul_sand", dropCount: 1 },
    "minecraft:soul_soil": { drop: "minecraft:soul_soil", dropCount: 1 },
    "minecraft:mud": { drop: "minecraft:mud", dropCount: 1 },
    "minecraft:snow_block": { drop: "minecraft:snow_block", dropCount: 1 }
};
