import { HOE_VEIN_BLOCKS } from "./hoe.js";

// Blocks a Vein-enabled Shears can chain-cut: every leaf block (reuses the
// Hoe list so both stay in sync). With Shears in hand the vanilla loot table
// drops the leaf block itself.
export const SHEARS_VEIN_BLOCKS = Object.fromEntries(
    Object.entries(HOE_VEIN_BLOCKS).filter(([id]) => id.endsWith("_leaves"))
);
