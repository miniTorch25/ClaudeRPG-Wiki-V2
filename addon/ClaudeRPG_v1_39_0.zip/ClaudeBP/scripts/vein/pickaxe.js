import { XP_CONFIG } from "../config/xp_config.js";

// Pickaxe Vein reuses the ore/block list already defined in xp_config.js
// (only "block" type entries that also define a drop are eligible) - no
// need to duplicate the ore list in a second place.
export const PICKAXE_VEIN_BLOCKS = Object.fromEntries(
    Object.entries(XP_CONFIG).filter(([, config]) => config.type === "block" && config.drop)
);
