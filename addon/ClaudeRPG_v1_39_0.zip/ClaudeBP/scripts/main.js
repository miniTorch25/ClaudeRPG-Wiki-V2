// ClaudeRPG bootstrap — intentionally small.
// Core event ownership lives in core/event_router.js and recurring jobs live in
// core/scheduler.js. Feature modules expose handlers instead of subscribing to
// the same world events themselves.
import { registerEventRouter, registerScheduledJobs } from "./core/event_router.js";
import { RuneManager } from "./rune/rune_manager.js";
import { KillManager } from "./managers/kill_manager.js";
import { MobXpManager } from "./managers/mob_xp.js";
import { AugmentManager } from "./systems/augment.js";
import { ChorusEffects } from "./systems/chorus_effects.js";
import { GemAbility } from "./systems/gem_ability.js";
import { ItemStack } from "@minecraft/server";
import { ProgressionManager } from "./managers/progression_manager.js";
import { MasteryManager } from "./managers/mastery_manager.js";
import { MOB_SCALING } from "./config/progression_config.js";
import { EvolutionManager } from "./managers/evolution_manager.js";
import { SpecialMobManager } from "./managers/special_mob_manager.js";
import { AchievementManager } from "./systems/achievement_manager.js";
import { ToastManager } from "./systems/toast_manager.js";
import { ToastCommand } from "./systems/toast_command.js";
import { GuideQuest } from "./systems/guide_quest.js";
import { SculkPotion } from "./systems/sculk_potion.js";
import { registerCombatAchievementHooks, registerWorkAchievementHooks, registerMiscAchievementHooks, onKill as achievementOnKill } from "./systems/achievement_hooks.js";

import { startRuneItemScanner } from "./rune/rune_item.js";
import { startRuneEngine } from "./rune/rune_effects.js";
import { Logger } from "./core/logger.js";

function guard(label, fn) { Logger.guard(label, fn); }

// KillManager remains the sole owner of entityDie. Other systems register
// listeners through it rather than subscribing to entityDie independently.
guard("kill pipeline", () => {
    MobXpManager.register();
    SpecialMobManager.register();
    // Achievements read the victim's Evolution tier, so they must also run before EvolutionManager.onKill.
    KillManager.addListener((killEvent) => achievementOnKill(killEvent));
    // Must run before EvolutionManager.onKill (which clears the tier cache): Awakened Creeper death blast.
    KillManager.addListener((killEvent) => SpecialMobManager.onKill(killEvent));
    KillManager.addListener((killEvent) => {
        if (!killEvent.isPlayerKill || killEvent.isPlayerVictim) return;
        AugmentManager.applyScavenging({ deadEntity: killEvent.victim, damageSource: killEvent.damageSource });
    });
    KillManager.addListener((killEvent) => {
        if (!killEvent.isPlayerKill || killEvent.isPlayerVictim) return;
        ProgressionManager.rollBonusDrop(killEvent.killer, killEvent.victim);
        MasteryManager.onKill(killEvent);
        EvolutionManager.onKill(killEvent);
    });
    KillManager.addListener((killEvent) => {
        if (!["minecraft:ender_dragon", "minecraft:wither", "minecraft:warden"].includes(killEvent.victim?.typeId)) return;
        let dimension, location;
        try {
            dimension = killEvent.victim.dimension;
            location  = killEvent.victim.location;
        } catch (_) {
            // Entity already invalid (removed) — fall back to the killer's position
            const fallback = killEvent.killer ?? killEvent.damageSource?.damagingEntity;
            if (!fallback?.isValid) return;
            dimension = fallback.dimension;
            location  = fallback.location;
        }
        if (ProgressionManager.getAscension() < MOB_SCALING.BOSS_GEM_MIN_ASCENSION) return;   // Ascension 2+ only
        const count = Math.floor(Math.random() * 7) + 1;
        for (let i = 0; i < count; i++) dimension.spawnItem(new ItemStack("crpg:uncarved_gem", 1), location);
    });
    RuneManager.registerKillHooks();
    KillManager.register();
});


// Chorus (armor element set effects) — hooks into the damage pipeline via EventBus.
guard("chorus effects", () => ChorusEffects.register());
guard("gem abilities", () => GemAbility.register());

// Specialized managers still own their unique event channels.
guard("core event router", () => registerEventRouter());
guard("core scheduler", () => registerScheduledJobs());

// Achievements: per-player counters, unlock notifications and periodic save (hooks call AchievementManager.add/max).
guard("achievements", () => AchievementManager.register());
guard("toast", () => { ToastManager.register(); ToastCommand.register(); });
guard("sculk potion", () => SculkPotion.register());
guard("guide quest", () => GuideQuest.register());
guard("achievement hooks", () => registerCombatAchievementHooks());
guard("achievement work hooks", () => registerWorkAchievementHooks());
guard("achievement misc hooks", () => registerMiscAchievementHooks());

// Rune items: roll the rune inside any Rune item that has none yet (creative menu, /give, loot).
guard("rune item scanner", () => startRuneItemScanner());
guard("rune engine", () => startRuneEngine());
